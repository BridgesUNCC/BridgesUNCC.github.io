from bridges.bridges import *
from bridges.color import *
from bridges.color_grid import *
from bridges.data_src_dependent.data_source import *
import math
import re

def split_lyrics(lyrics):
    lyrics = re.sub('[\(\[].*?[\)\]]', '', lyrics)
    lyrics = lyrics.strip()
    lyrics_split = lyrics.split()
    print(lyrics_split)


    for i in range(len(lyrics_split)):
        lyrics_split[i] = lyrics_split[i].replace("\\W+$", "")
        lyrics_split[i] = lyrics_split[i].replace("^\\W+", "")
        lyrics_split[i] = lyrics_split[i].strip()

    return lyrics_split


def main():
    # Init a Bridges Connection with your credentials
    bridges = Bridges(207, "BRIDGES_USER_ID", "BRIDGES_API_KEY")

    # Set assignment details
    bridges.set_title("Song Grids.")
    bridges.set_description("Visualize lyrics patterns as an image.")

    so = get_song("Delicate", "Taylor Swift")
    song = so.lyrics
    
    lyrics = split_lyrics(song)

    if len(lyrics) > 480:
        word_count = 480
    else:
        word_count = len(lyrics)

    grid = ColorGrid(word_count, word_count)

    match_color = Color(0,0,0,1)
    default_color = Color(255,255,255,1)

    for i in range(word_count):
        for j in range(word_count):
            if lyrics[i].lower() != lyrics[j].lower():
                grid.set(i,j,match_color)
            else:
                grid.set(i,j,default_color)

    bridges.set_title("Song Grid")
    bridges.set_data_structure(grid)
    bridges.visualize()

if __name__ == '__main__':
    main()

