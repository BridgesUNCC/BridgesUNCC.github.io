#include "Bridges.h"
#include "DataSource.h"
#include "Array.h"
#include "SLelement.h"


using namespace bridges;

int main() {

  //create the Bridges object, set credentials
  Bridges bridges(1, "BRIDGES_USER_ID", "BRIDGES_API_KEY");

  bridges.setTitle("List IMDB");

  DataSource ds;
  std::vector< ActorMovieIMDB > am_list = ds.getActorMovieIMDBData();

  //building linked list
  SLelement<ActorMovieIMDB>* head = nullptr;

  for (auto im : am_list) {
    SLelement<ActorMovieIMDB>* am_node = new SLelement<ActorMovieIMDB> (im,
        im.getActor() + " - " + im.getMovie());
    am_node->setNext(head);
    head = am_node;
  }

  // tell Bridges what data structure to visualize
  bridges.setDataStructure(head);

  // visualize the list
  bridges.visualize();

  //free memory
  while (head != nullptr) {
    auto next = head->getNext();
    delete head;
    head = next;
  }

  return 0;
}
