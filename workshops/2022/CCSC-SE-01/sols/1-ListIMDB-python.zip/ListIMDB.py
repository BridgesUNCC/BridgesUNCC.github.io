from bridges import *

def main():
    # Create the Bridges object, set the user credentials
    bridges = Bridges(201, "BRIDGES_USER_ID", "BRIDGES_API_KEY")

    bridges.set_title("List IMDB")
    bridges.set_description("Create a linked list of elements that hold pairs of (Actor, Movie) data")

    data = get_actor_movie_imdb_data()

    # Create Linked list start element
    head = None

    # Populate the list of elements with Actor/Movie pairs
    for im in data:
        head = SLelement(e=im, label=str(im.actor + " - " + im.movie), next=head)
    # Tell Bridges what data structure to visualize
    bridges.set_data_structure(head)

    # Visualize the linked list
    bridges.visualize()

if __name__ == '__main__':
    main()
