
#include <string>
#include "Bridges.h"
#include "DataSource.h"
#include "data_src/EarthquakeUSGS.h"
#include "BSTElement.h"

using namespace std;
using namespace bridges;
using namespace bridges::dataset;

BSTElement<float, EarthquakeUSGS> *insert (BSTElement<float, 
	EarthquakeUSGS> *rt, BSTElement<float, EarthquakeUSGS> *new_el);

void styleLargest(BSTElement<float, EarthquakeUSGS> *rt);
void styleQuakes(BSTElement<float, EarthquakeUSGS> *rt);

int max_quakes = 700;
int count23 = 0;

int main(int argc, char **argv) {
	// create Bridges object
	// command line args provide credentials and server to test on
	Bridges bridges (137, "BRIDGES_USER_ID", "BRIDGES_API_KEY");

	// set title, description
	bridges.setTitle("A Binary Search Tree Example with Earthquake Data");
	bridges.setDescription("This example illustrates retrieving USGS earthquake data records and inserted into a binary search tree. Attributes of the quake are displayed at each node.");

	// get earthquake data
	DataSource *ds = new DataSource;
	vector<EarthquakeUSGS> eq_list = ds->getEarthquakeUSGSData(max_quakes);

	// create the binary tree root
	BSTElement<float, EarthquakeUSGS> *root = nullptr;

	// insert quake records into the tree
	for (int k = 0; k < max_quakes; k++) {
		EarthquakeUSGS eq = eq_list[k];
		if (eq.getMagnitude() > 2.) {
			if (eq.getMagnitude() < 3. && count23 > 25)
				continue;
			BSTElement<float, EarthquakeUSGS> *bst_node = 
					new BSTElement<float, EarthquakeUSGS>(eq.getMagnitude(), eq);
			bst_node->setLabel(eq.getTitle() + "\nLat/Long: ( " +
					to_string(eq.getLatit()) + "," + to_string(eq.getLongit()) + 
					" )\n" + eq.getDateStr());
			root = insert (root, bst_node);
			if (eq.getMagnitude() < 3.)
				count23++;
		}
	}
	root->setColor("red");
	root->setSize (30.);

	styleLargest(root);
	styleQuakes(root);

	// visualize the binary search tree
	bridges.setDataStructure(root);
	bridges.visualize();

	return 0;
}

// inserts a record into the tree
BSTElement<float, EarthquakeUSGS> *insert (
		BSTElement<float, EarthquakeUSGS> *rt,
		BSTElement<float, EarthquakeUSGS> *new_el) {
	if (rt == nullptr)
		return new_el;
	else if (new_el->getKey() < rt->getKey())
		rt->setLeft(insert(rt->getLeft(), new_el));
	else
		rt->setRight(insert(rt->getRight(), new_el));

	return rt;
}

void styleQuakes (BSTElement<float, EarthquakeUSGS>* rt) {
	if (rt) {
		float magn = rt->getValue().getMagnitude();
		rt->setSize(30.);
		if (magn < 3.) {
			rt->setColor("blue");
			rt->setSize(20.);
		}
		else if (magn < 4.) {
			rt->setColor("green");
			rt->setSize(30.);
		}
		else if (magn < 5.) {
			rt->setColor("yellow");
			rt->setSize(40.);
		}
		else {
			rt->setColor("red");
			rt->setSize (49.);
		}
		styleQuakes(rt->getLeft());
		styleQuakes(rt->getRight());
	}
}
void styleLargest(BSTElement<float, EarthquakeUSGS>* rt) {
	while (rt) {
		if (!rt->getRight())  {
			// largest reached
			rt->setSize (30.);
			rt->setColor("orange");
		}
		rt = rt->getRight();
	}
}
