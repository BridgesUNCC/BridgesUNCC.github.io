import java.util.List;

// Import Bridges and relevant data source
import bridges.connect.Bridges;
import bridges.base.SLelement;
import bridges.data_src_dependent.ActorMovieIMDB;
import bridges.connect.DataSource;

// This example illustrates how to access the IMDB dataset of actors and movies
//
public class ListIMDB {

  public static void main(String[] args) throws Exception {

    // Initialize a Bridges connection with your credentials
    Bridges bridges = new Bridges(1, "BRIDGES_USER_ID", "BRIDGES_API_KEY");

    //   Set an assignment title
    bridges.setTitle("ListIMDB Example");
    bridges.setDescription("Create a linked list of elements that hold pairs of (Actor, Movie) data");


    //  get the data source object
    DataSource ds = bridges.getDataSource();

    //   Get a List of ActorMovieIMDB objects from Bridges - there are 1814 pairs
    List<ActorMovieIMDB> mylist = ds.getActorMovieIMDBData(1814);

    //   Set up a prev and head element
    SLelement<ActorMovieIMDB> prev = new SLelement<ActorMovieIMDB>();
    SLelement<ActorMovieIMDB> head = new SLelement<ActorMovieIMDB>();

    //  Read each actor movie pair and set up a new SLelement (singly linked
    //  list element)  for each; create a linked list
    for (int i = 0; i < mylist.size(); i++) {

      //   Create each new SLelement
      SLelement<ActorMovieIMDB> element = new SLelement<ActorMovieIMDB>();

      //   Set the element label equal to 'Actor - Movie' for each pair.
      //   these will be accessible through mouse over in the visualization
      element.setLabel(mylist.get(i).getActor() + " - " + mylist.get(i).getMovie());

      //   Add 'next' pointer where appropriate
      if (i > 0) {
        prev.setNext(element);
      }
      else {
        //   Set the head pointer
        head = element;
      }
      //   Update the prev pointer
      prev = element;
    }

    //   Pass the head of the list to Bridges
    bridges.setDataStructure(head);

    //   Visualize the list
    bridges.visualize();
  }
}
