#ifndef ALLTYPES_H
#define ALLTYPES_H

namespace bridges{
  class DataSource;
}

#endif
