
import bridges.connect.Bridges;
import bridges.data_src_dependent.Tweet;
import bridges.base.BinTreeElement;


public class bintree {
	public static void main(String[] args) throws Exception{
    	
		Bridges.setDebugFlag(true);
   					//create the Bridges object
		Bridges bridges = new Bridges(8, "kalpathi60", "486749122386");

		bridges.setTitle("Binary Tree Example");

   					//create  an   tree
		BinTreeElement<String> t0 = 
			new BinTreeElement<String>("Hello");
		BinTreeElement<String> t2 = 
			new BinTreeElement<String>("This");
		BinTreeElement<String> t3 = 
			new BinTreeElement<String>("is");
		BinTreeElement<String> t4 = 
			new BinTreeElement<String>("a");
		BinTreeElement<String> t5 = 
			new BinTreeElement<String>("generic");
		BinTreeElement<String> t6 = 
			new BinTreeElement<String>("BinTree");

					// put in the balance factors - done manually  here 
					// for illustration, but in a real project, the user will
					// implement this as part of the insert/delete
					// operations on the tree to maintain a balanced tree

		t0.setLabel("10");
		t2.setLabel("20");
		t3.setLabel("30");
		t4.setLabel("40");
		t5.setLabel("50");
		t6.setLabel("60");


		t0.setLeft(t2);
		t0.setRight(t3);
		t2.setLeft(t4);
		t2.setRight(t5);
		t3.setRight(t6);

									// set some attributes
		t0.getVisualizer().setColor("cyan");
		t0.getVisualizer().setOpacity(0.4f);

                                  //Print the JSON to console
//		bridges.getVisualizer().setVisualizeJSON(true);
             					//set visualizer type
		bridges.setDataStructure(t0);
        						// visualize the tree
		bridges.visualize();
    }
}
