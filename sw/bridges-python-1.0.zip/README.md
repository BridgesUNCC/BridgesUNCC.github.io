# bridges-python

This is the Python implementation of the BRIDGES API

Authors: Matthew Mcquaigue, David Burlinson, Kalpathi Subramanian

Date: June 2018
