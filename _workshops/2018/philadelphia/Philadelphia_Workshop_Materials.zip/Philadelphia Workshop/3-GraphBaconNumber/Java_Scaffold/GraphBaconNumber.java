
import java.util.HashMap;
import java.util.Map.Entry;
import java.lang.String;
import java.util.List;

import bridges.connect.Bridges;
import bridges.base.SLelement;
import bridges.base.Element;
import bridges.base.Edge;
import bridges.base.GraphAdjList;
import bridges.base.GraphAdjListSimple;
import bridges.data_src_dependent.ActorMovieIMDB;

//  This class implements computing the Bacon Number of an actor.
//  The Bacon number of an actor or actress is the number of degrees of
//  separation (see Six degrees of separation) they have from actor Kevin
//  Bacon, as defined by the game known as Six Degrees of Kevin Bacon.
//  It applies the Erdős number concept to the movie industry.
//
//  Source : Wikipedia

public class GraphBaconNumber {
  public static void main(String[] args) throws Exception {

    // Initialize BRIDGES with your credentials
    Bridges bridges = new Bridges(3, "YOUR_USER_ID", "YOUR_API_KEY");

    // set title for visualization
    bridges.setTitle("Bacon Number: IMDB Actor-Movie Data");

    // use an adjacency list based graph
    GraphAdjListSimple<String> gr = new GraphAdjListSimple<>();

    // build the actor-movie graph
    buildActorMovieGraph(gr, bridges);

    //set the data structure handle, and visualize the input graph
    bridges.setDataStructure(gr);
    bridges.visualize();

    //    getBaconNumber(gr, "Kevin_Bacon_(I)", "Cate_Blanchett");
    //    bridges.setDataStructure(gr);
    //    bridges.visualize();
  }

  public static void buildActorMovieGraph (GraphAdjListSimple<String> gr,
      Bridges bridges) {

    // get the actor movie IMDB data through the BRIDGES API
    try {
      List<ActorMovieIMDB> actor_list =
        bridges.getActorMovieIMDBData ("ActorMovie", 1814);
      String actor, movie;
      for (int k = 0; k < actor_list.size(); k++) {

        // get the actor and movie names
        actor = actor_list.get(k).getActor();
        movie = actor_list.get(k).getMovie();

        // our graph needs to have a unique set of actors and movies;
        // so create the actor and movie vertices only if they dont already
        // exist; use an STL map to check for that

        // first get the graph's vertex list
        HashMap<String, Element<String>> vertices = gr.getVertices();

        // add actor if it does not exist
        if (!vertices.containsKey(actor))
          gr.addVertex(actor, actor);

        // add movie if it does not exist
        if (!vertices.containsKey(movie))
          gr.addVertex(movie, movie);

        // create the edge -- assumes no duplicate edges
        // undirected graph, edges go both ways
        gr.addEdge(actor, movie, 1);
        gr.addEdge(movie, actor, 1);

        // TO DO : Highlight "Cate_Blanchett" node and the movie nodes
        // she is connected to  in "orange" and do the same for
        //  "Kevin_Bacon_(I)" in "green"
        //  To set node attributes, you can do something like
        //  gr.getVisualizer(key-val).setColor(color-name)
        //  To set link attributes, you can do something like
        //  gr.getLinkVisualizer(src-key-val, dest-key-val).setColor(color-name)
        //  similarly for  other attributes (see the docs  on LinkVisualizer
        //  and ElementVisualizer classes)
        // specify colors by their names, "red", for example
      }
    }
    catch (Exception exc) {
    }
  }
  //
  // Computes the Bacon Number of a an actor (#links that takes you from the
  // source actor to the destination actor.
  //
  public static int getBaconNumber (
    GraphAdjListSimple<String> gr,  // input graph
    String src_actor,         // source actor
    String dest_actor) {      // destination actor

    // TODO: Perform a BFS traversal of the graph from src_actor. You will
    // to maintain distance information (basically the number of links from
    // the source actor until the destination node is reached.  Keep
    // parent information as the traversal progresses; once the destination
    // node is found, you will use the parent pointers to follow them to
    // the source node (source node's parent is null).

    // TODO: Highlight all edges and vertices on the shortest path
    // between src_actor and dest_actor; Make the nodes in the path bigger,
    // and the links thicker so that it stands out.

    return 0;
  }
} // class BaconNumber
