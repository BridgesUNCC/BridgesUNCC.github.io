#include "Bridges.h"
#include "DataSource.h"
#include "BinTreeElement.h"
#include "SLelement.h"
#include "ColorGrid.h"
#include <sstream>

using namespace bridges;


#include "MyHeap.hpp"


//Tokenize a string into individual word, removing punctuation at the
//end of words
std::vector<std::string> lyrics_tokenize(const std::string& lyrics) {
  std::vector<std::string> ret;

  std::stringstream ss (lyrics);

  std::string line;

  //For each line
  while (getline(ss, line, '\n')) {
    //Skip all like starting with [
    if (line[0] == '[')
      continue;

    std::stringstream ssline (line);
    //For all words
    while (ssline) {
      std::string word;
      ssline >> word;
      if (ssline) {

        //remove punctuation at the end of word
        while (word.length() > 0
               && std::ispunct(word[word.length() - 1])) {
          word.pop_back();
        }
        ret.push_back(word);
      }
    }
  }

  return ret;
}

int main() {

  //create the Bridges object, set credentials
  Bridges::initialize(108, "YOUR_USER_ID", "YOUR_API_KEY");

  Bridges::setTitle("PQ Book");

  //Get Earthquake data
  std::vector<Shakespeare> s = DataSource::getShakespeareData("poems");

  Shakespeare po1 = s[0];
  //print lyrics
  std::cout << po1.getText() << std::endl;

  //tokenize lyrics
  auto words = lyrics_tokenize(po1.getText());

  //print lyrics one word at a time
  for (auto w : words) {
    std::cout << w << std::endl;
  }

  //build count
  std::unordered_map<std::string, int> counts;
  for (auto w : words) {
    auto it = counts.find(w);
    if (it == counts.end()) {
      std::pair<std::string, int> p = {w, 1};
      counts.insert(p);
    }
    else {
      it->second++;
    }
  }

  //checking wheter counts are correct.
  for (auto it : counts) {
    std::cout << it.first << " " << it.second << std::endl;
  }

  // building heap
  MyHeap<int, std::string> mh;
  for (auto it : counts) {
    mh.insert(it.second, it.first);
  }

  mh.updateLabels();

  //tell Bridges what data structure to visualize
  Bridges::setDataStructure(mh.root);


  // visualize the grid
  Bridges::visualize();

  //check correctness
  while (mh.count() > 10) {
    auto it = mh.pop();
    std::cout << it.first << " " << it.second << std::endl;
  }

  mh.updateLabels();


  // visualize the grid
  Bridges::visualize();

  return 0;
}
