from bridges import *
import random

def main():
    #create the Bridges object, set credentials
    bridges = Bridges(206, "BRIDGES_USER_ID", "BRIDGES_API_KEY")
    bridges.set_title("Square Fill Grid")
    bridges.set_description("Fill the image with random colored squares.")

    rows = 100
    columns = 100

    totalPixels = rows * columns
    filledPixels = 0

    free = 0

    grid = ColorGrid(rows, columns, Color(255, 255, 255, free))

    while (filledPixels < totalPixels):
        # TODO:
        # Pick a random point on the grid and check
        #  if it has been filled yet.
        #
        # If not, set it to a random color and continue to the next step
        # else, generate a new point until you find a free one..

        collision = False
        layers = 1

        # begin adding layers
        while (not collision):
            # TODO: 
            # store locations of the bottomLeft and topRight of current layer
            # Example:
            #    int bottomLeftX = originX - layers;
            #    int bottomLeftY = originY - layers;
            #    int topRightX = originX + layers;
            #    int topRightY = originY + layers;

            # TODO:
            # Check if the corners are out of bounds,
            # if so, break and start a new square.
            #

            sideLength = 1 + layers * 2

            # collision check pass
            for i in range(sideLength):
                # TODO:
			    # Check the each side of the layer for collision with 
			    # another square, if there is, escape the loops and
			    # start a new square

            # if collision on current layer, don't draw the layer
            if (collision):
                continue

            # else generate a new color and fill the layer
            # TODO:
		    # Generate a new color to be used for this layer

            for i in range(sideLength):
                # TODO:
                # Go back over the layer and fill in the 
                # points with your generated color

            filledPixels += sideLength * 4 - 4
            layers += 1

    bridges.set_data_structure(grid)
    bridges.visualize()

if __name__ == '__main__':
    main()
