#include <iostream>
#include "Bridges.h"
#include "ColorGrid.h"
#include "Color.h"
#include "ctime"

using namespace bridges;

//
// Uses color grid to draw filled squares
//
int main() {
  Bridges bridges(106, "USER_NAME", "API_KEY");

  int rows = 100;
  int columns = 100;

  int totalPixels = rows * columns;
  int filledPixels = 0;

  // initializes a value to check if a point is free or not
  int free = 0;

  ColorGrid grid(rows, columns, Color(255, 255, 255, free));
  bridges.setTitle("Square Fill Grid");
  bridges.setDescription("Fill the image with random colored squares.");

  // fill grid
  while (filledPixels < totalPixels) {
    /* TODO:
    * Pick a random point on the grid and check
    *  if it has been filled yet.
    *
    * If not, set it to a random color and continue to the next step
    * else, generate a new point until you find a free one..
    */
    bool collision = false;
    int layers = 1;

    // begin adding layers
    while (!collision) {
      /* TODO:
      * store locations of the bottomLeft and topRight of current layer
      * Example:
      int bottomLeftX = originX - layers;
      int bottomLeftY = originY - layers;
      int topRightX = originX + layers;
      int topRightY = originY + layers;
      */

      /* TODO:
       * Check if the corners are out of bounds,
       * if so, break and start a new square.
       */

      int sideLength = 1 + layers * 2;

      // collision check pass
      for (int i = 0; i < sideLength; ++i) {
        /* TODO:
        * Check the each side of the layer for collision with
        * another square, if there is, escape the loops and
        * start a new square
        */
      }

      // if collision on current layer, don't draw the layer
      if (collision)
        continue;


      /* TODO:
       * Generate a new color to be used for this layer
       */

      for (int i = 0; i < sideLength; ++i) {
        /* TODO:
        * Go back over the layer and fill in the
        * points with your generated color
        */
      }

      filledPixels += sideLength * 4 - 4;
      layers++;
    }

  }

  bridges.setDataStructure(&grid);
  bridges.visualize();

  return 0;
}
