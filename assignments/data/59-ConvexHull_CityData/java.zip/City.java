public class City {
    String name;
    String state;
    double latitude;
    double longitude;

    public City(String name, String state, double longitude, double latitude) {
        this.name = name;
        this.state = state;
        this.latitude = latitude;
        this.longitude = longitude;
    }

    public City(String name, double longitude, double latitude){
        this.name = name;
        this.latitude = latitude;
        this.longitude = longitude;
    }

    public City(){
        this.name = null;
        this.state = null;
        this.latitude = 0;
        this.longitude = 0;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getState() { return state; }

    public void setState() { this.state = state; }

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }
}
