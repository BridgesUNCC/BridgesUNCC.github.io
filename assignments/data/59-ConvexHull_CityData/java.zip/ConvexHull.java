import bridges.base.Circle;
import bridges.base.Polyline;
import bridges.base.SymbolCollection;
import bridges.connect.Bridges;
import bridges.connect.DataSource;
import bridges.data_src_dependent.City;
import bridges.validation.RateLimitException;

import java.awt.geom.Point2D;
import java.io.IOException;
import java.util.*;
import java.util.List;

public class ConvexHull {

    public static void main(String[] args) throws RateLimitException, IOException {
        // create Bridges object
        // command line args provide credentials and server to test on
        Bridges bridges = new Bridges(59, "USERNAME", "API KEY");
        bridges.setTitle("Convex Hull of a set of US Cities");
	bridges.setDescription("Determine the Convex Hull of a set of locations representing US Cities, using a brute-force approach.");

        ConvHull cv = new ConvHull();

		// get US city locations
		DataSource ds = bridges.getDataSource();
        getInputPoints(ds, cv);

		// get bounding box of the city locations
        float[] bbox = cv.getBoundingBox();

        // run the brute force convex hull algorithm
        Vector<Line> cvLines = cv.getConvexHullBruteForce();

        // draw the input points and lines that make up the convex hull
        SymbolCollection cvh = drawConvexHull(cv, cvLines);

       
        cvh.setViewport(bbox[0], bbox[2], bbox[1], bbox[3]);

        bridges.setDataStructure(cvh);
		bridges.visualize();
    }

	// gets the US cities data from the server
    static void getInputPoints(DataSource ds, ConvHull cv) throws IOException {

		// get US city data - see the tutorial on how to do this at
    	// http://bridgesuncc.github.io/tutorials/Data_USCities.html
    	//
    	// Use the provided helper classes in primitives.h to input the points
    	// into the ConvexHull class. Those will also be used for holding the drawing
    	// primtives.

    }

    static SymbolCollection drawConvexHull(ConvHull cv, Vector<Line> cvLines){
        SymbolCollection cvh = new SymbolCollection();

		// This method draws the convex hull of the input points. The points
    	// are marked and in this data set represent locations of cities
    	// The lines bound the points and represent the convex hull of the city
    	// locations.  We use the SymbolCollection and lines and points to 
    	// to create the visualization. Use the Polyline to draw the lines and 
    	// Circle to draw the points

    	// draw the city locations first


    	// next draw the lines that make up the convex hull


    	// put both the points and lines into the SymbolCollection object
		return cvh;
    }
}
