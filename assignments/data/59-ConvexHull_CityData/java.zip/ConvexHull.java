import bridges.base.Circle;
import bridges.base.GraphAdjList;
import bridges.base.Polyline;
import bridges.base.SymbolCollection;
import bridges.connect.Bridges;
import bridges.validation.RateLimitException;

import java.awt.*;
import java.awt.geom.Point2D;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Scanner;
import java.util.Vector;


public class ConvexHull {

    
    public static void main(String[] args) throws IOException, RateLimitException {
        Bridges bridges = new Bridges(10, "USERNAME", "API KEY"); // CHANGE ASSIGNMENT # FOR EACH UNIQUE RUN
        bridges.setTitle("Convex Hull on USA Dataset");
        bridges.setDescription("Lab 9. Including Alaska and Hawaii");

        SymbolCollection sc;

        sc = constructGraph(false);
        bruteForce(sc);
        bridges.setDataStructure(sc);
        bridges.visualize();

        sc = constructGraph(true);
        bruteForce(sc);
        bridges.setDescription("Not including Alaska and Hawaii");
        bridges.setDataStructure(sc);
        bridges.visualize();
    }

    static SymbolCollection constructGraph(boolean continental) throws FileNotFoundException {
        /*
        Constructs graph using Circles as points
         */
	return null;
    }

    static void bruteForce(SymbolCollection sc){
        /*
        Checks if all points are to the 'left' side of the city1,city2 edge
        if so, draws line
         */
    }

    static boolean nonContinental(String city){
        /*
        Checks if city is Honolulu or Anchorage and returns the result

        @param city: City being checked
         */

	return false;
    }
}
