public class Line {
    double x0, y0, x1, y1;
    String label1, label2;

    boolean conv_hull = false, upper_hull = false, 
		lower_hull = false, dividing = false, extreme = false;

    Line(double xx0, double yy0, double xx1, double yy1){
        this.x0 = xx0; this.y0 = yy0; this.x1 = xx1; this.y1 = yy1;
    }
    Line(Point pt1, Point pt2){
        this.x0 = pt1.x; this.y0 = pt1.y; this.x1 = pt2.x; this.y1 = pt2.y;
    }
}
