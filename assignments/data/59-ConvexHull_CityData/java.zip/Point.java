public class Point {
    double x, y;
    String name;

    Point(double xx, double yy){
        this.x = xx;
        this.y = yy;
        name = "";
    }
    Point(double xx, double yy, String l){
        this.x = xx;
        this.y = yy;
        this.name = l;
    }

    public Point() {

    }

    static boolean comp(Point pt1, Point pt2){
        if (pt1.x < pt2.x) return true;
        else if (pt1.x == pt2.x) return pt1.y < pt2.y;
        else return false;
    }

    String getName(){ return name; }

    double getX(){ return x; }
    double getY(){ return y; }
}
