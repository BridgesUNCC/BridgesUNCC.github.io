import bridges.base.Polyline;

import java.util.*;

public class ConvHull {
    static int numQueriedPts = 0;
    private List<Point> cvPoints = new ArrayList<>(); // input points in 2D
    private Vector<Line> cvLines = new Vector<>(); // line segments making up the hull
    private float[] bbox = null;

	// TODO: Constructors, Setters/Getters, bounding box access
    ConvHull(){
    }

	
	public float[] getBoundingBox(){
        return bbox;
    }

    public Vector<Line> getConvexHullBruteForce(){
		// brute force algorithm  to compute the convex hull 
        // of a set of points

        // clear out the conv hull lines array


        // brute force algorithm  considers every pair of points as 
        // a potential convex hull segment and checks to see if all
        // remaining points are on one side of the line segment. If not,
        // it moves on to the next pair of points. 

        // the set of line segments that are part of the convex hull is
        // retained as a list of line segments in the object.

        // use the line equation from the pair of input points and
        // check the side of each of the remaining points

        // compute line equation coefficients, ax+by=c
        // float a = pt2.y - pt1.y;
        // float b = pt1.x - pt2.x;
        // float c = pt1.x*pt2.y - pt1.y*pt2.x;

        // then plug each point's coordinates into it

        // The sign of the result indicates which side the incoming 
        // point belongs with respect to the line segment

        return cvLines;
    }
};
