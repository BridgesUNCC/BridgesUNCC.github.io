//primitives.h:		defines line and point primitives

#ifndef PRIMITIVES_H
#define PRIMITIVES_H

struct Point {
	double x, y;
	string label;

	Point () {}
	Point (double xx, double yy) {
		x = xx; y = yy;
		label = "";
	}
	Point (double xx, double yy, string l) {
		x = xx; y = yy;
		label = l;
	}
	bool extreme=false, internal=false, upper_hull=false, lower_hull=false,
			dividing = false, queried = false;
		
					//comparison method for sorting
	static bool comp(Point pt1, Point pt2) {
		if (pt1.x < pt2.x)
			return true;
		else if (pt1.x == pt2.x)
			return pt1.y < pt2.y;
		else return false;
	}
};

struct Line {
		double x0, y0, x1, y1;
		string label1, label2;

		bool conv_hull=false, upper_hull=false, lower_hull=false,
				dividing = false, extreme = false;
		Line(double xx0, double yy0, double xx1, double yy1) {
			x0 = xx0; y0 = yy0; x1 = xx1; y1 = yy1;
		}
		Line (Point pt1, Point pt2) {
			x0 = pt1.x; y0 = pt1.y; x1 = pt2.x; y1 = pt2.y;
		}
};
#endif
