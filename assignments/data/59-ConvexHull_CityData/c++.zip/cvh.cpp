/**
 * Created by Kalpathi Subramanian, 1/10/22
 * krs@uncc.edu
 */

#include "Bridges.h"
#include "DataSource.h"
#include "data_src/City.h"
#include "SymbolCollection.h"
#include "GraphAdjList.h"
#include "Polyline.h"
#include "Circle.h"
#include "primitives.h"

#include "cvh.h"
#include <string>
#include <vector>

using namespace bridges;
using namespace std;

void getInputPoints (DataSource& ds,  ConvHull& cv);
SymbolCollection drawConvexHull (ConvHull& cv, vector<Line> cv_lines);

int main (int argc, char **argv) {

	// create Bridges object
	// command line args provide credentials and server to test on
	Bridges bridges (159, "BRIDGES_USER_ID", "BRIDGES_API_KEY");

	// set title
	bridges.setTitle("Convex Hull of a Set of US Cities.");
	bridges.setDescription("Determine the Convex Hull of a set of locations representing US Cities, using a brute-force approach.");

	// get Data Source object
	DataSource ds(&bridges);
	// get the US city data
	ConvHull cv;
	getInputPoints (ds, cv);


	// run the brute force convex hull algorithm
	vector<Line> cv_lines = cv.getConvexHull_BruteForce();

	// draw the input points and lines that make up the convex hull
	SymbolCollection cvh = drawConvexHull(cv, cv_lines);

	// set  description
	bridges.setDescription("Convex Hull Construction: Brute Force Algorithm");

	// set viewport (using bounding box of points)
	float *bbox = cv.getBoundingBox();
	cvh.setViewport (bbox[0], bbox[2], bbox[1], bbox[3]);

	// visualize
	bridges.setDataStructure(&cvh);
	bridges.visualize();
}

void getInputPoints (DataSource& ds, ConvHull& cv) {

	// get US city data - see the tutorial on how to do this at
	// http://bridgesuncc.github.io/tutorials/Data_USCities.html
	//
	// Use the provided helper classes in primitives.h to input the points
	// into the ConvexHull class. Those will also be used for holding the drawing
	// primtives.
}

SymbolCollection drawConvexHull (ConvHull& cv, vector<Line> cv_lines) {

	// This method draws the convex hull of the input points. The points
	// are marked and in this data set represent locations of cities
	// The lines bound the points and represent the convex hull of the city
	// locations.  We use the SymbolCollection and lines and points to 
	// to create the visualization. Use the Polyline to draw the lines and 
	// Circle to draw the points
	SymbolCollection sc;

	// draw the city locations first


	// next draw the lines that make up the convex hull


	// put both the points and lines into the SymbolCollection object and 
	// return
	return sc;
}


