/**
 * Created by Kalpathi Subramanian, 1/10/22
 * krs@uncc.edu
 */

#include "Bridges.h"
#include "SymbolCollection.h"
#include "GraphAdjList.h"
#include "Polyline.h"
#include "Circle.h"
#include "primitives.h"
#include "cvh.h"
#include <string>
#include <fstream>

using namespace bridges;
using namespace std;

void getInputPoints (ConvHull& cv, string data_file);
SymbolCollection drawConvexHull (ConvHull& cv, vector<Line> cv_lines);

int main (int argc, char **argv) {

	// create Bridges object
	// command line args provide credentials and server to test on
	Bridges bridges (159, "BRIDGES_USER_ID", "BRIDGES_API_KEY");

	// set title
	bridges.setTitle("Convex Hull of a Set of US Cities.");

	// get the US city data
	ConvHull cv;
	getInputPoints (cv, "../data/us_cities.txt");

	float *bbox = cv.getBoundingBox();

	// run the brute force convex hull algorithm
	vector<Line> cv_lines = cv.getConvexHull_BruteForce();

	// draw the input points and lines that make up the convex hull
	SymbolCollection cvh = drawConvexHull(cv, cv_lines);

	// set  description
	bridges.setDescription("Convex Hull Construction: Brute Force Algorithm");

	// set viewport (using bounding box of points)
	cvh.setViewport (bbox[0], bbox[2], bbox[1], bbox[3]);

	// visualize
	bridges.setDataStructure(&cvh);
	bridges.visualize();

	// run the divide/conquer convex hull algorithm
	cv_lines = cv.getConvexHull_DivideConquer();
		
	// draw the input points and lines that make up the convex hull
	cvh = drawConvexHull(cv, cv_lines);

	// set  description
	bridges.setDescription("Convex Hull Construction: Divide/Conquer Algorithm");
	// set viewport (using bounding box of points)
	cvh.setViewport (bbox[0], bbox[2], bbox[1], bbox[3]);
	// visualize
	bridges.setDataStructure(&cvh);
	bridges.visualize();
}

void getInputPoints (ConvHull& cv, string data_file) {

	// read the data file and get the city data into the 
	// the Convex Hull class as a list of points
	// Use the  helper classes in primitives.h  that represents lines and
	// points
}

SymbolCollection drawConvexHull (ConvHull& cv, vector<Line> cv_lines) {

	// This method draws the convex hull of the input points. The points
	// are marked and in this data set represent locations of cities
	// The lines bound the points and represent the convex hull of the city
	// locations.  We use the SymbolCollection and lines and points to 
	// to create the visualization. Use the Polyline to draw the lines and 
	// Circle to draw the points
	SymbolCollection cvh;

	// draw the city locations first


	// next draw the lines that make up the convex hull


	// put both the points and lines into the SymbolCollection object and 
	// return
	}

	return cvh;
}


