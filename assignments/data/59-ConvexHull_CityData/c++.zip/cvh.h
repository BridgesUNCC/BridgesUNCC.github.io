#include <vector>
#include "primitives.h"
#include <cmath>
#include <list>
#include <algorithm>

using namespace std;

#ifndef CVH_H

#define CVH_H

static int num_queried_pts = 0;

class ConvHull {

	private:
		list<Point> cv_points;	// input points in 2D
		vector<Line>  cv_lines;		// line segments making up the convex hull

		float *bbox = nullptr;

		enum HullType {UPPER, LOWER};

		/////////////////////////////////////////

	public:

		ConvHull() {
			// TODO: constructor
		}
		// getters/setters

		// public methods

		/////////////////////////////////////////
		float *getBoundingBox() {
			float  *bbox;

			// TODO: compute the bounding box of the input points 
			return bbox;
		}
		/////////////////////////////////////////
		vector<Line> getConvexHull_BruteForce() {
			vector<Line> lines;
			// brute force algorithm  to compute the convex hull 
			// of a set of points
				
			// clear out the conv hull lines array

			
			// brute force algorithm  considers every pair of points as 
			// a potential convex hull segment and checks to see if all
			// remaining points are on one side of the line segment. If not,
			// it moves on to the next pair of points. 

			// the set of line segments that are part of the convex hull is
			// retained as a list of line segments in the object.

			// use the line equation from the pair of input points and
			// check the side of each of the remaining points

			// compute line equation coefficients, ax+by=c
			// float a = pt2.y - pt1.y;
			// float b = pt1.x - pt2.x;
			// float c = pt1.x*pt2.y - pt1.y*pt2.x;

			// then plug each point's coordinates into it
     
            // The sign of the result indicates which side the incoming 
     		// point belongs with respect to the line segment

			return lines;
		}
		/////////////////////////////////////////
};
#endif
