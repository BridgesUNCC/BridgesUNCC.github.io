class Point:
    x = 0
    y = 0
    label = ""

    def __init__(self, xx=None, yy=None, name=None):
        self.x = 0
        self.y = 0
        self.name = ""
        if xx is not None and yy is not None:
            self.x = xx
            self.y = yy

        if name is not None:
            self.label = name


    def comp(self, pt1, pt2):
        if pt1.x < pt2.x:
            return True
        elif pt1.x == pt2.x:
            return pt1.y < pt2.y
        else: return False

    def get_x(self):
        return self.x


class Line:
    def __init__(self, xx0=None, yy0=None, xx1=None, yy1=None, pt1=None, pt2=None):
        self.x0 = 0
        self.y0 = 0
        self.x1 = 0
        self.y1 = 0
        self.label1 = 0
        self.label2 = 0
        if xx0 is not None and yy0 is not None and xx1 is not None and yy1 is not None:
            self.x0 = xx0
            self.y0 = yy0
            self.x1 = xx1
            self.y1 = yy1

        if pt1 is not None and pt2 is not None:
            self.x0 = pt1.x
            self.y0 = pt1.y
            self.x1 = pt2.x
            self.y1 = pt2.y


