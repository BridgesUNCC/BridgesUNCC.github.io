import math
import sys

from primitives import *

class conv_hull:
    def __init__(self):
        self.cv_points = []
        self.cv_lines = []
        self.bbox = []

        # shows if upper or lower hull, True = upper, False = lower
        # default set to upper
        self.cv_points.clear()
        self.cv_lines.clear()
        self.bbox = [0, 0, 0, 0]
        self.bbox[0] = self.bbox[1] = sys.maxsize
        self.bbox[2] = self.bbox[3] = - sys.maxsize


    #  TODO: define getters/setters for lines, points, adding points, bounding box operations


    def get_ConvexHull_BruteForce(self):
       # brute force algorithm  to compute the convex hull 
       # of a set of points
                
       # clear out the conv hull lines array

            
       # brute force algorithm  considers every pair of points as 
       # a potential convex hull segment and checks to see if all
       # remaining points are on one side of the line segment. If not,
       # it moves on to the next pair of points. 

       # the set of line segments that are part of the convex hull is
       # retained as a list of line segments in the object.

       # use the line equation from the pair of input points and
       # check the side of each of the remaining points

       # compute line equation coefficients, ax+by=c
       # float a = pt2.y - pt1.y;
       # float b = pt1.x - pt2.x;
       # float c = pt1.x*pt2.y - pt1.y*pt2.x;
       # then plug each point's coordinates into it

       # The sign of the result indicates which side the incoming point belongs with respect
       # to the line segment
       pass

    def get_bounding_box(self):
       pass


