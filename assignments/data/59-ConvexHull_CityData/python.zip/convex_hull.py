from bridges.bridges import *
from bridges.graph_adj_list import *
from bridges.element import *
from bridges.link_visualizer import *
from bridges.edge import *
from bridges.symbol_collection import *
from bridges.circle import *
from bridges.polyline import *
import math

city_coords = {}


def main():
    bridges = Bridges(10, "USERNAME", "API KEY")
    bridges.set_title("Convex Hull on USA dataset")

    sc = construct_graph(False, "./data/us_cities.txt")
    brute_force(sc)
    bridges.set_data_structure(sc)
    bridges.visualize()

    sc = construct_graph(True, "./data/us_cities.txt")
    brute_force(sc)
    bridges.set_description("Not including Alaska and Hawaii")
    bridges.set_data_structure(sc)
    bridges.visualize()


def construct_graph(continental, file):
    # Constructs graph using Circles as points
    


def brute_force(sc):
    # Check if all points are to the 'left' of city1,city2 edge
    # if true, draw hull line
    


def non_continental(city):
    # returns True if city == Honolulu or Anchorage
    

if __name__ == "__main__":
    main()
