from bridges.bridges import *
from bridges.graph_adj_list import *
from bridges.element import *
from bridges.link_visualizer import *
from bridges.edge import *
from bridges.symbol_collection import *
from bridges.circle import *
from bridges.polyline import *
from bridges.data_src_dependent import *
from primitives import *
from conv_hull import *
import math


def main():
    bridges = Bridges(259, "USERNAME", "API KEY")
    bridges.set_title("Convex Hull on USA dataset")

    # get us city data
    cv = conv_hull()
    getInputPoints(cv)


    # run the brute force convex hull algorithm
    cv_lines = cv.get_ConvexHull_BruteForce()

    # draw the input points and lines that make up the convex hull
    cvh = draw_Convex_Hull(cv, cv_lines)

    bridges.set_description("Convex Hull Construction: Brute Force Algorithm IN PYTHON")

    # set viewport
    #bbox = cv.get_bounding_box()
    #cvh.setviewport(bbox[0], bbox[2], bbox[1], bbox[3])

    # visualize
    bridges.set_data_structure(cvh)
    bridges.visualize()


def getInputPoints(cv):
    # TODO: get US city data - see the tutorial on how to do this at
    # http://bridgesuncc.github.io/tutorials/Data_USCities.html

    # Use the provided helper classes in primitives.h to input the points
    # into the ConvexHull class. Those will also be used for holding the drawing
    # primtives.
    pass



def draw_Convex_Hull(cv, cv_lines):
    sc = SymbolCollection()
    # TODO: This method draws the convex hull of the input points. The points
    # are marked and in this data set represent locations of cities
    # The lines bound the points and represent the convex hull of the city
    # locations.  We use the SymbolCollection and lines and points to 
    # to create the visualization. Use the Polyline to draw the lines and 
    # Circle to draw the points

    # draw the city locations first


    # next draw the lines that make up the convex hull
    # 

    # put both the points and lines into the SymbolCollection object and 
    # return

    return sc


if __name__ == '__main__':
    main()
