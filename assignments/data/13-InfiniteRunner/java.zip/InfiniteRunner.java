package infiniterunner;

import bridges.base.NamedColor;
import bridges.base.NamedSymbol;

import java.util.ArrayList;

public class InfiniteRunner extends LBGame {
	java.util.Random random = new java.util.Random(System.currentTimeMillis());
	
	ArrayList<Node> nodes;
	
	int points = 0;
	int lives = 3;
	
	NamedSymbol numberList[] = { NamedSymbol.zero, NamedSymbol.one, NamedSymbol.two, NamedSymbol.three, NamedSymbol.four, NamedSymbol.five, NamedSymbol.six, NamedSymbol.seven, NamedSymbol.eight, NamedSymbol.nine };

	public InfiniteRunner(int assid, String login, String apiKey) {
		super(assid, login, apiKey);
	}

	@Override
	public void initialize() {
	}
	
	private void draw() {
	}

	@Override
	public void process() {
	}
	
	public static void main(String args[]) {
		InfiniteRunner ir = new InfiniteRunner(0, "user", "pass");
		ir.setTitle("Infinite Runner");
		ir.start();
	}

}

// Represents a base object on the grid
abstract class Node {
	public Vector2 position;
	public NamedColor color;
	public NamedSymbol symbol;
	public NamedColor symbolColor;
	
	public Node(Vector2 position) {
		this.position = position;
	}
	
	abstract public void update(InfiniteRunner ss);
}