
import bridges.games.NonBlockingGame;
import bridges.base.NamedColor;
import bridges.base.NamedSymbol;

import java.util.ArrayList;

public class InfiniteRunner extends NonBlockingGame {

  static int rows = 24;
  static int cols = 24;

  public static void main(String args[]) {
    InfiniteRunner ir = new InfiniteRunner(13, "BRIDGES_USER_ID", "BRIDGES_API_KEY", cols, rows);
  }

  public InfiniteRunner(int assid, String login, String apiKey, int c, int r) {
    super(assid, login, apiKey, c, r);
    setTitle("Infinite Runner");
    setDescription("Press Q to restart, Up arrow to jump. Jump to avoid the bombs.");
    start();
  }

  public void gameLoop() {
    // TODO Set up the game grid with a player to the left
    // and a floor at the bottom

    // As the game updates objects will move towards the player
    // The player will be able to jump to avoid obstacles and
    // collect other objects
  }

  @Override
  public void initialize() {
    // TODO Set up the game grid with a player to the left
    // and a floor at the bottom
  }
}