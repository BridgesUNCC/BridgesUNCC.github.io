package STUDENT_PACKAGE;

import bridges.games.NonBlockingGame;
import bridges.base.NamedColor;
import bridges.base.NamedSymbol;

import java.util.ArrayList;

public class STUDENT_CLASS_NAME extends NonBlockingGame {

    // / the game map.
    int rows = 24;
    int cols = 24;

    java.util.Random random = new java.util.Random(System.currentTimeMillis());

    ArrayList<Node> nodes;

    int points = 0;
    int timer = 0;

    NamedSymbol numberList[] = {NamedSymbol.zero, NamedSymbol.one, NamedSymbol.two, NamedSymbol.three, NamedSymbol.four, NamedSymbol.five, NamedSymbol.six, NamedSymbol.seven, NamedSymbol.eight, NamedSymbol.nine};

    public static void main(String args[]) {
        STUDENT_CLASS_NAME ir = new STUDENT_CLASS_NAME(ASSIGNMENT_NUMBER, "Student_Username", "Profile_APIKey");
    }

    public STUDENT_CLASS_NAME(int assid, String login, String apiKey) {
        super(assid, login, apiKey);
        SetTitle("Infinite Runner");
        start();
    }

    public void GameLoop() {
        process();
    }
    
    @Override
    public void initialize() {

    }

    private void draw() {
 
    }

    // Returns state of the up key to the player class
    public boolean checkKeyUp() {
        return KeyUp();
    }

    public void process() {
        
    }
}

// Represents a base object on the grid
abstract class Node {

    public Vector2 position;
    public NamedColor color;
    public NamedSymbol symbol;
    public NamedColor symbolColor;

    public Node(Vector2 position) {
        this.position = position;
    }

    abstract public void update(STUDENT_CLASS_NAME ss);
}
