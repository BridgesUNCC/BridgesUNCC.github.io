package STUDENT_PACKAGE;

import bridges.games.NonBlockingGame;
import bridges.base.NamedColor;
import bridges.base.NamedSymbol;

import java.util.ArrayList;

public class STUDENT_CLASS_NAME extends NonBlockingGame {

    // / the game map.
    static int rows = 24;
    static int cols = 24;

    java.util.Random random = new java.util.Random(System.currentTimeMillis());

    ArrayList<Node> nodes;

    int points = 0;
    int timer = 0;

    NamedSymbol numberList[] = {NamedSymbol.zero, NamedSymbol.one, NamedSymbol.two, NamedSymbol.three, NamedSymbol.four, NamedSymbol.five, NamedSymbol.six, NamedSymbol.seven, NamedSymbol.eight, NamedSymbol.nine};

    public static void main(String args[]) {
        STUDENT_CLASS_NAME ir = new STUDENT_CLASS_NAME(ASSIGNMETN_NUMBER, "Assignment_Username", "Public_APIKey", cols, rows);
    }

    public STUDENT_CLASS_NAME(int assid, String login, String apiKey, int c, int r) {
        super(assid, login, apiKey, c, r);
        setTitle("Infinite Runner");
        start();
    }

    public void gameLoop() {
        process();
    }

    @Override
    public void initialize() {
        
    }

    private void draw() {
        
    }

    // Returns state of the up key to the player class
    public boolean checkKeyUp() {
        return keyUp();
    }

    public void process() {
        
    }
}

// Represents a base object on the grid
abstract class Node {

    public Vector2 position;
    public NamedColor color;
    public NamedSymbol symbol;
    public NamedColor symbolColor;

    public Node(Vector2 position) {
        this.position = position;
    }

    abstract public void update(STUDENT_CLASS_NAME ss);
}
