#include <NonBlockingGame.h>

using namespace bridges;
using namespace bridges::game;

class Runner : public NonBlockingGame {
  public:
    Runner(int assignmentID, std::string username, std::string apikey)
      : NonBlockingGame(assignmentID, username, apikey, 24, 24) {}

    virtual void initialize() override {
      // TODO Set up the game grid with a player to the left
      // and a floor at the bottom

      // As the game updates objects will move towards the player
      // The player will be able to jump to avoid obstacles and
      // collect other objects
    }

    virtual void gameLoop() override {
      // TODO:
      // Keep track of the players velocity
      // Allow the user to jump with input by setting
      // the velocity to a negative value
      // Add to the velocity every loop to emulate gravity
      // Move the player based on its current velocity which
      // will just handle up and down movement

      // Do not allow the player to fall past the floor

      // Create objects that move from the right side of the
      // screen towards the player each step. Have an object
      // for the player to avoid and one for them to collect

      // End the game if the player overlaps with the object
      // to avoid
    }
};

int main(int argc, char *argv[]) {
  Runner nbg(113, "BRIDGES_USER_ID", "BRIDGES_API_KEY");

  nbg.start();

  return 0;
}
