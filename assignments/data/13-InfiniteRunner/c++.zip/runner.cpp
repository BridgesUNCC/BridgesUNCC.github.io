#include <NonBlockingGame.h>

using namespace bridges;
using namespace bridges::game;

class Runner : public NonBlockingGame {
public:
	Runner(int assignmentID, std::string username, std::string apikey)
		: NonBlockingGame(assignmentID, username, apikey, 24, 24) {}

	virtual void initialize() override {
        // TODO Set up the game grid with a player to the left
        // and a floor at the bottom
    }

    void handleInput() {
        // Move the player up if they are on the floor and press a button
    }

    void movePlayer() {
        // If the player is not on the floor move them down
        // only call every certain number of frames to make this slower
    }

    void draw() {
        // Draw the player, any collectables or enemies, and the floor
    }

    virtual void gameLoop() override {
        handleInput();
        movePlayer();
        draw();
    }
};

int main(int argc, char *argv[]) {
	Runner nbg(10, "user", "auth");

	nbg.start();

	return 0;
}