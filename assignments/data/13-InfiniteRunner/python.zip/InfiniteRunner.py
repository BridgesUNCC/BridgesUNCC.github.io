from bridges import *

import random
from datetime import datetime

class Base(object):
    position = [0, 0]
    symbol = NamedSymbol.circle
    symbol_color = NamedColor.black
    # All game objects should inherit from base
    # Implement what you want for each game object here
    # with unique properties in the game objects themselves

class Runner(NonBlockingGame):
    def __init__(self, assid, login, apikey):
        super(Runner, self).__init__(assid, login, apikey, 24, 24)
        
        super(Runner, self).set_title("Infinite Runner")
        super(Runner, self).set_description("Press Q to restart, Up arrow to jump. Jump to avoid the bombs.")

    def initialize(self):
        random.seed(datetime.now())
        # Initialize the game state

    def draw(self):
        # Draw the board

    def game_loop(self):
        # Handle game logic
        # There should be a player object, something to avoid, and something to collect
        # These objects should inherit from base or your own type
        self.draw()

def main():
    game = Runner(ASSIGNMENT_NUMBER, "BRIDGES_USER_ID", "BRIDGES_API_KEY")
    
    # Start the game
    game.start()

if __name__ == '__main__':
    main()