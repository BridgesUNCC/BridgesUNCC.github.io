from bridges import *

class Runner(NonBlockingGame):
    def __init__(self, assid, login, apikey):
        super(Runner, self).__init__(assid, login, apikey, 24, 24)
        
        super(Runner, self).set_title("Infinite Runner")
        super(Runner, self).set_description("Press Q to restart, Up arrow to jump. Jump to avoid the bombs.")

    def initialize(self):
        # TODO Set up the game grid with a player to the left
        # and a floor at the bottom

        # As the game updates objects will move towards the player
        # The player will be able to jump to avoid obstacles and 
        # collect other objects

    def game_loop(self):
        # TODO:
        # Keep track of the players velocity
        # Allow the user to jump with input by setting
        # the velocity to a negative value
        # Add to the velocity every loop to emulate gravity
        # Move the player based on its current velocity which
        # will just handle up and down movement

        # Do not allow the player to fall past the floor
        
        # Create objects that move from the right side of the 
        # screen towards the player each step. Have an object
        # for the player to avoid and one for them to collect
        
        # End the game if the player overlaps with the object
        # to avoid

def main():
    game = Runner(ASSIGNMENT_NUMBER, "BRIDGES_USER_ID", "BRIDGES_API_KEY")
    
    # Start the game
    game.start()

if __name__ == '__main__':
    main()