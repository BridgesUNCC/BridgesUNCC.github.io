package SpreadingFire;

import babybridges.game.NGCKGame;
import bridges.base.NamedColor;
import bridges.base.NamedSymbol;
import java.util.Random;

public class SpreadingFire extends NGCKGame{
    
    // Variables for the array size.
    int gridColumns = grid.getDimensions()[0];
    int gridRows = grid.getDimensions()[1];
    
    // Array that contains forest grid state: 1 = trees, 2 = fire, 0 = empty
    int[][] treeMap = new int[gridColumns][gridRows];
    
    int spreadingProbability = 20;
    
    // Forest values
    final int FIRE = 2;
    final int TREE = 1;
    final int EMPTY = 0;
    
    // Forest colors
    NamedColor fireColor = NamedColor.red;
    NamedColor treeColor = NamedColor.green;
    NamedColor emptyColor = NamedColor.yellow;
    
    // Forest symbols
    NamedSymbol fireSymbol = NamedSymbol.campfire;
    NamedSymbol treeSymbol = NamedSymbol.triangle_up;
    NamedSymbol emptySymbol = NamedSymbol.none;
    
    // Used to control the games frame rate.
    final long FRAMERATE = 1000000000 / 50;
    long frameTime;
    long nextFrameTime;

    // Loops through game logic continously.
    public void GameLoop(){
        if (System.nanoTime() > nextFrameTime) { // Runs when it's time for the next frame.
            frameTime = System.nanoTime();
            nextFrameTime = frameTime + FRAMERATE;
            
            for (int col = 0; col < gridColumns; col++){
                for (int row = 0; row < gridRows; row++){
                    switch(treeMap[col][row]){
                        case TREE: // There is a tree in this cell
                            break;
                        case FIRE: // There is a fire in this cell
                            break;
                        case EMPTY: // Cell is empty
                            break;
                    }
                }
            }
        }
    }
    
    // Draw the initial state of the game grid.
    public void initialize(){
        
    }
    
    public static void main(String args[]) {
        int assignmentID = 0;
        String userName = "student username";
        String apiKey = "student api key";
        
        // Initialize our nonblocking game
        SpreadingFire sf = new SpreadingFire(assignmentID, userName, apiKey);
        sf.setTitle("Spreading Fire");
        sf.setDescription("Simulate the spread of fire in a forest using probabilities so that the result is different every time.");
        
        // start running the game
        sf.start();
    }
    
    public SpreadingFire(int assid, String login, String apiKey) {
        super(assid, login, apiKey);
    }
}
