import bridges.games.NonBlockingGame;
import bridges.base.NamedColor;
import bridges.base.NamedSymbol;
import java.util.Random;

public class SpreadingFire extends NonBlockingGame{
    
    // Variables for the array size.
    static int gridColumns = 30;
    static int gridRows = 30;
    
    // Array that contains forest grid state: 1 = trees, 2 = fire, 0 = empty
    int[][] treeMap = new int[gridColumns][gridRows];
    
    // Given a random number from 0 to 100 and the probability that a fire will
    // spread == 20 there is a 20% chance the site will catch fire.
    int spreadingProbability = 20;
    
    // Given a random number from 0 to 100 and the forest density == 90
    // there is a 10% chance the forest will burn out.
    int forestDensity = 90;

    // Forest values
    final int FIRE = 2;
    final int TREE = 1;
    final int EMPTY = 0;
    
    // Forest colors
    NamedColor fireColor = NamedColor.red;
    NamedColor treeColor = NamedColor.green;
    NamedColor emptyColor = NamedColor.yellow;
    
    // Forest symbols
    NamedSymbol fireSymbol = NamedSymbol.campfire;
    NamedSymbol treeSymbol = NamedSymbol.triangle_up;
    NamedSymbol emptySymbol = NamedSymbol.none;
    
    // Used to control the games frame rate.
    final long FRAMERATE = 1000000000 / 50;
    long frameTime;
    long nextFrameTime;

    // Loops through game logic continously.
    public void gameLoop(){
        if (System.nanoTime() > nextFrameTime) { // Runs when it's time for the next frame.
            frameTime = System.nanoTime();
            nextFrameTime = frameTime + FRAMERATE;
            
            for (int col = 0; col < gridColumns; col++){
                for (int row = 0; row < gridRows; row++){
                    switch(treeMap[col][row]){
                        case TREE:
                            // There is a tree in this cell
                            break;
                        case FIRE:
                            // There is a fire in this cell
                        case EMPTY:
                            // empty cell
                            break;
                    }
                }
            }
        }
    }
    
    // Draw the initial state of the game grid.
    public void initialize(){
    }
    
    public static void main(String args[]) {
        // Initialize our nonblocking game
        SpreadingFire sf = new SpreadingFire(1, "kalpathi60", "486749122386");
    }
    
    public SpreadingFire (int assid, String login, String apiKey) {
        super(assid, login, apiKey, gridColumns, gridRows);
        setTitle("Spreading Fire");
        setDescription("Simulate the spread of fire. Probability of fire spreading 15%. Forest Density 95. Press the arrow keys to try different types of forests");
        // start running the game
        start();
    }
}
