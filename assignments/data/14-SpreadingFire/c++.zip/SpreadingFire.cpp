//
//  main.cpp
//  Bridges_Student_Project_Example
//
//  Created by Allie Beckman on 9/12/19.
//  Copyright © 2019 Allie Beckman. All rights reserved.
//

#include <NonBlockingGame.h>
#include <iostream>
#include <time.h>
#include <vector>

using namespace bridges::game;
using namespace std;

struct my_game : public NonBlockingGame {
    
    int gridCols = 30;
    int gridRows = 30;
    
    int treeMap[30][30];
    
    int sprProb = 20;
    int forestDen = 90;
    
    int r;
    
    int FIRE = 2;
    int TREE = 1;
    int EMPTY = 0;
    
    NamedColor fColor;
    NamedColor tColor;
    NamedColor eColor;
    
    NamedSymbol fSymbol;
    NamedSymbol tSymbol;
    NamedSymbol eSymbol;
    
    int timer;
    int maxTime = 100;
    
    // Checks if fire nearby - starts fire
    virtual void cellContainsForest(int col, int row){
        
    }
    
    // Set fire to a cell
    virtual void ignite(int col, int row){
        drawSymbol(row, col, fSymbol, fColor);
        treeMap[col][row] = FIRE;
    }
    
    // If a fire exists call this to see if the fire burns out.
    virtual void cellContainsFire(int col, int row){
        
    }
    
    // Creates empty cell
    virtual void burnOut(int col, int row){
        
    }
    
    // Grow tree
    virtual void growTree(int col, int row){
        
    }
    
    my_game(int assID, std::string username, std::string apikey)
        : NonBlockingGame (0, username, apikey, 30, 30) {
    }

    virtual void initialize() override {
        
    }

    virtual void gameLoop() override {
        
    }
};

int main(int argc, char** argv) {
    my_game bridges_g (114, "BRIDGES_USER_ID", "BRIDGES_API_KEY");
    
    bridges_g.start();
}
