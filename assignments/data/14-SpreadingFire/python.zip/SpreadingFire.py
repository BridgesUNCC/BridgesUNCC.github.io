import random
from bridges import *

class StudentClass(NonBlockingGame):
    gridColumns = 30
    gridRows = 30 

    spreadingProbability = 20

    forest_density = 90

    FIRE = 2
    TREE = 1
    EMPTY = 0

    fireColor = NamedColor.red
    treeColor = NamedColor.green
    emptyColor = NamedColor.yellow

    fireSymbol = NamedSymbol.campfire
    treeSymbol = NamedSymbol.triangle_up
    emptySymbol = NamedSymbol.none
            

    def ignite(self, col, row):
        pass

    def burn_out(self, col, row):
        pass

    def grow_tree(self, col, row):
        self.set_bg_color(col, row, self.treeColor)
        self.draw_object(col, row, self.treeSymbol, self.treeColor)
        self.treeMap[col][row] = self.TREE

    def game_loop(self):
        i = 0
        j = 0
        for i in range(self.gridColumns):
            for j in range(self.gridRows):
                if self.treeMap[i][j]==self.TREE:
                    pass
                if self.treeMap[i][j]==self.FIRE:
                    pass
                if self.treeMap[i][j]==self.EMPTY:
                    pass # Empty

    def initialize(self):
        pass

    def __init__(self, assid, login, apikey, cols, rows):
        super(SpreadingFire, self).__init__(assid, login, apikey, cols, rows)
        
        super(SpreadingFire, self).set_title("Spreading Fire")
        super(SpreadingFire, self).set_description("Simulation of fire in a forest.")

        self.treeMap = [[0 for i in range(self.gridColumns)] for j in range(self.gridRows)]


def main():
    my_game = SpreadingFire(ASSIGNMENT_NUMBER, "BRIDGES_USER_ID", "BRIDGES_API_KEY", 30, 30)
    my_game.start()


if __name__ == '__main__':
    main()
