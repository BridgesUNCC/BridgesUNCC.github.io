import random

from bridges import *


class StudentClass(NonBlockingGame):
    gridColumns = 30
    gridRows = 30

    treeMap = int[gridColumns][gridRows]

    spreadingProbability = 20

    forestDensity = 90

    rand = random.random()

    FIRE = 2
    TREE = 1
    EMPTY = 0

    fireColor = NamedColor.red
    treeColor = NamedColor.green
    emptyColor = NamedColor.yellow

    fireSymbol = NamedSymbol.campfire
    treeSymbol = NamedSymbol.triangle_up
    emptySymbol = NamedSymbol.none

    def cell_contains_forest(self, col, row):
        probabilityTest = random.randrange(100)
        nearbyFire = False

        if col > 0 and self.treeMap[col-1][row]==2 or col < self.gridColumns-1 and self.treeMap[col+1][row]==2 or row > 0 and self.treeMap[col][row-1]==2 or row < self.gridRows-1 and self.treeMap[col][row-1]==2:
            

        if nearbyFire and probabilityTest < self.spreadingProbability:
            

    def ignite(self, col, row):
        

    def burn_out(self, col, row):
        

    def grow_tree(self, col, row):
        self.set_bg_color(col, row, self.treeColor)
        self.draw_object(col, row, self.treeSymbol, self.treeColor)
        self.treeMap[col][row] = self.TREE

    def game_loop(self):
        i = 0
        j = 0
        if i < self.gridColumns:
            if j < self.gridRows:
                if self.treeMap[i][j]==self.TREE:
                    
                if self.treeMap[i][j]==self.FIRE:
                    
                if self.treeMap[i][j]==self.EMPTY:
                    
                j+=1
            i+=1

    def initialize(self):
        

    def __init__(self, assid, login, apikey, cols, rows):
        super(StudentClass, self).__init__(assid, login, apikey, cols, rows)


def main():
    my_game = StudentClass(80, "STUDENT_USERNAME", "STUDENT_API_KEY", 30, 30)
    my_game.start()


if __name__ == '__main__':
    main()
