import random
from bridges import *

class SpreadingFire(NonBlockingGame):
    gridColumns = 30
    gridRows = 30 

    treeMap = []

    FIRE = 2
    TREE = 1
    EMPTY = 0

    fireColor = NamedColor.red
    treeColor = NamedColor.green
    emptyColor = NamedColor.yellow

    fireSymbol = NamedSymbol.campfire
    treeSymbol = NamedSymbol.triangle_up
    emptySymbol = NamedSymbol.none

    def game_loop(self):
        # TODO:
        # Each frame run the logic of each cell based on what object
        # the cell currently is.
        # Fire should have a random chance to burn out and turn into an empty cell
        # Trees should turn into fire if they are adjacent to a fire cell

    def initialize(self):
        # TODO:
        # Set up the initial board by adding fire or trees to the map
        # in a pattern on the map

    def __init__(self, assid, login, apikey, cols, rows):
        super(SpreadingFire, self).__init__(assid, login, apikey, cols, rows)
        
        super(SpreadingFire, self).set_title("Spreading Fire")
        super(SpreadingFire, self).set_description("Simulation of fire in a forest.")

        self.treeMap = [[0 for i in range(self.gridColumns)] for j in range(self.gridRows)]


def main():
    my_game = SpreadingFire(214, "BRIDGES_USER_ID", "BRIDGES_API_KEY", 30, 30)

    my_game.set_title("Spreading Fire")
    my_game.set_description("Simulate the spread of fire. Probability of fire spreading 15%. Forest Density 95. Press the arrow keys to try different types of forests")
    
    my_game.start()


if __name__ == '__main__':
    main()
