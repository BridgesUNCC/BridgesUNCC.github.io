#include "Bridges.h"
#include "DataSource.h"
#include "Array.h"
#include "SLelement.h"
#include "GraphAdjList.h"
#include "WorldMap.h"

using namespace bridges;

double degree_to_rad(double d) {
  return d * M_PI / 180;
}

double calcDistance(double la1, double lo1, double la2, double lo2) {

  double R = 6371; // Radius of the earth in km

  // Haversine formula to calculate a value between 0 and 1 between 2
  // points on a sphere, 1 being the opposite side of the sphere
  double laDistance = degree_to_rad(la2 - la1);
  double loDistance = degree_to_rad(lo2 - lo1);
  double a = sin(laDistance / 2) * sin(laDistance / 2)
             + cos(degree_to_rad(la1)) * cos(degree_to_rad(la2))
             * sin(loDistance / 2) * sin(loDistance / 2);

  double c = 2. * atan2(sqrt(a), sqrt(1 - a));


  double distance = R * c;    //convert to km
  return distance;
}


int main() {

  //create the Bridges object, set credentials  - refer to Bridges class
  Bridges bridges(104, "BRIDGES_USER_ID", "BRIDGES_API_KEY");

  /* TODO:
   * Grab 10000 earthquakes.
   * Retain only the 100 earthquakes of highest magnitude.
   * Use the Datasource object's method, getEarthquakeUSGSData()
   */


  bridges.setTitle("Earthquake Map");
  bridges.setDescription("Grab recent earthquake data and build a graph representing the locations of the 100 strongest earthquakes.");
  
  /* TODO:
   * Initialize a Graph of your choice (recommend a GraphAdjList <int, EarthquakeUSGS>)
   * Tell Bridges to visualize that graph.
   * Add the Earthquakes to the graph as individual vertices.
   * Set each earthquake's location based on its longitude and latitude
   * (Use ElementVisualizer::setLocation() ).
   * Tweak the colors or other visual elements if you wish.
     * You can set teh label of vertices based on earthquake's properties
   * using the vertex element's setLabel() method
   */


  WorldMap wm;
  bridges.setMap(wm);

  // visualize the list
  // bridges.visualize();

  /* TODO:
   *
   * Compare the distances between all vertexes in the graph,
   * drawing an edge if they are within 500km.
   *
   * Use calcDistance to compute the distance between two
   * earthquakes.
   */


  // visualize the list
  // bridges.visualize();

  // Visualize the graph just by itself

  /* TODO:
   *
   * Reset the locations of the vertices by setting their location to INFINITY
   */


  bridges.setMapOverlay(false);


  // visualize the list
  // bridges.visualize();


  return 0;
}
