from bridges import *
from bridges.world_map import *
import math

def distance(la1, lo1, la2, lo2):
    R = 6371 # Radius of the earth in KM

    # Haversine formula to calculate a value between 0 and 1 between 
	# 2 points on a sphere, 1 being the opposite side of the sphere
    laDistance = math.radians(la2 - la1)
    loDistance = math.radians(lo2 - lo1)

    a = math.sin(laDistance / 2) * math.sin(laDistance / 2) + math.cos(math.radians(la1)) * math.cos(math.radians(la2)) * math.sin(loDistance / 2) * math.sin(loDistance / 2)
    c = 2.0 * math.atan2(math.sqrt(a), math.sqrt(1 - a))

    distance = R * c #convert to KM
    return distance

def main():
    #create the Bridges object, set credentials
    bridges = Bridges(204, "BRIDGES_API_KEY", "BRIDGES_API_KEY")

    bridges.set_title("Graph EQ")
    bridges.set_description("Grab recent earthquake data and build a graph representing the locations of the 100 strongest earthquakes.")

    # TODO:
	# Grab 10000 earthquakes.
	# Retain only the 100 earthquakes of highest magnitude.
    # refer to the data source methods (get_earthquake_usgs_data() method)
	
	# TODO:
	# Initialize a Graph of your choice (recommend a GraphAdjList) 
	# Tell Bridges to visualize that graph.
	# Add the Earthquakes to the graph as individual vertices.
	# Set each earthquake's location based on its longitude and latitude (Use ElementVisualizer.set_location() ).
	# Tweak the colors or other visual elements if you wish.

    bridges.set_map(WorldMap())

    # visualize the list
    bridges.visualize()

    # TODO: 
	# 
	# Compare the distances between all vertexes in the graph,
	# drawing an edge if they are within 500km.
    # the location information is in element visualizer accessible from each
    # vertex element (refer to the Element class --> visualer --> location_x, location _y
	#
	# Use calcDistance() method above to compute the distance between two
	# earthquakes.

    bridges.visualize()

    # TODO:
	#
	# Reset the locations of the vertices by setting their location to INFINITY

    bridges.set_map_overlay(False)
    bridges.visualize()

if __name__ == '__main__':
    main()
