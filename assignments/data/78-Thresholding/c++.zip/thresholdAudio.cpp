#include "Bridges.h"
#include "AudioClip.h"
#include "ColorGrid.h"

#include <algorithm>

using namespace std;
using namespace bridges;

//  Threshold an audio clip and view its impact on the resulting audio clip

// functions thresholds the amplitude of audio clip
void thresholdAudio (AudioClip& ac_in, AudioClip& ac_out, float pos_thresh,
				float neg_thresh);

int main() {
	Bridges bridges = Bridges(178, "BRIDGES_USER_ID", "BRIDGES_API_KEY");

	bridges.setTitle("Thresholding");
        bridges.setDescription(" First Tab is original Sound, Second Tab is audio after applying Thresholding");

	AudioClip ac_in = AudioClip("../audio/piano.wav");
	AudioClip ac_out = ac_in;

	// play the audio so you can also see and hear the wave
	bridges.setDataStructure(ac_in);
	bridges.visualize();

	// display the wave in a color grid as an image
	// filter it to see the amplitude variation
	thresholdAudio (ac_in, ac_out, 100., 10.);

	// visualize
	bridges.setDataStructure(ac_out);
	bridges.visualize();

	return 0;
}

// Function to threshold the audio based on amplitude
void thresholdAudio(AudioClip& ac_in, AudioClip& ac_out, float pos_thresh,
				float neg_thresh) {

	// will threshold the amplitude by a fixed % both positive and negative
	
	// find the range of the samples in the original audio clip
	// Apply thresholding logic

	// set the sample thresholds
	}

