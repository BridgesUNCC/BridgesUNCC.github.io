import bridges.connect.Bridges;
import bridges.validation.RateLimitException;

import java.io.IOException;

import bridges.base.AudioClip;
import bridges.base.Color;
import bridges.base.ColorGrid;

/*
 * Class Thresholding
 * Creates Colorgrid for audio file and transformed audio
 */
public class Thresholding {
    
    public String audioFile;

    /*
     * Constructor
     * audioFileLocation: String, location of audio compared to this file
     */
    public Thresholding(String audioFileLocation) {
        audioFile = audioFileLocation;
    }

    /* Transforms samples from the normal samples to 
     * compressed samples so they will fit on the CG
     * inputSamples: Array of samples to transform
     */
    public int[] transformSamples(int[] inputSamples) {
        
        int[] transformSamples = new int[1920];
        int samplesPer = inputSamples.length / 1920;
        int sum = 0;
        for(int i = 0; i < inputSamples.length; i++) {
            sum += inputSamples[i];
            
            if( i % samplesPer == 0 && i != 0) {
                int avgofSamples =  (int) ((sum / (double) samplesPer) / 2.2);
                if( (i/samplesPer) - 1 == 1920) {
                    break;
                }
                transformSamples[(i / samplesPer) - 1] = avgofSamples;
                sum = 0;
            }
        }

        return transformSamples;
    }

    /* method for transforming the samples
     * turns down any samples above a certain volume
     * oriSamples: array of the samples from the audiofile
     */
    public int[] threshingSamples(int[] oriSamples) {
        
        int[] samples = oriSamples.clone();
        // Create a Threshold value

        //identify any values that fall above that value and cap it to the threshold value
        
        return null;
    } 

    /* method for getting an array of the samples from the audio file
     */
    public int[] oriSample() throws IOException {
        // Create AudioClip Object using file location

        // Create and initialize an 1D array with all the samples using the AudioClip object
        return null;
    }

    
    /* method for creating a grid that shows the audio as 
     * blue lines
     * transformedSamples: the transformed sampleArray to use
     */
    public  ColorGrid createGrid(int[] transformedSamples) {
        
        ColorGrid cg = new ColorGrid(1080, transformedSamples.length);
        int row;
        for(int i = 0; i < 1080; i++) {
            for(int j = 0; j < 1920; j++) {
                cg.set(i, j, new Color("white"));
                
            }
        }
        Color sampleColor = new Color("blue");
        for(int i = 0; i < transformedSamples.length; i++) {
            if (transformedSamples[i] < 0) {
                row = transformedSamples[i] + 530;
                cg.set(row, i, sampleColor);
                for(int j = row; j < 530; j++) {
                    cg.set(j, i, sampleColor);
                }
            } else {
                row = transformedSamples[i] + 530;
                cg.set(row, i, sampleColor);
                for(int j = row; j > 530; j--) {
                    cg.set(j, i, sampleColor);
                }
            }
            cg.set( 530, i, new Color("black"));

        }
        return cg;
    }

    /* main method for Thresholding
     * Creates bridges objects and handles interact between methods
     */
    public static void main(String[] args) throws IOException, RateLimitException {
        Bridges bridges = new Bridges(78, "BRIDGES_USER_ID", "BRIDGES_API_KEY");
        //Audio Location
        String audioLoc = "../audio.wav";
        //Instanciate class
        Thresholding holding = new Thresholding(audioLoc);

        // Create sample arrays
        int[] oriSamples = holding.oriSample();
        int[] threshingSamples = holding.threshingSamples(oriSamples);

        // create original CG array
        int[] oriCGSamples = holding.transformSamples(oriSamples);
       
        // Create Colorgrid
        ColorGrid oriColor = holding.createGrid(oriCGSamples);

        //Set Title and Description
        bridges.setTitle("Thresholding");
        bridges.setDescription(" First Tab is original Sound, Second Tab is audio after applying Thresholding");
        
        bridges.setDataStructure(oriColor);
        bridges.visualize();

        // Handle Threshing CG
        if(threshingSamples != null) {
            int[] threshCGSamples = holding.transformSamples(threshingSamples);
            ColorGrid threshColor = holding.createGrid(threshCGSamples);
            bridges.setDataStructure(threshColor);
            bridges.visualize();
        }
        
        
        
        
    }
}