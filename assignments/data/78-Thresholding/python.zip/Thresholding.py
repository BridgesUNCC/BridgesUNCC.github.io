from bridges.bridges import Bridges
from bridges.audio_clip import AudioClip


def threshold_audio(ac_in, ac_out, pos_thresh, neg_thresh):
    # Implement the thresholding logic
    pass


if __name__ == "__main__":
    bridges = Bridges(78, "BRIDGES_USER_ID", "BRIDGES_API_KEY")
    bridges.set_title("Audio Thresholding")
    bridges.set_description("First wave is the original, second is thresholded")

    # Load the audio file
    ac_in = AudioClip("../audio/piano.wav")
    ac_out = AudioClip("", ac_in.get_sample_count(), ac_in.get_num_channels(), ac_in.get_sample_bits(), ac_in.get_sample_rate())

    # Visualize the original audio
    bridges.set_data_structure(ac_in)
    bridges.visualize()

    # Apply thresholding
    threshold_audio(ac_in, ac_out, 10.0, 10.0)

    # Visualize thresholded audio
    bridges.set_data_structure(ac_out)
    bridges.visualize()

