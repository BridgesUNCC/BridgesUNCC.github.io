#include <iostream>
#include <string>
#include <vector>
#include <queue>
#include <algorithm>
#include <utility>
#include <set>

using namespace std;

#include "Bridges.h"
#include "GraphAdjList.h"
#include "DataSource.h"
#include "data_src/City.h"
#include "USMap.h"
#include "data_src/USState.h"
#include "data_src/USCounty.h"

using namespace bridges;

void buildGraph(GraphAdjList<string, int, double>& gr);
void buildNCGraph (GraphAdjList<string, int, double>& gr, DataSource& ds);

void buildMSTPrim(GraphAdjList<string, int, double>& gr, string start, 
								int& cost);
void buildMSTPrimFringe(GraphAdjList<string, int, double>& gr, int& cost); 
string getMinVertex (GraphAdjList<string, int, double>& gr, 
				unordered_map<string, int> minDist, 
				unordered_map<string, bool> mark);

struct location {
	string name;   // concatenated city and state
	double lat, longit;

	location () {};
	location (string nm, double latitude, double longitude) {
		name = nm; lat = latitude; longit = longitude;
	} 
};

double getDist (double lat1, double long1, double lat2, double long2);

int main() {
	// Initialize BRIDGES with your credentials
	Bridges bridges(144, "BRIDGES_USER_ID", "BRIDGES_API_KEY");

	// get a data source object
	DataSource ds(&bridges);

	// set title for visualization
	bridges.setTitle("MST on US Cities Dataset");
	bridges.setDescription("Implement Prim's Minimum Spanning Tree Algorithm and demonstrate its application using US city data.");

	// we will run MST on a set of cities in North Carolina

	// set the state list
	vector<string> states = {"North Carolina"};

	// get state boundary - no counties
	vector<bridges::dataset::USState> map_data = ds.getUSMapCountyData (states, false);
	USMap us_maps(map_data);

    bridges.setMap (us_maps);

	// use an adjacency list based graph
	GraphAdjList<string, int, double> gr, gr_out;
	GraphAdjList<string, int, double> gr2;


	int cost = 0;
	// retrieve the us city data and build a graph  using distance between
	// cities as edge weights
	buildNCGraph(gr, ds);

	// visualize
	bridges.setDataStructure(&gr2);
	bridges.visualize();
	

	// run Prim's MST algorithm on the graph given a starting city
	buildMSTPrim(gr2, "Charlotte", cost);

	bridges.visualize();

	return 0;
}

void buildNCGraph (GraphAdjList<string, int, double>& gr, DataSource& ds) {

// TODO - must get the dataset (see tutorial on US cities), get distances
// betweeen cities and build graph
}


void buildMSTPrim(GraphAdjList<string, int, double>& gr, string start, 
							int& cost) {
// TODO
}

string getMinVertex (GraphAdjList<string, int, double>& gr, 
				unordered_map<string, int> minDist, 
				unordered_map<string, bool> mark) {

	string minV = "";
// TODO

	return minV;
}

void buildMSTPrimFringe(GraphAdjList<string, int, double>& gr, int& cost) {
// TODO
}


double getDist (double lat1, double long1, double lat2, double long2) {
	// uses the haversine formula

	const double R = 6371e3; // metres
	const double phi1 = lat1 * M_PI/180; //  in radians
	const double phi2 = lat2 * M_PI/180;
	const double del_phi = (lat2-lat1) * M_PI/180.;
	const double del_lambda = (long2-long1) * M_PI/180.;

	const double a = sin(del_phi/2.)*sin(del_phi/2) + cos(phi1)*cos(phi2) *
					sin(del_lambda/2.)*sin(del_lambda/2.);
	const double c = 2.*atan2(sqrt(a), sqrt(1.-a));

	double dist = R * c; // in metres

	return dist;
}
