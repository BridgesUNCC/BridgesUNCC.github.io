from bridges.bridges import *
from bridges.graph_adj_list import *
from bridges.element import *
from bridges.link_visualizer import *
from bridges.edge import *
from bridges.data_src_dependent import *
import math


def main():
    # Initialize BRIDGES with your credentials
    bridges = Bridges(244, "BRIDGES_USERNAME", "BRIDGES_API_KEY")
    bridges.set_title("MST on US Cities Dataset")
    bridges.set_description("Implement Prim's Minimum Spanning Tree Algorithm and demonstrate its application using US city data.")

    # we will run Prim's MST algorithm on a set of North Carolina cities

    # set the state list
    state_data = get_us_map_county_data(['north carolina'], False)
    nc_map = USMap(state_data)
    bridges.set_map(nc_map)

    graph = GraphAdjList()
    # build graph using a set of cities in North Carolina
    build_nc_graph(graph)
   
    #visualize the NC graph with cities
    bridges.set_data_structure(graph)
    bridges.visualize()

    cost = 0.0
    # run Prim's MST algorithm
    build_mst(graph, "Charlotte", cost)

    #visualize the MST graph with cities
    bridges.visualize()


def build_nc_graph(graph):
    # must get the city data, compute distances between cities and build
    # graph; see the tutorial on US cities for details on how to get the
    # for North Carolina
    pass


def get_dist(lat1, long1, lat2, long2):
    # haversine formula
    # in meters
    R = 6371000
    phi1 = math.radians(lat1)
    phi2 = math.radians(lat2)
    del_phi = math.radians(lat2 - lat1)
    del_lambda = math.radians(long2 - long1)

    a = math.sin(del_phi / 2) * math.sin(del_phi / 2) + math.cos(phi1) * math.cos(phi2) * math.sin(
        del_lambda / 2) * math.sin(del_lambda / 2)
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    # in meters
    return R * c
    

def get_min_vertex(graph, min_dist, mark):
    # greedy choice in picking the next vertex closest to a tree vertex
    pass


def build_mst(graph, start, cost):
    # prim's algorithm to build the MST
    pass
    


if __name__ == '__main__':
    main()
