import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.String;
import java.util.*;
import bridges.base.GraphAdjList;
import bridges.connect.Bridges;
import bridges.connect.DataSource;
import bridges.base.Edge;
import bridges.validation.RateLimitException;

public class primMSTCities {

    public static void main(String[] args) throws IOException, RateLimitException {
        Bridges bridges = new Bridges(44, "BRIDGES_USERNAME","BRIDGES_APIKEY");
        bridges.setTitle("MST on US Cities Dataset");
        bridges.setCoordSystemType("albersusa");

		// US map overlay over the data
        bridges.setMapOverlay(true);
		bridges.setMap("us", "all");

		//create graph
        GraphAdjList<String, String, Double> graph = new GraphAdjList<>();

		// build a graph that contains cities in North Carolina; edge
		// weights are based on distances between cities
        buildNCGraph(graph, bridges.getDataSource());

		// visualize the graph
        bridges.setDataStructure(graph);
        bridges.visualize();

		// run Prim's MST algorithm
        float cost = 0.0f;
        buildMST(graph, "Asheville", cost);

        System.out.println("MST Min. Cost: " + cost);
        bridges.visualize();

		// optional, use only fringe vertices of tree and rerun the algorithm
        // cost = 0;
        // buildMSTPrimFringe(graph, cost);
        // bridges.visualize();
    }

    static void buildNCGraph(GraphAdjList<String, String, Double> gr, DataSource ds) {
        //TODO - must get the dataset (see tutorial on US cities), get 
		// distances betweeen cities and build graph
    }

	// computes distances between cities, given their lat/long coords
    static double getDist(double lat1, double long1, double lat2, double long2){
        final int R = 6371000;
        final double phi1 = Math.toRadians(lat1);
        final double phi2 = Math.toRadians(lat2);
        final double delPhi = Math.toRadians((lat2 - lat1));
        final double delLambda = Math.toRadians((long2 - long1));

        final double a = Math.sin(delPhi/2) * Math.sin(delPhi/2)
                + Math.cos(phi1) * Math.cos(phi2)
                * Math.sin(delLambda/2) * Math.sin(delLambda/2);
        final double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
        return R * c;
    }

    static void  buildMST(GraphAdjList<String, String, Double> gr, String start, float cost){
        //TODO
    }

    static String getMinVertex(GraphAdjList<String, String, Double> graph, HashMap<String, Double> minDist, HashMap<String, Boolean> mark){
        //TODO
		String min_v = "";

		return min_v;
    }

    static void buildMSTPrimFringe(GraphAdjList<String, String, Double> gr, float cost){
        //TODO
    }
}
