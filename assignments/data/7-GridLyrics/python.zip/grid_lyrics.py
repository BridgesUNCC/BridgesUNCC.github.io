from bridges.bridges import *
from bridges.color import *
from bridges.color_grid import *
from bridges.data_src_dependent.data_source import *
import math
import re

def split_lyrics(lyrics):
    lyrics = re.sub('[\(\[].*?[\)\]]', '', lyrics)
    lyrics = lyrics.strip()
    lyrics_split = lyrics.split()
    print(lyrics_split)

    for i in range(len(lyrics_split)):
        lyrics_split[i] = lyrics_split[i].replace("\\W+$", "")
        lyrics_split[i] = lyrics_split[i].replace("^\\W+", "")
        lyrics_split[i] = lyrics_split[i].strip()

    return lyrics_split

def main():
    # Init a Bridges Connection with your credentials
    bridges = Bridges(36, "LOGIN", "APIKEY")

    # Set assignment title
    bridges.set_title("ListEQ Example")

    # TODO:
    # Grab a song from the bridges server and get its lyrics
    # Upon doing so, call the splitLyrics method, passing the lyrics
    # to remove any punctuation or tags in the lyrics, returning
    # an array of single cleaned up terms
    #
    # After that, create a new Bridges ColorGrid object, passing
    # in the word count of the lyrics in as the dimensions.
    # You may also specify a default color if you wish, if not
    # it defaults to white
    
		
    # TODO:
    # Iterate over the lyrics, checking to see if there are matching terms
    # if so, set that coordinate to a color representing a match.
    #
    # Each row and columin will represent an individual word in the lyrics,
    # meaning your main diagonal of your matrix should be completely filled in
    # as that represents each word compared against itself.
    

if __name__ == '__main__':
    main()

