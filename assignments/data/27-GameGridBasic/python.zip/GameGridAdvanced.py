from bridges import *

class Smiley(NonBlockingGame):
    row = 0
    col = 0

	# initializations, constructors
    def __init__(self, assid, login, apikey):
        super(Smiley, self).__init__(assid, login, apikey, 10, 10)

    def initialize(self):
        self.set_title("Face")
        self.set_description("Draw a happy face on your game grid")

        # Loop through the board's columns and rows and draw the background color
        for r in range(self.grid.grid_size[0]):
            for c in range(self.grid.grid_size[1]):
                self.set_bg_color(r, c, NamedColor.darkred)

    def draw_eyes(self):
        # Draw eyes on your grid.
        # use the set_bg_color() and draw_symbol() functions and place
        # them appropriately (using row, col indices) in the grid
        pass

    def draw_smile(self):
        # Draw a smile on your grid.
        # use the set_bg_color() for this
        pass
    
    def game_loop(self):
        # note that this loop is continuously executed, so only do 
        # all drawing once
        #
        # Loop through the rows and cols and draw the background color
        # for each cell
        # Then draw the eyes and the smile
        # Optional: consider animating the smile (to grin, smirk!)
        pass

def main():
    # set Bridges credentials
    game = Smiley(227, "BRIDGES_USER_ID", "BRIDGES_API_KEY")

    # Start the game
    game.start()

if __name__ == '__main__':
    main()
