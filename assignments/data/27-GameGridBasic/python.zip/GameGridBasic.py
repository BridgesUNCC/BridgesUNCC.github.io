from bridges import *

class Smiley(NonBlockingGame):
    # First the constructor must be overwritten and the size of the grid passed in
    def __init__(self, assid, login, apikey):
        super(Smiley, self).__init__(assid, login, apikey, 10, 10)

    def initialize(self):
        # Set the title for the game which will show up as a title on the page
        self.set_title("Face")
        # Set a description which will show under the title
        self.set_description("Draw a happy face on your game grid")

        # TODO: Draw a face here
        # use the set_bg_color() and draw_symbol() methods to do the drawing
        # within the 10 by 10 grid, using row, col indices to access/modify 
        # each grid cell
    
    # Game loop must be overwriten to complete the abstract class however,
    # it will not be used here. It is called every frame of the game loop.
    def game_loop(self):
        # this is a simple example, everything is drawn in initialize(), so
        # nothing to do here.
        pass

def main():
    game = Smiley(227, "user", "auth")

    # Start the game
    game.start()

if __name__ == '__main__':
    main()
