#include "NonBlockingGame.h"

using namespace bridges::game;

class Smiley : public NonBlockingGame {
public:
    // First the constructor must be overwritten and the size of the grid passed in
	Smiley(int assignmentID, std::string username, std::string apikey)
		: NonBlockingGame(assignmentID, username, apikey, 10, 10) {}

	virtual void initialize() override {
        // Set the title for the game which will show up as a title on the page
        setTitle("Face");
        // Set a description which will show under the title
        setDescription("Draw a happy face on your game grid");
    }

    // Game loop must be overwriten to complete the abstract class however,
    // it will not be used here. It is called every frame of the game loop.
    virtual void gameLoop() override {
		
	}

};

int main() {
    // Create an instance of smiley
    Smiley nbg(27, "user", "auth");

    // Start the game
	nbg.start();

    return 0;
}