
import bridges.games.NonBlockingGame;
import bridges.base.NamedColor;
import bridges.base.NamedSymbol;

public class SmileyFace extends NonBlockingGame {

  // Specify your grid size here. Make sure these values are static and that they create a grid that is less
  // than 1024 cells total. The largest square grid is 32 x 32
  static int numCols = 10;
  static int numRows = 10;

  public static void main(String args[]) {
    // Initialize our blocking game
    SmileyFace  sf = new SmileyFace(1, "BRIDGES_USER_ID",
                                    "BRIDGES_API_KEY", numRows, numCols);
  }

  public SmileyFace(int assid, String login, String apiKey, int row,
                    int col) {
    super(assid, login, apiKey, row, col);

    // Title and description of game
    setTitle("Face");
    setDescription("Draw a happy face on your game grid.");

    // Start game
    start();
  }

  public void initialize() {
    // Set the title for the game which will show up as a title on the page
    setTitle("Face");
    // Set a description which will show under the title
    setDescription("Draw a happy face on your game grid");

    // do all your drawing here to create a smiley face
    // use the backgroud and drawSymbol calls for your drawing
  }

  public void gameLoop() {
    // noting in this function for this assignment as we draw just once

  }
}
