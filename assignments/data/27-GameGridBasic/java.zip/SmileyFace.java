package STUDENT_PACKAGE;

import bridges.games.NonBlockingGame;
import bridges.base.NamedColor;
import bridges.base.NamedSymbol;

public class STUDENT_CLASS_NAME extends NonBlockingGame {

    // Specify your grid size here. Make sure these values are static and that they create a grid that is less
    // than 1024 cells total. The largest square grid is 32 x 32
    static int numCols = 10;
    static int numRows = 10;

    public static void main(String args[]) {
        // Initialize our blocking game
        STUDENT_CLASS_NAME bg = new STUDENT_CLASS_NAME(ASSIGNMENT_NUMBER, "Bridges_Username", "Profile_APIKey", numRows, numCols);
    }

    public STUDENT_CLASS_NAME(int assid, String login, String apiKey, int row, int col) {
        super(assid, login, apiKey, row, col);

        // Title and description of game
        setTitle("Face");
        setDescription("Draw a happy face on your game grid.");

        // Start game
        start();
    }

    public void initialize() {

    }

    public void gameLoop(){

    }
