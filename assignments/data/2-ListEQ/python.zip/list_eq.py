from bridges import *


def set_properties(elem):
    # TODO: set the properties on the element based on location, magnitude of the earthquake

def main():
    #create the Bridges object, set credentials
    bridges = Bridges(7, "user", "auth")

    bridges.set_title("ListEQ")

    data = get_earthquake_usgs_data(100)

    head = None

    #Building linked list
    for el in data:
        head = SLelement(el, el.get_title(), head)

    current = head
    while current != None:
        set_properties(current)
        current = current.get_next()

    # tell Bridges what data structure to visualize
    bridges.set_data_structure(head)

    # visualize the list
    bridges.visualize()

if __name__ == '__main__':
    main()