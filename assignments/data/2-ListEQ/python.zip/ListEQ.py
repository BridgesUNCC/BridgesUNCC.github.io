from bridges import *

def main():
    # Create the Bridges object, set the user credentials
    bridges = Bridges(202, "BRIDGES_USER_ID", "BRIDGES_API_KEY")

    bridges.set_title("ListEQ")
    bridges.set_title("Styled linked list of earthquake records")

    data = get_earthquake_usgs_data(100)


    # TODO: Build the linked list

    # TODO: set the properties of the elements in the list


    # Tell Bridges what data structure to visualize
    # bridges.set_data_structure(head)

    # Visualize the linked list
    # bridges.visualize()

def set_properties(elem):
    # TODO: set the properties on the element based on location and magnitude of the earthquake
	pass


if __name__ == '__main__':
    main()
