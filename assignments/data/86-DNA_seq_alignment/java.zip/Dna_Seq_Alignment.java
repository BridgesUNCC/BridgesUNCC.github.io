import bridges.connect.Bridges;
import bridges.base.Array2D;
import bridges.base.Element;
import bridges.base.BinTreeElement;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map.Entry;
import java.util.StringTokenizer;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Dna_Seq_Alignment {
    public static void main(String[] args) throws Exception {
        //initializes the Bridges object and the filepaths
        //TODO: update with your bridges API details and adjust filepaths if needed
        Bridges bridges = new Bridges(86, "BRIDGES_USER_ID", "BRIDGES_API_KEY");
        String blosumDataFilePath = "../data/blosum62.bla";
        String organismsJsonFilePath = "../data/organisms.json";
        String pairsJsonFilePath = "../data/pairsJava.json";
        bridges.setTitle("DNA Similarity Alignment of 70 organisms");

        //Visualized example of the needlemanWunsch string comparison
        //TODO: uncomment this code after finishing the Needleman-Wunsch method
        /*
        bridges.setDescription("Trivial Example of DNA String Comparison");
        String string1 = "aabaab";
        String string2 = "ababaa";
        HashMap<String, Integer> exampleData = new HashMap<>() {{
            put("a*", -1);
            put("b*", -2);
            put("ab", -3);
            put("ba", -3);
            put("aa", 2);
            put("bb", 3);
        }};
        Array2D<Integer> tempArray = needlemanWunsch(string1, string2, exampleData);
        Array2D<Integer> visualizationExample = new Array2D<Integer>(string1.length() + 2, string2.length() + 2);
        for (int i = 0; i < string1.length()+2; i++) {
            for (int j = 0; j < string2.length()+2; j++) {
                if (i == j && i == 0) {
                    visualizationExample.getElement(0, 0).setLabel(" ");
                } else if (i == 0) {
                    visualizationExample.getElement(0, j).setLabel(("*"+string1).substring(j-1, j));
                } else if (j == 0) {
                    visualizationExample.getElement(i, 0).setLabel(("*"+string2).substring(i-1, i));
                } else {
                    visualizationExample.getElement(i, j).setLabel(tempArray.getElement(i-1, j-1).getLabel());
                }
                visualizationExample.getElement(i, j).setColor("white");
            }
        }
        bridges.setDataStructure(visualizationExample);
        bridges.visualize();
        */

        //Create and initialize the pairs HashMap using either pairsDataParse if pairs.json exists or allPairsComparison if it doesn't exist
        //TODO: uncomment this code after finishing data parsing and all pairs comparison methods
        /* 
        HashMap<String, Integer> pairs;
        try {
            System.out.println("Attempting to parse pairs data from " + pairsJsonFilePath);
            pairs = pairsDataParse(pairsJsonFilePath);
            System.out.println("Successfully read from " + pairsJsonFilePath);
        } catch (FileNotFoundException e) {
            System.out.println("File Not Found at " + pairsJsonFilePath + ", creating file now");
            pairs = allPairsComparison(organismsJsonFilePath, pairsJsonFilePath, parseBlosumData(blosumDataFilePath));
        }
        */

        //Naive Clustering
        //TODO: uncomment this code after finishing naive method
        /* 
        bridges.setDescription("Using the Exhaustive Naive Single Clustering Algorithm");
        ArrayList<BinTreeElement<String[]>> leaves = binaryTreeInitialization(organismsJsonFilePath);
        BinTreeElement<String[]> naiveRoot = naiveClustering(leaves, pairs);
        bridges.setDataStructure(naiveRoot);
        bridges.visualize();
        */

        //Kruskal's Clustering
        //TODO: uncomment this code after finishing Kruskal's method
        /*
        bridges.setDescription("Using the Kruskal's Disjoint Set Algorithm");
        leaves = binaryTreeInitialization(organismsJsonFilePath);
        BinTreeElement<String[]> kruskalRoot = kruskalsClustering(leaves, pairs);
        bridges.setDataStructure(kruskalRoot);
        bridges.visualize();
        */
    }
    /**
     * Ignores the first 6 lines in the file, parses the 7th line as the possible DNA string characters. Each line after is parsed as values,
     * placed into a 2d array. Where each nested list is a line from the file.
     * Traverses through the 2d array, using indices i and j respectively, and creating key, value pairs into a hashmap:
     * - The key will be the i'th character plus the j'th character in the DNA string characters list.
     * - The value will be the (i, j)th element in the 2d array.
     * - Note: this works since the DNA string characters list and the values 2d array should be the same length.
     * @param blosumFile file path for chosen blosum data (blosum50.bl or blosum62.bla)
     * @return matrix the generated blosum data hashmap.
     * @throws IOException
     */
    public static HashMap<String, Integer> parseBlosumData(String blosumFile) throws IOException {
        //TODO: use a BufferedReader to get the contents of the blousmFile. 
        //Hint: the first 6 lines of the blosumFile starts with '#'
        HashMap<String, Integer> blosumData = new HashMap<>();
        //TODO: place each pair of symbols and their cost value into the hashmap. 
        //Hint: Key and Value pairs will look like "AA": 4
        return blosumData;
    }

    /**
     * Applies the algorithm as described at http://nifty.stanford.edu/2025/tralie-phylogenetic-trees/Week9_Phylogenetic/index.html#needleman
     * Traverses through two strings using indices i and j respectively, a BRIDGES Array2D is filled in with the following rules:
     * 1. The first or top-left most element, which represents the start of the algorithm, is always 0.
     * 2. If i == 0, when the current element is in the first column, the value will be the element above plus the cost of deleting the (j-1)th character in the second string.
     * 3. If j == 0, when the current element is in the first row, the value will be the element to the left plus the cost of deleting the (i-1)th character in the first string.
     * 4. If neither i or j are 0, when the current element is past the first row and column, three values are calculated and the max of the three is chosen. The potential values are:
     *   - The element to the top-left plus the cost of comparing the (i-1)th character in the first string to the (j-1)th character in the second string.
     *   - The element above plus the cost of deleting the (i-1)th character in the second string.
     *   - The element to the left plus the cost of deleting the (i-1)th character in the first string.
     * 5. The last or bottom-right most element, once calculated, is the comparison score of the two DNA strings. 
     * @param s1 the first DNA string you are comparing
     * @param s2 the second DNA string
     * @param costs the blosum data hashmap
     * @return the DNA string comparison score (integer).
     */
    public static Array2D<Integer> needlemanWunsch(String s1, String s2, HashMap<String, Integer> costs) {
        Array2D<Integer> matrix = new Array2D<>(s1.length()+1, s2.length()+1);
        //TODO: fill the matrix using the described dynamic programming algorithm
        return matrix;
    }

    /**
     * Extracts the organisms hashmap in the organisms.json file, containing each
     * species name and its related DNA string.
     * Traverses the organisms hashmap, creating key, value pairs that are stored
     * in a new pairs hashmap:
         * The keys are tuples of the organisms being compared, 
         * such as ("Wild boar", "Indian wolf").
         * The values are integers calculated by using the Needleman-Wunsch function with 
         * parameters: tuple key 1, tuple key 2, blosum data.
     * Saves the resulting pairs hashmap in a new json file, "pairs.json," 
     * which can be referred to in the future. In other words, this file only needs to
     * be generated once to save time.
     * @param organismsJson
     * @param blosumData
     * @return the pairs hashmap, and creates pairs.json
     */
    public static HashMap<String, Integer> allPairsComparison(String organismsJson, String pairsFile, HashMap<String, Integer> blosumData) throws IOException{
        HashMap<String, Integer> pairsData = new HashMap<>();
        //TODO: use a BufferedReader to read the organismJson file, save each species pair with it's score in the HashMap, and write the values to pairsFile.
        return pairsData;
    }

    /**
     * Extracts the pairs hashmap in the pairs.json file, containing each possible
     * pair of organisms and their Needleman-Wunsch comparison score. If the pairs.json file
     * does not exist, an exception will be thrown and caught by main.
     * @param pairsJson filepath to the pairs.json file.
     * @return HashMap with the pairs' data.
     * @throws FileNotFoundException if pairs.json does not exist. 
     */
    public static HashMap<String, Integer> pairsDataParse(String pairsJson) throws FileNotFoundException, IOException {
        HashMap<String, Integer> pairsData = new HashMap<>();
        //TODO: use a BufferedReader to read the pairsJson file, and save the species and scores into a HashMap
        return pairsData;
    }

    /**
     * Extracts the organisms hashmap keys in the organisms.json file, which are all
     * the species names. Creates a binary tree element for each species, using species names as 
     * labels, null for left and right, and a list as the "e" object containing just the species 
     * name as an entry. This list contains the species that fall under the cluster.
     * @param organismsJson filepath to the organisms.json file.
     * @return an array of the leaf nodes for each individual species. 
     */
    public static ArrayList<BinTreeElement<String[]>> binaryTreeInitialization(String organismsJson) throws IOException {
        ArrayList<BinTreeElement<String[]>> treeList = new ArrayList<>();
        //TODO: use a BufferedReader to read the organismJson file and create a BinTreeElement for each organism
        return treeList;
    }

    /**
     * Traverses the list of binary tree nodes, or clusters, until one cluster remains. 
     * Then, traverses each pair of clusters with indices i and j respectively, keeping track of the 
     * best score and the pair of clusters that goes along with it.
     * For each pair of clusters, gather all the species that fall under them through traversing their 
     * "e" lists. Compute the score for every possible pair of species between the two clusters using 
     * the pairs hashmap. The highest score of these is compared to the best score. If it 
     * is higher, the best score is updated and the best pair becomes that pair of clusters.
     * Note: in this step you only compute scores you have not previously computed. For example, Eastern newt 
     * and Fire salamander are in one cluster, while Fugu rubipres and Goldfish are in another. Traversing through 
     * their "e" lists would result in computing the scores for (Eastern newt, Fugu rubipres) but not (Eastern newt, Fire salamander).
     * Once all pairs of clusters have been traversed, create a new node where left and right point to the best pair 
     * of clusters and "e" gets a list concatenated from the best pair's "e" lists. Add this node to the list of binary tree nodes 
     * and remove the best pair nodes, since those are now clustered under the new node.
     * @param nodes the list of binary tree leaf nodes
     * @param pairs the hashmap from pairs.json
     * @return the final cluster node of species in the list, which is the uppermost root node of the dendrogram.
     */
    public static BinTreeElement<String[]> naiveClustering(ArrayList<BinTreeElement<String[]>> nodes, HashMap<String, Integer> pairs) {
        //TODO: iterate over nodes until only one element remains, keeping track of the best pair and score
        //Use nested loops to iterate over each pair of cluster nodes. Use another set of nested loops to obtain the scores in each species within the cluster
        //and compare them to the best score, updating the best score and pair if needed. Outside the loops, create a new cluster node using the best pair and remove
        //both original nodes from the list. 
        return nodes.get(0);
    }

    /**
     * Initializes a union find hashmap that keeps track of each species' root node. Keys are the species' name (string) and values are initially set to the corresponding leaf node.
     * Iterate through the sorted pairs hashmap, which has already been sorted for selecting the 
     * highest comparison scores. For each pair of species, check their root nodes with union find. If the roots are the same, you can simply skip this pair.
     * Otherwise, create a new node with left and right children as the two roots and "e" as a list concatenated 
     * from the root's "e" lists. Then, for each species in this new node's "e" list, set their root nodes to this new node in union find.
     * @param nodes the list of binary tree leaf nodes
     * @param pairs the hashmap from pairs.json
     * @return any of the roots in union find, which will all point to the uppermost root node of the dendrogram by the end of the iterations.
     */
    public static BinTreeElement<String[]> kruskalsClustering(ArrayList<BinTreeElement<String[]>> nodes, HashMap<String, Integer> pairs) {
        Comparator<Entry<String, Integer>> comp = Entry
            .<String, Integer>comparingByValue().reversed()
            .thenComparing(Entry.comparingByKey());
        LinkedHashMap<String, Integer> sortedPairs =
        pairs.entrySet().stream().sorted(comp)
                .collect(Collectors.toMap(Entry::getKey,
                        Entry::getValue,
                        (a, b) -> a,      // merge function
                        LinkedHashMap::new));
        
        HashMap<String, BinTreeElement<String[]>> unionFind = new HashMap<>();
        //TODO: save each node label and node into the unionFind HashMap from the sorted map, 
        // iterate through the sorted HashMap, checking for the root of each pair in the unionFind
        //when you encounter a pair with different roots, crate a new cluster using that pair's roots and update all species roots to the new node
        return unionFind.get("Wild boar"); //any node can be returned, as they should all point to the root node. 
    }
}
