#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <list>
#include <cmath>
#include <regex>
#include <utility>
#include <unordered_map>

#include "Bridges.h"
#include "BinTreeElement.h"
#include "Color.h"

// use this constant to switch between reading the matched scores from a
// file or to compute it
#define ALL_PAIRS_MATCH 0

using namespace std;
using namespace bridges;

class Organism {
	public:
		string name, dna;
};

// read the BLOSUM table alignment cost
unordered_map<string, int> parseScores(string file_name);

// read the organisms
void parseOrganisms (string file_name, vector<Organism>& orgs);

// NeedlemanWunch dynamic prog. algorithm
int NeedlemanWunch(string s1, string s2, unordered_map<string, int> costs);

// the matching function to find match between all possible pairs
unordered_map<string, int>  allPairsMatch (vector<Organism>& orgs, 
					unordered_map<string, int>& costs);

// read the all pairs scores
unordered_map<string, int> allPairsRead (string file_name);

// write the all pairs scores
void allPairsWrite (unordered_map<string, int>& score_map, string file);


// single link Naive algorithm to implement the clustering
BinTreeElement<list<string>> *clusterOrganismsNaive (
			const vector<Organism>& orgs,
			unordered_map<string,int>& pair_scores);

// Kruskal's union find method to implement the clustering
BinTreeElement<list<string>> *clusterOrganismsKruskal(
			const vector<Organism>& orgs,
			unordered_map<string,int>& pair_scores);



int main() {
	Bridges bridges (86, "BRIDGES_USER", "BRIDGES_API_KEY");
	bridges.setTitle("DNA Similarity Alignment of 70 Organisms");
	bridges.setElementLabelFlag(true);

	// trivial example
	// You might want to implement the example provided in the Nifty assignment
	// to check your algorithm correctness

	// parse the blosum score table
	unordered_map<string, int> parseScores(string file_name);

	// parse the organisms and their dna strings
	vector<Organism> organisms;
	string file_name;
	parseOrganisms (file_name, organisms);

#if ALL_PAIRS_MATCH
	unordered_map<string, int> score_map = allPairsMatch (organisms, scores);
	allPairsWrite (score_map, "../data/pairs_dict_c++.txt");
#else
	// read precomputed score map
	unordered_map<string, int> score_map = allPairsRead ("../data/pairs_dict_c++.txt");
#endif

	// single link clustering
	bridges.setDescription("Using the Exhaustive Single Clustering Algorithm");

	// Kruskal's union find to determine the clusters
	BinTreeElement<list<string>> *root = clusterOrganismsNaive(organisms, score_map);

	// bridges.setDataStructure (root);
	// bridges.visualize();
	
	bridges.setDescription("Using the Kruskal's Disjoint Set Algorithm");
	root = clusterOrganismsKruskal (organisms, score_map);

	// bridges.setDataStructure (root);
	// bridges.visualize();

	return 0;
}

unordered_map<string, int> allPairsMatch (vector<Organism>& orgs, 
						unordered_map<string, int>& costs) {

	unordered_map<string, int> score_map;

	return score_map;
}

unordered_map<string, int>  allPairsRead (string file_name) {

	unordered_map<string, int> score_map; 

	return score_map;
}
void allPairsWrite (unordered_map<string, int>& score_map, string file_name) {

	ofstream outfile(file_name);
}

int NeedlemanWunch(string s1, string s2, unordered_map<string, int> costs) {

	// compares strings s1 and s2 and uses dynamic progamming to 
	// compute a score based on assgined costs.
	vector<vector<int>> score_tab (s1.size() +1);

	// will return the score in the lower right corner of the table
	
	return score_tab[s1.size()-1][s2.size()-1];
}

BinTreeElement<list<string>> *clusterOrganismsNaive (
			const vector<Organism>& organisms, 
			unordered_map<string,int>& pair_scores) {

	// implements the single link clustering algorithm. Start with each
	// organism as a leaf node of the tree and then start forming clusters
	// can keep the clustered organisms in the tree node's data object
	// as a list
	BinTreeElement<list<string>> *root;

	return root;
}

BinTreeElement<list<string>> *clusterOrganismsKruskal (
				const vector<Organism>& orgs, 
				unordered_map<string,int>& pair_scores) {

	// Use Kruskal's union find data structure to form the clusters
	// start with an array tree leaf node pointers for the tree as before
	// and its cluster organisms in its data object.
	// object to keep pairs together
	// Have  map to access the pointers for each organism
	// then iterate through the pairs in descending order of scores to
	// implement the clustering
	// Next build the tree, scanning through the sorted list of organism pairs
	// skip pairs that point to the same root (they are in the same 
	// connected component), remaining pairs are merged

	BinTreeElement<list<string>> *new_root;
	return new_root;
}

unordered_map<string, int> parseScores(string file_name) {
	ifstream infile(file_name);
	unordered_map<string, int> scores;

	return scores;
}

void parseOrganisms (string file_name, vector<Organism>& organisms) {
	ifstream orgs_file(file_name);
	
}
