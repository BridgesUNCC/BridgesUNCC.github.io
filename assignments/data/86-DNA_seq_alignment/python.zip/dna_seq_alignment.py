from bridges.bridges import Bridges
from bridges.array2d import Array2D
from bridges.bin_tree_element import BinTreeElement
import json

def blosum_data_parse(blosum_file:str) -> dict:
    ''' Ignores the first 6 lines in the file, parses the 7th line as the possible DNA string characters.
    Each line after is parsed as values and placed into a 2D list, where each nested list is a line from the file.
    Traverses through the 2D list, creating key, value pairs into a dictionary:
      - Keys are the pairs of DNA string characters concatenated together.
      - Values are the score corresponding to comparing a pair of characters. 
    :param blosum_file: file path to the chosen blosum data (blosum50.bla or blosum62.bla)
    :return: a blosum data dictionary for DNA string comparisons.
    :raises FileNotFoundError: if file path is invalid or the file does not exist.
    '''
    blosum_data = {}
    # TODO: open blosum_file in read mode and parse its lines into a dictionary.
    # Hints: the first 6 lines all start with '#'. Key, value pairs must look like: {"AA": 4}
    
    return blosum_data

def needleman_wunsch(s1:str, s2:str, costs:dict)->list:
    ''' Traverses through two strings using indices i and j respectively, filling in a 2D list with the following rules:
    1. The first or top-left most element, which represents the start of the algorithm, is always 0.
    2. If i == 0 (when the current element is in the first row), the value will be the element to the left plus the cost of
       deleting the (j-1)th character in the first string.
    3. If j == 0 (when the current element is in the first column), the value will be the element above plus the cost of
       deleting the (i-1)th character in the second string.
    4. If neither i or j are 0 (when the current element is past the first row and column), three values are calculated and the
       max of the three is chosen. The potential values are:
        - The element to the top-left plus the cost of comparing the (j-1)th character in the first string to the (i-1)th character
          in the second string.
        - The element to the left plus the cost of deleting the (i-1)th character in the first string.
        - The element above plus the cost of deleting the (i-1)th character in the second string.
    5. The last or bottom-right most element, once calculated, is the comparison score of the two DNA strings.
    :param s1: the first DNA string to compare
    :param s2: the second DNA string to compare
    :param costs: a blosum data dictionary
    :return: the 2D list containing the comparison score of the provided DNA strings
    '''
    matrix = [[0 for i in range(len(s1)+1)] for j in range(len(s2)+1)]
    # TODO: fill in the 2D list by implementing the above dynamic programming algorithm.
    # Hint: deleting a character in blosum is through the "*" character. So, "A*" refers to deleting the character "A".
    
    return matrix

def all_pairs_comparison(organisms_file:str, pairs_file:str, blosum_data:dict)->dict:
    ''' Extracts the organisms dictionary from the provided organisms file path, containing each species name and its
    related DNA string. Traverses the organisms dictionary, creating key, value pairs stored in a new pairs dictionary:
      - The keys are tuples of the organisms being compared, such as ("Wild boar", "Indian wolf").
      - The values are integers calculated from a matrix using the Needleman-Wunsch function with parameters:
        (tuple key 1's DNA string, tuple key 2's DNA string, blosum data). The score is extracted from the bottom-rightmost entry
        in the resulting matrix.
    Saves the resulting pairs dictionary in a new json file with the provided pairs file path. This file only needs to be
    generated once to save future execution time, since we are able to use pairs_data_parse to recreate the dictionary once
    the file is generated.
    :param organisms_file: file path to the organisms data
    :param pairs_file: file path to save the pairs comparison data
    :param blosum_data: blosum data dictionary for DNA string comparisons
    :return: the pairs dictionary, which is also written into a json file
    :raises FileNotFoundError: if a file path is invalid or a file does not exist.
    '''
    print("Comparing all possible pairs of species. This may take a long time.")
    pairs_data = {}
    # TODO: open organisms_file and load it as a dictionary using the json module.
    # Refer to the following documentation on json loading: https://docs.python.org/3/library/json.html#json.load
    
    # TODO: iterate each possible pair of species, obtain their Needleman-Wunsch score, and save into a new dictionary.
    # Hints: the score is the bottom-rightmost entry in the generated 2D list. You can cut execution time in half by saving
    # pairs symmetrically (saving pairs A-B and B-A in the same iteration).
    # Key, value pairs must look like: {("Wild boar", "Horse"): 1347}
    
    # TODO: save the resulting dictionary into a file using the json module.
    # Refer to the following documentation on json dumping: https://docs.python.org/3/library/json.html#json.dump
    
    return pairs_data

def pairs_data_parse(pairs_file:str)->dict:
    ''' Extracts the pairs dictionary in the pairs comparison data file, containing each possible pair of organisms and
    their Needleman-Wunsch comparison score.
    :param pairs_file: file path to the pairs comparison data file
    :return: dictionary with the pairs comparison data
    :raises FileNotFoundError: if file path is invalid or the file does not exist.
    '''
    pairs_data = {}
    # TODO: open pairs_file and load it as a dictionary using the json module.
    # If using tuples as keys, make sure to convert keys back to tuples after loading.
    # Refer to the following documentation on json loading: https://docs.python.org/3/library/json.html#json.load
    
    return pairs_data

def binary_tree_init(organisms_file:str)->list:
    ''' Extracts the organisms dictionary keys in the organisms file, which are all the species names.
    Creates a binary tree element (BinTreeElement) for each species, using species names as labels, null for left
    and right children, and a list as the "e" object containing just the species name an entry. This list contains
    the species that full under the cluster.
    :param organisms_file: file path to the organisms data
    :return: a list of leaf nodes for each individual species.
    :raises FileNotFoundError: if file path is invalid or the file does not exist.
    '''
    # TODO: open organisms_file and load it as a dictionary using the json module.
    
    # TODO: create a binary tree element for each species.
    # Refer to the following tutorial on BRIDGES BinTreeElement: https://bridgesuncc.github.io/tutorials/BinTree.html
    # Return the list of BinTreeElement nodes.
    pass

def naive_clustering(nodes_list:list, pairs_data:dict)->BinTreeElement:
    ''' Traverses the list of binary tree nodes, or clusters, until one cluster remains. Then, traverses each pair of clusters,
    keeping track of the best score and the corresponding best pair. For each pair of clusters, gather all the species that fall
    under them through traversing their "e" lists. Compute the score for every pair of species between the two clusters using the
    pairs dictionary. If any of these scores are higher, the best score is updated and the best pair becomes that pair of clusters.
    Once all pairs of clusters have been traversed, create a new node where left and right children point to the best pair and "e"
    gets a list concatenated from the best pair's "e" lists. Add this node to the list of binary tree nodes and remove the best pair nodes.
    :param nodes_list: the list of binary tree leaf nodes
    :param pairs_data: the pairs comparison data dictionary 
    :return: the final cluster node of species in the list, which is the root node of the binary tree.
    '''
    # TODO: iterate until nodes_list has one element remaining, keeping track of the best pair and score.
    # Use nested loops to obtain pairs of cluster nodes (BinTreeElements) from nodes_list.
    # Use nested loops once more through each cluster's species lists, calculating the scores available under those clusters,
    # and compare them to the best score. Update best score and pair if needed.
    # Back in the non-nested loop, create a new cluster node using the best pair and remove the best pair nodes.

    return nodes_list[0] # Return the last remaining BinTreeElement node.

def kruskals_clustering(nodes_list:list, pairs_data:dict)->BinTreeElement:
    ''' Initializes a union find dictionary that keeps track of each species' root node. Keys are the species' name and values are
    initially set to the corresponding leaf node. Iterate through a sorted pairs dictionary/hashmap, which is sorted in descending
    order by values for selecting the highest comparison scores first. For each pair of species, check their root nodes with union
    find. If the roots are the same, you can simply skip this pair. Otherwise, create a new node with left and right chilren as the
    two roots and "e" as a list concatenated from the roots' "e" lists. Then, for each species in this new node's "e" list, set their
    root nodes to this new node in union find.
    :param nodes_list: the list of binary tree leaf nodes
    :param pairs_data: the pairs comparison data dictionary 
    :return: any of the roots in union find, which will all point to the root node of the tree.
    '''
    sorted_pairs = dict(sorted(pairs_data.items(), key=lambda item: item[1], reverse=True))
    union_find = {node.label : node for node in nodes_list}
    # TODO: iterate through the sorted pairs dictionary, checking the roots for each pair with union find.
    # When a pair has different roots, create a new cluster node using the pair's roots and update all species' roots to the new node.
    
    return list(union_find.values())[0] # Return the final cluster node

if __name__ == "__main__":
    # Initalize BRIDGES Assignment
    # TODO: Enter your BRIDGES API information
    bridges = Bridges(86, "BRIDGES_USER_ID", "BRIDGES_API_KEY")
    bridges.set_title("DNA Similarity Alignment of 70 Organisms")
    bridges.element_label_flag = True

    # Example of Needleman-Wunsch String Comparison
    # TODO: Uncomment the following code when finished with Needleman-Wunsch function
    # bridges.set_description("Trivial Example of DNA String Comparison")
    # s1 = "aabaab"
    # s2 = "ababaa"
    # example_data = {"a*": -1, "b*": -2, "ab": -3, "ba": -3, "aa": 2, "bb": 3}
    # temp_matrix = needleman_wunsch(s1, s2, example_data)
    # example_matrix = Array2D(len(s1)+2, len(s2)+2)
    # for i in range(len(s1)+2):
    #     for j in range(len(s2)+2):
    #         if i == j == 0:
    #             example_matrix[0, 0].label = " "
    #         elif i == 0:
    #             example_matrix[0, j].label = ("*"+s1)[j-1]
    #         elif j == 0:
    #             example_matrix[i, 0].label = ("*"+s2)[i-1]
    #         else:
    #             example_matrix[i, j].label = temp_matrix[i-1][j-1]
    #         example_matrix[i, j].color = "white"
    # bridges.set_data_structure(example_matrix)
    # bridges.visualize()

    # Obtain Pairs Comparson Data
    # TODO: Uncomment the following code when finished with data parsing and all pairs comparison. Change file paths if needed.
    # try:
    #     pairs_data = pairs_data_parse("../data/pairs.json")
    # except:
    #     blosum_data = blosum_data_parse("../data/blosum62.bla")
    #     pairs_data = all_pairs_comparison("../data/organisms.json", "../data/pairs.json", blosum_data)

    # # Naive Clustering of Species
    # TODO: Uncomment the following code when finished with Naive. Change file paths if needed.
    # bridges.set_description("Using the Exhaustive Naive Single Clustering Algorithm")
    # leaves = binary_tree_init("../data/organisms.json")
    # root = naive_clustering(leaves, pairs_data)
    # bridges.set_data_structure(root)
    # bridges.visualize()

    # Kruskal's Clustering of Species
    # TODO: Uncomment the following code when finished with Kruskal's. Change file paths if needed.
    # bridges.set_description("Using the Kruskal's Disjoint Set Algorithm")
    # leaves = binary_tree_init("../data/organisms.json")    
    # root = kruskals_clustering(leaves, pairs_data)
    # bridges.set_data_structure(root)
    # bridges.visualize()
