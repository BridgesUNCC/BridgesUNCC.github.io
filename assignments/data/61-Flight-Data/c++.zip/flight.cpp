#include <iostream>
#include <fstream>
#include <random>
#include <sstream>
#include <string>
#include <utility>
#include <vector>
#include <filesystem>
#include <random>
#include <GraphAdjList.h>
#include "Bridges.h"
#include "WorldMap.h"

#include <string>
using namespace std;


std::string datafilepath = "../data/airports.txt";

using namespace bridges;

class Airport{
    public:
        std::string code;
        std::string name;
        std::string city;
        std::string country;
        double lat;
        double longitude;
		Airport(string airportCode, string airportName, string airportCity, 
				string airportCountry, double airportLat, double airportLong){
            code = std::move(airportCode);
            name = std::move(airportName);
            Airport::city = std::move(airportCity);
            Airport::country = std::move(airportCountry);
            Airport::lat = airportLat;
            Airport::longitude = airportLong;
        }
        std::string getString(){
            return code + " -- " + name + " in " + city + ", " + country;
        }

};

int main(){
    Bridges bridges(161, "BRIDGES_USER_ID", "BRIDGES_API_KEY");
    bridges.setTitle("Airports filtering");
    bridges.setDescription("Displaying 200 airports");

    ifstream airportsData(datafilepath);
    string dataText;

	vector<Airport> airports;

    // Read data from the file and store in airports vector
    // Read each line and split it by commas
    // Add Airport object to the list

   GraphAdjList<string, string> g;

    // Initialize Graph
    // Shuffle the airports vector randomly
    // Pick 200 random airports and add to the graph
    // Add the airport as a vertex in the graph using the airport code as the ID and name
            // Set the vertex location based on the airport's longitude and latitude
		// Generate random RGB values for the color of the vertex
		// Set the color of the vertex using the generated RGB values and a fixed opacity



    // Close the file after processing
    airportsData.close();

    WorldMap wm;
    bridges.setMap(wm);
    bridges.setTitle("Airport World Map");
    bridges.setDescription("Displaying: " + to_string(100) + " airports");
    bridges.setDataStructure(g);
    bridges.visualize();

    return 0;

}

