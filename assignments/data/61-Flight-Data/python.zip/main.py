# builtin imports
import random

# bridges imports
from bridges.bridges import *
from bridges.world_map import *
from bridges.graph_adj_list import *

# custom imports
from airports import Airport

# get the path to the data
datafilepath = "../data/airports.txt"


# get the list of airports from the file
def getAirports() -> list:
    airports = []
    # TODO: Read the data
    # Read the entire file content as a single string
    # Split the file content by newlines to create a list of raw airport data lines

    # Iterate through each line of raw airport data
    # Split each line by commas to extract airport attributes
    # Create an Airport object with extracted attributes and add it to the airports list

    return airports


def filter(airports, numAirports) -> list:
    # TODO: filter the airports based on values
    # Limit the number of airports by choosing a random number then return airports

    return airports


def display(airports, numAirports):
    bridges = Bridges(261, "BRIDGES_USER_ID", "BRIDGES_API_KEY")
    # Create an adjacency list-based graph for representing the airport data
    # Build a graph indexed on the airport code
    # Loop through each airport in the airports list
    # Add a vertex to the graph for each airport, using the airport code as both identifier and label
    # Set the geographic location of the airport vertex based on longitude and latitude
    # Generate a color based on the airport code by converting each character to a color component
    # Print airport information for debugging or tracking

    # visualize
    bridges.set_map(WorldMap());

    bridges.set_title("Airport World Map")
    bridges.set_description("Displaying: " + str(numAirports) + " airports")
    # bridges.set_data_structure(g)
    bridges.visualize()


def main():
    num = 100
    airports = getAirports()
    airports = filter(airports, num)
    display(airports, num)


if __name__ == '__main__':
    main()
