class Airport:
    def __init__(self, code, name, city, country, lat, long):
        self.code = code
        self.name = name
        self.city = city
        self.country = country
        self.lat = lat
        self.long = long

    def __str__(self) -> str:
        return self.code + " - " + self.name + " in " + self.city + ", " + self.country