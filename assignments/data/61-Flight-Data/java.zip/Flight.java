

import bridges.base.GraphAdjList;
import bridges.base.WorldMap;
import bridges.connect.Bridges;
import bridges.validation.RateLimitException;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.*;



public class Flight {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException, RateLimitException {
        Bridges bridges = new Bridges(61, "BRIDGES_USER_ID", "BRIDGES_API_KEY");
        GraphAdjList<String, String, String> graph = 
					new GraphAdjList<String, String, String>();

	// read the data
        String pathToData =  "../data/airports.txt";
        // Initialize an ArrayList to store Airport objects
        ArrayList<Airport> airports = new ArrayList<Airport>();
        
        // Create a Scanner to read the data file line by line
        // Loop through each line in the file
        // Split the line by commas and store each field in a list
        // Create a new Airport object using parsed values and add it to the list
	// Print the stack trace if the file is not found


/*
        for(Airport airport : airports){
            if(airport.longitude < 0){
                filterAirports.add(airport);
            }
        }
*/

        //Pick 100 Randomly
        // Shuffle the list of airports to randomize their order
	// Initialize a Random object for selecting random airports
        // Loop 200 times to pick random airports and add them to the graph
            // Select a random Airport from the shuffled list
            // Add the airport as a vertex in the graph using the airport code as the ID and name
            // Set the vertex location based on the airport's longitude and latitude
			// Generate random RGB values for the color of the vertex
			// Set the color of the vertex using the generated RGB values and a fixed opacity
     

        bridges.setDescription("Displaying 200 airports");
        bridges.setTitle("Airport World Map");

        bridges.setMap(new WorldMap());
        bridges.setDataStructure(graph);
        bridges.visualize();
    }
    
}
