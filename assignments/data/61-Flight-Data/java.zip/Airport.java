
public class Airport {
    String code;
    String name;
    String city;
    String country;
    double lat;
    double longitude;
    public Airport(String code, String name, String city, String country, double lat, double longitude){
        this.code = code;
        this.name = name;
        this.city = city;
        this.country = country;
        this.lat = lat;
        this.longitude = longitude;
    }

    @Override
    public String toString() {
        return code + " - " + name + " in " + city + ", " + country;
    }
}
