from bridges import *
from bridges.sorting_benchmark import *

def selectionsort(arr):
    # TODO implement selection sort
    pass

def pythonsort(arr):
    arr.sort()

#def bubblesort(arr):
    # TODO Sort the array using bubble sort
    pass

def main():
    bridges = Bridges(229, "BRIDGES_USER_ID", "BRIDGES_API_KEY")

    bridges.set_title("Sorting Benchmark")
    bridges.set_description("Plot the performance of sorting algorithms using Bridges Line Chart.")

#     plot = LineChart()
#     plot.title = "Sort Runtime"
#     bench = SortingBenchmark(plot)
#     bench.linear_range(100, 10000, 20)
#     bench.time_cap = 1000*1
#     bench.run("selection sort", sort)
# #   bench.run("bubble sort", bubblesort)
#     bench.run("python sort", pythonsort)

#     bridges.set_data_structure(plot)
#     bridges.visualize()

    plot2 = LineChart()
    plot2.title = "Sort Runtime"
    bench2 = SortingBenchmark(plot2)
    bench2.geometric_range(100, 10000000, 1.3)
    bench2.time_cap = 1000*1*60*5
    #bench2.generator = "reverseorder"
    
#    bench2.run("selection sort", sort)
#   bench2.run("bubble sort", bubblesort)
    bench2.run("python sort", pythonsort)    
    
    bridges.set_data_structure(plot2)
    bridges.visualize()


if __name__ == '__main__':
    main()
