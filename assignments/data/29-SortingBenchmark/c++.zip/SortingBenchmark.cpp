#include <iostream>
#include <algorithm>
#include <SortingBenchmark.h>
#include <Bridges.h>

using namespace bridges;
using namespace bridges::datastructure;
using namespace bridges::benchmark;

void myfirstsort (int* arr, int n) {
  // ...
}

void standardsort (int* arr, int n) {
  std::sort(arr, arr+n);
}

int main () {
  Bridges bridges (129, "BRIDGES_USER_ID", "BRIDGES_API_KEY");

  LineChart plot;
  SortingBenchmark sb(plot);

  sb.linearRange (100, 10000, 20);
  sb.setTimeCap(1.0); //1 seconds
  
  sb.run("myfirstsort", myfirstsort);
  sb.run("std::sort", standardsort);

  bridges.setDataStructure (&plot);
  bridges.visualize();


  LineChart plot2;
  plot2.setTitle("Sort Runtime");
  SortingBenchmark sb2 (plot2);
  sb2.geometricRange(100, 1000000, 1.5);
  sb2.setTimeCap(1); //1 seconds

  sb2.run("myfirstsort", myfirstsort);
  sb2.run("std::sort", standardsort);
  
  bridges.setDataStructure(plot2);
  bridges.visualize();

  
  
  return 0;
}
