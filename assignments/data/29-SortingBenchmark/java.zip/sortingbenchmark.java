import bridges.base.LineChart;
import bridges.benchmark.SortingBenchmark;
import bridges.connect.Bridges;
import bridges.validation.RateLimitException;

import java.io.IOException;
import java.util.*;
import java.util.function.Consumer;

public class sortingbenchmark {

  static Consumer <int[]> mysort = arr -> {
  //TODO: Implement selection sort
  };

  static Consumer <int[]> javasort = arr -> {
    Arrays.sort(arr);

  };


  public static void main(String[] args) throws IOException, RateLimitException, InterruptedException {

    Bridges bridges = new Bridges(29, "MY_USERNAME", "MY_APIKEY");

    bridges.setTitle("Sorting Benchmark");
    bridges.setDescription("Sorting Benchmark test");

    LineChart plot = new LineChart();
    plot.setTitle("Sort Runtime");
    SortingBenchmark bench = new SortingBenchmark(plot);
    bench.linearRange(100, 10000, 20);
    bench.setTimeCap(1000 * 1); //1 seconds
    bench.run("selection sort", mysort);
    bench.run("javasort", javasort);

    bridges.setDataStructure(plot);
    bridges.visualize();

    LineChart plot2 = new LineChart();
    plot2.setTitle("Sort Runtime");
    SortingBenchmark bench2 = new SortingBenchmark(plot2);
    bench2.geometricRange(100, 1000000, 1.5);
    bench2.setTimeCap(1000 * 1); //1 seconds

    bench2.run("selection sort", mysort);
    bench2.run("javasort", javasort);

    bridges.setDataStructure(plot2);
    bridges.visualize();
  }

}
