#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <map>
#include "Bridges.h"
#include "DataSource.h"
#include "ColorGrid.h"
#include "BarChart.h"

using namespace std;
using namespace bridges;

//Implement the readCsv to parse the data from File

map<string, vector<double>> readCsv(const vector<string>& countries, const string& path) {
    map<string, vector<double>> table;
    return table;
}

int main() {
    Bridges bridges(85, "BRIDGES_USER_ID", "BRIDGES_API_KEY");
    BarChart barChart;

    barChart.setTitle("Forest Cover % Over Years");
    barChart.setValueLabel("Forest Cover%");
    barChart.setCategoriesLabel("Years");

    string path = "../data/API_AG.LND.FRST.ZS_DS2_en_csv_v2_190.csv";
    vector<string> bins = {
        "1992", "1993", "1994", "1995", "1996", "1997", "1998", "1999", "2000",
        "2001", "2002", "2003", "2004", "2005", "2006", "2007", "2008", "2009",
        "2010", "2011", "2012", "2013", "2014", "2015", "2016", "2017", "2018",
        "2019", "2020"
    };
    vector<string> countries = {"United States", "United Kingdom", "Turkey", "China", "Brazil"};

    // Read data from CSV
    map<string, vector<double>> mapData = readCsv(countries, path);


    //bridges.setDataStructure(barChart);
    //bridges.visualize();

    return 0;
}
