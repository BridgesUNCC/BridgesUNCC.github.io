from bridges.bridges import Bridges
from bridges.bar_chart import BarChart
import json




#implement this fucntion to parse the data

def read_csv(countries, path):

    return 


def main():
    # Initialize BRIDGES with credentials
    bridges = Bridges(85, "BRIDGES_USERNAME", "BRIDGES_APIKEY")

    # Set up the bar chart
    bar_chart = BarChart()
    bar_chart.title = "Forest Cover % Over Years"
    bar_chart.value_label = "Forest Cover%"
    bar_chart.categories_label = "Years"

    path = "../data/API_AG.LND.FRST.ZS_DS2_en_csv_v2_190.csv"
    bins = [
        "1992", "1993", "1994", "1995", "1996", "1997", "1998", "1999", "2000",
        "2001", "2002", "2003", "2004", "2005", "2006", "2007", "2008", "2009",
        "2010", "2011", "2012", "2013", "2014", "2015", "2016", "2017", "2018",
        "2019", "2020"
    ]
    countries = ["United States", "United Kingdom", "Turkey", "China", "Brazil"]
    

    # Read data from the CSV file
    map_data = read_csv(countries, path)

    #Write for loops to add map data as dataSeries to the barChart
    

    # Visualize
    bridges.set_data_structure(bar_chart)
    bridges.visualize()

if __name__ == '__main__':
    main()
