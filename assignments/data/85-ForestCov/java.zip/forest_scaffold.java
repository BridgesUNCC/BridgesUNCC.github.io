import bridges.base.BarChart;
import bridges.connect.Bridges;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Scanner;
import java.util.Vector;


public class forest_scaffold {
    public static void main(String[] args) throws Exception {

        // Initialize BRIDGES with your credentials
        Bridges bridges = new Bridges(85, "BRIDGES_USER_ID", "BRIDGES_API_KEY");
        BarChart barChart = new BarChart();
        String path = "../data/API_AG.LND.FRST.ZS_DS2_en_csv_v2_190.csv";
        String[] bins = {"1992", "1993", "1994", "1995", "1996", "1997", "1998", "1999", "2000", "2001", "2002", "2003", "2004", "2005", "2006", "2007", "2008", "2009", "2010", "2011", "2012", "2013", "2014", "2015", "2016", "2017", "2018", "2019", "2020"};
        Vector<String> arr = new Vector<>();
        Collections.addAll(arr, bins);
        String[] countries= {"United States", "United Kingdom", "Turkiye", "China", "Brazil"};
    	//Parse the data in the file located at path



	    
	    //bridges.setDataStructure(barChart);
        //bridges.visualize();

    }

    /** 
    public static HashMap<String, Vector<Double>> readCsv(String[] countries,String path) {
    	//parse the data into a HashMap with <Country, forest_cover for the country
	//you should have an array of size 19(1992-2020) as Vector<Double> of forest cover for that year	
	}
    */

}

