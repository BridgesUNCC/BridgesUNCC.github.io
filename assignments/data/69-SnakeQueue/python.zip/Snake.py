from bridges.non_blocking_game import NonBlockingGame
from bridges.named_symbol import NamedSymbol
from bridges.named_color import NamedColor
import bridges
from enum import Enum
from random import randrange



class Block:
    def __init__(self, x = -1, y = -1, next=None) -> None:
        self.x = x
        self.y = y
        self.next = next

class Direction(Enum):
    NORTH = 0
    EAST = 1
    SOUTH = 2
    WEST = 3
    
bg = NamedColor.forestgreen
bc = NamedColor.green
fg = NamedColor.silver
hc = NamedColor.white
ac = NamedColor.red

class Snake(NonBlockingGame):
    
    flag = False

    dir: Direction = Direction.EAST
    last_dir: Direction = Direction.EAST
    
    head: Block = Block()
    tail: Block = Block()
    
    apple: Block = Block()
    bombs: list[Block] = [Block(), Block(), Block(), Block(), Block()]
    
    def __init__(self, assid, login, apikey, rows, cols, debug=False):
        super().__init__(assid, login, apikey, rows, cols, debug)
    
    
    def handleInput(self):
        '''Set the direction based on the keyboard'''
    
    def place_in_empty_location(self, block:Block) -> Block:
        '''find an empty location and place the block there'''
        return block
    
    def update_position(self):
        '''move the snake in one block in the current direction'''
    
    def place_apple(self):
        self.apple = self.place_in_empty_location(self.apple)
        
    def place_all_bombs(self):
        for i in range(5):
            self.bombs[i] = self.place_in_empty_location(Block())
            
    def place_bomb(self, bomb:Block):
        self.bombs[self.bombs.index(bomb)] = self.place_in_empty_location(bomb)
        
    def detect_apple(self):
        '''If the head is over the apple, enqueue'''
    
    def detect_bomb(self):
        '''if the head is over any of the bombs, dequeue'''
        
    def detect_death(self):
        '''detect an overlap between head and any other snake block'''
                
    
    def paint(self):
        #paint alternating colors for the background
        for i in range(0, 30):
            for j in range(0, 30):
                if (i % 2 == j % 2):
                    self.set_bg_color(j, i, bg)
                else:
                    self.set_bg_color(j, i, bc)
        
        #make the head a different color 
        self.set_bg_color(self.head.y, self.head.x, hc)
        
        #draw the apple 
        self.draw_symbol(self.apple.y, self.apple.x, NamedSymbol.apple, NamedColor.white)
        
        #place the bombs
        for bomb in self.bombs:
            self.draw_symbol(bomb.y, bomb.x, NamedSymbol.bomb, NamedColor.red)
        
        #draw the snake
        current = self.head.next
        while (current != None):
            self.set_bg_color(current.y, current.x, fg)
            current = current.next
    
    def initialize(self):
        self.head = Block(15, 15)
        self.tail = self.head
        
        apple = Block()
        for i in range(0, 9):
            self.bombs[i] = Block()
        
        self.place_apple()
        self.place_all_bombs()
        
        self.paint()
        
        for i in range(0, 3):
            self.set_bg_color(15, 15 - i, fg)
            if (i > 0):
                self.tail = Snake.enqueue(self.tail, Block(15 - i, 15))
    
    
    def game_loop(self):
        if self.flag:
            self.handleInput()
            self.last_dir = self.dir
            self.detect_apple()
            self.detect_bomb()
            
            self.update_position()
            
            self.paint()
            
            self.detect_death()
        else:
            self.flag = self.key_space()

        
        
  
    
    def enqueue(tail:Block, next:Block) -> Block:
        '''add a new block to the snake'''
        return tail

    def dequeue(head:Block) -> Block:
        '''remove a block from the snake'''
        return head


if __name__ == '__main__':
    game = Snake(269, "bridges username", "api key", 30, 30)
    game.set_title("snake")
    game.set_description("Snake: Eat the food, not bombs, not yourself! (press space to start)")
    game.fps = 15

    game.start()
