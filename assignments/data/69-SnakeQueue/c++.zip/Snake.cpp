#include <NonBlockingGame.h>
#include <stdlib.h>
#include <ctime>
 
using namespace bridges::game;
using namespace std;

// this structure represents a  block that will be used to represent the snake with 
// a starting number of blocks. The snake can grow or shrink bepending on the object
// it hits (apple to grow, bomb to shrink)

struct Block {
    Block *next;
    int x;
    int y;

    Block() : x(-1), y(-1), next(nullptr){}
	Block(int xx, int yy) : x(xx), y(yy), next(nullptr){}
    Block(int xx, int yy, Block* n) : x(xx), y(yy), next(n) {}
};

enum Direction {North, South, East, West};

struct my_snake_queue : public NonBlockingGame {

	// grid size
	int numCols = 30, numRows = 30;

	// starting positions, length
	int startX = numCols/3, startY = numRows/3, startLength = 3;

	// snake, apple, bomb  vars
	Block *head, *tail, apple, bomb[5];

	Direction dir, lastDir;

	// color decls
	NamedColor bg = NamedColor::forestgreen;
	NamedColor bc = NamedColor::green;
	NamedColor fg = NamedColor::silver;
	NamedColor hc = NamedColor::white;
	NamedColor ac = NamedColor::red;

	my_snake_queue (int ass_id, std::string username, std::string apikey) 
				: NonBlockingGame(ass_id, username, apikey, 30, 30) {
					setTitle ("Snake that can grow or shrink!");
					setDescription("Snake: Eat the food, grow, not bombs, not kill yourself! \n\n Press the  Space key to start.");
				}


	// this function sets the direction changes based on key press and 
	// current direction
	// use the 4 arrow keys for moving the snake
	void handleInput () {
	}

	void updatePosition() {

	// move the snake one position, based on its direction 
	// handle edge cases - check to make sure the snake
    // doesnt go off the edge of the board; can do a wrap around
    // in X or Y to handle it. Must handle all 4 directions the snake
    // might be traveling..
    }

	// find a random position for an apple - needed when the snake consumes an
	// apple
	void plantApple() {
	}

	// plant a set of bombs to fill the bomb array -- done initially after which
	// individual bombs will be replaced - again use random locations
	void plantBomb() {
	}
	// plant a bomb to replace one in the bomb array at index i
	void plantBomb(int i) {
	}
	
	// did the snake hit an apple - check for it
	// if it did, then grow the snake - using the enqueue method
	void detectApple() {
	}

	// did the snake hit a bomb - check for it
	// if it did, then shrink the snake - using the dequeue method
	void detectBomb() {
	}

	// Is the snake down to 1 or fewer blocks, exit the application
	void detectDeath() {
    }

	// queue methods to add or remove an element from the snake

	// enqueue a new block return the tail of the snake
	Block *enqueue () {
	}

	// deque the head and return the new snake head 
	Block *dequeue (Block *head) {
	}

	// find a random location to place an apple or a bomb
	void getLocation(int& loc_x, int& loc_y) {

	// make sure the location is not part of the apple, bomb or the snake
	
	}
	  
    // redraw
	void paint() {
	// update the view - background, snake, bombs, apple
	}

    // Set up the first state of the game grid
	virtual void initialize() override {
		// seed the random number generator
		srand(time(0));
		// perform all initializations here and draw the screen

		paint();
    }

    // Game loop will run many times per second.
	// wait to start for space to be pressed
    // handle input, check if apple was detected, update position, redraw,
    // detect if snake ate itself
	virtual void gameLoop() override {
    }
};

int main(int argc, char **argv) {
	// seed the random number generator
	my_snake_queue SnakeGame(169, "BRIDGES_USER_ID", "BRIDGES_API_KEY");

	SnakeGame.start();

	return 0;
}
