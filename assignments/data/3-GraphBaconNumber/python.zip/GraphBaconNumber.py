from bridges import *
import queue

def build_graph(gr):
    actor_list = get_actor_movie_imdb_data(1814)
    
    # TODO Build the actor data into the graph
    # highlight the appropriate actors

def get_bacon_number(gr, src_actor, dest_actor, mark, dist, parent):
    # TODO Traverse the graph and highlight the path between src_actor
    # and dest_actor
        
def main():
    bridges = Bridges(203, "BRIDGES_USER_ID", "BRIDGES_API_KEY")

    bridges.set_title("Bacon Number: IMDB Actor-Movie Data")
    bridges.set_description("Highlights the shortest path between two actors in a Movie Actor graph.")

    gr = GraphAdjList()

    build_graph(gr)

    bridges.set_data_structure(gr)
    bridges.visualize()

    mark = {}
    parent = {}
    dist = {}

    for k, v in gr.vertices.items():
        mark[k] = "unvisited"
        parent[k] = "none"
        dist[k] = 0

    d = get_bacon_number(gr, 'Kevin_Bacon_(I)', 'Cate_Blanchett', mark, dist, parent)

    bridges.set_data_structure(gr)
    bridges.visualize()

if __name__ == '__main__':
    main()
