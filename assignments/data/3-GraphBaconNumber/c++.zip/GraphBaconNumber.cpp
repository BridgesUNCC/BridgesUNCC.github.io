
#include <iostream>
#include <string>
#include <vector>

using namespace std;

#include "Bridges.h"
#include "GraphAdjList.h"
#include "DataSource.h"
#include "data_src/ActorMovieIMDB.h"

using namespace bridges;

//  This class implements computing the Bacon Number of an actor.
//  The Bacon number of an actor or actress is the number of degrees of
//  separation (see Six degrees of separation) they have from actor Kevin
//  Bacon, as defined by the game known as Six Degrees of Kevin Bacon.
//  It applies the Erdős number concept to the movie industry.
//
//  Source : Wikipedia

int getBaconNumber (GraphAdjList<string, string> *gr, string src_actor,
                    string dest_actor);


void buildActorMovieGraph(GraphAdjList<string, string> *gr) {
  // get the actor movie IMDB data through the BRIDGES API
  DataSource ds;
  vector<ActorMovieIMDB> actor_list = ds.getActorMovieIMDBData(1814);

  for (int k = 0; k < actor_list.size(); k++) {
    string actor, movie;

    // get the actor and movie names
    actor = actor_list[k].getActor();
    movie = actor_list[k].getMovie();

    // our graph needs to have a unique set of actors and movies;
    // so create the actor and movie vertices only if they dont already
    // exit; use an STL map to check for that

    // first get the graph's vertex list
    unordered_map<string, Element<string>*> *vertices = gr->getVertices();

    // add actor if it does not exist
    if (vertices->find(actor) == vertices->end())
      gr->addVertex(actor);

    // add movie if it does not exist
    if (vertices->find(movie) == vertices->end())
      gr->addVertex(movie);

    // create the edge -- assumes no duplicate edges
    // undirected graph, edges go both ways
    gr->addEdge(actor, movie);
    gr->addEdge(movie, actor);

    // TODO : Highlight "Cate_Blanchett" node and the movie nodes she is
    // connected to  in "red" and do the same for "Kevin_Bacon_(I)" in "green"
    // specify colors by Color("red"), for example
    //
    // You can get a LinkVisualizer with gr->getLinkVisualizer(src, dest).
    // LinkVisualizer have functions such as setColor().

  }


}

int main() {
  string hilite_color = "orange",
         def_color = "green",
         end_color = "red";

  // Initialize BRIDGES with your credentials
  Bridges bridges(103, "BRIDGES_USER_ID", "BRIDGES_API_KEY");

  // set title for visualization
  bridges.setTitle("Bacon Number: IMDB Actor-Movie Data");
  bridges.setDescription("Highlights the shortest path between two actors in a Movie Actor graph.");

  // use an adjacency list based graph
  GraphAdjList<string> gr;

  buildActorMovieGraph(&gr);

  //set the data structure handle, and visualize the input graph
  bridges.setDataStructure(&gr);
  bridges.visualize();


  getBaconNumber(&gr, "Kevin_Bacon_(I)", "Cate_Blanchett");
  bridges.setDataStructure(&gr);
  bridges.visualize();

  return 0;
}

//
// Computes the Bacon Number of a an actor (#links that takes you from the
// source actor to the destination actor.
//
int getBaconNumber (GraphAdjList<string> *gr,  // input graph
                    string src_actor,          // source actor
                    string dest_actor          // destination actor
                   ) {

  // TODO: Perform a BFS traversal of the graph from src_actor. You will
  // to maintain distance information (basically the number of links from
  // the source actor until the destination node is reached.  Keep
  // parent information as the traversal progresses; once the destination
  // node is found, you will use the parent pointers to follow them to
  // the source node (source node's parent is null).


  // TODO: Highlight all edges and vertices on the shortest path
  // between src_actor and dest_actor; Make the nodes in the path bigger,
  // and the links thicker so that it stands out.

  // temporary to suppress warning, must return bacon number
  return 0;
}
