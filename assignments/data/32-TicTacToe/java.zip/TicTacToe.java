import bridges.base.NamedColor;
import java.util.Scanner;
import bridges.base.NamedSymbol;
import bridges.games.NonBlockingGame;

public class TicTacToe extends NonBlockingGame {
  int frame = 0;
  boolean flag = true;
  boolean board[] = new boolean[9];

  public TicTacToe(int assid, String login, String apiKey) {
    super(assid, login, apiKey, 3, 3);
  }

  @Override
  protected void gameLoop() {
    //  This function is executed each frame of the game;
    //  this is where all your game logic goes in

    // skip the first frame, so that you get a link to the server and then
    // you can connect to the game on the provided link. You must be logged into
    // BRIDGES to see board output and enabled the connection to the server.
    if (frame == 0) {
      frame += 1;
      return;
    }

    // you will need the moves to alternate between the two symbols

    // you need to check for a winner (gameOver() will do that; if a player wins, exit,
    // use exit(1) call  - no other graceful way to terminate in the current implementation)

    // players need to make a move on the board

    // before you make a move, print to console a helpful prompt on what value to enter to
    // play, for instance, 1 through 9. Use standard input to receive the values from
    // the player

    // check the move if it is legal, value outside range, moving into an already occupied
    // position, both cases forfeit the move, and the other player makes the next move

    // the following call simply illustrates how to draw symbols on the board in a particular
    // color; we will draw on positions 1 and 9 (opposite diagonal corners
    // Check the GameBase class for complete documentation

    flag = !flag;
  }

  @Override
  protected void initialize() {
    clearBoard();
  }

  private void drawBoard(int move, NamedSymbol sym) {
    // updates the board with given move
  }

  private boolean checkMove(int move) {
    // checks to see if a legal move was made, check for incorrect input
    // and making a move into an occupied position - in both cases the player
    // forfeits his/her move
    return true;
  }

  private boolean gameOver() {
    // checks the board to see if a player has won: rows, column, diagonal
    return false;
  }

  void clearBoard() {
    // clears the board (use if needed); use NamedSymbol:none to clear a symbol
  }

  public static void main(String args[]) {
    TicTacToe game = new TicTacToe(32, "BRIDGES_USER_ID", "BRIDGES_API_KEY");

    game.setTitle("TicTacToe");
    game.setDescription("Play a fun game of TicTacToe.");
    
    game.start();
  }
}
