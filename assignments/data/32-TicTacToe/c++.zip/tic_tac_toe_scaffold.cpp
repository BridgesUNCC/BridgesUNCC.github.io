#include <NonBlockingGame.h>
#include <iostream>

using namespace bridges::game;

struct my_game : public NonBlockingGame {
  // Need keep track of occupied positions for the board; use
  // a suitable data structure

  // the game skeleton, building a 3x3 board
  my_game(int assID, std::string username, std::string apikey)
    : NonBlockingGame (assID, username,  apikey, 3, 3) {

    // do any needed initializations for the game here
  }
  virtual void initialize() override {
    // initialize the board - you shouldn have to change this
    for (int i = 0; i < getBoardHeight(); ++i)
      for (int j = 0; j < getBoardWidth(); ++j) {
        setBGColor(i, j, NamedColor::ivory);
        drawSymbol(i, j, NamedSymbol::none, NamedColor::ivory);
      }
  }

  virtual void gameLoop() override {
    //  This function is executed each frame of the game;
    //  this is where all your game logic goes in

    static int frame = 0;           // frame number
    static bool flag = true;    // to switch between players

    // skip the first frame, so that you get a link to the server and then
    // you can connect to the game on the provided link. You must be logged into
    // BRIDGES to see board output and enabled the connection to the server.
    if (!frame) { // first frame, continue, will enter this statement only once
      frame++;
      return;
    }

    // you are using two symbols for the game: X and O (see other symbols in
    // the GameBase class (look for NamedSymbol enumerated type)
    enum bridges::game::NamedSymbol sym = (flag) ?  NamedSymbol::X : NamedSymbol::O;

    // you will need the moves to alternate between the two symbols

    // you need to check for a winner (gameOver() will do that; if a player wins, exit,
    // use exit(1) call  - no other graceful way to terminate in the current implementation)

    // players need to make a move on the board

    // before you make a move, print to console a helpful prompt on what value to enter to
    // play, for instance, 1 through 9. Use standard input to receive the values from
    // the player

    // check the move if it is legal, value outside range, moving into an already occupied
    // position, both cases forfeit the move, and the other player makes the next move

    // the following call simply illustrates how to draw symbols on the board in a particular
    // color; we will draw on positions 1 and 9 (opposite diagonal corners
    // Check the GameBase class for complete documentation

    drawSymbol(0, 0, NamedSymbol::X, NamedColor::blue);
    drawSymbol(2, 2, NamedSymbol::O, NamedColor::red);

  }
  bool legalMove (int move) {
    // checks to see if a legal move was made, check for incorrect input
    // and making a move into an occupied position - in both cases the player
    // forfeits his/her move

  }

  void drawBoard (int move, enum bridges::game::NamedSymbol sym) {
    // updates the board with given move
  }
  void clearBoard () {
    // clears the board (use if needed); use NamedSymbol:none to clear a symbol
  }
  bool gameOver() {
    // checks the board to see if a player has won: rows, column, diagonal
  }
};

int main (int argc, char** argv) {
  // put in your BRIDGES credentials
  my_game g(132, "BRIDGES_USER_ID", "BRIDGES_API_KEY");

  g.start();
}
