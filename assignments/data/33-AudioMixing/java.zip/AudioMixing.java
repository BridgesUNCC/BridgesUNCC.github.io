import bridges.connect.Bridges;
import bridges.validation.RateLimitException;
import java.io.IOException;
import bridges.base.AudioClip;
import bridges_external.WavFileException;

public class AudioMixing {

    /**
     * Return a new AudioClip of the two AudioClips mixed together
     */
    private static AudioClip mixClips(AudioClip ac1, AudioClip ac2, float duration) {
        if (ac1.getSampleRate() != ac2.getSampleRate()) {
            throw new IllegalArgumentException("sampling rate must be the same");
        }

        int SAMPLE_RATE = ac1.getSampleRate();
        int sampleCount = (int) (SAMPLE_RATE * duration);

        AudioClip acMix = new AudioClip(sampleCount, 1, ac1.getSampleBits(), SAMPLE_RATE);

        // Loop through the samples of both clips and use the average amplitude value
        // TODO
        return acMix;
    }

    private static AudioClip mixClips(AudioClip ac1, AudioClip ac2) {
        // If no duration is given then just use the minimum song duration
        return mixClips(ac1, ac2, Math.min((float) ac1.getSampleCount() / ac1.getSampleRate(), (float) ac2.getSampleCount() / ac2.getSampleRate()));
    }

    /**
     * This function mixes two audio clips with a fade effect based on the
     * specified fade duration and total duration. The function ensures that the
     * sampling rate of both audio clips is the same, throwing an
     * IllegalArgumentException if not. It creates a new AudioClip with the
     * desired sample count, sample bits, and sample rate for the mixed audio.
     * The fade effect is applied by gradually adjusting the amplitude of the
     * samples in both input clips around the center point of the mix, creating
     * a smooth transition. The fade duration is capped to prevent it from
     * exceeding the clip duration.
     */
    
    /**
     * Function that mixes two audio clips with a fade effect. If no duration is
     * given for the audio clips, the function uses the minimum duration among
     * the provided clips. If no fade duration is specified, it defaults to half
     * of the total duration. The function then calls another overloaded version
     * of itself to perform the actual mixing with the specified fade and total
     * durations.
     */
    
    public static void main(String[] args) throws IOException, WavFileException, RateLimitException {
        Bridges bridges = new Bridges(33, "BRIDGES_USER_ID", "BRIDGES_API_KEY");

        bridges.setTitle("Audio Mixing");
        bridges.setDescription("Mixing two AudioClips together");

        // Path to the audio folder
        // If you have issues with unrecognized paths, try making this path absolute instead of relative
        final String AUDIO_PATH = "../audio/";

        // Load the clips
        AudioClip acPiano = new AudioClip(AUDIO_PATH + "piano.wav");
        bridges.setDataStructure(acPiano);
        bridges.visualize();

        AudioClip acBass = new AudioClip(AUDIO_PATH + "bass.wav");
        bridges.setDataStructure(acBass);
        bridges.visualize();

        // Apply simple mixing of the two AudioClips and visualize
        AudioClip acMix = mixClips(acPiano, acBass);
        bridges.setDataStructure(acMix);
        bridges.visualize();

        // Apply fade mixing to the two AudioClips and visualize
        // TODO
    }

}
