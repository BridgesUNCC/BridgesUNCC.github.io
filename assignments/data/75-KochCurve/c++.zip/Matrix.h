
#ifndef MATRIX_H

#define MATRIX_H 1
class Matrix {
	private:
		int rows, cols;
		double el[3][3];

	public:
		Matrix() {
			rows = 3; cols = 3;

			// default is identity matrix
			for (int i = 0; i < 3; i++) 
			for (int j = 0; j < 3; j++)
				el[i][j] = (i == j) ? 1. : 0.;
		}

		void set(int row, int col, double val) {
			el[row][col] = val;
		}
		double get(int row, int col) {
			return el[row][col];
		}

		// matrix-matrix multiplication
		Matrix operator *(Matrix m) {
			Matrix result;
			for (int i = 0; i < 3; i++) {
				for (int j = 0; j < 3; j++) {
					double sum = 0.;
					for (int k = 0; k < 3; k++) 
						sum += get(i,k)*m.get(k,j);
					result.set(i, j, sum);
				}
			}
			return result;
		}
};

#endif
