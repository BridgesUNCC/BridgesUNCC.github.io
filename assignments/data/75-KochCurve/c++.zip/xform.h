#include "Matrix.h"
#include <cmath>
#include <iostream>

#ifndef XFORM_H
#define  XFORM_H 1

Matrix translate (double, double);
Matrix scale (double, double);
Matrix rotate (double);
Matrix rotateAboutPoint(double, double*);
Matrix matMult(Matrix m1, Matrix m2);
void matVecMult(Matrix m1, double *vec, double* result);
void printMat(Matrix m1);

Matrix  translate (double tx, double ty) {
	Matrix m;
	m.set(0, 2, tx);
	m.set(1, 2, ty);

	return m;
}
Matrix  scale (double sx, double sy) {
	Matrix m;
	m.set(0, 0, sx);
	m.set(1, 1, sy);

	return m;
}

Matrix rotate(double angle) {
	Matrix m;
	double rads = angle*M_PI/180.;
	m.set(0, 0, cos(rads)); m.set(0, 1, -sin(rads));
	m.set(1, 0, sin(rads)); m.set(1, 1, cos(rads));

	return m;
}


Matrix rotateAboutPoint(double angle, double *pt) {
	double pt_neg[] = {-pt[0], -pt[1], 1.};

//	Matrix m = matMult(translate(pt[0], pt[1]), 
//				matMult(rotate(angle), translate(-pt[0], -pt[1])));
	Matrix m = translate(pt[0], pt[1])*rotate(angle)*translate(-pt[0],-pt[1]);

	return m;
}

// matrix - matrix multiplication
Matrix matMult (Matrix m1, Matrix m2) {
	Matrix result;
	for (int k = 0; k < 3; k++) 
	for (int j = 0; j < 3; j++)
		result.set(k,j, 0.);

	for (int i = 0; i < 3; i++) {
		for (int j = 0; j < 3; j++) {
			double sum = 0.;
			for (int k = 0; k < 3; k++) 
				sum += m1.get(i,k)*m2.get(k,j);
			result.set(i, j, sum);
		}
	}
	return result;
}

// matrix - vector multiplication
void matVecMult (Matrix m, double *v, double *result) {

	result[0] = m.get(0,0)*v[0] + m.get(0, 1)*v[1] + m.get(0,2)*v[2];
	result[1] = m.get(1,0)*v[0] + m.get(1, 1)*v[1] + m.get(1,2)*v[2];
	result[2] = m.get(2,0)*v[0] + m.get(2, 1)*v[1] + m.get(2,2)*v[2];
}

void printMat(Matrix m) {
	for (int i = 0; i < 3; i++) {
		for (int j = 0; j < 3; j++) {
			std::cout << m.get(i,j) << " ";
		}
		std::cout << "\n";
	}
}

#endif
