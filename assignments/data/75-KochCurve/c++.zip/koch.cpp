#include "Bridges.h"
#include "SymbolCollection.h"
#include "Polyline.h"
#include "xform.h"
#include <cmath>

using namespace bridges;

#include <utility>

using namespace std;

double degree_to_rad(double d) {
  return d * M_PI / 180;
}

// illustrates drawing a Koch Curve and Koch Snowflake using the 
// Symbol Collection in BRIDGES

SymbolCollection *KochCurve(double *pt1, double* pt2,  int order);
SymbolCollection *KochSnowFlake(double *pt1, double* pt2, double*pt3,int order);
void KochCurve_R(double *pt1, double *pt2, Polyline& p, int order);

int main() {

	//create the Bridges object, set credentials
	Bridges bridges(175, "BRIDGES_USER_ID", "BRIDGES_API_KEY");

	bridges.setTitle("Koch Curve");

	// define the initial points for the Koch curve
	// curve will be generated between the two points
	double pt1[] = {-40., 0.}; double pt2[] = {40., 0.};

	SymbolCollection *sc = KochCurve(pt1, pt2, 7);
	bridges.setDataStructure(sc);

	// visualize the list without locations (set location coords to infinity
	bridges.visualize();

	// add the 3rd point to form an equilateral triangle for the Koch
	// snowflake
	double pt3[] = {0, sqrt(4800.)};

	// create the snow flake
	sc = KochSnowFlake(pt1, pt2, pt3, 7);
	bridges.setDataStructure(sc);

	// visualize the list without locations (set location coords to infinity
	bridges.visualize();
	
	return 0;
}

// draws a Koch curve of a given order
SymbolCollection* KochSnowFlake (double *pt1, double *pt2, double *pt3, int order) {

	// initializations to put the curve points in a symbol collection
	SymbolCollection *sc = new SymbolCollection();
		sc->setViewport (-40., 40., -40., 40.);
	
	// points are part of a polyline object
	Polyline p;

	// TODO: create Koch curves for the 3 edges of the triangle

	// add the polyline to the symbol collection	
	sc->addSymbol (p);

	return sc;
}
// draws a Koch curve of a given order
SymbolCollection *KochCurve (double *pt1, double *pt2, int order) {

	SymbolCollection *sc = new SymbolCollection();
		sc->setViewport (-40., 40., -40., 40.);
	
	Polyline p;

	// create the Koch curve
	KochCurve_R (pt1, pt2, p, order);

	// return the polyline with all the curve points
	sc->addSymbol(p);

	return sc;
}

void KochCurve_R (double *pt1, double *pt2, Polyline& p, int order) {
	// this function generates the Koch curve between the pt1 and pt2
	//TODO create cutoff using order, and if not cutoff, rotate then perform recursion
		
}

