from bridges import Polyline, SymbolCollection, Bridges
import numpy as np

# Class Koch contains methods for implementing Koch curve and handling recursion
class Koch:

    # Create koch curve between 2 points
    # pt1: first point (list of 2 float values)
    # pt2: second point (list of 2 float values)
    # order: number of recursions (int)
    def koch_curve(self, pt1: list[float], pt2: list[float], order: int):

        #initializes collection/line and sets viewport
        collection = SymbolCollection()
        collection.setviewport(-40, 40, -40, 40)
        polyline = Polyline()

        # Create koch curve between pt1 and pt2 (recursively)
        self.koch_r(pt1, pt2, polyline, order)

        #adds the curve to collection for visualizing
        collection.add_symbol(polyline)
        return collection
    
    # Creates koch curve between 3 points in a equilateral triangle
    # pt1: first point (list of 2 float values)
    # pt2: second point (list of 2 float values)
    # pt3: third point (list of 2 float values)
    # order: number of recursions (int)
    def koch_snowflake(self, pt1: list[float], pt2: list[float], pt3: list[float], order: int):
        
        #initializes collection/line and sets viewport
        sc = SymbolCollection()
        sc.setviewport(-40, 40, -40, 40)
        p = Polyline()

        #todo: create koch curve between all 3 edges  of the triangle

        #adds curve to collection for visualizing
        sc.add_symbol(p)
        return sc
    
    # does the recursion for both koch curves
    # pt1: first point (list of 2 float values)
    # pt2: second point (list of 2 float values)
    # polyline: Polyline object to set points on after recursion is finished
    # order: number of recursions (int)
    def koch_r(self, pt1: list[float], pt2: list[float], polyline: Polyline, order: int):
        #TODO set cutoff point for recursion, if it isnt the cutoff, then rotate and call recursion
        return
    
    
# Main function used for creating bridges object
# and SymbolCollections used for visualization            
def main():
    #create bridges object with creditials
    bridges = Bridges(75, "clarson9", "761846361890")
    bridges.set_title("Koch Curves")
    bridges.set_description("Koch curve with recursion")

    # create points/objects
    pt1: list[float] = [-40, 0]
    pt2: list[float] = [40, 0]
    koch: Koch = Koch()
    #makes symbol using koch_curve
    symbolCollection: SymbolCollection =  koch.koch_curve(pt1, pt2, 7)

    #visualize
    bridges.set_data_structure(symbolCollection)
    bridges.visualize()

    #adds 3rd point
    pt3: list[float] = [0, np.sqrt(4800)]
    #get symbol returned by koch_snowflake
    symbolCollection = koch.koch_snowflake(pt1, pt2, pt3, 7)
    
    #visualize
    bridges.set_data_structure(symbolCollection)
    bridges.visualize()


if __name__ == '__main__':
    main()
