import java.io.IOException;

import java.awt.geom.AffineTransform;

import bridges.base.Polyline;
import bridges.base.SymbolCollection;
import bridges.connect.Bridges;
import bridges.validation.RateLimitException;

// illustrates drawing a Koch Curve and Koch Snowflake using the 
// Symbol Collection in BRIDGES

public class Koch {
    /*
     * converts degrees to their radian counterpart Ex: 360 into 2Pi
     * @param d the turn radius in degrees
     * @returns the number of radians coresponding to the degree
     */
    public static double degree_to_rad(double d){
        return d * Math.PI / 180.0;
    }

    /*
     * Creates a koch curve between 2 points
     * @param pt1 the first point with a x and y coord
     * @param pt2 the second point with a x and y coord
     * @param order the number of times to perform recursion
     */
    public static SymbolCollection koch(double[] pt1, double[] pt2, int order){
        SymbolCollection symbolCollection = new SymbolCollection();

		// set viewport and create symbol collection related objects
        symbolCollection.setViewport(-40, 40, -40, 40);
        Polyline polyline = new Polyline();

		// create the Koch curve between pt1 and pt2
        KochCurve_R(pt1, pt2, polyline, order);

		// create the Koch Snowflake
        symbolCollection.addSymbol(polyline);

        return symbolCollection;
    }

    /*
     * Creates a koch curve using a equalaterial triangle
     * Uses recursion on each side
     * @param pt1 the first point with an x and y coord
     * @param pt2 the second point with an x and y coord
     * @param pt3 the third point with an x and y coord
     * @param order the number of times to perform recursion
     */
    public static SymbolCollection KochSnowFlake(double[] pt1, double[] pt2, double[] pt3, int order){
        SymbolCollection symbolCollection = new SymbolCollection();
        symbolCollection.setViewport(-40, 40, -40, 40);
        Polyline polyline = new Polyline();

		// TODO: Create Koch curves for the 3 edges of the equilateral triangle

		// add to symbol collection
        symbolCollection.addSymbol(polyline);

        return symbolCollection;
    }
    /*
     * Recursion method for koch curve
     * rotates 1/3rd midpoint around 2/3rd midpoint
     * @param pt1 the first point with an x and y coord
     * @param pt2 the second point with an x and y coord
     * @param polyline The line to modify
     * @param order Number of recursions
     */
    public static void KochCurve_R(double[] pt1, double pt2[], Polyline polyline, int order){
        //TODO Set endpoint for recursion, if not endpoint, rotate and recurse
    }
    /*
     * Main method, initializes bridges object, initializes first points,
     * and creates symbolcollections
     */
    public static void main(String[] args) throws IOException, RateLimitException {
		//create the Bridges object, set credentials
        Bridges bridges = new Bridges(75, "User ID", "User API key");
        bridges.setTitle("Koch Curves");
        bridges.setDescription("Koch curve with recursion");

        double[] pt1 = {-40, 0};
        double[] pt2 = { 40, 0};

		// create the Koch curve between two points, pt1 and pt2
        SymbolCollection symbolCollection = koch(pt1, pt2, 7);

		// visualize
        bridges.setDataStructure(symbolCollection);
        bridges.visualize();

		// create the Koch Snowflake (basicall koch curve between
		// 3 points in an equilateral triangle
        double pt3[] = {0, Math.sqrt(4800)};

        symbolCollection = KochSnowFlake(pt1, pt2, pt3, 7);

		// visualize
        bridges.setDataStructure(symbolCollection);
        bridges.visualize();
    }
}
