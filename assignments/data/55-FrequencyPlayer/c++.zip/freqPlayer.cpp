#include "Bridges.h"
#include "AudioClip.h"

using namespace std;
using namespace bridges;

// Time is measured in seconds
static int generateSineSample(double frequency, double amplitude, double time){
	/*
    Part 1:
    Complete this method.
    This method is called once for every sample in the clip.
    It should return the appropriate sample value for each sample to generate a sine wave.
    The formula for a sine wave is: A * sin(2 * pi * f * t), where A is amplitude, f is frequency, and t is time in seconds
    */
	
	
}

void addSound(AudioClip& ac, double start, double end, double volume, double freq){

    // Plug this value in for the amplitude of the sine wave.
	// It scales the amplitude value by the volume as a percentage (1.0 is max, 0.0 is min)
    double amplitudeMultiplier = ((pow(2, 32) / 2.0) - 1.0)*volume;
    // Number of oscillations per second, 261.63 is middle C (on piano)
    double frequency = freq;
    // The number of samples needed for a complete sine wave at that frequency
    double period = ac.getSampleRate() / freq;
	
	// Initializes firstSample and lastSample to the first and last sample in the clip.
    int firstSample = 0;
    int lastSample = 20 * 44100;

    /*
    Part 2:
    Reassign firstSample and lastSample so that they use the start and end parameters in this method
    Start and end are where the sine wave should start and end, in seconds.
    You'll need to turn those values into the proper sample numbers somehow.
    */
	
	// For part 2, uncomment the lines below:
    /*
    firstSample =
    lastSample =
    */

	/*
	Part 3:
	If a sine wave ends on a sample value other than zero, it makes a cracking noise.
	To prevent this, we'll need to change lastSample's value so that it always lands on a zero value sample.
	The period variable above may be useful for this.
	*/

    // For part 3, uncomment the line below:
    /*
    lastSample =
    */

    // Iterates over all the samples in the clip from firstSample to lastSample.
    for (int i = firstSample; i < lastSample; i++) {

        // The current second (with decimals) of the clip
        double time = (double)i / ac.getSampleRate();
        int sampleValue = generateSineSample(frequency, amplitudeMultiplier, time);

        // Set the sample at i to the new value
        ac.setSample(0, i, sampleValue);
    }
}

int main(int argc, char **argv) {
    // create the Bridges object, set credentials
    Bridges bridges(155, "BRIDGES_USER_ID", "BRIDGES_API_KEY");
    bridges.setTitle("FreqPlayer");
    bridges.setDescription("This assignment uses the BRIDGES API to generate and visualize audio clips by creating sine wave samples at different frequencies.");

    // Length of the clip in seconds
    const float LENGTH = 20;
    const int SAMPLE_FREQ = 44100;
    const int SAMPLE_COUNT = (int) (LENGTH*SAMPLE_FREQ);

    AudioClip ac(SAMPLE_COUNT, 1, 32, SAMPLE_FREQ);

    addSound(ac, 0, 10, 0.2, 261.63);
    addSound(ac, 10, 20, 0.2, 523.251);

    bridges.setDataStructure(ac);
    bridges.visualize();
    
    return 0;
}
