from bridges import *

def main():
    # create the Bridges object, set credentials
    bridges = Bridges(55, "BRIDGES_USER_ID", "BRIDGES_API_KEY")
    bridges.set_title("FreqPlayer")

    # Length of the clip in seconds
    LENGTH = 20
    SAMPLE_FREQ = 44100
    SAMPLE_COUNT = LENGTH*SAMPLE_FREQ

    ac = AudioClip(sample_count=SAMPLE_COUNT, num_channels=1, sample_bits=32, sample_rate=SAMPLE_FREQ)

    addSound(ac, 0, 10, 0.2, 261.63)
    addSound(ac, 10, 20, 0.2, 523.251)

    bridges.set_data_structure(ac)
    bridges.visualize()

def addSound(ac, start, end, volume, freq):

    # Plug this value in for the amplitude of the sine wave.
	# It scales the amplitude value by the volume as a percentage (1.0 is max, 0.0 is min)
    amplitudeMultiplier = (((2 ** 32) / 2.0) - 1.0)*volume
    # Number of oscillations per second, 261.63 is middle C (on piano)
    frequency = freq
    # The number of samples needed for a complete sine wave at that frequency
    period = ac.get_sample_rate() / freq
	
	# Initializes firstSample and lastSample to the first and last sample in the clip.
    firstSample = 0
    lastSample = 20 * 44100

    """
    Part 2:
    Reassign firstSample and lastSample so that they use the start and end parameters in this method
    Start and end are where the sine wave should start and end, in seconds.
    You'll need to turn those values into the proper sample numbers somehow.
    """
	
	# For part 2, uncomment the lines below:
    """
    firstSample =
    lastSample =
    """

    """
    Part 3:
    If a sine wave ends on a sample value other than zero, it makes a cracking noise.
    To prevent this, we'll need to change lastSample's value so that it always lands on a zero value sample.
	The period variable above may be useful for this.
    """

	# For part 3, uncomment the line below:
    """
    lastSample =
    """

    # Iterates over all the samples in the clip from firstSample to lastSample.
    for i in range(firstSample, lastSample):

        # The current second (with decimals) of the clip
        time = i / ac.get_sample_rate()
        sampleValue = int(generateSineSample(frequency, amplitudeMultiplier, time))

        # Set the sample at i to the new value
        ac.set_sample(0, i, sampleValue)

"""
* Gives the appropriate sample value for a sine wave with the specified frequency and amplitude at the given time
* @param frequency Frequency of the sine wave, in hertz
* @param amplitude Amplitude of the sine wave, as a sample value of a Bridges AudioClip
* @param time The time in the sine wave to generate a sample for, in seconds
* @return The sample value at that time.
"""
def generateSineSample(frequency, amplitude, time):
    """
    Part 1:
    Complete this method.
    This method is called once for every sample in the clip.
    It should return the appropriate sample value for each sample to generate a sine wave.
    The formula for a sine wave is: A * sin(2 * pi * f * t), where A is amplitude, f is frequency, and t is time in seconds
    """
    
    
    
if __name__ == "__main__":
    main()