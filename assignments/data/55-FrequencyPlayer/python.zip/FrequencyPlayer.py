from bridges import *

def main():
    # create the Bridges object, set credentials
    bridges = Bridges(255, "BRIDGES_USER_ID", "BRIDGES_API_KEY")
    bridges.set_title("FreqPlayer")
	bridges.set_description("This assignment uses the BRIDGES API to generate and visualize audio clips by creating sine wave samples at different frequencies.")

    # Length of the clip in seconds
    LENGTH = 20
    SAMPLE_FREQ = 44100
    SAMPLE_COUNT = LENGTH * SAMPLE_FREQ

    ac = AudioClip(sample_count=SAMPLE_COUNT, num_channels=1, sample_bits=32, sample_rate=SAMPLE_FREQ)

    addSound(ac, 0, 10, 0.2, 261.63)
    addSound(ac, 10, 20, 0.2, 523.251)

    bridges.set_data_structure(ac)
    bridges.visualize()


def addSound(ac, start, end, volume, freq):
    # Plug this value in for the amplitude of the sine wave.
    # It scales the amplitude value by the volume as a percentage (1.0 is max, 0.0 is min)
    # Number of oscillations per second, 261.63 is middle C (on piano)
    # The number of samples needed for a complete sine wave at that frequency

    # Initializes firstSample and lastSample to the first and last sample in the clip.

    # Part 2:
    # Reassign firstSample and lastSample so that they use the start and end parameters in this method
    # Start and end are where the sine wave should start and end, in seconds.
    # You'll need to turn those values into the proper sample numbers somehow.

    # Part 3:
    # If a sine wave ends on a sample value other than zero, it makes a cracking noise.
    # To prevent this, we'll need to change lastSample's value so that it always lands on a zero value sample.
    # The period variable above may be useful for this.

    # Iterates over all the samples in the clip from firstSample to lastSample.
    # The current second (with decimals) of the clip
    # Set the sample at i to the new value

    # Gives the appropriate sample value for a sine wave with the specified frequency and amplitude at the given time
    # @param frequency Frequency of the sine wave, in hertz
    # @param amplitude Amplitude of the sine wave, as a sample value of a Bridges AudioClip
    # @param time The time in the sine wave to generate a sample for, in seconds
    # @return The sample value at that time.
    pass

def generateSineSample(frequency, amplitude, time):
    # Part 1:
    # Complete this method.
    # This method is called once for every sample in the clip.
    # It should return the appropriate sample value for each sample to generate a sine wave.
    # The formula for a sine wave is: A * sin(2 * pi * f * t),
    # where A is amplitude, f is frequency, and t is time in seconds

    # Generates the sine value
    # Scales it by the amplitude value
    pass


if __name__ == '__main__':
    main()
