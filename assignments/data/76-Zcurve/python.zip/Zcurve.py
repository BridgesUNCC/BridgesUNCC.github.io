from bridges.symbol_collection import *
from bridges.bridges import *
from bridges.circle import *
from bridges.polygon import *
from bridges.rectangle import *
from bridges.text import *
from bridges.color import *
from bridges.text import *
import sys

# Zcurve generation using recursion
# Method. At zero order, generates a single point of the bounding box
# Each additional order divides the bounding box into 4 equal areas and 
# generates point within each. The sequence of points by virtue of its
# ordering (upper left, upper right, lower left and lower right generats
# the connected  curve


def Zorder(minx, maxx, miny, maxy, depth, poly):
    """
    Student work here:
    
    Base case:
        - add the center point to the poly line
    General Recursion:
        - Recurse on upper left
        - Recurse on upper right
        - Recurse on lower left
        - Recurse on lower right
    """
    pass

#do we need different cases for different orientations?
        

def main():

    # create the Bridges object, set credentials
    bridges = Bridges(76, "YOUR_USER_ID", "YOUR_API_KEY")

    # title, description
    bridges.set_title("Symbol Collection")
    bridges.set_description("Z curve generation");

	# create polyline  to store the Z curve points
    pl = Polyline()

	# set attributes
    pl.stroke_color = "magenta"
    #Hilbert(0., 100., 0., 100., 2, pl)
    pl.stroke_width = 0.5
    pl.opacity = 1.0

	# generate Z curve
    Zorder(-100., 100., -100., 100., 6, pl)

	# add to symbol collection
    sc = SymbolCollection()
    sc.add_symbol(pl)

	# set data structure, visualize
    bridges.set_data_structure(sc)
    bridges.visualize()


if __name__ == "__main__":
    main()
