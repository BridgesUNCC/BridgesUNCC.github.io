#include "Bridges.h"
#include "SymbolCollection.h"
#include "Polyline.h"

using namespace bridges;
// Zcurve generation using recursion
// Method. At zero order, generates a single point of the bounding box
// Each additional order divides the bounding box into 4 equal areas and 
// generates point within each. The sequence of points by virtue of its
// ordering (upper left, upper right, lower left and lower right generats
// the connected  curve
void zcurve_R(float minX, float maxX, float minY, float maxY, int depth, Polyline *poly);

int main() {
	Bridges bridges(176, "BRIDGES_USER_ID", "BRIDGES_API_KEY");
    bridges.setTitle("Z curve Generation");
	bridges.setDescription("Space Filling Z-Curve");

	// use a polyline to hold the Z curve
	Polyline pl;

	// set its attributes
	pl.setStrokeColor("magenta");
	pl.setStrokeWidth(0.5f);
	pl.setOpacity(1);

	// generate the Z curve
	zcurve_R(-100, 100, -100, 100, 6, &pl);

	// add polyline to the symbol collection
	SymbolCollection sc;
	sc.addSymbol(pl);

	bridges.setDataStructure(&sc);
	bridges.visualize();
}

void zcurve_R(float minX, float maxX, float minY, 
				float maxY, int depth, Polyline *poly){
		/*
		Student work here:
    
		Base case:
			- add the center point to the poly line
		General Recursion:
			- Recurse on upper left
			- Recurse on upper right
			- Recurse on lower left
			- Recurse on lower right
		
		*/
}
