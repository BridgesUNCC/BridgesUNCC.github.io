import java.io.IOException;

import bridges.base.Polyline;
import bridges.base.SymbolCollection;
import bridges.connect.Bridges;
import bridges.validation.RateLimitException;

class Zcurve{
    public static void Zorder(float minX, float maxX, float minY, float maxY, int depth, Polyline polyline){
        /**
         * todo: Implement Zorder algorithm recursively
         * 
         * The algoritm can be described
         *  - The lowest depth should just place a point in the center of the square defined by minX, maxX, minY, and maxY
         *  - Every other depth should split it into 4 quadrants and call again
         *      - half x to max x & min y to half y
         *      - min x to half x & min y to half y
         *      - half x to max x & half y to max y
         *      - min x to half x & half y to max y
         *      
         * Learn more about Zorder here https://en.wikipedia.org/wiki/Z-order_curve
         */
    }

    public static void main(String[] args) throws IOException, RateLimitException {
        Bridges bridges = new Bridges(76, "USER_ID", "API_KEY");
        
        bridges.setTitle("Z-Curve");
        bridges.setDescription("An implementation of the space filling curve Z-curve");

        SymbolCollection symbolCollection = new SymbolCollection();
        Polyline polyline = new Polyline();

        polyline.setStrokeColor("magenta");
        polyline.addPoint(0, 0);
        Zorder(-50, 50, -50, 50, 5, polyline);
        polyline.setStrokeWidth(0.5f);
        polyline.setOpacity(1);
        symbolCollection.addSymbol(polyline);

        bridges.setDataStructure(symbolCollection);
        bridges.visualize();
    }
}
