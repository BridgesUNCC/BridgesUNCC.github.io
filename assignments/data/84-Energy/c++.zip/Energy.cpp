/**
 * Created by Kalpathi Subramanian, 1/30/18
 * krs@uncc.edu
 */

#include "Bridges.h"
#include "DataSource.h"
#include "BarChart.h"

#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <sstream>
#include <unordered_map>

using namespace std;


std::unordered_map<string, vector<float>> readCsv(string name)
{
	unordered_map<string, vector<float>> obj;
	//return map of <country, vector of countries energy consumption
	
	return obj;
}

int main (int argc, char **argv) {

   // parse the csv file by implementing above function
    std::unordered_map<std::string, std::vector<float>> table = readCsv("../data/global-data-on-sustainable-energy.csv");
    //create Bridges object
    bridges::Bridges bridges (184, "BRIDGES_USERNAME", "BRIDGES_APIKEY");

    //initialize countries and data list
    std::vector<std::string> bins = {"United States", "United Kingdom", "Turkey", "China", "Brazil"};
    //CODE HERE
    


    // bridges.setDataStructure(bar);
    // bridges.visualize();
    bridges.setTitle("Energy Consumption per Capita");
    bridges.setDescription("Visualize Data in the form of a Bar Chart");


    return 0;
}
