
import json
from bridges import *
from bridges.bar_chart import *


# Creating function to read in data from csv
def read_file(fileName: str):
	# return a dictionary of <Country, Countries Energy Consumption over x years in a list
    return data_dict


if __name__ == '__main__':


	# Parse The data by implementing above function
    table = read_file("../data/global-data-on-sustainable-energy.csv")
    bridges = Bridges(284, "BRIDGES_USERNAME", "BRIDGES_APIKEY")
    bridges.set_title("Energy Consumption per Capita")
    bridges.set_description("Visualize Data in the form of a Bar Chart")
    bins = ["United States", "United Kingdom", "Turkey", "China", "Brazil"]

	#CODE HERE

	



    bar = BarChart()
    bar.set_title("Energy Consumption Per Capita")
    bar.set_plot_sub_title("(kWh/person)")
    bar.set_bins_label("Country")
    bar.set_series_label("Killowatt hours")
    bar.set_alignment("vertical")
    bar.set_tooltip_suffix("Killowatt hours per capita")
    bar.set_series_bins(bins)
    bar.add_series_data("Energy Consumption", data)
    bar.get_data_structure_representation()
    bridges.set_json_flag(True)
    bridges.set_data_structure(bar)
    bridges.visualize()
