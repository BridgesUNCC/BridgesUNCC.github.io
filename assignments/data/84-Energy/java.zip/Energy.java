import bridges.base.BarChart;
import bridges.connect.Bridges;
import bridges.validation.RateLimitException;


import java.io.*;
import java.util.*;

//
// This tutorial creates a set of singly linked list elements, links them
// and displays them
//
// Reference: SLelement, Bridges classes
//
/**
public class energy_scaffold {

    public static void main(String[] args) throws RateLimitException, IOException {


        // Create Bridges object,  fill in credentials
        Bridges bridges = new Bridges(ASSIGNMENT_NUMBER, USERNAME, BRIDGES_API_KEY);
        BarChart barChart = new BarChart();
        barChart.setTitle("Energy Consumption per Capita");
        barChart.setDescription("Visualize Data in the form of a Bar Chart");
	String[] temp = {"United States", "United Kingdom", "Turkey", "China", "Brazil"};

	// bar chart year range is 2000 - 2021 not including 2021


        bridges.setDataStructure(barChart);
        bridges.visualize();

    }

    public static HashMap<String,Vector<Double>> read_csv(String[] arr, String path) {
    //use this function to parse the graph to build a HashMap <Country, array of Energy Consumption for Country
	}
}
**/
