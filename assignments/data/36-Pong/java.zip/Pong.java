import bridges.games.NonBlockingGame;
import bridges.base.NamedSymbol;
import bridges.base.NamedColor;

public class Pong extends NonBlockingGame {

    public Pong(int assid, String login, String apiKey) {
        super(assid, login, apiKey, 20, 50);
        rows = 20;
        cols = 50;
    }

    //adds paddles and balls
    Paddle player_one, player_two;
    Ball ball;

    //scores and game barriers
    int score1 = 0, score2 = 0;
    int rows;
    int cols;

    // Handles user input for controlling the paddles.
    public void handleInput() {
        // If the 'W' key is pressed and the first player's paddle is not at the top boundary move the first player's paddle up by 1 unit

        // If the 'S' key is pressed and the first player's paddle is not at the bottom boundary move the first player's paddle down by 1 unit
        
        // If the 'Up' arrow key is pressed and the second player's paddle is not at the top boundary move the second player's paddle up by 1 unit
        
        // If the 'Down' arrow key is pressed and the second player's paddle is not at the bottom boundary move the second player's paddle down by 1 unit
    }

    // Draws ball and paddles
    public void draw() {
        // Loop through the columns of the game area for each column then loop through the rows of the game area and set the background color of each cell to black

        // Loop through the length of the first player's paddle and set the background color of the cells occupied by the first player's paddle to white
        // This visually represents the first player's paddle on the screen
        
        // Loop through the length of the second player's paddle and set the background color of the cells occupied by the second player's paddle to white
        // This visually represents the second player's paddle on the screen
        
        // Set the background color of the cell occupied by the ball to white
        // This visually represents the ball on the screen
    }

    // Controls ball movement
    public void ballPlay() {
        // Decrement the y position of the ball based on its vertical velocity
        // Decrement the x position of the ball based on its horizontal velocity
        
        // Check if the ball has reached the top or bottom boundary of the game area
        // If the ball has reached the left or right boundary then reverse the y velocity of the ball
        // This simulates the bouncing effect of the ball on the left and right walls

        // Check if the ball has reached the leftmost boundary of the game area
        // If the ball has reached the leftmost boundary then set both the horizontal and vertical velocities of the ball to 0
        // Increment the score of player 2 and reset the position of the ball to the center of the game area

        // Check if the ball has reached the rightmost boundary of the game area
        // If the ball has reached the rightmost boundary then set both the horizontal and vertical velocities of the ball to 0
        // Increment the score of player 1and reset the position of the ball to the center of the game area
    }

    // Updates and displays score
    public void updateScoreBoard(int score, int score2) {
        // Draw the symbol representing the score of player 1 at the specified position in white
        // Draw the symbol representing the score of player 2 at the specified position in white
        
        // Check if either player has reached a score of 10
        // If either player has reached a score of 10 then clear the symbols representing the scores of both players
        // Call the win function to handle the win condition
    }

    // Win condition, will update and display winner 
    public void win() {
        // Check if player one or player two has reached a score of 10
        
        // Update the background color of the cells occupied by the first and second player's paddle to black
        // This resets the background color of the first and second player's paddle
        
        // Set the horizontal and vertical velocities of the ball to 0 to stop ball movement
        
        // Check if either player has won the game
        // If either player has won, display the 'PLAYER' message
        // Display the winning player's number
        // Display the 'WINS GAME OVER' message on the screen
    }

    // Initializing the game state: velocity and position
    public void startGame() {
        // Generate a random value for the initial velocity of the ball in the x direction and store the random value in the variable rand
        // Generate a random value for the initial velocity of the ball in the y direction and store the random value in the variable rand2
        
        // If the 'Q' key has been pressed
        // Reset the symbols on the screen between the columns 17 and 32 on row 7 to 'none' symbol with white color

        // Set the horizontal velocity of the ball based on the random value rand
        // If 'rand' is less than 0.5, set the horizontal velocity to -1 otherwise, set it to 1

        // Set the vertical velocity of the ball based on the random value rand2
        // If 'rand2' is greater than 0.5, set the vertical velocity to -1 otherwise, set it to 1

        // Reset the symbols on the screen between the columns 14 and 35 on row 8 to 'none' symbol with white color
    }

    public void gameLoop() {
        // Execute checkHit(), handleInput(), draw(), ballPlay(), updateScoreBoard(), and startGame()
    }

    // Collision function
    public void checkHit() {
        // Define the minimum Y coordinate for collision detection as 3 this represents the top boundary
        // Define the maximum Y coordinate for collision detection as 'cols - 4' this represents the bottom boundary
        
        // Check if the ball has collided with either the top or bottom boundary
        // If the ball has collided with either the top or bottom boundary, execute the following checks

        // Check if the ball has collided with the first player's paddle
        // If the ball's x position is within the range of the first player's paddle and its y position matches that of the paddle
        // Reverse the vertical velocity of the ball to simulate a bounce

        // Check if the ball has collided with the second player's paddle
        // If the ball's x position is within the range of the second player's paddle and its y position matches that of the paddle
        // Reverse the vertical velocity of the ball to simulate a bounce
    }

    public void initialize() {
        // Create a new player_one and a paddle with an initial position at (3, rows / 2)
        // Create a new player_two and a paddle with an initial position at (cols - 4, rows / 2)
        
        // Create a new ball object with an initial position at (rows / 2, cols / 2) and zero velocity
        
        // Draw the "PRESS Q TO START" message for player one at the specified locations
        // Draw each character of the message using the specified symbols and white color

        // Draw the "PRESS Q TO START AGAIN" message for player two at the specified locations
        // Draw each character of the message using the specified symbols and white color
    }

    public static void main(String[] args) {
        Pong g = new Pong(36, "BRIDGES_USER_ID", "BRIDGES_API_KEY");
        g.setTitle("Pong");
        g.start();
    }

    //paddle and ball classes  
    class Paddle {
        // Declare the x-coordinate of the paddle to 0
        // Declare the y-coordinate of the paddle to 0
        // Declare the length of the paddle to 0
        
        public Paddle(int x, int y){
            // Assign the provided x value to the x-coordinate of the paddle
            // Assign the provided y value to the y-coordinate of the paddle

            // Set the length of the paddle to 4 as that is the size
        }
    }

    class Ball {
        // Declare the x-coordinate of the ball to 0
        // Declare the y-coordinate of the ball to 0

        // Declare the velocity in the x-direction of the ball and set it to 0
        // Declare the velocity in the y-direction of the ball and set it to 0
        
        public Ball(int x, int y, int vely, int velx) {
            // Assign the provided x value to the x-coordinate of the ball
            // Assign the provided y value to the y-coordinate of the ball

            // Assign the provided vely value to the velocity in the y-direction of the ball
            // Assign the provided velx value to the velocity in the x-direction of the ball
        }
    }

}
