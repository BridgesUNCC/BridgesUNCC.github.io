from bridges import NamedColor
from bridges import NamedSymbol
from bridges import NonBlockingGame
import random


class Pong(NonBlockingGame):

    def __init__(self, assid, login, api_key):
        super().__init__(assid, login, api_key, 20, 50)
        self.rows = 20
        self.cols = 50
        # adds paddles and balls
        self.player_one, self.player_two = None, None
        self.ball = None
        # scores and game barriers
        self.score1, self.score2 = 0, 0

    def handle_input(self):
        # If the 'W' key is pressed and the first player's paddle is not
        # at the top boundary move the first player's paddle up by 1 unit

        # If the 'S' key is pressed and the first player's paddle is not
        # at the bottom boundary move the first player's paddle down by 1 unit

        # If the 'Up' arrow key is pressed and the second player's paddle is
        # not at the top boundary move the second player's paddle up by 1 unit

        # If the 'Down' arrow key is pressed and the second player's paddle is
        # not at the bottom boundary move the second player's paddle down by 1 unit
        pass

    def draw(self):
        # Loop through the columns of the game area for each column then loop through
        # the rows of the game area and set the background color of each cell to black

        # Loop through the length of the first player's paddle and set the background color
        # of the cells occupied by the first player's paddle to white
        # This visually represents the first player's paddle on the screen

        # Loop through the length of the second player's paddle and set the background color
        # of the cells occupied by the second player's paddle to white
        # This visually represents the second player's paddle on the screen

        # Set the background color of the cell occupied by the ball to white
        # This visually represents the ball on the screen
        pass

    def ball_play(self):
        # Decrement the y position of the ball based on its vertical velocity
        # Decrement the x position of the ball based on its horizontal velocity

        # Check if the ball has reached the top or bottom boundary of the game area
        # If the ball has reached the left or right boundary then reverse the y velocity of the ball
        # This simulates the bouncing effect of the ball on the left and right walls

        # Check if the ball has reached the leftmost boundary of the game area
        # If the ball has reached the leftmost boundary then set both the horizontal and vertical velocities to 0
        # Increment the score of player 2 and reset the position of the ball to the center of the game area

        # Check if the ball has reached the rightmost boundary of the game area
        # If the ball has reached the rightmost boundary then set both the horizontal and vertical velocities to 0
        # Increment the score of player 1and reset the position of the ball to the center of the game area
        pass

    def update_score_board(self, score, score2):
        # Draw the symbol representing the score of player 1 at the specified position in white
        # Draw the symbol representing the score of player 2 at the specified position in white

        # Check if either player has reached a score of 10
        # If either player has reached a score of 10 then clear the symbols representing the scores of both players
        # Call the win function to handle the win condition
        pass

    def win(self):
        # Check if player one or player two has reached a score of 10

        # Update the background color of the cells occupied by the first and second player's paddle to black
        # This resets the background color of the first and second player's paddle

        # Set the horizontal and vertical velocities of the ball to 0 to stop ball movement

        # Check if either player has won the game
        # If either player has won, display the 'PLAYER' message
        # Display the winning player's number
        # Display the 'WINS GAME OVER' message on the screen
        pass

    def start_game(self):
        # Generate a random value for the initial velocity of the ball in the x direction
        # and store the random value in the variable rand
        # Generate a random value for the initial velocity of the ball in the y direction
        # and store the random value in the variable rand2

        # If the 'Q' key has been pressed
        # Reset the symbols on the screen between the columns 17 and 32 on row 7 to 'none' symbol with white color

        # Set the horizontal velocity of the ball based on the random value rand
        # If 'rand' is less than 0.5, set the horizontal velocity to -1 otherwise, set it to 1

        # Set the vertical velocity of the ball based on the random value rand2
        # If 'rand2' is greater than 0.5, set the vertical velocity to -1 otherwise, set it to 1

        # Reset the symbols on the screen between the columns 14 and 35 on row 8 to 'none' symbol with white color
        pass

    def game_loop(self):
        # Execute checkHit(), handleInput(), draw(), ballPlay(), updateScoreBoard(), and startGame()
        pass

    def check_hit(self):
        # Define the minimum Y coordinate for collision detection as 3 this represents the top boundary
        # Define the maximum Y coordinate for collision detection as 'cols - 4' this represents the bottom boundary

        # Check if the ball has collided with either the top or bottom boundary
        # If the ball has collided with either the top or bottom boundary, execute the following checks

        # Check if the ball has collided with the first player's paddle
        # If the ball's x position is within the range of the first player's paddle
        # and its y position matches that of the paddle
        # Reverse the vertical velocity of the ball to simulate a bounce

        # Check if the ball has collided with the second player's paddle
        # If the ball's x position is within the range of the second player's paddle
        # and its y position matches that of the paddle
        # Reverse the vertical velocity of the ball to simulate a bounce
        pass

    def initialize(self):
        # Create a new player_one and a paddle with an initial position at (3, rows / 2)
        # Create a new player_two and a paddle with an initial position at (cols - 4, rows / 2)

        # Create a new ball object with an initial position at (rows / 2, cols / 2) and zero velocity

        # Draw the "PRESS Q TO START" message for player one at the specified locations
        # Draw each character of the message using the specified symbols and white color

        # Draw the "PRESS Q TO START AGAIN" message for player two at the specified locations
        # Draw each character of the message using the specified symbols and white color
        pass

    class Paddle:
        # Assign the provided x value to the x-coordinate of the paddle
        # Assign the provided y value to the y-coordinate of the paddle
        # Set the length of the paddle to 4 as that is the size
        pass

    class Ball:
        # Assign the provided x value to the x-coordinate of the ball
        # Assign the provided y value to the y-coordinate of the ball
        # Assign the provided vely value to the velocity in the y-direction of the ball
        # Assign the provided velx value to the velocity in the x-direction of the ball
        pass


def main():
    g = Pong(236, "BRIDGES_USER_ID", "BRIDGES_API_KEY")
    g.set_title("Pong")
    g.start()


if __name__ == '__main__':
    main()
