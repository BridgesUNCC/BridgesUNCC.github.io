#include <NonBlockingGame.h>

using namespace bridges::game;
using namespace std;

class Paddle {
    
};

class Ball {

};

class Pong (
    public:
    int score1, score2;
    int rows, cols;
    Paddle player_one, player_two;
    Ball ball;

    Pong(int assid, string login, string apiKey) {
        rows = 20;
        cols = 50;
        score1 = 0;
        score2 = 0;
        player_one = Paddle(0, rows / 2);
        player_two = Paddle(cols - 4, rows / 2);
        ball = Ball(rows / 2, cols / 2, 0, 0);
    }

    void handleInput() {
        // Handle input logic
    }

    void draw() {
        // Draw logic
    }

    void ballPlay() {
        // Ball movement logic
    }

    void updateScoreBoard(int score1, int score2) {
        // Scoreboard update logic
    }

    void win() {
        // Win condition logic
    }

    void startGame() {
        // Game start logic
    }

    void gameLoop() {
        // Game loop logic
    }

    void checkHit() {
        // Collision logic
    }

    void initialize() {
        // Initialization logic
    }
);

int main(int argc, char** argv) {
    Pong g(36, "BRIDGES_USER_ID", "BRIDGES_API_KEY");
    g.start();
    return 0;
}