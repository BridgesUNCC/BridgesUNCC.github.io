#include <NonBlockingGame.h>

using namespace bridges::game;

//paddle and ball classes  
struct Paddle {
public:
  
  int x = 0;
  int y = 0;
  int length = 0; // Paddle size

  Paddle() = default;
  
  Paddle(int x, int y) {
    this->x = x;
    this->y = y;
    this->length = 6; 
  }
};

struct Ball {
public:
  int x = 0;
  int y = 0;
  int velocityx = 0;
  int velocityy = 0;

  Ball() = default;
  
  Ball(int x, int y, int vely, int velx) {
    this->x = x;
    this->velocityx = velx;
    this->velocityy = vely;
    this->y = y;
  }
};


struct Pong : public NonBlockingGame {

  //adds paddles and balls
  Paddle player_one, player_two;
  Ball ball;
  
  //scores and game barriers
  int score1 = 0, score2 = 0;
  int rows;
  int cols;

  
  Pong(int assID, std::string username, std::string apikey)
    : NonBlockingGame (assID, username,  apikey, 20, 50) {
    rows = 20;
    cols = 50;
  }

  virtual void initialize() override {
    // Creates two players and the ball object
    
    // Drawing "PRESS Q TO START" for player one

   // Draws ball and paddles
  }
  
  void draw() {
    //draw paddles

    //draw ball
  }

  void handleInput() {
        // INPUT LOGIC: movement

        //player 1 movement

        //player 2 movement
    }

  void startGame() {
    //handle game start
  }

  //collision function
  void checkHit() {
    //handle paddle 1 collision

    //handle paddle 2 collision
  }

  void ballPlay() {
    //move ball

    //handle top/bottom collision
  }

  void updateScoreBoard(int score, int score2) {
    //draw score board
  }

  void win() {
    //handle win condition
    
  }

  virtual void gameLoop() override {
    //This function is executed each frame of the game
    checkHit();
    handleInput();
    draw();
    win();
    ballPlay();
    updateScoreBoard(score1, score2);
    startGame();
  }
};

int main (int argc, char** argv) {

  try {
    Pong g(136, "YOUR_USER_ID", "YOUR_API_KEY");
  
    g.start();
  } catch (std::string s) {
    std::cerr<<"Exception caught: "<<s<<'\n';
  } catch (char const* s) {
    std::cerr<<"Exception caught: "<<s<<'\n';
  }

  
}
