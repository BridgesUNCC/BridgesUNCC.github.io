import bridges.connect.Bridges;
import bridges.base.Color;
import bridges.base.ColorGrid;
import bridges.base.Edge;
import bridges.base.Element;
import bridges.base.GraphAdjList;
import bridges.base.SLelement;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.PriorityQueue;

public class seamCarving {
    private int height;
    private int width;
    private int maxEnergy;
    public static void main(String[] args) throws Exception {
        //Initialize Bridges Assignment and Seam Carving object
        Bridges bridges = new Bridges(87, "BRIDGES_USER", "BRIDGES_API_KEY");
        bridges.setTitle("Seam Carving Image");
        seamCarving carver = new seamCarving();

        //Visualize original image
        //TODO: Uncomment this code after finishing the imageParse and normalColorGrid methods
        // ArrayList<ArrayList<ArrayList<Integer>>> colorMatrix = carver.imageParse("data/HJoceanSmall_text.ppm");
        // ColorGrid grid = carver.normalColorGrid(colorMatrix);
        // bridges.setDescription("The original image before any modifications");
        // bridges.setDataStructure(grid);
        // bridges.visualize();

        //Calculate energy and visualize
        //TODO: Uncomment this code after finishing the calculateEnergy and energyColorGrid methods
        // ArrayList<ArrayList<Double>> energyMatrix = carver.calculateEnergy(colorMatrix);
        // grid = carver.energyColorGrid(energyMatrix);
        // bridges.setDescription("The energy of the image");
        // bridges.setDataStructure(grid);
        // bridges.visualize();

        //Create seam using a dynamic programming solution
        //TODO: Uncomment this code after finishing the dynamic programming methods for vertical and horizontal seams
        // bridges.setDescription("Vertical and Horizontal Seam using dynamic programming");
        // verticalSeamDP(colorMatrix, energyMatrix);
        // horizontalSeamDP(colorMatrix, energyMatrix);
        // grid = carver.normalColorGrid(colorMatrix);
        // bridges.setDataStructure(grid);
        // bridges.visualize();
        // grid = carver.energyColorGrid(energyMatrix);
        // bridges.setDataStructure(grid);
        // bridges.visualize();

        //Recreate colorMatrix and energyMatrix
        // colorMatrix = carver.imageParse("data/HJoceanSmall_text.ppm");
        // energyMatrix = carver.calculateEnergy(colorMatrix);

        //Create horizontal and vertical seam using Dijkstra's Algorithm
        //TODO: Uncomment this code after finishing the makeHorizontalGraph, makeVerticalGraph, and removeGraphSeam methods
        // GraphAdjList<String, Double, String> energyGraph = makeHorizontalGraph(energyMatrix);
        // removeGraphSeam(energyGraph, colorMatrix, energyMatrix);
        // energyGraph = makeVerticalGraph(energyMatrix);
        // removeGraphSeam(energyGraph, colorMatrix, energyMatrix);
        // grid = carver.normalColorGrid(colorMatrix);
        // bridges.setDescription("Vertical and horizontal seams created from Dijkstra's Algorithm(normal image)");
        // bridges.setDataStructure(grid);
        // bridges.visualize();
        // grid = carver.energyColorGrid(energyMatrix);
        // bridges.setDescription("Vertical and horizontal seams created from Dijkstra's Algorithm(energy image)");
        // bridges.setDataStructure(grid);
        // bridges.visualize();
    }

    /**
     * Skip the first and third lines of the ppm. Create a 3D list with the size dimensions provided in the second line of the file, 
     * which is formatted as "Width Height". You should also set the global variables to their corresponding value here. Iterate through 
     * and split the remaining lines, and retrieve every 3 integers as one pixel in the image. For example, the first three integers on 
     * the fourth line are "202 191 205". This corresponds to the RGB (in that order) values of the top-leftmost pixel in the image. 
     * The next three integers correspond to the pixel to its right, and so on. In your 3D list, set the value at position i, j 
     * (where i and j are the current column and row respectively of a pixel) to a list containing the three RGB values.
     * @param imageFile the ppm file containing the rgb representation of the image
     * @return the colorMatrix containing each pixel of the image
     * @throws FileNotFoundException
     * @throws IOException
     */
    public ArrayList<ArrayList<ArrayList<Integer>>> imageParse(String imageFile) throws FileNotFoundException, IOException {
        ArrayList<ArrayList<ArrayList<Integer>>> colorMatrix = new ArrayList<ArrayList<ArrayList<Integer>>>();
        //Read through the imageFile using a Buffered Reader and save the height and width of the image into the global height and width variables, 
        //and save each row to the colorMatrix list, with each pixel being saved as a list of the red, green and blue value. 
        return colorMatrix;
    }

    /**
     * Create a 2D list with the same NxM dimensions as the RGB matrix. Then, iterate through each pixel and follow these rules to calculate its energy value:
     *  - First, find the absolute value in the differences of the red, green, and blue values of the left and right pixels of the current pixel.
     *  - Next, find the absolute value in the differences of the red, green, and blue values of the top and bottom pixels of the current pixel.
     *  - Lastly, square all six of these new values and add them up. The resulting sum is the energy value of the pixel. 
     *  - In the case where a pixel is at an image border(s):
     *    - For top border pixels, treat their top pixel as the bottommost pixel in the same column. 
     *    - For bottom border pixels, treat their bottom pixel as the topmost pixel in the same column.
     *    - For left border pixels, use their left pixel as the rightmost pixel in the same row.
     *    - For right border pixels, use their right pixel as the rightmost pixel in the same row.
     *  - When you calculate an energy value, make sure to compare it to the max energy global variable and update as needed.
     * @param colorMatrix
     * @return the 2D list that contains each pixel from the image and its energy value.
     */
    public ArrayList<ArrayList<Double>> calculateEnergy(ArrayList<ArrayList<ArrayList<Integer>>> colorMatrix) {
        ArrayList<ArrayList<Double>> energyMatrix = new ArrayList<>();
        //using the color matrix, create a new matrix and fill it with the energy scores of each pixel. 
        //additionally, compare each energy value to the max energy global variable and update it as needed. 
        return energyMatrix;
    }

    /**
     * Creates a BRIDGES ColorGrid with the same amount of resized rows and columns as the 3D RGB list. 
     * You can get these dimensions from the global variables height and width, which are accurate before and after 
     * vertical and horizontal seam alterations. Iterate through each pixel in the RGB list, creating a BRIDGES ColorGrid
     * with the corresponding RGB values, and set each pixel in the ColorGrid to that color. When you come across a marked pixel, 
     * simply skip it and use the next available pixel's RGB values - essentially deleting the former from the image.
     * @param colorMatrix
     * @return the complete BRIDGES ColorGrid object
     */
    public ColorGrid normalColorGrid(ArrayList<ArrayList<ArrayList<Integer>>> colorMatrix) {
        ColorGrid grid = new ColorGrid(height, width, new Color("Black"));
        //Initialize the ColorGrid object using the values in colorMatrix
        return grid;
    }

    /**
     * Creates a BRIDGES ColorGrid with the same amount of resized rows and columns as the 2D energy list. 
     * You can get these dimensions from the global variables height and width, which are accurate before and after 
     * vertical and horizontal seam alterations. Iterate through each pixel in the energy list, and calculate an 
     * RGB value with the following formula:
     * - RGB = energy of the pixel / highest energy in the image * 255
     * Use the max energy global variable for this. Set the BRIDGES color of the pixel with R, G, and B all being this calculated value.
     * @param energyMatrix
     * @return the complete BRIDGES ColorGrid object
     */
    public ColorGrid energyColorGrid(ArrayList<ArrayList<Double>> energyMatrix) {
        ColorGrid grid = new ColorGrid(height, width, new Color("Black"));
        //Initialize the ColorGrid object using the values in energyMatrix
        return grid;
    }

    /**
     * Creates a directed BRIDGES GraphAdjList object, with a "start" vertex and an "end" vertex, both with costs of 0. Traverses through the
     * energy matrix by rows, then columns, creating a vertex for each pixel and connecting them by creating edges with the following rules:
     * - Each vertex gets a cost, being the energy value of the pixel it represents.
     * - All the vertices representing the first row of the energy matrix should be pointed to by the start vertex.
     * - All the vertices representing the last row of the energy matrix should point to the end vertex.
     * - All other vertices should be pointed to by the vertices representing the pixels to their top-left, top-middle, and top-right. Left and
     *   right border vertices will simply be pointed to by their top-middle and either top-left or top-right vertex respectively.
     * @param energyMatrix
     * @return energyGraph
     */
    public static GraphAdjList<String, Double, String> makeVerticalGraph(ArrayList<ArrayList<Double>> energyMatrix) {
        GraphAdjList<String, Double, String> energyGraph = new GraphAdjList<>();
        
        return energyGraph;
    }

    /**
     * Creates a directed BRIDGES GraphAdjList object, with a "start" vertex and an "end" vertex, both with costs of 0. Traverses through the
     * energy matrix by columns, then rows, creating a vertex for each pixel and connecting them by creating edges with the following rules:
     *  - Each vertex gets a cost, being the energy value of the pixel it represents.
     *  - All the vertices representing the first column of the energy matrix should be pointed to by the start vertex.
     *  - All the vertices representing the last column of the energy matrix should point to the end vertex.
     *  - All other vertices should be pointed to by the vertices representing the pixels to their top-left, middle-left, and bottom-left. Top and
     *    bottom border vertices will simply be pointed to by their middle-left and either top-left or bottom-left vertex respectively.
     * @param energyMatrix
     * @return energyGraph
     */
    public static GraphAdjList<String, Double, String> makeHorizontalGraph(ArrayList<ArrayList<Double>> energyMatrix) {
        GraphAdjList<String, Double, String> energyGraph = new GraphAdjList<>();
        
        return energyGraph;
    }

    /**
     * Completes Dijkstra's shortest path algorithm on the energy graph, to find a vertical or horizontal seam:
     *  - Keep track of the distances for each vertex from start, initially set to infinity.
     *  - Keep track of the parents for each vertex, with the start vertex having None.
     *  - Use a priority queue, where you will put vertices you encounter and their distance from start. Start should be placed first.
     *  - Iterate through the queue until it is empty. For each vertex, check the vertices it points to (neighbors). If a neighbor is not
     *    marked and the distance of the vertex pointing to it plus the cost of the neighbor is less than the distance of the neighbor:
     *     - Update the distance of the neighbor to that sum.
     *     - Put the neighbor and its distance in the queue.
     *     - Update the neighbor's parent to the vertex pointing to it.
     * After finishing up with the graph, traverse through the parents of each node starting at the end vertex to obtain the shortest path (seam).
     * With the newfound shortest path (seam), traverse through the color matrix and mark all the seamed pixels. You can do this by setting a
     * pixel's RGB to an empty list, None, etc. Do the same with the energy matrix. Lastly, subtract one from the height or width global variable,
     * depending on the direction of the graph, if you have implemented a way to delete marked pixels rather than highlight them.
     * @param energyGraph
     * @param colorMatrix
     * @param energyMatrix from either makeVerticalGraph or makeHorizontalGraph
     */
    public static void removeGraphSeam(GraphAdjList<String, Double, String> energyGraph, ArrayList<ArrayList<ArrayList<Integer>>> colorMatrix, ArrayList<ArrayList<Double>> energyMatrix) {
        
    }

    /**
     * Creates a Dynamic Programming 2D list (dp table) to find a vertical seam. Start by creating the dp table with the same dimensions as the
     * color and energy matrices. Every value should be infinity except for the bottom row, which retains the energy costs of the bottom pixels.
     * Then, iterate the rest of the dp table's rows in reverse, but columns as normal. For each entry, or pixel, find the pixels to the bottom-left,
     * bottom-middle, and bottom-right (neighbors). For left and right border pixels, simply find their top-middle and either top-left or top-right
     * pixel respectively. For each neighbor, if the current pixel is not marked in the energy matrix, then find the sum of the current pixel's
     * energy plus the cost of the neighbor in the dp table. If the current pixel's dp table cost is greater than this sum, update it to the sum.
     * With the complete dp table, look through the top row and find the indices for the lowest cost pixel. From this pixel, check the bottom-left,
     * bottom-middle, and bottom-right pixels (neighbors). For left and right border pixels, simply find their bottom-middle and either bottom-left
     * or bottom-right pixels respectively. Find the neighbor with the lowest cost, keep track of its indices, and iterate to this neighbor.
     * Continue until the bottom row is reached. At this point, the sequence of indices is the vertical seam.
     * With the resulting seam, traverse through the color matrix and mark each pixel. You can do this by setting a pixel's RGB to an empty list,
     * None, etc. Do the same with the energy matrix. Lastly, subtract one from the width global variable, if you have implemented a way to delete
     * marked pixels rather than highlight them.
     * @param colorMatrix
     * @param energyMatrix
     */
    public static void verticalSeamDP(ArrayList<ArrayList<ArrayList<Integer>>> colorMatrix, ArrayList<ArrayList<Double>> energyMatrix) {
        
    }

    /**
     * Creates a Dynamic Programming 2D list (dp table) to find a horizontal seam. Start by creating the dp table with the same dimensions as the
     * color and energy matrices. Every value should be infinity except for the rght-most column, which retains the energy costs of the right-most
     * pixels. Then, iterate the rest of the dp table's columns in reverse, but rows as normal. For each entry, or pixel, find the pixels to the
     * top-right, middle-right and bottom-right (neighbors). For top and bottom border pixels, simply find their middle-right and either top-right
     * or bottom-right pixel respectively. For each neighbor, if the current pixel is not marked in the energy matrix, then find the sum of the
     * current pixel's energy plus the cost of the neighbor in the dp table. If the current pixel's dp table cost is greater than this sum,
     * update it to the sum.
     * With the complete dp table, look through the left-most column and find the indices for the lowest cost pixel. From this pixel, check the
     * top-right, middle-right, and bottom-right pixels (neighbors). For top and bottom border pixels, simply find their middle-right and either
     * top-right or bottom-right pixels respectively. Find the neighbor with the lowest cost, keep track of its indices, and iterate to this neighbor.
     * Continue until the bottom row is reached. At this point, the sequence of indices is the horizontal seam.
     * With the resulting seam, traverse through the color matrix and mark each pixel. You can do this by setting a pixel's RGB to an empty list,
     * None, etc. Do the same with the energy matrix. Lastly, subtract one from the height global variable, if you have implemented a way to delete
     * marked pixels rather than highlight them.
     * @param colorMatrix
     * @param energyMatrix
     */
    public static void horizontalSeamDP(ArrayList<ArrayList<ArrayList<Integer>>> colorMatrix, ArrayList<ArrayList<Double>> energyMatrix) {
        
    }
}

//class used to store pairs for use in Dijkstra's Algorithm's priority queue
//adapted from assignment #9: Shortest Path: Open Street Map
class Pair {
  Double v;
  String d;

  Pair(Double ve, String di) {
    v = ve;
    d = di;
  }

  String getValue() {
    return d;
  }

  Double getKey() {
    return v;
  }
}

//Comparator use in Dijkstra priority queue
class PQ_Comparator implements Comparator<Pair> {
  // Overriding compare()method of Comparator for descending order
  public int compare(Pair p1, Pair p2) {
    if (p1.getKey() > p2.getKey())
      return 1;
    else if (p1.getKey() < p2.getKey())
      return -1;
    return 0;
  }
}