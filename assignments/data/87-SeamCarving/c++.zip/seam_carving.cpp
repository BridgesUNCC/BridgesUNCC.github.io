#include "Bridges.h"
#include "ColorGrid.h"
#include "Color.h"
#include "GraphAdjList.h"

#include<vector>
#include<queue>
#include<unordered_map>
#include<fstream>
#include<limits>

using namespace std;
using namespace bridges;

class Pixel {
	int height, width;
	public:
		float r, g, b;
};

ColorGrid readPPMImage(vector<vector<Pixel>>& image, string file_name);
ColorGrid gradientImage(vector<vector<Pixel>>& image, vector<vector<float>>& 
							gradient);
// using dynamic programming
void verticalSeamDP (vector<vector<float>>& grad, vector<int>& seam_indices);
void horizontalSeamDP (vector<vector<float>>& grad, vector<int>& seam_indices);

// using shortest path on graphs
void dijkstra (GraphAdjList<int, float>& gr, int source,
               std::unordered_map<int, float>& distance,
               std::unordered_map<int, int>& parent);
void verticalSeamGraph(vector<vector<float>>& grad, vector<int>& seam_indices);
void horizontalSeamGraph(vector<vector<float>>& grad, vector<int>& seam_indices);

void seamPointsToColorGrid (vector<vector<float>>& grad, 
			vector<int>& seam_indices, ColorGrid& cg, bool flag);

int main() {
    Bridges bridges(87, "BRIDGES_USER_ID", "BRIDGES_API_KEY");
    bridges.setTitle("Seam Carving Images");

	vector<vector<Pixel>> image;

    // read in the input image  and return a color grid
	ColorGrid cg = readPPMImage(image,  "../data/HJoceanSmall_text.ppm");

    //  display the original image
	// bridges.setDescription ("Original Image");
    // bridges.setDataStructure(&cg);
    // bridges.visualize();
	
	// compute the gradient (using central differences and energy for
	// each pixel
	vector<vector<float>> gradient;
	cg = gradientImage(image, gradient);


	// display the energy image
	// bridges.setDescription ("Energy Image");
	// bridges.setDataStructure(&cg);
	// bridges.visualize();

	vector<int> seam_indices;

	// compute vertical and horizontal  seam - using dynamic programming
	// and display them over the energy image

	verticalSeamDP(gradient, seam_indices);
	seamPointsToColorGrid(gradient, seam_indices, cg, true);
	horizontalSeamDP (gradient, seam_indices);
	seamPointsToColorGrid(gradient, seam_indices, cg, false);
	bridges.setDataStructure(&cg);
	bridges.setDescription("Vertical and Horizontal seams in image with minimal energy sum (Using Dynamic Programming)");
	bridges.visualize();

	// Also  solve using Dijkstra's shortest path algorithm

	// make a copy of cg for the graph version
	int height = 285, width = 507;
	ColorGrid cg2(height, width); 
	// for (auto i = 0; i < height; i++)
	// for (auto j = 0; j < width; j++)
	// 	cg2.set(i, j, cg[i][j]);

	verticalSeamGraph(gradient, seam_indices);
	seamPointsToColorGrid(gradient, seam_indices, cg2, true);
	horizontalSeamGraph(gradient, seam_indices);
	seamPointsToColorGrid(gradient, seam_indices, cg2, false);
	// bridges.setDescription("Vertical and Horizontal seams in image with minimal energy sum (Using Dijkstra's Shortest Path Algorithm)");
	// bridges.setDataStructure(&cg2);
	// bridges.visualize();
}

ColorGrid gradientImage (vector<vector<Pixel>>&  image, 
				vector<vector<float>>& grad) { 
	ColorGrid cg;

	return cg;
}

// calculates a vertical seam in the image, given the image gradient
// using dynamic programming

void verticalSeamDP (vector<vector<float>>& image_gradient, 
							vector<int>& seam_indices) {
}

void horizontalSeamDP (vector<vector<float>>& image_gradient, 
							vector<int>& seam_indices){
}

// Calculates a vertical seam in the image, given the image gradient
// using shortest path alg.
void verticalSeamGraph (vector<vector<float>>& image_gradient, 
							vector<int>& seam_indices) {
}
// Calculates a horizontal seam in the image using shortest path alg.
void horizontalSeamGraph (vector<vector<float>>& image_gradient, 
							vector<int>& seam_indices) {
}

//Dijsktra shortest path implementation
void dijkstra (GraphAdjList<int, float>& gr,
               int source,
               std::unordered_map<int, float>& distance,
               std::unordered_map<int, int>& parent) {
}

void seamPointsToColorGrid(vector<vector<float>>& grad, vector<int> &seam_indices, ColorGrid& cg, bool flag) {

}

ColorGrid readPPMImage (vector<vector<Pixel>>& image, string file_name) {
	ColorGrid cg;

	return cg;
}
