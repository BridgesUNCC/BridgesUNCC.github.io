from bridges.bridges import Bridges
from bridges.color_grid import ColorGrid
from bridges.color import Color
from bridges.graph_adj_list import GraphAdjList
from queue import PriorityQueue

height = 0
width = 0
max_energy = -1

def image_parse(image_file:str)->list:
    '''
    Skips the first and third lines of the provided file. Create a 3D list with the size dimensions provided in the second line of the file,
    which is formatted as "Width Height". You should also set the global variables to their corresonding value here. Iterate through and
    split the remaining lines, and retrieve every 3 integers as one pixel in the image.
     - For example, the first three integers on the fourth line are "202 191 205". This corresponds to the RGB (in that order) values of
       the top-leftmost pixel in the image.
     - The next three integers correspond to the pixel to its right, and so on.
    In your 3D list, set the value at position i, j (where i and j are the current column and row respectively of a pixel) to a list
    containing the three RGB values.
    :param image_file: the file path to a ppm file that contains the RGB information of an image.
    :return: the 3D list that contains each pixel in the image's RGB values.
    :raises FileNotFoundError: if file path is invalid or the file does not exist.
    '''
    global height, width
    color_matrix = []
    # TODO: Parse image_file and save image info into color_matrix
    
    return color_matrix

def calculate_energy(color_matrix:list)->list:
    ''' Create a 2D list with the same NxM dimensions as the RGB matrix. Then, iterate through each pixel and follow these rules to
    calculate its energy value:
     - First, find the absolute value in the differences of the red, green, and blue values of the left and right pixels of the current pixel.
     - Next, find the absolute value in the differences of the red, green, and blue values of the top and bottom pixels of the current pixel.
     - Lastly, square all six of these new values and add them up. The resulting sum is the energy value of the pixel. 
    In the case where a pixel is at an image border(s):
     - For top border pixels, treat their top pixel as the bottommost pixel in the same column. 
     - For bottom border pixels, treat their bottom pixel as the topmost pixel in the same column.
     - For left border pixels, use their left pixel as the rightmost pixel in the same row.
     - For right border pixels, use their right pixel as the rightmost pixel in the same row.
    When you calculate an energy value, make sure to compare it to the max energy global variable and update as needed.
    :param color_matrix: the 3D list that contains each pixel in the image's RGB values.
    :return: the 2D list that contains each pixel in the image's energy values.
    '''
    global max_energy
    energy_matrix = []
    # TODO: Iterate through color_matrix and determine energy values in energy_matrix
    
    return energy_matrix

def vertical_seam_dp(color_matrix:list, energy_matrix:list):
    ''' Creates a Dynamic Programming 2D list (dp table) to find a vertical seam. Start by creating the dp table with the same dimensions as the
    color and energy matrices. Every value should be infinity except for the bottom row, which retains the energy costs of the bottom pixels.
    Then, iterate the rest of the dp table's rows in reverse, but columns as normal. For each entry, or pixel, find the pixels to the bottom-left,
    bottom-middle, and bottom-right (neighbors). For left and right border pixels, simply find their top-middle and either top-left or top-right
    pixel respectively. For each neighbor, if the current pixel is not marked in the energy matrix, then find the sum of the current pixel's
    energy plus the cost of the neighbor in the dp table. If the current pixel's dp table cost is greater than this sum, update it to the sum.
    With the complete dp table, look through the top row and find the indices for the lowest cost pixel. From this pixel, check the bottom-left,
    bottom-middle, and bottom-right pixels (neighbors). For left and right border pixels, simply find their bottom-middle and either bottom-left
    or bottom-right pixels respectively. Find the neighbor with the lowest cost, keep track of its indices, and iterate to this neighbor.
    Continue until the bottom row is reached. At this point, the sequence of indices is the vertical seam.
    With the resulting seam, traverse through the color matrix and mark each pixel. You can do this by setting a pixel's RGB to an empty list,
    None, etc. Do the same with the energy matrix. Lastly, subtract one from the width global variable, if you have implemented a way to delete
    marked pixels rather than highlight them.
    :param color_matrix: the 3D list that contains each pixel in the image's RGB values.
    :param energy_matrix: the 2D list that contains each pixel in the image's energy values.
    :return: None
    '''
    dp_table = []
    # TODO: Set up dp_table vertically
    
    seam = []
    # TODO: Find the vertical seam
    
    # TODO: Mark seamed pixels in color and energy matrices

def horizontal_seam_dp(color_matrix:list, energy_matrix:list):
    ''' Creates a Dynamic Programming 2D list (dp table) to find a horizontal seam. Start by creating the dp table with the same dimensions as the
    color and energy matrices. Every value should be infinity except for the rght-most column, which retains the energy costs of the right-most
    pixels. Then, iterate the rest of the dp table's columns in reverse, but rows as normal. For each entry, or pixel, find the pixels to the
    top-right, middle-right and bottom-right (neighbors). For top and bottom border pixels, simply find their middle-right and either top-right
    or bottom-right pixel respectively. For each neighbor, if the current pixel is not marked in the energy matrix, then find the sum of the
    current pixel's energy plus the cost of the neighbor in the dp table. If the current pixel's dp table cost is greater than this sum,
    update it to the sum.
    With the complete dp table, look through the left-most column and find the indices for the lowest cost pixel. From this pixel, check the
    top-right, middle-right, and bottom-right pixels (neighbors). For top and bottom border pixels, simply find their middle-right and either
    top-right or bottom-right pixels respectively. Find the neighbor with the lowest cost, keep track of its indices, and iterate to this neighbor.
    Continue until the bottom row is reached. At this point, the sequence of indices is the horizontal seam.
    With the resulting seam, traverse through the color matrix and mark each pixel. You can do this by setting a pixel's RGB to an empty list,
    None, etc. Do the same with the energy matrix. Lastly, subtract one from the height global variable, if you have implemented a way to delete
    marked pixels rather than highlight them.
    :param color_matrix: the 3D list that contains each pixel in the image's RGB values.
    :param energy_matrix: the 2D list that contains each pixel in the image's energy values.
    :return: None
    '''
    dp_table = []
    # TODO: Set up dp_table horizontally
    
    seam = []
    # TODO: Find the horizontal seam
    
    # TODO: Mark seamed pixels in color and energy matrices

def make_vertical_graph(energy_matrix:list)->GraphAdjList:
    ''' Creates a directed BRIDGES GraphAdjList object, with a "start" vertex and an "end" vertex, both with costs of 0. Traverses through the
    energy matrix by rows, then columns, creating a vertex for each pixel and connecting them by creating edges with the following rules:
     - Each vertex gets a cost, being the energy value of the pixel it represents.
     - All the vertices representing the first row of the energy matrix should be pointed to by the start vertex.
     - All the vertices representing the last row of the energy matrix should point to the end vertex.
     - All other vertices should be pointed to by the vertices representing the pixels to their top-left, top-middle, and top-right. Left and
       right border vertices will simply be pointed to by their top-middle and either top-left or top-right vertex respectively.
    :param energy_matrix: the 2D list that contains each pixel in the image's energy values.
    :return: the complete BRIDGES GraphAdjList object with vertical connecting vertices.
    '''
    energy_graph = GraphAdjList()
    energy_graph.add_vertex("start", data=0.0)
    energy_graph.add_vertex("end", data=0.0)
    # TODO: Construct the vertical graph
    
    return energy_graph

def make_horizontal_graph(energy_matrix:list)->GraphAdjList:
    ''' Creates a directed BRIDGES GraphAdjList object, with a "start" vertex and an "end" vertex, both with costs of 0. Traverses through the
    energy matrix by columns, then rows, creating a vertex for each pixel and connecting them by creating edges with the following rules:
     - Each vertex gets a cost, being the energy value of the pixel it represents.
     - All the vertices representing the first column of the energy matrix should be pointed to by the start vertex.
     - All the vertices representing the last column of the energy matrix should point to the end vertex.
     - All other vertices should be pointed to by the vertices representing the pixels to their top-left, middle-left, and bottom-left. Top and
       bottom border vertices will simply be pointed to by their middle-left and either top-left or bottom-left vertex respectively.
    :param energy_matrix: the 2D list that contains each pixel in the image's energy values.
    :return: the complete BRIDGES GraphAdjList object with horizontal connecting vertices.
    '''
    energy_graph = GraphAdjList()
    energy_graph.add_vertex("start", data=0.0)
    energy_graph.add_vertex("end", data=0.0)
    # TODO: Construct the horizontal graph
    
    return energy_graph

def remove_graph_seam(energy_graph:GraphAdjList, color_matrix:list, energy_matrix:list):
    ''' Completes Djikstra's shortest path algorithm on the energy graph, to find a vertical or horizontal seam:
     - Keep track of the distances for each vertex from start, initially set to infinity.
     - Keep track of the parents for each vertex, with the start vertex having None.
     - Use a priority queue, where you will put vertices you encounter and their distance from start. Start should be placed first.
     - Iterate through the queue until it is empty. For each vertex, check the vertices it points to (neighbors). If a neighbor is not
       marked and the distance of the vertex pointing to it plus the cost of the neighbor is less than the distance of the neighbor:
        - Update the distance of the neighbor to that sum.
        - Put the neighbor and its distance in the queue.
        - Update the neighbor's parent to the vertex pointing to it.
    After finishing up with the graph, traverse through the parents of each node starting at the end vertex to obtain the shortest path (seam).
    With the newfound shortest path (seam), traverse through the color matrix and mark all the seamed pixels. You can do this by setting a
    pixel's RGB to an empty list, None, etc. Do the same with the energy matrix. Lastly, subtract one from the height or width global variable,
    depending on the direction of the graph, if you have implemented a way to delete marked pixels rather than highlight them.
    :param energy_graph: a BRIDGES GraphAdjList object with vertical or horizontal connecting vertices.
    :param color_matrix: the 3D list that contains each pixel in the image's RGB values.
    :param energy_matrix: the 2D list that contains each pixel in the image's energy values.
    :return: None
    '''
    distances = {v: float("inf") for v in energy_graph.vertices}
    distances["start"] = 0.0
    parents = {"start": None}
    pq = PriorityQueue()
    pq.put((0.0, "start"))
    # TODO: Implement Djikstra's Algorithm on energy_graph
    
    seam = []
    # TODO: Traverse the shortest path to find the seam
    
    # TODO: Mark seamed pixels in color and energy matrices

def normal_color_grid(color_matrix)->ColorGrid:
    ''' Creates a BRIDGES ColorGrid with the same amount of resized rows and columns as the 3D RGB list. You can get these dimensions from the
    global variables height and width, which are accurate before and after vertical and horizontal seam alterations.
    Iterate through each pixel in the RGB list, creating a BRIDGES Color with the corresponding RGB values, and set each pixel in the ColorGrid
    to that color. When you come across a marked pixel, use a unique color that stands out from the image, like red, to show the pixel is part
    of a seam. Alternatively, you can implement a way of removing this pixel from the image.
    :param color_matrix: the 3D list that contains each pixel in the image's RGB values.
    :return: the complete BRIDGES ColorGrid object containing the image.
    '''
    cg = ColorGrid(height, width, Color(0,0,0))
    # TODO: Fill in the color grid with color_matrix, handling marked pixels
    
    return cg

def energy_color_grid(energy_matrix)->ColorGrid:
    ''' Creates a BRIDGES ColorGrid with the same amount of resized rows and columns as the 2D energy list. You can get these dimensions from
    the global variables height and width, which are accurate before and after vertical and horizontal seam alterations. Iterate through each
    pixel in the energy list, and calculate an RGB value with the following formula, using the max energy global variable:
     - RGB = energy of the pixel / max energy in the image * 255
    Set the BRIDGES color of the pixel with R, G, and B all being this calculated value. When you come across a marked pixel, use a unique color
    that stands out from the image, like red, to show the pixel is part of a seam. Alternatively, you can implement a way of removing this
    pixel from the image.
    :param energy_matrix: the 2D list that contains each pixel in the image's energy values.
    :return: the complete BRIDGES ColorGrid object containing a gradient version of the image.
    '''
    cg = ColorGrid(height, width, Color(0,0,0))
    # TODO: Fill in the gradient color grid with energy_matrix, handling marked pixels

    return cg

if __name__ == "__main__":
    # Initalize BRIDGES Assignment
    bridges = Bridges(87, "BRIDGES_USER", "BRIDGES_API_KEY")
    bridges.set_title("Seam Carving Images")
    
    # Visualize Original Image
    # TODO: Uncomment this portion of code when you implement image_parse and normal_color_grid
    # bridges.set_description('Original Image')
    # color_matrix = image_parse('../data/HJoceanSmall_text.ppm') # TODO: change this file path if needed
    # cg = normal_color_grid(color_matrix)
    # bridges.set_data_structure(cg)
    # bridges.visualize()
    
    # Calculate Energy and Visualize
    # TODO: Uncomment this portion of code when you implement calculate_energy and energy_color_grid
    # bridges.set_description('Energy Image')
    # energy_matrix = calculate_energy(color_matrix)
    # cg = energy_color_grid(energy_matrix)
    # bridges.set_data_structure(cg)
    # bridges.visualize()
    
    # Perform Seam Carving with a Dynamic Programming Solution
    # TODO: Uncomment this portion of code if you implement dynamic programming seams
    # bridges.set_description("Vertical and Horizontal seams in image (Using Dynamic Programming)")
    # vertical_seam_dp(color_matrix, energy_matrix)
    # horizontal_seam_dp(color_matrix, energy_matrix)
    # cg = energy_color_grid(energy_matrix)
    # bridges.set_data_structure(cg)
    # bridges.visualize()
    
    # Reset necessary components
    # TODO: OPTIONAL - uncomment this portion of code if you implement both seam methods
    # bridges.set_description("Vertical and Horizontal seams in image (Using Dijkstra's Shortest Path Algorithm)")
    # color_matrix = image_parse('../data/HJoceanSmall_text.ppm')
    # energy_matrix = calculate_energy(color_matrix)
    
    # Perform Seam Carving with Djikstra's Shortest Path Algorithm
    # TODO: Uncomment this portion of code if you implement Djikstra's seams
    # energy_graph = make_vertical_graph(energy_matrix)
    # remove_graph_seam(energy_graph, color_matrix, energy_matrix)
    # energy_graph = make_horizontal_graph(energy_matrix)
    # remove_graph_seam(energy_graph, color_matrix, energy_matrix)    
    # cg = energy_color_grid(energy_matrix)
    # bridges.set_data_structure(cg)
    # bridges.visualize()
