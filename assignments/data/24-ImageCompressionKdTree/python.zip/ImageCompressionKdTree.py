from bridges import *
from bridges.kd_tree_element import *
from random import *

class Image():
    def __init__(self, file_name):
        # Read the data from the ppm file at file_name
        # Data includes header, width, height, max value, and image data

    def get_image(self):
        # Return this image as a bridges ColorGrid

def main():
    bridges = Bridges(ASSIGNMENT_NUMBER, "BRIDGES_USER_ID", "BRIDGES_API_KEY")

    bridges.set_title("KD Tree Image")
    bridges.set_description("KD Tree Compression Representation of an Image")

    img = Image("mickey_mouse.ppm")
    cg = img.get_image()

    bridges.set_data_structure(cg)
    bridges.visualize()

    region = [0, 0, img.width, img.height]
    root = build_image_tree(region, 0, cg, 0)
    
    bridges.visualize()

def is_region_homogeneous(grid, region):
    # Recurse through the image breaking it into subregions
    # stop when the current region is homogeneous and fill it in
    # also draw the partition lines between two regions

def fill_region(grid, region, color):
    # Completely fill a region on the grid with a color

def color_region(grid, region):
    # Find the average color of a region and fill it in with
    # the color

if __name__ == '__main__':
    main()