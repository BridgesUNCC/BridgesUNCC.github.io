#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>

using namespace std;

#include "Bridges.h"
#include "KdTreeElement.h"
#include "ColorGrid.h"

using namespace bridges;

int genRandom(int min, int max) {
  // generate a number between 1/3 and 2/3 of the min-max range
  int r;
  return r;
}


//
// Function prototypes
//
// write the prototypes for all functions in this application
ColorGrid *readPPMImage ();
KdTreeElement<int, string> *buildImageTree ();
void ColorRegion ();
bool IsRegionHomogeneous();


// define any needed constants, max height of kd tree, homogeneity (termination)
// threshold, etc.

int main(int argc, char **argv) {

  // Bridges credentials
  Bridges *bridges = new Bridges(124, "BRIDGES_USER_ID", "BRIDGES_API_KEY");

  // assume a color grid object
  ColorGrid *cg;

  // read the input PPM image
  // visualize the original image

  bridges->setDataStructure(cg);
  bridges->visualize();

  // set title
  bridges->setTitle("KD Tree Representation of an Image");
	bridges->setDescription("KD Tree Compression Representation of an Image");

  // set the initial region - width and height of input image

  // build the image tree, passing in the entire region
  KdTreeElement<int, string> *root = buildImageTree ();

  // visualize
  bridges->visualize();

  return 0;
}

// this function reads in the PPM image
ColorGrid *readPPMImage () {

  // open input file, read dimensions, create ColorGrid object

  ColorGrid *cg;

  // read image pixels (assumes rgb - magic of P3 in PPM image)

  return cg;
}

// this function builds a KD tree representation of a 2D color image
// it recursively partitions the image into smaller and smaller regions and
// and tests its pixel colors until they are deemed to be homogeneous (or
// pass a homogeneity criteria, or the tree reaches a maximum height.
KdTreeElement<int, string> *buildImageTree () {

  // create kd tree element
  KdTreeElement<int, string> *root;

  // check the region's homogeneity (must also include max level test - not shown
  // below
  bool homogeneous = IsRegionHomogeneous();

  if (!homogeneous) {
    // partition the region on one of two dimensions
    // the dimension can alternate between X and Y, controlled by  a boolean flag
    // or use a different criteria to choose a dimension
    bool dim_flag;

    if (!dim_flag) {  // partition on X
      // X partition - locate between 1/3 and 2/3 - use a random position
      // of the partition interval

      // compute the two sub regions'  bounds and recurse on the sub regions
      int *lregion, *rregion;

      // recurse on the two regions
    }
    else {      // partition on Y
      // Y partition - locate between 1/3 and 2/3
      // of the partition interval

      // compute the two regions' sub region bounds
      int *lregion, *rregion;

      // recurse on the two regions
    }

    // color the partition line

    // find the region of the partitioning line, different for
    // X or Y partitioned dimension
    int *pregion;

    // color the partitioning line
    ColorRegion ();

    return root;
  }

  // this is a homogeneous region, so color it
  ColorRegion ();

  return nullptr;
}

// this function colors the provided region with the provided color
// used for partitioning lines; all pixels have the same color
// as the region is homogeneous
// there are two versions of this function, depending on whether a
// constant or average color is used.  The average color is the average
// r,g,b of all pixesl in the region.
// Use function overloading to implement the functions

void ColorRegion () {
}


// this function tests a given region for homogeneity, i.e.,
// if the region is within a threshold for approximation
bool IsRegionHomogeneous() {

  // need to compute variance ideally;

  // if the region is too small (use a threshold), then return true;

  // sum all the red, green and blue components in the image
  int sum_r = 0, sum_g = 0, sum_b = 0;

  // get the average for each primary

  // cheat: look for a difference of 5 or more in any or the
  // primaries and return false, if thats the case
  float diff_r, diff_g, diff_b;

  return true;
}
