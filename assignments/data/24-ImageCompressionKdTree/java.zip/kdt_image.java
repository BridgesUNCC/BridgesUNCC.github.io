
import bridges.connect.Bridges;
import bridges.base.KdTreeElement;
import bridges.base.Color;
import bridges.base.ColorGrid;

import java.io.File;
import java.util.Scanner;
import java.util.*;
import java.lang.String;
import java.io.FileNotFoundException;


public class kdt_image {

  // define some constants
  public static final int MaxLevel  = 12;
  public static final float HomogeneityThresh  = 10.0f;
  public static final Boolean ShowPartitioners = false; // for viewing/hiding partitioning lines

  public static void main(String[] args) throws Exception {

    // Bridges credentials
    Bridges bridges = new Bridges(24, "BRIDGES_USER_ID", "BRIDGES_API_KEY");

    bridges.setTitle ("Image Representation/Compression Using K-D Trees");

    // read the input PPM image
    // visualize the original image

    bridges.visualize();

    // set the initial region - width and height of input image
    // build the image tree, passing in the entire region

    // visualize the original image
    bridges.visualize();
  }

  public static ColorGrid readPPMImage (String file_name) throws FileNotFoundException {
    // read input image from ppm file
    File infile = new File(file_name);
    Scanner sc = new Scanner(infile);

    // read header
    String magic = sc.next();
    int width = sc.nextInt();
    int height = sc.nextInt();
    int maxVal = sc.nextInt();  // not used now

    // read the image
    // initialize the region dimensions and create the color grid.
    // Size will depend on the input image
    // create a color grid - to hold the image
    ColorGrid cg  = new ColorGrid (height, width, new Color("red"));

    // read image pixels (assumes rgb - magic of P3 in PPM image)
    for (int row = 0; row < height; row++)
      for (int column = 0; column < width; column++) {
        int red = sc.nextInt();
        int green = sc.nextInt();
        int blue = sc.nextInt();
        cg.set(row, column, new Color(red, green, blue));
      }
    return cg;
  }

  // this function builds a KD tree representation of a 2D color image
  // it recursively partitions the image into smaller and smaller regions and
  // and tests its pixel colors until they are deemed to be homogeneous (or
  // pass a homogeneity criteria, or the tree reaches a maximum height.
  public static KdTreeElement<Integer, String> buildImageTree (int[] region, int level,
      ColorGrid cg, Boolean dim_flag, Boolean draw_partitioners) {

    // create a kd tree element

    int orientation = (dim_flag) ? 1 : 0;
    KdTreeElement<Integer, String> root = new KdTreeElement<Integer, String>(0, orientation);

    // check the region's homogeneity
    Boolean homogeneous = IsRegionHomogeneous(cg, region);

    if ((level < MaxLevel) && !homogeneous) {
      // partition the region on one of two dimensions
      // here the dimension alternates between X and Y, controlled by
      // a boolean flag
      int partition;
      if (!dim_flag) {  // partition on X
        // X partition - locate between 1/3 and 2/3
        // of the partition interval

        // compute the two regions' sub region bounds
        int[] lregion;
        int[] rregion;
      }
      else {      // partition on Y
        // Y partition - locate between 1/3 and 2/3
        // of the partition interval

        // compute the two regions' sub region bounds
        int[] lregion;
        int[] rregion;
      }

      // color the partition line

      // find the region of the partitioning line, different for
      // X or Y partitioned dimension

      return root;
    }

    // this is a homogeneous region, so color it
    ColorRegion (cg, region);

    return null;
  }

  public static int genRandom(int min, int max) {
    // generate a number between 1/3 and 2/3 of the min-max range
    return 0;
  }

  // this function colors the provided region with the provided color
  // used for partitioning lines; all pixels have the same color
  // as the region is homogeneous
  // there are two versions of this function, depending on whether a
  // constant or average color is used.  The average color is the average
  // r,g,b of all pixesl in the region.
  // Use function overloading to implement the functions
  public static void ColorRegion (ColorGrid cg, int[] region, String col) {
  }

  // this function colors the region with an average color
  public static void ColorRegion (ColorGrid cg, int[] region) {
  }

  // this function tests a given region for homogeneity, i.e.,
  // if the region is within a threshold for approximation
  public static Boolean IsRegionHomogeneous(ColorGrid cg, int[] region) {
    // TODO:
    // need to compute variance ideally;
    // if the region is too small (use a threshold), then return true;
    // sum all the red, green and blue components in the image

    // TODO:
    // get the average for each primary
    // cheat: look for a difference of 5 or more in any or the
    // primaries and return false, if thats the case

    return true;
  }
};
