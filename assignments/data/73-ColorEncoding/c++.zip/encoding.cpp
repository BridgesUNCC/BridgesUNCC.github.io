#include "Bridges.h"
#include "ColorGrid.h"
#include <random>

using namespace bridges;

// Add gradient1 function
// generate ColorGrid of a particular size, with a gradient of color
// between beg and end from the top left to the bottom right.
// This interpolates the color between beg and end linearly.
// The simple rounding utilized generates color bands.
ColorGrid gradient1(int size, Color beg, Color end) {

ColorGrid grid = ColorGrid(size, size);
 // TODO: Implement linear gradient logic
// Iterate through grid cells and calculate color values
// TODO: Compute alpha and interpolate colors (Red, Green, Blue)

  return grid;
}


// generate ColorGrid of a particular size, with a gradient of color
// between beg and end from the top left to the bottom right.
// This interpolates the color between beg and end linearly. To
// prevent color banding, the algorithm randomizes the interpolation.
ColorGrid gradient2(int size, Color beg, Color end) {

 ColorGrid grid = ColorGrid(size, size);
 // TODO: Implement randomized gradient logic
// Iterate through grid cells and calculate color values
// TODO: Compute alpha and add random dithering for each color channel


  return grid;
}


int main() {
  Bridges bridges (173, "BRIDGES_USER_ID", "BRIDGES_API_KEY");

  bridges.setTitle("Color Encoding");
  bridges.setDescription("This assignment let students explore the implication of encoding of colors in graphics.");


  int size = 800;
  
   // Step 1: Black to White Gradient
  Color beg = Color(0, 0, 0);
  Color end = Color(255, 255, 255);

  ColorGrid grid = gradient1(size, beg, end);

  
  bridges.setDataStructure(&grid);
  bridges.visualize();

  // Step 2: Dark Gray Gradient

  // Step 3: Randomized Gradient

  
  return 0;
}

