import bridges.base.Color;
import bridges.base.ColorGrid;
import bridges.connect.Bridges;

import java.util.Random;


public class ColorEncoding {

    // Add gradient1 function    
    // Generate a ColorGrid of a particular size with a gradient of color
    // between beg and end from the top left to the bottom right.
    // This interpolates the color between beg and end linearly.
    public static ColorGrid gradient1(int size, Color beg, Color end) {
        ColorGrid grid = new ColorGrid(size, size);        
        // TODO: Implement linear gradient logic
        // Iterate through grid cells and calculate color values
        // TODO: Compute alpha and interpolate colors (Red, Green, Blue)

          return grid;
    }

    // Add gradient2 function with randomization
    // Generate a ColorGrid of a particular size with a gradient of color
    // between beg and end from the top left to the bottom right.
    // This interpolates the color between beg and end linearly with randomization.
    public static ColorGrid gradient2(int size, Color beg, Color end) {
        ColorGrid grid = new ColorGrid(size, size);
        // TODO: Implement randomized gradient logic
        // Iterate through grid cells and calculate color values
        // TODO: Compute alpha and add random dithering for each color channel

         return grid;
    }

    // Helper function to generate randomized color values
    private static int generateRandomizedValue(float alpha, int begVal, int endVal, Random random) {
        // TODO: Compute blended value and apply random dithering
        return 0;
    }

    public static void main(String[] args) throws Exception {
        Bridges bridges = new Bridges(73, "BRIDGES_USER_ID", "BRIDGES_API_KEY");

        bridges.setTitle("Color Encoding");
        bridges.setDescription("This assignment lets students explore the implications of color encoding in graphics.");

        int size = 800;


        // Step 1: Black to White Gradient
        Color beg = new Color(0, 0, 0);
        Color end = new Color(255, 255, 255);
        ColorGrid grid = gradient1(size, beg, end);

        bridges.setDataStructure(grid);
        bridges.visualize();

        // Step 2: Dark Gray Gradient
        
        // Step 3: Randomized Gradient
          }
}
