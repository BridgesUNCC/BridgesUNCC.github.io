from bridges.bridges import *
from bridges.color import *
from bridges.color_grid import *
import math
import random


def gradient1(size, beg, end):
    grid = ColorGrid(size, size)

    # Calculate the maximum distance from the origin (0, 0) to the furthest corner

    # Iterate over each cell in the grid
    # Calculate alpha as the normalized distance from (0, 0) to (i, j)
    # Calculate the interpolated color based on alpha
    # Set the color of the cell at position (i, j) in the grid

    return grid


def gradient2(size, beg, end):
    grid = ColorGrid(size, size)

    maxdist = math.sqrt(2) * size

    # Iterate over each pixel in the grid.
    # Compute the blending parameter 'alpha' based on the distance.
    # TODO: Calculate the blended values for red, green, and blue channels.
    # Apply random dithering to the blended values.
    # Repeat for green and blue channels.
    # Create a color using the adjusted values
    # Set the color of the current pixel.

    return grid


def main():
    # Init a Bridges Connection with your credentials
    bridges = Bridges(273, "BRIDGES_USER_ID", "BRIDGES_API_KEY")

    bridges.set_title("Color Encoding")
    bridges.set_description("This assignment let students explore the implication of encoding of colors in graphics.")

    size = 799

    # Step 1: Generate and display a gradient from black to white
    # TODO: Generate a gradient using 'gradient1' and visualize it.

    # Step 2: Generate and display a gradient from dark gray to light gray
    # TODO: Generate and visualize the new gradient using 'gradient1'

    # Step 3: Generate and display a gradient with an alternative function
    # TODO: Generate and visualize the gradient using 'gradient2'.

    bridges.visualize()


if __name__ == '__main__':
    main()

