import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import bridges.base.*;
import bridges.games.NonBlockingGame;

/*
 * Pixel class to play a drawing game
 * Implements initialize() and gameLoop() from NonBlockingGame
 */
class Pixel extends NonBlockingGame {
    int[][] gameBoard;
    int row, colum;
    NamedColor defaultColor, cursorColor, altColor;
    int[] cursorLoc;
    Color pixelCol;
    
    //Enum Class for Managing gameBoard and pixelCol
    enum Color {
        black(0),
        white(1);

        int num;
        private Color(int colorNum) {
            num = colorNum;
        }

        int value() {
            return num;
        }

    }

    /*
     * Main Constructor for the Pixel class, 
     * initializes the gameboard and calls super constructor
     * @param assignID The assignment number in bridges
     * @param username The bridges username for the user
     * @param apiKey The Api key for the user, found in profile of bridges website
     * @param colums The amount of colums in the board
     * @param rows The amount of rows in the board
     */
    Pixel(int assignID, String username, String apiKey, int colums, int rows) {

        super(assignID, username, apiKey, rows, colums);
        gameBoard = new int[rows][colums];
        row = rows;
        colum = colums;

    }

    /*
     * initialize from NonBlockingGame
     * Called once at game start
     * More info at http://bridgesuncc.github.io/doc/java-api/current/html/classbridges_1_1games_1_1_non_blocking_game.html
     */
    public void initialize() {

        keyLeftSetupFire(2);
        keyUpSetupFire(2);
        keyDownSetupFire(2);
        keyRightSetupFire(2);
        keyQSetupFire(10);

        defaultColor = NamedColor.black;
        cursorColor = NamedColor.blue;
        altColor = NamedColor.white;
        pixelCol = Color.white;
        
        cursorLoc = new int[]{0,0};
        updateBoard();
        
    }

    /*
     * gameLoop from NonBlockingGame
     * Called once each frame
     * More info at http://bridgesuncc.github.io/doc/java-api/current/html/classbridges_1_1games_1_1_non_blocking_game.html
     * Sets up the key presses a person can do to affect the board
     */
    public void gameLoop() {
        
        if(keyUpFire() && cursorLoc[0] != 0) {
            cursorLoc[0]--;
        }
        else if(keyDownFire() && cursorLoc[0] != row-1){
            cursorLoc[0]++;
        }
        if(keyLeftFire() && cursorLoc[1] != 0) {
            cursorLoc[1]--;
        }
        else if(keyRightFire() && cursorLoc[1] != (colum-1)){
            cursorLoc[1]++;
        }

        if(keySpace()) {
            gameBoard[cursorLoc[0]][cursorLoc[1]] = pixelCol.value();
        }

        if(keyQFire()) {
            changeCursor();
        }

        //Saves the Game
        if(keyS()) {
            try {
                save();
            }
            catch(IOException e){
                System.out.println("File not Saved");
            }

        }

        //Loads the Game
        if(keyD()) {
            try {
                load();
                
            }
            catch(IOException e){
                System.out.println("File not Loaded");
            }
            
        }

        updateBoard();
    }

    /*
     * updates the visual board by changing the colors to match the gameBoard
     */
    public void updateBoard() {
        Color black = Color.black;
        Color white = Color.white;
        for(int i = 0; i < row; i++) {
            for (int j = 0; j < colum; j++) {
                if(gameBoard[i][j] == black.value()) {
                    setBGColor(i, j, defaultColor);
                }
                else if(gameBoard[i][j] == white.value()) {
                    setBGColor(i, j, altColor);
                }
            }
        }

        setBGColor(cursorLoc[0], cursorLoc[1], cursorColor);
    }
    
    /*
     * Method to reset the location of the user's Cursor
     */
    public void resetCursor() {
        cursorLoc[0] = 0;
        cursorLoc[1] = 0;

    }

    /*
     * Changes the cursor back and forth from normal to alternate color
     */
    public void changeCursor() {
        if(pixelCol == Color.black ) {
         pixelCol = Color.white;
        }
        else {
         pixelCol = Color.black;
        }
     }
    
    /** 
     * @throws IOException
     * Saves the Gameboard Array to a .txt file
     * The file to save to must be specified when creating the Filewriter
     */
    public void save() throws IOException{
        // TODO Save the current state to a file


    }

    
    /** 
     * @throws IOException
     * Loads array from file into GameBoard
     * The file must be specified when creating the FileReader Object
     */
    public void load() throws IOException {
        // TODO Load a state from a file

    }

    
    /** 
     * @param args
     * The Main Method, Creates a new game using user info and starts it
     */
    public static void main(String[] args) {
        Pixel myGame = new Pixel(72, "BRIDGES_USER_ID", "BRIDGES_API_KEY", 16, 16);

        myGame.setTitle("Pixel Drawing");
        myGame.setDescription("Arrow keys for moving the cursor around the game board.\n" + 
                "Space key for drawing the color where the cursor is.\n" + 
                "Q key for changing the color the user is drawing with.\n" + 
                "- S key for saving the game board to a file.\n" + 
                "- D key for loading the game board from a file.");
        
                
        myGame.start();
    }
}