from enum import Enum
import bridges
from bridges import *
from bridges import NamedColor

# Pixel class to play a drawing game
# Implements initialize() and game_loop() from NonBlockingGame

class Color(Enum):
    BLACK = 0
    WHITE = 1

class Pixel(NonBlockingGame):
    def __init__(self, assignID, username, api_key, rows, columns):
        # Initialize the game with the provided parameters
        super().__init__(assignID, username, api_key, rows, columns)
        self.gameBoard = [[Color.BLACK.value for _ in range(columns)] for _ in range(rows)]
        self.row = rows
        self.column = columns
        self.cursorColor = NamedColor.blue
        self.cursorLoc = [0, 0]
        self.update_board()
        self.pixelColor = Color.WHITE

    def game_loop(self):
        # The main game loop, called once per frame
        if self.key_up_fire() and self.cursorLoc[0] != 0:
            self.cursorLoc[0] -= 1
        elif self.key_down_fire() and self.cursorLoc[0] != self.row - 1:
            self.cursorLoc[0] += 1
        if self.key_left_fire() and self.cursorLoc[1] != 0:
            self.cursorLoc[1] -= 1
        elif self.key_right_fire() and self.cursorLoc[1] != (self.column - 1):
            self.cursorLoc[1] += 1

        if self.key_space():
           self.gameBoard[self.cursorLoc[0]][self.cursorLoc[1]] = self.pixelColor.value
           

        # Change the drawing cursor color
        if self.key_q_fire():
            if self.pixelColor.value == Color.BLACK.value:
                self.pixelColor = Color.WHITE
            else:
                self.pixelColor = Color.BLACK



        # Save the game state to a file
        if self.key_s():
            try: 
                self.save()
            except:
                print("File not Saved")
            

        # Load the game state from a file
        if self.key_d():
            try: 
                self.load()
            except:
                print("File not Loaded")

        self.update_board()

    def update_board(self):
        # Update the visual board to reflect the game state
        for i in range(self.row):
            for j in range(self.column):
                if(self.gameBoard[i][j] == Color.BLACK.value):
                    self.set_bg_color(i, j, NamedColor.black)
                elif(self.gameBoard[i][j] == Color.WHITE.value):
                    self.set_bg_color(i,j, NamedColor.white)

        self.set_bg_color(self.cursorLoc[0], self.cursorLoc[1], self.cursorColor)

    def reset_cursor(self):
        self.cursorLoc = [0, 0]

    # TODO Save the current state to a file
    def save(self):
        print("TODO")
    # TODO Load a state from a file
    def load(self):
        print("TODO")

def main():
    myGame = Pixel(272, "BRIDGES_USER_ID", "BRIDGES_API_KEY", 16, 16)
    myGame.set_title("Pixel Drawing")
    myGame.set_description("Arrow keys for moving the cursor around the game board.\n" +
                           "Space key for drawing the color where the cursor is.\n" +
                           "Q key for changing the color the user is drawing with.\n" +
                           "- S key for saving the game board to a file.\n" +
                           "- D key for loading the game board from a file.")
    myGame.start()


if __name__ == '__main__':
    main()
