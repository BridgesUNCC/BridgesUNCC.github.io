import bridges.games.NonBlockingGame;
import bridges.base.NamedColor;
import java.util.ArrayList;
import java.util.Stack;
import java.util.PriorityQueue;
import java.util.Random;

class AStarMazeRecursive extends NonBlockingGame {

  // Possible Directions
  Vector2 UP = new Vector2(0, -1);
  Vector2 LEFT = new Vector2(-1, 0);
  Vector2 DOWN = new Vector2(0, 1);
  Vector2 RIGHT = new Vector2(1, 0);

  Random random = new Random(System.currentTimeMillis());
  static int gridColumns = 32;
  static int gridRows = 32;

  int startLength = 3;

  ArrayList<Cell> cells = new ArrayList<Cell>();

  // Pathfinder holds the position of the AStar algorithm
  // It's also used for looping back and drawing the best path using its parents
  Cell pathfinder;
  Cell goal;

  PriorityQueue<Cell> open_list;
  ArrayList<Cell> closed_list;

  boolean keyPressed = false;

  // All 4 directions starting right going clockwise
  Vector2[] Directions = {
    RIGHT, DOWN, LEFT, UP
  };

  public static void main(String args[]) {
    AStarMazeRecursive game = new AStarMazeRecursive(12, "BRIDGES_USER_ID", "BRIDGES_API_KEY", gridColumns, gridRows);
  }

  public AStarMazeRecursive(int assid, String login, String apiKey, int gc, int gr) {
    super(assid, login, apiKey, gc, gr);
    setTitle("AStar Maze");
    setDescription("Build an algorithm that finds the shortest path out of the maze from your starting point.");
    start();
  }

  public void gameLoop() {
    // TODO:
    // Check input for resetting the board

    // Run one step of the AStar algorithm each time step.
    // Use recursion to itterate through a cells neighbors
    // Update the pathfinders position to the position of the current step

    // Draw the grid including different colors or symbols for walls,
    // empty cells, the pathfinder, and the end goal.
  }

  // Set up the first state of the game grid
  public void initialize() {
    // TODO:
    // Initialize the pathfinder cell which represents
    // a position on the grid.

    // Initialize the goal cell

    // Populate the cells list for the entire grid

    // Generate a maze on the grid using any maze algorithm
    // Set cells that are walls using your cell implementation
  }
}
