package STUDENT_PACKAGE;

import bridges.games.NonBlockingGame;
import bridges.base.NamedColor;
import java.util.ArrayList;
import java.util.Stack;
import java.util.PriorityQueue;
import java.util.Random;

class STUDENT_CLASS_NAME extends NonBlockingGame {

    // Possible Directions
    Vector2 UP = new Vector2(0, -1);
    Vector2 LEFT = new Vector2(-1, 0);
    Vector2 DOWN = new Vector2(0, 1);
    Vector2 RIGHT = new Vector2(1, 0);

    Random random = new Random(System.currentTimeMillis());
    int gridColumns = grid.getDimensions()[0];
    int gridRows = grid.getDimensions()[1];

    // A list of all cells on this grid
    ArrayList<Cell> cells = new ArrayList<Cell>();

    // Used to store the AI and the goal point
    Cell pathfinder;
    Cell goal;

    PriorityQueue<Cell> open_list;
    ArrayList<Cell> closed_list;

    // All 4 directions starting right going clockwise
    Vector2[] Directions = {
        RIGHT, DOWN, LEFT, UP
    };

    public static void main(String args[]) {
        STUDENT_CLASS_NAME game = new STUDENT_CLASS_NAME(ASSIGNMENT_NUMBER, "Student_Username", "Profile_APIKey");
    }

    public STUDENT_CLASS_NAME(int assid, String login, String apiKey) {
        super(assid, login, apiKey);
        SetTitle("pathfinding");
        start();
    }

    public void GameLoop() {
        process();
    }

    // Set up the first state of the game grid
    public void initialize() {

    }

    /**
     * Initialize the pathfinder and goal point
     */
    private void startPathfinder() {

    }

    // Game loop will run many times per second.
    public void process() {

    }
}

// Represents one tile in the grid
class Cell implements Comparable<Cell> {

    private boolean isWall = false;
    public boolean discovered = false;

    public int g = 1;
    public int h = 0;
    public int f = 0;

    public Cell parent;

    public Vector2 position;

    public Cell(Vector2 position) {
        this.position = position;
    }

    @Override
    public String toString() {
        return position.toString();
    }

    public void calculateH(Cell goal) {

    }

    @Override
    public int compareTo(Cell o) {
        return f - o.f;
    }
}
