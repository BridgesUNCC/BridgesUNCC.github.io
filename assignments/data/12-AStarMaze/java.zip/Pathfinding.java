package pathfinding;

import bridges.base.NamedColor;

import java.util.ArrayList;
import java.util.Stack;
import java.util.PriorityQueue;

class Pathfinding extends LBGame {
	java.util.Random random = new java.util.Random(System.currentTimeMillis());
	int gridColumns = grid.getDimensions()[0];
	int gridRows = grid.getDimensions()[1];

	// A list of all cells on this grid
	ArrayList<Cell> cells = new ArrayList<Cell>();
	
	// Used to store the AI and the goal point
	Cell pathfinder;
	Cell goal;
	
	PriorityQueue<Cell> open_list;
	ArrayList<Cell> closed_list;

	// All 4 directions starting right going clockwise
	Vector2[] Directions = {
		new Vector2(1, 0), new Vector2(0, 1), new Vector2(-1, 0), new Vector2(0, -1)
	};
	
	public Pathfinding(int assid, String login, String apiKey) {
		super(assid, login, apiKey);
	}
		
	// Set up the first state of the game grid
	public void initialize() {
	}
	
	/**
	 * Initialize the pathfinder and goal point
	 */
	private void startPathfinder() {
	}
	
	// Game loop will run many times per second.
	public void process() {
	}

	public static void main(String args[]) {
		Pathfinding game = new Pathfinding(0, "user", "pass");
		game.setTitle("pathfinding");
		game.start();
	}
}

// Represents one tile in the grid
class Cell implements Comparable<Cell> {
	public boolean isWall = false;
	public boolean discovered = false;
	
	public int g = 1;
	public int h = 0;
	public int f = 0;
	
	public Cell parent;
	
	public Vector2 position;
	
	public Cell(Vector2 position) {
		this.position = position;
	}
	
	@Override
	public String toString() {
		return position.toString();
	}
	
	public void calculateH(Cell goal) {
	}

	@Override
	public int compareTo(Cell o) {
		return f - o.f;
	}
}
