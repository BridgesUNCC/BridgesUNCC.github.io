package pathfinding;

import bridges.connect.Bridges;
import bridges.base.NamedColor;
import bridges.base.NamedSymbol;
import bridges.base.GameGrid;

import babybridges.connect.SocketConnection;
import babybridges.game.InputHelper;

public abstract class LBGame {

	// / the game map.
	protected int rows = 31;
	protected int cols = 31;
	protected GameGrid grid;

	// /Bridges interaction
	private Bridges bridges;
	private SocketConnection sock;

	// / this stores the JSON representation that will be sent to the BRIDGES
	// server.
	private String gridJSON;

	// /helper class to make Input Management a bit easier.
	public InputHelper input;

	// /used for fps control
	private long timeoflastframe;

	// /takes bridges credential and information as a parameter.
	public LBGame(int assid, String login, String apiKey) {
		timeoflastframe = System.currentTimeMillis();

		// bridges-sockets account (you need to make a new account:
		// https://bridges-sockets.herokuapp.com/signup)
		bridges = new Bridges(assid, login, apiKey);

		// make sure the bridges connects to the game version of the web app
		bridges.setServer("games");

		// create a new color grid with random color
		grid = new GameGrid(rows, cols);

		// set up socket connection to receive and send data
		sock = new SocketConnection();
		sock.setupConnection(Bridges.getUserName(), Bridges.getAssignment());

		input = new InputHelper(sock);
	}

	protected void setTitle(String title) {
		bridges.setTitle(title);
	}

	protected void setDescription(String desc) {
		bridges.setDescription(desc);
	}

	// /set background color of cell x, y to c
	// /
	protected void setBGColor(Vector2 position, NamedColor c) {
		grid.setBGColor(position.y, position.x, c);
	}

	// /set foreground color of cell x, y to c
	// /
	protected void setFGColor(int x, int y, NamedColor c) {
		grid.setFGColor(y, x, c);
	}

	// /set symbol of cell x, y to s
	// /
	protected void setSymbol(Vector2 pos, int s) {
		grid.drawObject(pos.y, pos.x, s);
	}

	// /set symbol of cell x, y to s
	// /
	protected void drawObject(Vector2 pos, NamedSymbol s) {
		grid.drawObject(pos.y, pos.x, s);
	}

	// /set symbol and foreground color of cell x, y to s and c
	// /
	protected void drawObject(int x, int y, NamedSymbol s, NamedColor c) {
		grid.drawObject(y, x, s, c);
	}

	// / function to define by the programmer. This function is called
	// / once at the beginning.
	public abstract void initialize();

	// / function to define by the programmer. This function is called
	// / once per frame.
	public abstract void process();

	// / This function prepare all that is needed to be able to render
	// / as fast as possible. Here it builds the correct representation
	// / to send to the server.
	private void prepareRender() {
		// get the JSON representation of the updated color grid
		String gridState = grid.getDataStructureRepresentation();
		gridJSON = '{' + gridState;
		// System.out.println(gridJSON);
	}

	///send the representation to the server
	private void render() {
		// send valid JSON for grid into the socket
		sock.sendData(gridJSON);
	}

	/// should be called right before render() Aims at having a fixed
	/// fps of 30 frames per second. This work by waiting until
	/// 1/30th of a second after the last call to this function.
	private void controlFrameRate() {
		int fps = 60;
		double hz = 1.0 / fps;

		long currenttime = System.currentTimeMillis();
		long theoreticalnextframe = timeoflastframe + (int) (hz * 1000);
		long waittime = theoreticalnextframe - currenttime;

		if (waittime > 0) {
			try {
				Thread.sleep(waittime); // this is super crude
			} catch (InterruptedException ie) {
				// die?
			}
		}
		timeoflastframe = System.currentTimeMillis();
	}

	/// calling this function starts the game engine.
	public void start() {
		try {
			Thread.sleep(5 * 1000); // wait for browser to connect
		} catch (InterruptedException ie) {
			// die?
		}

		// associate the grid with the Bridges object
		bridges.setDataStructure(grid);

		// visualize the grid
		try {
			bridges.visualize();
		} catch (Exception err) {
			System.out.println(err);
		}

		initialize();
		while (true) {
			process();

			prepareRender();
			controlFrameRate();
			render();
		}
	}
}
