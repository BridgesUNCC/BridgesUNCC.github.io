
// TODO:
// Create a cell class that holds each cells position, a bool for if it is a wall or open cell
// Also have values for g, h, f, and parent as helpers for astar
class Cell implements Comparable<Cell> {

	
  // TODO Implement needed properties and functions to represent a cell on the grid
	
  // Should include
  // Constructors
  // Properties for g, h, and f values used in AStar
  // Property to track if this cell contains a wall
  // Property to track if this cell has been discovered for AStar
  // A reference to this cells parent for AStar
	@Override
	public int compareTo(Cell o) {
		// TODO Compare Cell object to another object of type Cell
		return 0;
	}
}
