package pathfinding;

public class Vector2 {
	public int x;
	public int y;
	
	public Vector2(int x, int y) {
		this.x = x;
		this.y = y;
	}
	
	public static Vector2 add(Vector2 v0, Vector2 v1) {
		return new Vector2(v0.x + v1.x, v0.y + v1.y);
	}
	
	public void add(Vector2 other) {
		this.x += other.x;
		this.y += other.y;
	}
	
	@Override
	public String toString() {
		return "(" + Integer.toString(x) + ", " + Integer.toString(y) + ")";
	}
}
