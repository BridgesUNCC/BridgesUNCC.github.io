#include <NonBlockingGame.h>

#include <iostream>
#include <string>
#include <vector>
#include <queue>

using namespace bridges::game;

class Pathfind : public NonBlockingGame {
private:
	const vector<vector<int>> DIRECTIONS = {{0, 1}, {1, 0}, {-1, 0}, {0, -1}};

protected:
	static const vector<int> size;
	// Create a cell class that holds each cells position, a bool for if it is a wall or open cell
	// Also have values for g, h, f, and parent as helpers for astar
	vector<STUDENT_TYPE> cells;

	// Pathfinder holds the position of the AStar algorithm
	// It's also used for looping back and drawing the best path using its parents
	STUDENT_TYPE pathfinder;
	bool finished = false;

	vector<int> goal;

	// Open list and closed list used for AStar
	priority_queue<STUDENT_TYPE> openList;
	vector<STUDENT_TYPE> closedList;

public:
	Pathfind(int assignmentID, std::string username, std::string apikey)
		: NonBlockingGame(assignmentID, username, apikey, size[0], size[1]) {}

protected:
	virtual void initialize() override {
		// TODO Generate a random maze using any algorithm and draw it to the grid
		// Use the cell object you make to store whether each cell on the grid is a wall or not

		// Set the pathfinders initial position and also the goal's position
		// Initialize the open list with the start position
	}

	vector<STUDENT_TYPE> getNeighbors(STUDENT_TYPE cell) {
		// TODO Return all neighbors of the cell, used for AStar
	}

	void process() {
		if (openList.size() > 0) {
			// TODO If the open list is empty run 1 step of AStar set the pathfinders position to the next
			// Color the grid at the new position green
		}
		else if (!finished) {
			// TODO Otherwise color the pathfinders position as blue then set the pathfinder to its parent for the 
			// next iteration, once the pathfinder is back at the start set finished to true
		}
	}

	virtual void gameLoop() override {
		try {
			// Call multiple times to make the program run faster
			process();
		}
		catch (char const * e) {
			cout << e << endl;
		}
	}
};

const vector<int> Pathfind::size = { 31, 31 };

int main(int argc, char *argv[]) {
	Pathfind nbg(9, "user", "auth");

	nbg.start();

	return 0;
}
