from bridges import *
from heapq import *

import random
from datetime import datetime

class AStarMaze(NonBlockingGame):
    # AStarMazeer holds the position of the AStar algorithm
	# It's also used for looping back and drawing the best path using its parents

    def __init__(self, assid, login, apikey):
        super(AStarMaze, self).__init__(assid, login, apikey, 31, 31)
        
        super(AStarMaze, self).set_title("AStar Maze")
        super(AStarMaze, self).set_description("A pathfinder traverses the maze using AStar. Finding the best route to the bottom right point from the top left.")

    def initialize(self):
        random.seed(datetime.now())
        # TODO Generate a random maze using any algorithm and draw it to the grid
		# Use the cell object you make to store whether each cell on the grid is a wall or not

		# Set the pathfinders initial position and also the goal's position
		# Initialize the open list with the start position

    def get_neighbors(self, cell):
		# TODO Return all neighbors of the cell, used for AStar

    def game_loop(self):
        # Change number of loops to make program faster/slower
        for _ in range(3):
            if len(self.open_list) > 0:
                # TODO If the open list is empty run 1 step of AStar set the pathfinders position to the next
			    # Color the grid at the new position green
            elif self.pathfinder.parent != None:
                # TODO Otherwise color the pathfinders position as blue then set the pathfinder to its parent for the 
			    # next iteration, once the pathfinder is back at the start set finished to true

def main():
    game = AStarMaze(ASSIGNMENT_NUMBER, "BRIDGES_USER_ID", "BRIDGES_API_KEY")

    # Start the game
    game.start()

if __name__ == '__main__':
    main()