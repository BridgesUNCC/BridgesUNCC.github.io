from bridges import *
from heapq import *

import random
from datetime import datetime

class Cell:
    # TODO Implement needed properties and functions to represent a cell on the grid

    # Should incldude
    # Constructors
    # Properties for g, h, and f values used in AStar
    # Property to track if this cell contains a wall
    # Property to track if this cell has been discovered for AStar
    # A reference to this cells parent for AStar
    pass

class AStarMaze(NonBlockingGame):
    # AStarMazeer holds the position of the AStar algorithm
	# It's also used for looping back and drawing the best path using its parents

    def __init__(self, assid, login, apikey):
        super(AStarMaze, self).__init__(assid, login, apikey, 31, 31)
        
        super(AStarMaze, self).set_title("AStar Maze")
        super(AStarMaze, self).set_description("A pathfinder traverses the maze using AStar. Finding the best route to the bottom right point from the top left.")

    def initialize(self):
        random.seed(datetime.now())
        # TODO:
        # Initialize the pathfinder cell which represents
        # a position on the grid.

        # Initialize the goal cell

        # Populate the cells list for the entire grid
        
        # Generate a maze on the grid using any maze algorithm
        # Set cells that are walls using your cell implementation

    def game_loop(self):
        # TODO:
        # Check input for resetting the board

        # Run one step of the AStar algorithm each time process is called.
        # Update the pathfinders position to the position of the current step
        
        # Draw the grid including different colors or symbols for walls, 
        # empty cells, the pathfinder, and the end goal.

def main():
    game = AStarMaze(ASSIGNMENT_NUMBER, "BRIDGES_USER_ID", "BRIDGES_API_KEY")

    # Start the game
    game.start()

if __name__ == '__main__':
    main()