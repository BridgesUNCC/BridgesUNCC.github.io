import java.io.IOException;

import bridges.base.AudioClip;
import bridges.connect.Bridges;

// you will need to create classes for each instrument and its recommended to 
// also use an abstract class that would perform generic operations required
// of all instruments

public abstract class Instrument {
    public Instrument() {

    }

    public abstract void loadInstrumentNotes() throws IOException;

    public void playNote(AudioClip note, AudioClip ac, int seconds) {
        for (int i = 0; i < 44100*seconds; i++) {
            int j = i;
            while (j >= note.getSampleCount()) {
                j = j - note.getSampleCount();
            }
            ac.setSample(0, i, note.getSample(0, j));
        }
    }
    public static void main(String[] args) throws Exception {
        Bridges bridges = new Bridges(79, "BRIDGES_USERNAME", "BRIDGES_APIKEY");
        bridges.setTitle("Instrument Creation");
        bridges.setDescription("This assignment involves creating a musical composition, allowing users to play and visualize an audio clips, currently supports Marimba and Cello notes.");

        //TODO: uncomment these lines after finishing the composeSong method
        // AudioClip ac = composeSong();
        // bridges.setDataStructure(ac);
        // bridges.visualize();
    }
    
    public static AudioClip composeSong() throws IOException {
        // TODO: demonstrate an example sequence of notes using the cello and 
	    // marimba. Return the composed song as an audio clip to be played 
	    // using BRIDGES
        AudioClip ac = new AudioClip(44100*13, 1, 16, 44100);

        // this function will loop through each note of each instrument in 
        // a particular order to build the song. The notes need to be processed
        // so that they only are on for the required number of seconds.

        // song notes will specify the instrument, note (chord) and the time 
        // (seconds)

        return ac;
    }
}
