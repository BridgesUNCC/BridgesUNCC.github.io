from bridges import *
from bridges.audio_clip import AudioClip
from abc import ABC # Python Abstract Class

# TODO: You will need to create classes for each instrument and its
# recommended to use an abstract class that would perform generic
# operations required of all instruments

# class Instrument(ABC):
    # load_instrument_notes(): abstract method
    # play_note(): method
    
# class Cello(Instrument):
    # notes dictionary
    # __init__(): method
    # load_instrument_notes(): overriding method
    # get_note(): method
    # add_note(): method

# class Marimba(Instrument):
    # notes dictionary
    # __init__(): method
    # load_instrument_notes(): overriding method
    # get_note(): method
    # add_note(): method

def compose_song()->AudioClip:
    # Demonstrating an example sequence of notes using the cello and marimba.
    # Returns the composed song as an audio clip to be played using BRIDGES    
    
    ac = AudioClip(sample_count=44100*13, num_channels=1, sample_bits=16, sample_rate=44100)
    
    # TODO: Implement compose_song() method
    # This function will loop through each note of each instrument in 
	# a particular order to build the song. The notes need to be processed
	# so that they only are on for the required number of seconds.
 
    # Song notes will specify the instrument, note (chord) and the time (seconds)
    
    return ac

if __name__ == "__main__":
    # Initalize BRIDGES Assignment
    bridges = Bridges(79, "BRIDGES_USER", "BRIDGES_API_KEY")
    bridges.set_title("Instrument Creation")
    bridges.set_description("This assignment involves creating a musical composition, allowing users to play and visualize an audio clip, currently supports Marimba and Cello notes.")

    # Compose Song and Visualize It
    # TODO: Uncomment this portion when you implement classes and compose_song
    # ac = compose_song()
    # bridges.set_data_structure(ac)
    # bridges.visualize()
