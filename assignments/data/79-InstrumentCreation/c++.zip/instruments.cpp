#include "Bridges.h"
#include <iostream>
#include <string>

//#include "Instrument.h"
//#include "Marimba.h"
//#include "Cello.h"

#include "AudioClip.h"

using namespace std;
using namespace bridges;

// you will need to create classes for each instrument and its recommended to 
// also use an abstract class that would perform generic operations required
// of all instruments

AudioClip composeSong();

int main () {
    Bridges bridges = Bridges(79, "BRIDGES_USERNAME", "BRIDGES_APIKEY");
    bridges.setTitle("Instrument Creation");
    bridges.setDescription("This assignment involves creating a musical composition, allowing users to play and visualize an audio clips, currently supports Marimba and Cello notes.");
	
	// compose and demonstrate a song with 5 notes
	AudioClip ac = composeSong();

	bridges.setDataStructure(ac);
	bridges.visualize();
    
	return 0;
}

AudioClip composeSong () {
	// TODO
	// demonstrating an example sequence of notes using the cello and 
	// marimba. Returns the composed song as an audio clip to be played 
	// using BRIDGES

	
	AudioClip ac (44100*11, 1, 16, 44100);  // the composed song

	// this function will loop through each note of each instrument in 
	// a particular order to build the song. The notes need to be processed
	// so that they only are on for the required number of seconds.

	// song notes will specify the instrument, note (chord) and the time 
	// (seconds)

	return ac;
}
