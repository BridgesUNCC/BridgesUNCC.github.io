from bridges import NonBlockingGame
from bridges import NamedColor
from bridges import NamedSymbol
from random import*


class GamePiece:
    # this is a helper class to help you keep track of the pieces
    piece_color = NamedColor.black
    piece_loc = [0, 0]

    def __init__(self, row, column, color):
        self.piece_color = color
        self.piece_loc[0] = row
        self.piece_loc[1] = column

    # FUNCTIONS
    def get_piece_color(self):
        return self.piece_color

    def set_piece_color(self, color):
        self.piece_color = color


class ConnectFour(NonBlockingGame):

    # FIELDS
    p1_loc = [0, 0]  # player 1 location
    p2_loc = [0, 0]  # player 2 location
    board_size = [7, 8]  # size of the board

    # the size of the connect 4 board is 6 x 7
    # row 0 is for the player to select where to drop their disc
    # column 7 is to display messages (if someone won or if there was a tie)

    old_loc = [0, 0]  # player's old location
    new_loc = [0, 0]  # player's new location
    available_space = [6, 6, 6, 6, 6, 6, 6]  # available space to drop disks
    ttl_pieces = 42  # total amount of game pieces

    # create an element to keep track of whose turn it is
    # create an element to keep track whether or not someone dropped a piece onto the grid
    # create an element to hold all of the game pieces that have been dropped onto the grid
    # create an element that indicates whether or not a player has won
    key_frames = 3  # process key events once every key_frame, this makes the game run smoothly
    frames = 0

    def initialize(self):
        # color the background of the game grid

        # use a different color for row 0 (the area where the player chooses where to drop their disc)
        # and column 7 (for displaying messages)

        # decide which player will go first when the game runs

    def player_turn(self):
        # handle player movement based on who's turn it is
        # if a player has dropped a piece, their turn is over

    def handle_player(self):
        # depending on who's turn it is update the player's location

        # move the piece left and right to choose where to drop a piece
        # use down (or any other key) to drop a piece
        # make sure you update the amount of available space on the board
        # and the amount of total pieces as well as handle any edge cases

        # each player's piece is a different color, for example p1 is red and p2 is blue
        # if there is not enough space to drop a piece, the player's turn is not over
        # add the piece that was dropped to the collection of all pieces on board

    def update_screen(self):
        # depending on who's turn it is, draw a game piece of that player's color
        # redraw every piece that was dropped before

    def check_win(self):
        # get the location and color of the last piece dropped
        # check for a win (four of the same color disc) in every direction,
        # make sure to handle edge cases and to take note when a player has won
    def game_loop(self):
        # increase the amount of frames
        # if there are no more pieces left, there is a tie (display tie and exit the game)
        # process player movements once every key frames
        # if a player has won, display win message and exit game
        # check for a win
        # update screen

def main():
    connect_four = ConnectFour(35, "USER_ID", "API_KEY", 7, 8)
    connect_four.set_title("Connect Four")
    connect_four.set_description("Drop discs and see who can connect four first!")
    connect_four.start()

if __name__ == '__main__':
    main()

