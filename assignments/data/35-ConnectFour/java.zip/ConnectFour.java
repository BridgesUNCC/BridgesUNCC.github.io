
import bridges.games.NonBlockingGame;
import bridges.base.NamedColor;
import bridges.base.NamedSymbol;

public class ConnectFour extends NonBlockingGame {

    // FIELDS
    int[] p1Loc = {0, 0}; // player 1 location, {row, column}
    int[] p2Loc = {0, 0}; // player 2 location, {row, column}
    static int[] boardSize = {7, 8}; 
    /**
     * the board size for connect 4 is 6 x 7
     * row 0 is the area where the player decides where to drop their disc
     * column 7 is where the score (or tie) will be displayed
     */
    int[] oldLoc = new int[2]; // the old location of the player
    int[] newLoc = {0, 0}; // new location of the player
    int[] availableSpace = {6, 6, 6, 6, 6, 6, 6}; //available space to drop discs, each column has 6 (from 1-6), row 0 is for selection only
    int ttlPieces = 42; // total game pieces

    /**
     * create an element to hold all the pieces that have been already dropped onto the grid
     * (the objects that are inside this element are of type GamePiece)
     * 
     * create elements that track whether or not it is a player's turn
     * create elements that indicate whether or not a player has dropped a piece onto the grid
     * create an element that indicates if someone has won
     */
    
    public static void main(String[] args) {
        // initialize the game
        ConnectFour c4 = new ConnectFour(35, "USER_ID", "API_KEY", boardSize[0], boardSize[1]);
    }

   
    public ConnectFour(int assid, String login, String apiKey, int r, int c) {
        super(assid, login, apiKey, r, c);

        // title and description
        setTitle("CONNECT FOUR");
        setDescription("Use the arrow keys to drop discs to see who can connect four first!");

        // start running the game
        start();
    }

    /**
     * Initializes the game grid, runs only once.
     */
    @Override
    protected void initialize() {
     /**
      * color the background of the game grid
      * 
      * use a different color for row 0 (the area where the player chooses
      * where to drop a disc) and column 7 (the area where the winner is
      * displayed)
      * 
      * decide which player will go first when the game runs
      */ 

    }

    /**
     * handles player turns
     */
    public void playerTurn() {
        /**
         * handle player movement based on whoever's turn it is
         * if a player has dropped a piece, their turn is over
         */
    }

    /**
     * handles player movement
     */
    public void handlePlayer(int[] pLoc) {
        /**
         * depending on whose turn it is, update the player's location
         * 
         * move the piece left and right to choose where to drop the piece
         * use down to drop a piece, make sure to update the amount
         * of available space, the amount of pieces left, and to keep the piece within bounds
         * 
         * each player's pieces are different color, for example,
         * player 1 is red and player 2 is blue
         * 
         * if there isn't enough space to drop a piece,
         * the player can choose another place to drop their piece
         * 
         * add the piece that was dropped to the collection of all pieces on
         * the board
         */
    }

    /**
     * Updates the game grid
     */
    public void updateScreen() {
        /**
         * depending on whose turn it is, draw a gamepiece of that player's color
         * redraw every piece that was dropped before
         */

    }
    
    public boolean checkUp(int row, int column) {
        /**
         * get the color of the current piece and
         * see if the next 3 pieces are the same color
         */
    }

    public boolean checkDown(int row, int column) {
         /**
         * get the color of the current piece and
         * see if the next 3 pieces are the same color
         */
    }

    public boolean checkLeft(int row, int column) {
         /**
         * get the color of the current piece and
         * see if the next 3 pieces are the same color
         */
    }

    public boolean checkRight(int row, int column) {
        /**
         * get the color of the current piece and
         * see if the next 3 pieces are the same color
         */
    }

    
    public boolean checkNW(int row, int column) {
         /**
         * get the color of the current piece and
         * see if the next 3 pieces are the same color
         */
    }

    
    public boolean checkNE(int row, int column) {
         /**
         * get the color of the current piece and
         * see if the next 3 pieces are the same color
         */
    }

    
    public boolean checkSW(int row, int column) {
         /**
         * get the color of the current piece and
         * see if the next 3 pieces are the same color
         */
    }

    
    public boolean checkSE(int row, int column) {
         /**
         * get the color of the current piece and
         * see if the next 3 pieces are the same color
         */
    }

    /**
     * checks every piece on the grid for a win and displays the win message
     */
    public void win() {
        /**
        * run checks on every piece in the grid (a piece must exist in order to be checked)
        * make sure to handle edge cases for the checks
        * 
        * iteration for rows starts at 1 because row 0 is for the player to select where to drop their disc
        * 
        * if the checks return true, someone has won
        * depending on the color of the piece the check was ran on,
        * display which player has won
        */
       

    }

    /**
     * the game loop
     */
    @Override
    protected void gameLoop() {
        /**
         * if there are no more pieces, display a tie and end the game
         * 
         * if someone has won, end the game
         * 
         * handle player turn
         * 
         * update the screen
         * 
         * check to see if someone has won
         */
    }

}
