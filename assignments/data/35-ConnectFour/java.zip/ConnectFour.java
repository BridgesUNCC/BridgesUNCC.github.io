/*
* To change this license header, choose License Headers in Project Properties.
* To change this template file, choose Tools | Templates
* and open the template in the editor.
*/

import bridges.games.NonBlockingGame;
import bridges.base.NamedColor;
import bridges.base.NamedSymbol;
import java.util.ArrayList;

/**
 * class for connect four game
 *
 * @author eddgo
 */
public class ConnectFour extends NonBlockingGame {

	// FIELDS
	int x_size, y_size; 
	int curr_x = 0;
	int[] counters = {0, 0, 0, 0, 0, 0, 0, 0};

	int rcnt = 0,  bcnt = 0;

	NamedSymbol[][] board_symbols = new NamedSymbol[7][7];
	NamedColor[][] board_symbol_col = new NamedColor[7][7];
	NamedColor[][] board_bg_col = new NamedColor[7][7];

	boolean player = false; // which player's turn?

	/**
	 * @param args the command line arguments
	 */
	public static void main(String[] args) {
		// initialize the game
		ConnectFour c4 = new ConnectFour(35, "BridgesID", "BridgesApiKey", 7, 7);
	}

	// CONSTRUCTOR- sets up Bridges credentials and grid size
	/**
	 *
	 * @param assid the assignment number
	 * @param login the username for bridges
	 * @param apiKey api key of the user
	 * @param c columns for game grid
	 * @param r rows for game grid
	 */
	public ConnectFour(int assid, String login, String apiKey, int r, int c) {
		super(assid, login, apiKey, r, c);

		// title and description
		setTitle("CONNECT FOUR");
		setDescription("Use the arrow keys to move left/right and space key to drop a chip.!");
		// start running the game
		start();
	}

	/**
	 * Initializes the game grid, runs only once.
	 *
	 *
	 */
	@Override
	protected void initialize() {

		x_size = getBoardWidth();
		y_size = getBoardHeight();
		
		//setup cooldowns for buttons
		keyLeftSetupFire(3);
		keyRightSetupFire(3);
		keySpaceSetupFire(3);

		for (int i = 0; i < y_size; ++i) {
			for (int j = 0; j < x_size; ++j) {
				board_symbols[i][j] = NamedSymbol.none;
				board_symbol_col[i][j] = NamedColor.white;
				board_bg_col[i][j] = NamedColor.ivory;
			}
		}

		// draw the top row in a different color
		for (int i = 1; i < getBoardWidth(); ++i) 
			board_bg_col[0][i]  = NamedColor.limegreen;

		board_symbols[0][0]  = NamedSymbol.circle;
		board_symbol_col[0][0]  = (player) ? NamedColor.red : NamedColor.blue;
	}

	/**
	 * handles player movement
	 *
	 * @param pLoc the player location array
	 */
	public void makeMove() {
          /*
           * Student Code here
           * read the keys (left arrow, right arrow, space)
           * and handle the functionality
           */
	}

    public Boolean gameOver(int curr_row, int curr_col) {
        //  must check for 4 disks of same color across row, 
        //  column and diagonals containing the last move
        /*
         * Student write code to check for a win
         */
        return false;
    }

    public Boolean checkMatches (int row, int col) {
        // looks for a run of 4 disks of same color
        return false;
    }


    public void drawBoard() {
        // draw the board
        for (int i = 0; i < y_size; ++i) {
            for (int j = 0; j < x_size; ++j) {
                setBGColor(i, j, board_bg_col[i][j]);
                drawSymbol (i, j, board_symbols[i][j], board_symbol_col[i][j]);
            }
        }
    }


    public void printMessage() {
        NamedColor col = (player) ? NamedColor.blue : NamedColor.red;
        board_symbols[0][0] = NamedSymbol.circle;
        board_symbols[0][1] = NamedSymbol.none;
        board_symbols[0][2] = NamedSymbol.W;
        board_symbols[0][3] = NamedSymbol.I;
        board_symbols[0][4] = NamedSymbol.N;
        board_symbols[0][5] = NamedSymbol.S;
        board_symbol_col[0][0] = col;
        for (int k = 1; k < 6; k++)
            board_symbol_col[0][k] = NamedColor.green;
        // update view
        drawBoard();
    }


	/**
	 * the game loop
	 */
	@Override
	protected void gameLoop() {
		
		makeMove();
		drawBoard();
	}
}
