#include <NonBlockingGame.h>
#include <iostream>

//
// This is an scaffold  for the Connect 4 Game using the BRIDGES Game API.
//
//

using namespace bridges::game;

struct Connect4 : public NonBlockingGame {
	// board size, attributes
	enum bridges::game::NamedSymbol board_symbols[7][7];
	enum bridges::game::NamedColor  board_symbol_col[7][7];
	enum bridges::game::NamedColor  board_bg_col[7][7];

	// current position of disk
	int curr_x,  curr_y;
	bool player = false;
	
	int key_frames = 10; 	// process key events once every 'key_frames' times
	int frames = 0;

	// board size
	int  xsize, ysize;

	// keeps track of #disks in each column
	int counters[7] = {0, 0, 0, 0, 0, 0, 0};

	Connect4(int assID, std::string username, std::string apikey)
			: NonBlockingGame (assID, username,  apikey, 7, 7) {
	}
	virtual void initialize() override {
		// initialize the board, symbols, symbol colors and background colors
		// might want to draw the top row in a different color
		// draw the start symbol
	}

	virtual void gameLoop() override {
		//  make a move and update the screen
		frames++; 
		if (!(frames%key_frames))
			makeMove();
	}
	
	void makeMove () {
		// left or right moves the piece in the top row to choose 
		// a column to drop it
		// use appropriate keys and ensure you dont go off the board
  	}

	void drawBoard() {
		// draw the board
	}

	bool gameOver(int curr_row, int curr_col) {
		// 	must check for 4 disks of same color across row, 
		//	column and diagonals containing the last move

		// note that the last move might caused a winner, so only need to 
		// check cases where that move is part of the winning row, column or diagonal

		// the following is only to avoid a warning from the compiler
		return false;
	}

	void printMessage() {
		// when a winner is found, print a winning message on the board
	}
};


int main (int argc, char** argv) {
	Connect4 connect4(135, "BRIDGES_USER_ID", "BRIDGES_API_KEY");
  
	connect4.start();
}
