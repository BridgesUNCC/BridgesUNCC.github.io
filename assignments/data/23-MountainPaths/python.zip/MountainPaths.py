from bridges import *

class MountPath():
	def __init__(self, elev_data):
		self.width = elev_data.cols 
		self.height = elev_data.rows
		self.max_val = elev_data.maxVal
		self.data = elev_data.data
		self.sentinel_val = 99999

	# accessor functions
	def get_val(self, x, y):
	# Return the color of the pixel at x y
		return self.data[int(y)][int(x)]

	def set_val(self, x, y, val):
		# Set the color of the pixel at x, y
		self.data[int(y)][int(x)] = val

	def get_image(self, max_val):
		#TODO: take the processed elevation map and put that in to a Bridges 
		# ColorGrid object. You must scale the values of the elevation into 
		# a value of 0-255; use that as a gray value for the image (r = g = b)
        # use the Color(r, g, b) to set colors from the ColorGrid object
		# Return this elevation data as a ColorGrid image
		cg = ColorGrid(self.height, self.width)

		return cg


	# check the data for negative elevatiion values, in which case
	# shift them and adjust max value, also update the  the max elevation value, 
	#	useful for scaling the elevation  data, prior to loading it into the Color Grid
	def process_elev_data(self, elev_data):
		pass


	def greedy_path(self, start_y):
		# TODO: 
		# this function finds the path through the elevation data, starting from the left most
		# pixel of an arbitrary row
		# You will use a greedy approach - check the assignment description for more
		# details. You must ensure that the algorithm doesnt go off the bounds of 
		# elevation data. 

		# the simpler version always goes right based on the smallest difference in elevations
		# by comparing the top right, right and bottom right elevation to the current
		# position
		pass


def main():
	# Bridges credentials
	bridges = Bridges(223, "BRIDGES_USER_ID", "BRIDGES_API_KEY")

	# set title, description
	bridges.set_title("Mountain Paths - Greedy Algorithms Example")
	bridges.set_description("Path through the mountains through the lowest elevation.")

	# TODO:get elevation data, pass lat/long bounding box -  use your own city/town
	elev_data = get_elevation_data ([6.02, 44.10, 
						9.70, 47.77], 0,02)

	mnt_path = MountPath(elev_data)

	#do some processing of the data to check for negative values (below sealevel!)
	mnt_path.process_elev_data(elev_data)
	
	# apply the greedy algorithm to find hte path
	mnt_path.greedy_path(elev_data.rows/2)

	cg = mnt_path.get_image(elev_data.maxVal)

	# set bridges data structure, visualize, uncomment after you complete the program
	#bridges.set_data_structure(cg)
	#bridges.visualize()

if __name__ == '__main__':
    main()
