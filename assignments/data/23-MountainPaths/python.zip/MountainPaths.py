from bridges import *

class Image():
    def __init__(self, file_name):
        # TODO
        # Read the ppm file data into this image.
        # Should include header, width, height, and max value
        # Then read in the rest of the actual image data into a datastructure

    def get_image(self):
        # TODO
        # Return this image as a bridges ColorGrid

    def greedy_path(self, start_y):
        # TODO
        # Run the greedy path algorithm starting at x = 0 and y = start_y
        # create a path from the left of the image to the right

def main():
    bridges = Bridges(ASSIGNMENT_NUMBER, "BRIDGES_USER_ID", "BRIDGES_API_KEY")

    bridges.set_title("Mountain Paths - Greedy Algorithms Example")
    bridges.set_description("Path through the mountains through the lowest elevation.")

    # Open the image and run a path from the left-center of the image
    img = Image('colorado1.ppm')
    img.greedy_path(img.height // 2)

    bridges.set_data_structure(img.get_image())
    bridges.visualize()


if __name__ == '__main__':
    main()