import bridges.connect.Bridges;
import bridges.base.Color;
import bridges.base.ColorGrid;


// This program is a scaffold of the mountain paths assignment in Java. See the README.md for a 
// detailed description

public class mount_path {


	public static void main(String[] args) throws Exception {

		// bridges object initialization
		// provide assignment number (int), user id (string), application id (string)
		// may be sent through command line arguments

		Bridges bridges = new Bridges(BRIDGES_ASSIGNMENT_NUMBER, "BRIDGES_USER_ID", "BRIDGES_API_KEY");

		// set title
		bridges.setTitle("Mountain Paths - Greedy Algorithms Example");
		
		// 	read input elevation data, pass in data file name, returns width, height, 
		//	maxVal and the data in an integer array. maxVal is used to scale the data 
		// 	to display in an image with colors in the range 0-255
		int[]  elev_dat = readData();
		
		// find path by applying a greedy algorithm, must pass in a starting row number
		// image values are marked for those points on the path
		findPath (); 

		
		// get the path written into a color grid for visualization
		ColorGrid cg = getImage();

		// visualize
		bridges.setDataStructure(cg);
		bridges.visualize();
	}

	public static int[] readData() {
	}

	public static ColorGrid getImage() {
	}

	public static void findPath() {
	}
};
