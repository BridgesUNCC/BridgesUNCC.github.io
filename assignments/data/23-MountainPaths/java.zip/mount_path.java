import bridges.connect.Bridges;
import bridges.base.Color;
import bridges.base.ColorGrid;
import bridges.connect.DataSource;
import bridges.data_src_dependent.*;


// This program is a scaffold of the mountain paths assignment in Java. See the README.md for a
// detailed description

public class mount_path {


  public static void main(String[] args) throws Exception {

    // bridges object initialization
    // provide assignment number (int), user id (string), application id (string)
    // may be sent through command line arguments

    Bridges bridges = new Bridges(23, "BRIDGES_USER_ID", "BRIDGES_API_KEY");

    // set title
    bridges.setTitle("Mountain Paths - Greedy Algorithms Example");

	// get the elevation data - pass in lat/long rectangular bounding box
    // lat min, longit min, lat max, longit max
	// An example  is provided, but customize the lat/long to your city/town!
	DataSource ds = bridges.getDataSource();
	ElevationData ele_data = ds.getElevationData(6.020558108041891, 
					44.10757941505641, 9.707863253414155, 47.77059916141684, 0.02);


	// do some processing of the data to check for negative values (below sealevel!);
	// if there are negative values, shift the data so that they are all positive.
    processElevationData (ele_data);


    // load data  into a color grid for  visualization; make sure you scale the values
	// to 0-255 for r, g, b (use gray, all components are the same)
	ColorGrid cg = new ColorGrid(ele_data.getRows(), ele_data.getCols());
    getImage(ele_data, cg);

    // visualize just the elevation data
    bridges.setDataStructure(cg);
    bridges.visualize();


    // find path by applying a greedy algorithm, must pass in a starting row number
    // image values are marked for those points on the path
	int startRow = 50;
    findPath (ele_data, startRow);

    // get the path written into a color grid for visualization
    getImage(ele_data, cg);


    // visualize with the path
    bridges.setDataStructure(cg);
    bridges.visualize();
  }

  // functions to read the input elevation data, put into a color grid
  // and compute the lowest elevation path through the  mountains

  public static void processElevationData(ElevationData ele_data)  {
  }

  // takes in the processed elevation data and returns a color grid for
  // visualization using BRIDGES
  public static void  getImage(ElevationData ele_data, ColorGrid cg){
  }

  // Determines the least effort path through the mountain starting a point on
  // the left edge of the image. The elevation data is in a 1D array, but you might
  // choose to use a 2D array and avoid conversion of 1D to 2D addresses, which will
  // required. Must handle edge cases to ensure  you dont go past the edges of the data
  // array (top, bottom, right, or left, if you use variants to go backward
  public static void findPath(ElevationData ele_data, int startRow)  {
  }
};

