
#include "Bridges.h"
#include "ColorGrid.h"

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>

using namespace std;
using namespace bridges;

// This program implements the mountain paths assignment in C++. See the README.md for a 
// detailed description

// function prototypes
// use arguments as needed to the functions
ColorGrid *getImage ();
int *readData ();
void findPath();

int main(int argc, char **argv) {

	
	// initialize Bridges
	// provide assignment number (int), user id (string), application id (string)
	// may be sent through command line arguments
	Bridges bridges(123, "BRIDGES_USER_ID", "BRIDGES_API_KEY");

	// set title
	bridges.setTitle("Mountain Paths - Greedy Algorithms Example");

	// defaults for row number and data file
	string dataFile = "path/to/data/file";
	

	// read input elevation data, pass in data file name, returns width, height, maxVal and 
	// the data in an integer array. maxVal is used to scale the data to display in an image
	// with colors in the range 0-255

	int *elev_data = readData();

	// find path by applying a greedy algorithm, must pass in a starting row number
	// image values are marked for those points on the path
	findPath ();

	
	// get the path written into a color grid for visualization using BRIDGES
	ColorGrid *cg = getImage();

	// visualize
	bridges.setDataStructure(cg);
	bridges.visualize();

	return 0;
}

int *readData() {


return 0;
}

// takes in the processed elevation data and returns a color grid for 
// visualization using BRIDGES
ColorGrid *getImage() {

	// create color grid
	ColorGrid *cg = new ColorGrid(/*height, width*/);



	return cg;
		
}

// Determines the least effort path through the mountain starting a point on
// the left edge of the image. The elevation data is in a 1D array, but you might
// choose to use a 2D array and avoid conversion of 1D to 2D addresses, which will
// required. Must handle edge cases to ensure  you dont go past the edges of the data
// array (top, bottom, right, or left, if you use variants to go backward
void findPath() {
	
}
