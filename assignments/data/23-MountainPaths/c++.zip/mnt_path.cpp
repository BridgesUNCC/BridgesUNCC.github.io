
#include "Bridges.h"
#include "ColorGrid.h"

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <limits>

#include "DataSource.h"
#include "data_src/ElevationData.h"
using namespace std;
using namespace bridges;

// This program implements the mountain paths assignment in C++.
// Inspired by Nifty assignment, but here we get the elevation data based
// on user specified lat/long range, so it can be customized to your chosen
// area of the globe!
// See the README.md for a detailed description

// function prototypes
ColorGrid *getImage(ElevationData *elev_data);
void findPath(ElevationData  *elev_data, int startRow);
void processElevationData (ElevationData *elev_data);

int main(int argc, char **argv) {

  // bridges object initialization

  // initialize Bridges
  Bridges bridges(123, "BRIDGES_USER_ID", "BRIDGES_API_KEY");

  // defaults for row number (always starts the path at column 0
  int startRow = 50;

  // set title
  bridges.setTitle("Mountain Paths - Greedy Algorithms Example");

  // get elevation data

  DataSource ds;
  // order is latitude min, longitude min, latitude_max, longitude max
  // change this to your area of interest!
  ElevationData *elev_data = ds.getElevationData(6.02, 44.10,
                        9.70, 47.77, 0.02);

  // does some processing to get the elevation range, checks for negative
  // values and shifts them as needed.
  processElevationData(elev_data);

  // find path by applying a greedy algorithm
  findPath (elev_data, startRow);

  // get the path written into a color grid for visualization
  ColorGrid *cg = getImage(elev_data);

  // visualize
  bridges.setDataStructure(cg);
  bridges.visualize();

  return 0;
}

// check the data for negative elevatiion values, in which case
// shift them and adjust max value, also set the max value, useful for scaling the
// data
void processElevationData (ElevationData *elev_data) {

  // calculate range of elevation data
  int min_elev, max_elev;

  // check for negative elevation values in the data (below sealevel!), in
  // that case, translate all data so that the data is all positive.
  // finally update the max elevation value and store that in the
  // elevation data object (elev_data->setMaxVal(...)
}

// determines the least effort path through the mountain starting a point on
// the left edge of the image
void findPath(ElevationData  *elev_data, int startRow) {


  // first check the startRow is within the image bounds


  // iterate over each pixel in the column, updating the row as you
  // navigate from left to right. Initial address is (startRow, 0)

  int pixRow = startRow, col = 0;


  while (col < elev_data->getCols() - 1) {

    // for each iteration,  compute the neighbors (top-right, right, bottom-right);
    // the ElevationData object has accessor to get the elevation value
    // elev_data->getVal(row, col)
    // if the row is at the bounds of the data, then you only have two choices,
    // thus some book-keeping is needed to handl these boundary cases.

    // compute the difference in elevation between the current point and its
    // neighbors - and chose the one with the smallest difference - in case of
    // tie, move right, or pick at random.

    col++;
  }
}

// takes in the processed elevation data and returns a color grid for
// visualization using BRIDGES
ColorGrid *getImage(ElevationData *elev_data) {

  // create color grid given the width and height of the elevation data
  int width, height;
  // get width, height from the ElevationData object

  // create the color grid
  ColorGrid *cg = new ColorGrid(height, width);

  float pixel_val;
  int n = 0, gray;
  int maxVal = elev_data->getMaxVal();

  // load the elevation data into the color grid. Note that values with
  // the sentinel of -1 are the path points.
  // the color grid uses r,b,b triplets. Scale these to 0-255 range and
  // use them for red, green and blue (gray image).
  // color the path points using cg->set(row, col, Color(255, 0, 255), for
  // example

  return cg;
}
