import bridges.connect.Bridges;
import bridges.base.ColorGrid;
import bridges.base.Color;

import java.util.Vector;
import java.lang.String;

// helper class to maintain a pair of values
class Pair<E1, E2> {
	public E1 first; 
	public E2 second;

	Pair (E1 f, E2 s) {
		first = f; second = s;
	}

};

public class Layers {
	public static void main(String[] args) throws Exception {
		//create the Bridges object, set credentials
		Bridges bridges = new Bridges(1, "kalpathi60", "486749122386");

		bridges.setTitle("2D Grid Layers");
		bridges.setServer("live");

		// use a color grid to display cells examined and layers
		// initialize all cells to white
		ColorGrid cg  = new ColorGrid(20, 20, new Color("white"));

		// get the layers surrounding the cell (9, 11). Layers are generated
		// from inside out
		// Use a Pair class to conveniently keep the layer cell indices

		Vector<Pair<Integer, Integer>> layer_cells = getLayerCells(9, 11, cg);

		bridges.setDataStructure(cg);
		bridges.visualize();
	}

	public static Vector<Pair<Integer, Integer>>  getLayerCells(int col, int row, 
									ColorGrid cg) {

		// generate the layers, outwards from the center cell
		// each iteration you expand the layer by 1 cell in X andY

		// keep the identified cells in a vector
		Vector<Pair <Integer, Integer>> layer_cells = new Vector<Pair <Integer, Integer>>();

		// to keep track of the bounds of the grid
		int rowMin, rowMax, colMin, colMax; 

		// layer bounds
		int l_rowMin, l_rowMax, l_colMin, l_colMax;

		// color the initial cell

		// we will cycle through a color sequence of colors to delineate
		// the layers, i.e., each layer is drawn in a particular color

		// iterate on layers, can have as many as many layers as the size
		// of the grid, since the start cell can be on a boundary

		// However, need to make sure the indices are always within the bounds
		// of the grid; thus keep track of the layer bounds, which in turn is 
		// restricted by the grid bounds

		int gridSize = 20;
		for (int layer = 1; layer < gridSize; layer++) {
			// choose a color for the layer

			// find the bounds of the layer -- layers increase by 1 in each dimension
			// unless the grid bounds are reached

			// process the layer, identifying the cells in the horizontal
			// and vertical rows to be examined 

			// limit col indices to be within the grid

			// traverse bottom row 


			// traverse top row

			// next process the two columns of the layer

		}
		return layer_cells;
	}
};

