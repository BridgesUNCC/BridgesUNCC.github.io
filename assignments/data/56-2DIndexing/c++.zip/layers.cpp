#include "Bridges.h"
#include "ColorGrid.h"
#include <iostream>
#include <algorithm>
#include <vector>
#include <string>


using namespace std;
using namespace bridges;

vector<pair<size_t, size_t>>  getLayerCells(int col, double row, ColorGrid& cg);

int main(int argc, char **argv) {
	try {
		//create the Bridges object, set credentials
		Bridges bridges(2, "BRIDGES_USER_ID", "BRIDGES_API_KEY");

		bridges.setTitle("2D Grid Layers");
		bridges.setServer("live");

		// use a color grid to display cells examined and layers
		ColorGrid cg (20, 20, Color("white"));


		// generate the cells layer by layer starting from an arbitrary cell in
		// in the grid
		vector<pair<size_t, size_t>> layer_cells = getLayerCells(18, 18, cg);

		bridges.setDataStructure(cg);
		bridges.visualize();
	}
	catch (std::string s) {
		std::cerr << s << std::endl;
	}
	return 0;
}

vector<pair<size_t, size_t>>  getLayerCells(int col, double row, ColorGrid& cg) {
	// generate the layers, outwards from the center cell
	// each iteration you expand the layer by 1 cell in X andY

	// keep the identified cells in a vector
	vector<pair <size_t, size_t>> layer_cells;

	// to keep track of the bounds of the grid
	int rowMin, rowMax, colMin, colMax; 

	// layer bounds
	int l_rowMin, l_rowMax, l_colMin, l_colMax;

	// color the initial cell
	// we will cycle through a color sequence of colors to delineate
	// the layers, i.e., each layer is drawn in a particular color

	// iterate on layers, can have as many as many layers as the size
	// of the grid, since the start cell can be on a boundary

	// However, need to make sure the indices are always within the bounds
	// of the grid; thus keep track of the layer bounds, which in turn is 
	// restricted by the grid bounds
	for (int layer = 1; layer < gridSize; layer++) {
		// choose a color for the layer

		// find the bounds of the layer -- layers increase by 1 in each dimension
		// unless the grid bounds are reached

		// process the layer, identifying the cells in the horizontal
		// and vertical rows to be examined 

		// limit col indices to be within the grid

		// traverse bottom row 


		// traverse top row

		// next process the two columns of the layer

	}
	return layer_cells;
};
