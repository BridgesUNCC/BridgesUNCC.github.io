from bridges.bridges import *
from bridges.color import *


def main():

    bridges = Bridges(256, "BRIDGES_USER_ID", "BRIDGES_API_KEY")

    bridges.set_title("2D Grid Layers")

    # use a color grid to display cells examined and layers
    # initialize all cells to white
    cg = ColorGrid(20, 20, Color("white"))

    # get the layers surrounding the cell (9,11). Layers are generated from inside out
    layer_cells = get_layer_cells(9, 11, cg)

    bridges.set_data_structure(cg)
    bridges.visualize()


def get_layer_cells( col, row, cg):

    # generate the layers, outwards from the center cell
    # each iteration we expand the layer by 1 cell in x and y

    # get grid index of source point
    size = cg.dimensions
    grid_size = size[0]

    # iterate on layers, can have as many layers as the size of the grid,
    # since the start cell can be on a boundary
    for layer in range(1, grid_size):
        pass

        # find the bounds of the layer

        # process the layer, identifying the cells in the horizontal
        # and vertical rows to be examined

        # limit col indices to be within the grid

        # traverse bottom row

        # traverse the top row

        # next process the two columns of the layer

        # traverse left column

        # traverse right column

    # return layer_cells


def color_switcher(argument):
    switcher = {
        0: Color("red"),
        1: Color("green"),
        2: Color("blue"),
        3: Color("cyan"),
        4: Color("yellow"),
        5: Color("magenta"),
        6: Color("orange"),
        7: Color("black")
    }

    return switcher.get(argument)


class Pair:

    def __init__(self, f, s):
        self.first = f
        self.second = s


if __name__ == '__main__':
    main()
