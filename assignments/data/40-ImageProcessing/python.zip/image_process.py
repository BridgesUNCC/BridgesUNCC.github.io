from bridges import *
from image import *


def main():
    bridges = Bridges(240, "BRIDGES_USER_NAME", "BRIDGES_API_KEY")
    img = Image()
    img.read("../figures/yosemite.ppm")

    cg = ColorGrid(10, 10)

    # display the original image
    img.set_color_grid(cg, False)
    bridges.set_data_structure(cg)
    bridges.visualize()

    # convert to grayscale and display
    img.to_grayscale()
    img.set_color_grid(cg, True)
    bridges.set_data_structure(cg)
    bridges.visualize()

    # flip rows horizontally and display
    img.flip_horizontal()
    img.set_color_grid(cg, True)
    bridges.set_data_structure(cg)
    bridges.visualize()

    # flatten blue component and display
    img.flatten_blue()
    img.set_color_grid(cg, True)
    bridges.set_data_structure(cg)
    bridges.visualize()

    # negate red component (wraparound) and display
    img.negate_red()
    img.set_color_grid(cg, True)
    bridges.set_data_structure(cg)
    bridges.visualize()

    # blend images and display
    img.blend("../figures/Lenna.ppm", 0.5)
    img.set_color_grid(cg, True)
    bridges.set_data_structure(cg)
    bridges.visualize()


if __name__ == '__main__':
    main()
