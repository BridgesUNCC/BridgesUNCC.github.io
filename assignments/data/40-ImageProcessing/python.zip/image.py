# from bridges import *
# import re
# from pathlib import Path


class Image:
    def __init__(self, input_file=None, width=None, height=None):
        if not input_file and not width and not height:
            self.width = 0
            self.height = 0
            self.max_val = 0
        elif not input_file:
            self.read(input_file)
        elif not input_file and width and height:
            self.width = width
            self.height = height
            self.max_val = 0

        self.image_list = [] * self.width * self.height
        self.processed_list = [] * self.width * self.height

    def get_width(self):
        return self.width

    def set_width(self, w):
        self.width = w

    def get_height(self):
        return self.height

    def set_height(self, h):
        self.height = h

    def read(self, file_name):
        # Open the file in read mode
        # Read the header (Assumes PPM text images)
        # Read the magic number identifying the file format
        # Read the width, height, and maximum pixel value
        # Create an empty list to store image pixel values
        # Initialize a counter variable
        # Iterate through the remaining lines in the file
        # Split the line into a list of pixel values
        # Iterate through the pixel values and insert them into the image_list
        # Allocate the processed list of the same size as the image
        pass

    def set_color_grid(self, cg, processed):
        # Initialize a counter variable
        # Iterate through each row (height) of the color grid
        # Iterate through each column (width) of the color grid
        # Check if the pixels are processed or not
        # If processed, set the color in the color grid using processed values
        # If not processed, set the color in the color grid using original image values
        # Increment the counter variable by 3 to move to the next set of RGB values
        pass

    def flip_horizontal(self):
        # Initialize a counter variable
        # Iterate through each row (i) of the image
        # Iterate through the first half of the width of the image
        # Calculate the indices for the current and mirrored pixels
        # Swap the nth and mth pixels
        # Store the values of nth pixels in a temporary list
        # Update the processed list with the mirrored pixel values
        # Update the processed list with the original pixel values
        pass

    def to_grayscale(self):
        # Initialize a counter variable
        # Iterate through each row (i) of the image
        # Iterate through each column (j) of the image
        # Get the RGB values of the current pixel
        # Compute the grayscale value using weighted averages
        # Update the processed list with the grayscale value for each channel
        # Increment the counter variable by 3 to move to the next set of RGB values
        pass

    def flatten_blue(self):
        # Initialize a counter variable
        # Iterate through each row (i) of the image
        # Iterate through each column (j) of the image
        # Get the RGB values of the current pixel
        # Copy the Red and Green channels from the original pixel
        # Set the Blue channel to 0, effectively "flattening" the blue color
        # Increment the counter variable by 3 to move to the next set of RGB values
        pass

    def negate_red(self):
        # Initialize a counter variable
        # Iterate through each row (i) of the image
        # Iterate through each column (j) of the image
        # Negate the Red channel value by subtracting it from 255
        # Negate the Red channel
        # Copy the Green and Blue channels from the original pixel
        # Increment the counter variable by 3 to move to the next set of RGB values
        pass

    # reads a new image and blends with existing image
    def blend(self, file_name, blend_factor):
        # Initialize variables for width and height
        # Get the absolute path of the script
        # Open the blending image file in read mode
        # Read the header of the blending image
        # Calculate the range of pixels to blend
        # Iterate through the entire file and put the entire file into one list
        # Iterate through each pixel in the image
        # Read pixel and blend the pixels if within range
        # Blend the pixels using the specified blend factor
        # Update the processed list with the blended pixel values
        # If not within range, copy the original pixel values
        pass
