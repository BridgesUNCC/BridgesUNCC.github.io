#include "Image.h"

using namespace bridges;

int main() {

	Bridges bridges(140, "BRIDGES_USER_ID", "BRIDGES_API_KEY");

	bridges.setTitle("Image Processing");
	bridges.setDescription("Students are provided with sample images in a simple text format that they read and display using the ColorGrid datatype.");

	//TODO: the main program where you call various image processing
	// operations.

	return 0;
}

