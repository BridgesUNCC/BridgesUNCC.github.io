#include "Image.h"

using namespace bridges;

int main() {

	Bridges bridges(140, "BRIDGES_USER_ID", "BRIDGES_API_KEY");

	//TODO: the main program where you call various image processing
	// operations.

	return 0;
}

