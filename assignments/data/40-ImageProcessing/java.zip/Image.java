import java.util.Scanner;
import java.io.*;
import bridges.connect.Bridges;
import bridges.base.ColorGrid;
import bridges.base.Color;

public class Image {

    // image dimensions
    private int width, height, maxVal;

    // image array and processed array definitions
    private int[] image_array;
    private int[] processed_array;

    // constructors
    public Image() {
        // TODO
    }

    // creates an image object by reading the input image
    public Image(String input_file) {
        // TODO
    }

    //creates an image object using the given dimensions
    public Image(int width, int height) {
        // TODO
    }

    // accessors
    public int getWidth() {
        return width;
    }

    public void setWidth(int w) {
        width = w;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int h) {
        height = h;
    }

    // reads an image from  the given input image file
    public void read(String file_name) {
        // Open the file
        // Read the header (assumes PPM text images)
        // Display the header information
        // Initialize arrays if not already created
        // Read the pixels
        // Handle file not found exception
    }

    // displays image using the BRIDGES color grid
    public void setColorGrid(ColorGrid cg, Boolean processed) {
        // Initialize a counter variable
        // Iterate through each row (height) of the color grid
        // Iterate through each column (width) of the color grid
        // Check if the pixels are processed or not
        // If processed, set the color in the color grid using processed values
        // If not processed, set the color in the color grid using original image values
        // Increment the counter variable by 3 to move to the next set of RGB values
    }

    // convert image to grayscale
    public void toGrayscale() {
        // Initialize a counter variable
        // Iterate through each row (i) of the image
        // Iterate through each column (j) of the image
        // Get the RGB values of the current pixel
        // Compute the grayscale value using weighted averages
        // Store the grayscale value in the processed array for each channel
        // Increment the counter variable by 3 to move to the next set of RGB values
    }

    // flip image about the vertical axis 
    public void flipHorizontal() {
        // Initialize a counter variable
        // Iterate through each row (i) of the image
        // Iterate through the first half of the width of the image
        // Calculate the indices for the current and mirrored pixels
        // Swap the nth and mth pixels
        
    }

    // eliminate the blue component
    public void flattenBlue() {
        // Initialize a counter variable
        // Iterate through each row (i) of the image
        // Iterate through each column (j) of the image
        // Get the RGB values of the current pixel
        // Copy the Red and Green channels from the original pixel
        // Set the Blue channel to 0, effectively "flattening" the blue color
        // Increment the counter variable by 3 to move to the next set of RGB values
    }

    // negate the red component by using its complement (wraparound)
    public void negateRed() {
        // Initialize a counter variable
        // Iterate through each row (i) of the image
        // Iterate through each column (j) of the image
        // Get the RGB values of the current pixel
        // Negate the Red channel value by subtracting it from 255
        // Copy the Green and Blue channels from the original pixel
        // Increment the counter variable by 3 to move to the next set of RGB values
    }

    // reads a new image and blends with existing image
    public void blend(String file_name, float blend_factor) {
        // Open the blending image file
        // Read the header of the blending image (Assumes PPM text images)
        // Handle file not found exception
        // Center the incoming image, find their min, max addresses
        // Iterate through each pixel in the image
        // Read pixel and blend the pixels if within range
        // Blend the pixels using the specified blend factor
        // Update the processed array with the blended pixel values
        // If not within range, copy the original pixel values
    }
};
