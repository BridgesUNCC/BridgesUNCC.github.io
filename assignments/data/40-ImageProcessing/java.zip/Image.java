
import java.util.Scanner;
import java.io.*;
import bridges.connect.Bridges;
import bridges.base.ColorGrid;
import bridges.base.Color;


public class Image {

    // image dimensions
	private int width, height, maxVal;

	// image array and processed array definitions
	private int[] image_array;

	// you will need a processed array to hold results
	private int[] processed_array;

	// constructors
	public Image() {
	}

    // creates an image object by reading the input image
	public Image(String input_file){
	}

    //creates an image object using the given dimensions
	public Image(int width, int height) {
	}

	// you might nee accessors to various data times, pixel values


	// reads an image from  the given input image file
	public void read(String file_name) {
	}

	// displays image using the BRIDGES color grid
	public void setColorGrid (ColorGrid cg, Boolean processed) {
	}

	// convert image to grayscale
	public void toGrayscale () {
	}

	// flip image about the vertical axis 
	public void flipHorizontal() {
	}

	// eliminate the blue component
	public void flattenBlue() {

	// negate the red component by using its complement (wraparound)
	public void negateRed() {
	}

	// reads a new image and blends with existing image
	public void blend (String file_name, float blend_factor) {
	}
};

