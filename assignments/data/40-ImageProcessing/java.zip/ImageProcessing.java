import bridges.connect.Bridges;
import bridges.base.ColorGrid;
import java.io.IOException;

public class ImageProcessing {

    public static void main(String[] args) throws Exception {

		Bridges bridges = new Bridges(40, "BRIDGES_USER_ID", "BRIDGES_API_KEY");

		// read in the input image 
		Image img = new Image();
		img.read("../figures/yosemite.ppm");

		// create a BRIDGES color grid, change to image width and height
		ColorGrid cg = new ColorGrid(10, 10);
	
		//  display the original image
		img.setColorGrid(cg, false);
		bridges.setDataStructure(cg);
		bridges.visualize();

		
		// convert to grayscale and display
		img.toGrayscale();
		img.setColorGrid(cg, true);
		bridges.setDataStructure(cg);
		bridges.visualize();

		// flip rows horizontally and display
		img.flipHorizontal();
		img.setColorGrid(cg, true);
		bridges.setDataStructure(cg);
		bridges.visualize();

		// flatten blue component and display
		img.flattenBlue();
		img.setColorGrid(cg, true);
		bridges.setDataStructure(cg);
		bridges.visualize();

		// negat  red component (wraparond) and display
		img.negateRed();
		img.setColorGrid(cg, true);
		bridges.setDataStructure(cg);
		bridges.visualize();

		// blend images and display
		img.blend("../figures/Lenna.ppm", 0.5f);
		img.setColorGrid(cg, true);
		bridges.setDataStructure(cg);
		bridges.visualize();
	}

}
