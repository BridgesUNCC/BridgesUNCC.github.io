import bridges.base.*;
import bridges.base.Rectangle;
import bridges.connect.Bridges;
import bridges.validation.RateLimitException;

import java.awt.geom.Point2D;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Scanner;
import java.util.Vector;

public class quadtree {

    public static void main(String[] args) throws IOException, RateLimitException {
        Bridges bridges = new Bridges(9, "USERNAME", "APIKEY"); // CHANGE ASSIGNMENT # FOR EACH UNIQUE RUN
        bridges.setTitle("Quadtree Implementation on US Dataset");
        bridges.setDescription("Lab 8B");

        
    }

    static SymbolCollection constructGraph() throws FileNotFoundException {
        /*
        Function to construct the graph, using the us_cities.txt dataset
         */
		return null;
    }

    static QuadtreeElement build(Vector<Point2D> pts, double[] region, int threshold, SymbolCollection sc){
        /*
        Recursive function to "build" the quadtree visually

        @param pts: Collection of Double x,y points
        @param region: boundary, in x,y,width,height format where x,y is the central point of the node and width,height is from central point to edge
        @param threshold: maximum # of points allowed before subdividing
        @param sc: SymbolCollection used for line partitioning
         */
	return null;
    }

    static void search(QuadtreeElement root, String[] cityState, Circle pt, SymbolCollection sc){
        /*
        Recursive function that searches / highlights a given city

        @param root: Quadtree root node
        @param cityState: array of given dataset, formatted {cityName, latitude, longitude}
        @param pt: Circle pt that represents cityState
        @param sc: SymbolCollection used to upload pt and its label to the graph
         */
	}


