import bridges.base.*;
import bridges.connect.Bridges;
import bridges.connect.DataSource;
import bridges.data_src_dependent.City;

import java.util.Vector;
import java.util.HashMap;

public class QT {

    static double[] region = new double[4];

    public static void main(String[] args) throws Exception {

		// create BRIDGES object, credentials
        Bridges bridges = new Bridges(60, "USERNAME", "API KEY");

        bridges.setTitle("Quadtree Construction");

		// create data source object
		DataSource ds = bridges.getDataSource();

		// get the  US city data
		Vector<Point> pts = getInputData(ds, region);

		// build a quadtree from the points
        Quadtree qtree = new Quadtree();
        QuadtreeElement root = qtree.build(pts, region);

		// draw the tree using Symbol Collection primitives
        SymbolCollection sc = drawTree(root, region);

		// set viewport based on enclosing region
        sc.setViewport((float) region[0], (float) region[2], (float) region[1], (float) region[3]);

		// visualize
        bridges.setDataStructure(sc);
        bridges.visualize();

		// TODO: Illustrate searching using the quadtree
        // 		get a set of 100 cities at random; search, highlight and set 
		// 		their labels (names), visualize
    }

	// get a set of US cities from the server
	static Vector<Point> getInputData (DataSource ds, double[] region) {
		
		HashMap<String, String> params = new HashMap<String, String>();
			params.put("min_pop", "20000");

		Vector<Point> pts = new Vector<Point>();
		// TODO: get US city data -- see the tutorial on US Cities 
		// (http://bridgesuncc.github.io/tutorials/Data_USCities.html) for more
		// information on retrieving the data, use the Point object to hold the points in
		// a vector

		// TODO: Also compute the bounding box of the points coordinates and hold it in the
		// region[] array.

		return pts;
	}

    static boolean withinEpsilon(double val1, double val2){
        return Math.abs(val1-val2) < 1e-5;
    }

    static boolean searchByCityQuadTree(QuadtreeElement root, Point pt){
		Boolean found = false;

		// TODO: a function to search the quadtree and return the city closest
		// to the input point 

        return found;
    }

    // visualize the quadtree by drawing its bounding box and partitioning lines
    static SymbolCollection drawTree(QuadtreeElement root, double[] region){
        SymbolCollection sc = new SymbolCollection();

		// TODO: This function will draw the quadtree, illustrating the partitioning
		// lines and the bounding box that encloses the partitioned region.

		// Use the Polygon class to draw a bounded region, and the Polyline class to 
		// draw lines; use the attributes (thickness, color, opacity) to ensure the
		// visualization is clear. 
		// Optional: you can use color to indicate the depth of the tree structure.

		// The function returns a symbol collection object, which contains all the
		// drawn primitives.

        return sc;
    }

}
