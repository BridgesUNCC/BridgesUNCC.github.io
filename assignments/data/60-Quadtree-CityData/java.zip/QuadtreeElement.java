import java.awt.*;
import java.awt.geom.Point2D;
import java.util.Vector;

// class for a Quadtree element
public class QuadtreeElement {
	// partitioners that partition along X and Y
    private double[] partitioners = new double[2];

	// children of this element
    private QuadtreeElement ll, ul, lr, ur;

	// points stored at this node (if a leaf node)
    private Vector<Point> pts;

    private boolean leafNode = false;

    int minThreshold = 10;

	// constructors
    public QuadtreeElement(double x_partitioner, double y_partitioner) {
        partitioners[0] = x_partitioner;
        partitioners[1] = y_partitioner;
        ll = ul = lr = ur = null;
    }

    public QuadtreeElement() {
        partitioners[0] = 0;
        partitioners[1] = 0;
        ll = ul = lr = ur = null;
    }

	// TODO: setters, getters for all fields

}
