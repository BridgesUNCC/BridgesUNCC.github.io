import java.awt.*;
import java.awt.geom.Point2D;
import java.util.Vector;

public class QuadtreeElement {
    double[] x_partitioner;
    double[] y_partitioner;
    double[] region;
    QuadtreeElement ll, ul, lr, ur;
    Vector<Point2D> pts;

    public QuadtreeElement(double[] x_partitioner, double[] y_partitioner, QuadtreeElement ll, QuadtreeElement ul, QuadtreeElement lr, QuadtreeElement ur, Vector<Point2D> pts) {
        this.x_partitioner = x_partitioner;
        this.y_partitioner = y_partitioner;
        this.ll = ll;
        this.ul = ul;
        this.lr = lr;
        this.ur = ur;
        this.pts = pts;
    }

    public QuadtreeElement() {
    }

    public double[] getX_partitioner() {
        return x_partitioner;
    }

    public double[] getY_partitioner() {
        return y_partitioner;
    }

    public QuadtreeElement getLl() {
        return ll;
    }

    public QuadtreeElement getUl() {
        return ul;
    }

    public QuadtreeElement getLr() {
        return lr;
    }

    public QuadtreeElement getUr() {
        return ur;
    }

    public Vector<Point2D> getPts() {
        return pts;
    }

    public void setX_partitioner(double[] x_partitioner) {
        this.x_partitioner = x_partitioner;
    }

    public void setY_partitioner(double[] y_partitioner) {
        this.y_partitioner = y_partitioner;
    }

    public void setLl(QuadtreeElement ll) {
        this.ll = ll;
    }

    public void setUl(QuadtreeElement ul) {
        this.ul = ul;
    }

    public void setLr(QuadtreeElement lr) {
        this.lr = lr;
    }

    public void setUr(QuadtreeElement ur) {
        this.ur = ur;
    }

    public void setPts(Vector<Point2D> pts) {
        this.pts = pts;
    }
}
