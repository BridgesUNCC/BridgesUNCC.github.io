#ifndef QUADTREE_H

#define  QUADTREE_H

#include <limits>
#include <vector>

using namespace std;

#include "primitives.h"

// class that represents a node of the quadtree
class QuadTreeElement {
	private:

		// partitioner 1 (ortho to X axis), Partitioner 2 (ortho to Y axis)
		double partitioners[2] = {0., 0.};

		// 4 children
		QuadTreeElement *ll = nullptr, 
						*ul = nullptr, 
						*lr = nullptr, 
						*ur = nullptr;

		// keeps the location info of each city in a list
		// for this node
		vector<Point> pts;

		// boolean to distinguish between internal and leaf nodes
		bool leafNode = false;

	public:
		// TO DO: Methods to access object data, build quadtree

};

// the main quadtree class
class QuadTree {

	private:
		// recursive function to build the quadtree at a node
		QuadTreeElement *build_R (vector<Point> pts, double *region) {

			// create a quadtree node
			QuadTreeElement *root = new QuadTreeElement;

			if (pts.size() <= root->MinThreshold) {
				// leaf node
				root->setLeafNode(true);
				root->setPoints(pts);
			}
			else {
				// partition the region into 4 quadrants
				// note the region can span 0 and need to get mid point
				root->setLeafNode(false);

				double x_part = region[0] + (region[2] - region[0])/2.;
				double y_part = region[1] + (region[3] - region[1])/2.;

				// store the partitioning lines
				root->setPartitioners (x_part, y_part);

				// classify each point into one of the four regions
				vector<Point> ll_pts, lr_pts, ul_pts, ur_pts;

				for (auto pt : pts) {
					if ((pt.x <= x_part) && (pt.y <= y_part))
						ll_pts.push_back (pt);
					else if ((pt.x > x_part) && (pt.y <= y_part)) 
						lr_pts.push_back (pt);
					else if ((pt.x <= x_part) && (pt.y > y_part)) 
						ul_pts.push_back (pt);
					else if ((pt.x > x_part) && (pt.y > y_part)) 
						ur_pts.push_back (pt);
				}

				// create the 4 subregions (rectangles)
				double xmin = region[0], ymin = region[1],
						xmax = region[2], ymax = region[3];
				double ll_region[] = {xmin, ymin, x_part, y_part};
				double lr_region[] = {x_part, ymin, xmax, y_part};
				double ul_region[] = {xmin, y_part, x_part, ymax};
				double ur_region[] = {x_part, y_part, xmax, ymax};
										 
				// recurse on the 4 subregions
				root->setLowerLeft(build_R(ll_pts, ll_region)); 
				root->setLowerRight(build_R(lr_pts, lr_region));
				root->setUpperLeft(build_R (ul_pts, ul_region)); 	
				root->setUpperRight(build_R (ur_pts, ur_region)); 
			}

			return root;
		}

	public:
		// constructor
		// TODO: constructors, methods to build the tree using the
		// the QuadTreeElement class
		QuadTree () {
		};

		// TODO : function to build the quadtree
		QuadTreeElement *build () {
			// TODO : function to build the quadtree
			// returns the root of the tree
		}

		// TODO : find closest point
		
		Point findClosest () {
			//TODO
		}
};

#endif
