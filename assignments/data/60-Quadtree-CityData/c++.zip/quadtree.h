#ifndef QUADTREE_H

#define  QUADTREE_H

#include <limits>
#include <vector>

using namespace std;

#include "primitives.h"

// class that represents a node of the quadtree
class QuadTreeElement {
	private:

		// partitioner 1 (ortho to X axis), Partitioner 2 (ortho to Y axis)
		double partitioners[2] = {0., 0.};

		// 4 children
		QuadTreeElement *ll = nullptr, 
						*ul = nullptr, 
						*lr = nullptr, 
						*ur = nullptr;

		// keeps the location info of each city in a list
		// for this node
		vector<Point> pts;

		// boolean to distinguish between internal and leaf nodes
		bool leafNode = false;

	public:
		// TO DO: Methods to access object data, build quadtree

};

// the main quadtree class
class QuadTree {

	private:
		// recursive function to build the quadtree at a node
		QuadTreeElement *build_R (vector<Point> pts, double *region) {

			// create a quadtree node
            QuadTreeElement *root = new QuadTreeElement;
			// This is the function that recursively partitions the region
			// into 4 equal sized regions if the number of points within the
			// region is larger than a chosen threshold. 

			// The 4 recursive calls will use the 4 subdivide regions until
			// it reaches the base case. If the region is partitioned into the
			// 4 cells, the points will be classified into the 4 regions

			return root;
		}

	public:
		// constructor
		// TODO: constructors, methods to build the tree using the
		// the QuadTreeElement class
		QuadTree () {
		};

		// TODO : function to build the quadtree
		QuadTreeElement *build (vector<Point> pts, double *region) {
			// TODO : function to build the quadtree
			//  creates the region bounding the points and then calls
			//  recursive build_R() method 

			return build_R(pts, region);
		}

		// TODO : find closest point
		
		Point findClosest () {
			Point pt;
			//TODO
			return pt;
		}
};

#endif
