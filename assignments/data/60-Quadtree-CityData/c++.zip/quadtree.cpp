#include <iostream>
#include <fstream>
#include <vector>

#include "quadtree.h"
#include "primitives.h"
#include "Bridges.h"
#include "DataSource.h"
#include "SymbolCollection.h"
#include "Polygon.h"
#include "Circle.h"
#include "Text.h"
#include "Rectangle.h"

using namespace std;
using namespace bridges;

// 
// This assignment takes in a set of US cities with location information
// and uses a quadtree partitioning to store them. It also illustrates
// searching for cities using the quadtree structure
//
// Author: Kalpathi Subramaian
// Date : 3/9/22
//

const int NumCities  = 1000; // data has 1000 cities

// function prototypes

// draw  the quadtree structure
SymbolCollection* drawTree (QuadTreeElement *root, double *region);
void drawTree_R (QuadTreeElement *root, double *region, SymbolCollection *sc, int level);

// search for a specific city
bool  searchByCityQuadTree (QuadTreeElement *root, Point& pt);
bool  searchQuadTree_R (QuadTreeElement *root, Point& pt);

// read the input data of cities and locations
vector<Point> getInputData(DataSource& ds, double *region);

int main() {
	// set bridges credentials, initializations
	Bridges bridges (160, "BRIDGES_USER_ID", "BRIDGES_API_KEY");
	bridges.setTitle("Quadtree of US Cities and City Search");

	// get a data source object
	DataSource ds(&bridges);
	// represent a region with 4 element array
	double *region = new double[4];

	// get the US City data
	vector<Point> pts = getInputData (ds, region);

	// build the quadtree; the region bounding the data is returned
	QuadTree qtree;
	QuadTreeElement *root = qtree.build (pts, region);


	// draw the tree, using the Symbol Collection primitives
	// the method will return a symbol collection that contains the geometry
	// for the visualization (line segments)
	SymbolCollection *sc = drawTree(root, region);

	// right now, we dont have a map to overlay the tree structure
	// will be fixed soon!

	// set the viewport, so as to position the quadtree properly
	sc->setViewport(region[0], region[2], region[1], region[3]);

	// specify the data structure root, visualize
	// bridges.setDataStructure(sc);
	// bridges.visualize();

	// TODO:
	// get a set of 100 cities at random; search, highlight and set
	// their labels (names)
	// Use the Text object to set attributes for the labels and use
	// the Symbolclass's addSymbol() method to add the label

	// visualize again
//	bridges.setDataStructure(sc);
//	bridges.visualize();

	return 0;
}

// reads the input city data from a file
// also updates the bounding region of the data
vector<Point> getInputData(DataSource& ds, double *region) {

	
	vector<Point> pts;
	// TODO: Get US city data from the server. Look at the tutorial
	// at http://bridgesuncc.github.io/tutorials/Data_USCities.html on how
	// to do that.

	// Get them into a list of points; update the bounding region of the points, 
	// which is returned through the argument.

	// Function returns the point list

	return pts;
}

// closeness function
bool withinEpsilon (double val1, double val2) {
	return std::abs(val1-val2) < 1e-5;	
}

// search the quadtree given a random location
bool  searchByCityQuadTree (QuadTreeElement *root, Point& pt) {
	// TODO
	bool search_result;

	return  search_result;
}

bool  searchQuadTree_R (QuadTreeElement *root, Point& pt) {

	// TODO : this function recursively searches the quadtree
	// with the given point to find the closest match

	bool search_result;

	return  search_result;

}

// visualize the quadtree by drawing its bounding box and partitioning
// lines
SymbolCollection *drawTree (QuadTreeElement *root, double *region) {
	SymbolCollection *sc = new SymbolCollection;

	// TODO:
	// draw the bounding region as a polygon; make the outermost 
	// bounding region a bit larger to see the boundary points clearly

	// recurse and draw the sub-regions
	drawTree_R(root, region, sc, 0);

	// return the symbols representing the visualization geometry
	return sc;
}

void drawTree_R (QuadTreeElement *root, double *region, SymbolCollection *sc, int level) {

// TODO
}

