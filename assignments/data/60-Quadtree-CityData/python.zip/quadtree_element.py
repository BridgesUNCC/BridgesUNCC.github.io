import sys


class Point:
    def __init__(self, x, y, name=None):
        self.x = x
        self.y = y
        self.name = name

    def comp(self, pt1, pt2):
        if pt1.x < pt2.x:
            return True
        elif pt1.x == pt2.x:
            return pt1.y < pt2.y
        else:
            return False

    def get_name(self):
        return self.name


class quad_tree_element:
    def __init__(self, x_partitioner=None, y_partitioner=None):
        self.partitioners = [0, 0]
        self.ll = None
        self.ul = None
        self.lr = None
        self.ur = None
        self.pts = []
        self.leaf_node = False
        self.min_threshold = 10
        if x_partitioner is None and y_partitioner is None:
            self.partitioners[0] = 2
            self.partitioners[1] = 0
        elif x_partitioner is not None and y_partitioner is not None:
            self.partitioners.insert(0, x_partitioner)
            self.partitioners.insert(1, y_partitioner)

    #TODO: setters/getters for all object items


class quad_tree:
    # build the quadtree
    def build(self, pts, region):
        #TODO: find bounding box of region enclosing the points and build a quadtree
        #      partitioning of the points; the points will be classified into the 
        #      4 subregions as the space gets partitioned. Ultimately, if a leaf node
        #      is reached (based on a chosen point threshold, the points are stored in
        #      that element and marked as a leaf node
        pass


    # function to find the closest city location given a specific location (point)
    def find_closest(self, root, pt):
        #TODO:  given a point, find the city that is closest to it. Use the quadtree
        #       to search for the node (log time) with the closest city.
        pass
