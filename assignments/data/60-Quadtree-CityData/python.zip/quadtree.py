import sys
from bridges.bridges import *
from bridges.graph_adj_list import *
from bridges.element import *
from bridges.link_visualizer import *
from bridges.edge import *
from bridges.symbol_collection import *
from bridges.data_src_dependent import *
from bridges.text import *
from bridges.circle import *
from bridges.polyline import *
from bridges.polygon import *
from bridges.rectangle import *
from quadtree_element import Point
from quadtree_element import quad_tree
from quadtree_element import quad_tree_element
import math
import random


def getInputData (region):
    # TODO: get the US cities data. Refer to the tutorial at 
    #  http://bridgesuncc.github.io/tutorials/Data_USCities.html
    #  for information and example on how to get the data
    #  Once you get the city locations, compute the bounding rectangle around the points
    #  and store that in the region[] array
    pass


# closeness function
def within_epsilon(val1, val2):
    return abs(val1 - val2) < 1 * math.e - 2


# search quadtree given a random location
def search_by_city_quad_tree(root, pt):
    # TODO: given a city location (pt), check to see if that city exists in the
    # quadtree. Traverse the tree in log time to find the city
    pass


# visualize the quadtree by drawing its bounding box and partitioning lines
def draw_tree(root, region):
    # TODO: use the symbol collection for the drawing primities
    sc = SymbolCollection()

    # draw the bounding region as a polygon; make the outermost
    # bounding region a bit larger to see the boundary points clearly

    # Travers the tree and draw the partitioning lines - use the Polyline primitive
    # to specify the lines. Use color, width, opacity, thickness to make a nice visualization
    pass


def main():
    # create Bridges object, set credentials
    bridges = Bridges(260, "BRIDGES_USER_ID", "BRIDGES_API_KEY")
    bridges.set_title("Quadtree Partitioning Using US City Locations")

    region = [0, 0, 0, 0]

    
    # get US City data - see tutorial at 
    # 	http://bridgesuncc.github.io/tutorials/Data_USCities.html
    # for more information; returns a set of points of type Point
    pts = getInputData(region)

    # build the quadtree
    qtree = quad_tree()
    root = qtree.build(pts, region)

    # using the SymbolCollection, create  the tree's geometry: partitioning 
    # lines and enclosing region and city locations
    sc = draw_tree(root, region)

    # center the visualization around the bounding region
    sc.setviewport(region[0], region[2], region[1], region[3])

    # visualize
    bridges.set_data_structure(sc)
    bridges.visualize()


    # Get a set of 200 cities at random; search, highlight and set
    # their labels (city names) using the search_by_city() method.
    # Use the Text class to set labels at the city locations.

    # visualize
    bridges.set_data_structure(sc)
    bridges.visualize()


if __name__ == '__main__':
    main()
