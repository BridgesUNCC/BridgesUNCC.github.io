#include "Bridges.h"
#include "ColorGrid.h"
#include <random>
#include <cmath>
	
using namespace bridges;

//
// Using color grid to estimate the value of PI
//
// Method: Take a square shape of size S,  and inscribe a circle of radius S/2
//  Ration of the areas of the circle to the square is  
//	Pi r^2/ S^2 = Pi r^2/(2r)^2 = Pi/4.  Thus 4 times the ratio is an estimate
//  of Pi
//
//  Implementation: Use the color grid points and count the points within
//  the circle and divide by th total points in the square to get Pi estimate
//
// 	Useful classes: ColorGrid, Color
//

int main() {
    const int Grid_Size = 512; // Grid size
    const float Radius = Grid_Size / 2.0;
    int tot_pts = 100000; // Total number of points generated in the square
	
    // create Bridges object
    Bridges bridges (171, "BRIDGES_USER_ID", "BRIDGES_API_KEY");

    // set title
    bridges.setTitle("Pi Estimation");
    bridges.setDescription("Using color grid to estimate the value of PI");

    // create a color grid
    ColorGrid grid = ColorGrid(Grid_Size, Grid_Size);

    // TODO: Initialize a random number generator for generating points
    // within the square

    // TODO: Create a variable for number of points generated inside the circle
    
    // TODO: Write a loop that generates random points within a square and checks if they fall inside a circle.
	// Generate a 2D point at random within the square
		
	// Check if point is within the circle of radius 256 (512/2)
        // Compute distance to center (256, 256)
		
		// Count points within the circle and color the point red
    
    // TODO: End loop

    /* TODO: Calculate an estimation of the mathematical constant π (pi)
           using the Monte Carlo simulation method*/

    // TODO: Print out the pi value
	
    // TODO: Print pi value estimate as part of the description
	
    // set handle, visualize
    bridges.setDataStructure(&grid);
    bridges.visualize();

    return 0;

}
