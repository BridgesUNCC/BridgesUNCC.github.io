import bridges.base.Color; 
import bridges.base.ColorGrid; 
import java.util.Random;
import bridges.connect.Bridges;
import java.io.IOException;
import bridges.validation.RateLimitException;

//
// Using color grid to estimate the value of PI
//
// Method: Take a square shape of size S,  and inscribe a circle of radius S/2
//  Ration of the areas of the circle to the square is  
//	Pi r^2/ S^2 = Pi r^2/(2r)^2 = Pi/4.  Thus 4 times the ratio is an estimate
//  of Pi
//
//  Implementation: Use the color grid points and count the points within
//  the circle and divide by th total points in the square to get Pi estimate
//

public class Pi_Estimation{

    public static void main(String[] args) throws IOException, RateLimitException
    {
        final int gridSize = 512; //Grid Size
        final int halfGridSize = gridSize / 2;
        final int circleRadius = halfGridSize;
        final int tot_pts = 100000; // Total number of points generated in the squuare
        
        // Initialize Bridges object 
        Bridges bridges = new Bridges(71, "BRIDGES_USER_ID", "BRIDGES_API_KEY");
        
        // Set title
        bridges.setTitle("Pi Estimation");
        
        // Color grid created
        ColorGrid grid = new ColorGrid(gridSize, gridSize);

        // TODO: Initialize a random number generator 
        
        // TODO: Create a variable for number of points generated inside the circle

        // TODO: Write a loop that generates random points within a square and checks if they fall inside a circle.
            // Generate random x and y coordinates for a point within the square.
            // Calculate the distance from the center of the square to the generated point.
            // This distance helps determine if the point is inside the inscribed circle.
            
            // Check if the point is inside the circle and if it is increase the number of points in the circle.
                // Also, color the grid cell representing this point as red.
                // If the point is outside the circle, color the grid cell as blue.
                
        // TODO: End loop
        
        /* TODO: Calculate an estimation of the mathematical constant π (pi)
           using the Monte Carlo simulation method*/
        
        // TODO: Print out the pi value

        // TODO: Print pi value estimate as part of the description  
        
        // Set data structure and visualize 
        bridges.setDataStructure(grid); 
        bridges.visualize();

    }
}
