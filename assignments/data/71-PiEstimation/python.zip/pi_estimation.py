from bridges.color_grid import *
from bridges.bridges import *
import random
import math


def main():
    grid_size = 512
    radius = grid_size / 2
    red = Color(col_name="red")
    blue = Color(col_name="blue")
    tot_pts = 100000  # Total number of points generated in the square

    # Initialize Bridges
    bridges = Bridges(271, "BRIDGES_USER_ID", "BRIDGES_API_KEY")
    bridges.set_title("Pi Estimation")
    bridges.set_description("Using color grid to estimate the value of PI")

    # ColorGrid created
    grid = ColorGrid(grid_size, grid_size, red)

    # TODO: Random number generator initializations for generating points within the square

    # TODO: Create a variable for number of points generated inside the circle

    # TODO: Write a loop that generates random points within a square and checks if they fall inside a circle.
    # Generate a 2D point at random within the square

    # Check if point is within the circle of radius 256 (512/2)
    # Compute distance to center (grid_size / 2, grid_size / 2)

    # Count points within the circle and color the point red and the rest blue

    # End loop

    # TODO: Calculate an estimation of the mathematical constant π (pi) using the Monte Carlo simulation method

    # TODO: Print out the pi value

    # TODO: Print pi value estimate as part of the description

    # Set handle, visualize - commented out to avoid compilation error
    bridges.set_data_structure(grid)
    bridges.visualize()


if __name__ == '__main__':
    main()
