from bridges import *


class StudentClass(NonBlockingGame):

    gridColumns = 0
    gridRows = 0

    backgroundColor = NamedColor.blue
    duckColor = NamedColor.yellow
    duckSymbol = NamedSymbol.duck

    duckColumn = 0
    duckRow = 0

    def initialize(self):
        self.backgroundColor = NamedColor.blue
        self.duckColor = NamedColor.green
        self.duckSymbol = NamedSymbol.duck

    def update_grid(self):
        col = 0
        row = 0
        while col < self.gridColumns:
            rows = 0
            while row < self.gridRows:
                if col == self.duckColumn and row == self.duckRow:
                    
                else:
                    self.draw_object(col, row, NamedSymbol.none, self.backgroundColor)
                row+=1
            col+=1


    def game_loop(self):
        if self.key_up():
            if self.duckColumn > 0:
                
        if self.key_down():
            if self.duckColumn < self.gridColumns-1:
                self.duckColumn+=1
        if self.key_left():
            if self.duckRow > 0:
                
        if self.key_right():
            if self.duckRow < self.gridRows-1:
                self.duckRow+=1

        self.update_grid()

    def __init__(self, assid, login, apikey, cols, rows):
        super(StudentClass, self).__init__(assid, login, apikey, cols, rows)
        self.gridColumns = cols
        self.gridRows = rows


def main():
    my_game = StudentClass(80, "STUDENT_USERNAME", "STUDENT_API_KEY", 30, 30)
    my_game.start()


if __name__ == '__main__':
    main()
