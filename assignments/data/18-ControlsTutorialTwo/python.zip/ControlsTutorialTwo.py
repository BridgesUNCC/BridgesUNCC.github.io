from bridges import *


class StudentClass(NonBlockingGame):
    def __init__(self, assid, login, apikey, rows=0, cols=0):
        super(StudentClass, self).__init__(assid, login, apikey, rows, cols)
        self.gridColumns = rows
        self.gridRows = cols
        self.backgroundColor = NamedColor.blue
        self.duckColor = NamedColor.yellow
        self.duckSymbol = NamedSymbol.duck
        self.duckColumn = 0
        self.duckRow = 0

    def initialize(self):
        self.backgroundColor = NamedColor.blue
        self.duckColor = NamedColor.green
        self.duckSymbol = NamedSymbol.duck

    def update_grid(self):
        pass


    def game_loop(self):
        if self.key_up():
            pass
        if self.key_down():
            pass
        if self.key_left():
            pass
        if self.key_right():
            pass

        self.update_grid()


def main():
    my_game = StudentClass(218, "STUDENT_USERNAME", "API_KEY", 30, 30)

    my_game.set_title("Rubber Ducky")
    my_game.set_description("Test out your controls using the arrow keys to move the duck around.")
    
    my_game.start()


if __name__ == '__main__':
    main()
