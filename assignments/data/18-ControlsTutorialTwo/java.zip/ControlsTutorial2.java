import bridges.base.NamedColor;
import bridges.base.NamedSymbol;
import bridges.games.NonBlockingGame;

//
//  To teach students the functions that allow them to interact with their games.
//  In tutorial two, students will move a sprite around the grid.
//
//  Relevant classes: NonBlockingGame, NamedColor, NamedSymbol

public class ControlsTutorial2 extends NonBlockingGame {

  // Your grid can contain up to 1024 cells.
  // The largest square grid available is 32 x 32
  static int gridColumns = 30;
  static int gridRows = 30;

  // sprite properties
  NamedColor backgroundColor;
  NamedColor duckColor;
  NamedSymbol duckSymbol;

  // sprite position
  int duckColumn;
  int duckRow;

  // The initialize function runs once before the game loop begins.
  // Assign your game variables here.
  public void initialize() {
    // some initializations for the sprite
    // sprite color, symbol, background color
    // initial position of sprite
  }

  // Create your own functions to make changes to your game.
  // This is an example function that sets the background color of
  // each grid cell to your background color and checks for the location
  // of your player so that it appears on your game.
  public void updateGrid() {
    // redraw method
    // draw the sprite at its current position (remaining cells are
    // NamedSymbol::None; then paint background color for all cells
  }

  // The game loop runs contiunously. So anything you put here will be called
  // repeatedly until the game ends.
  public void gameLoop() {

    // There are 10 keys that you can use to control your game.
    // In the last tutorial we used them to change colors. This time we will
    // use the arrow keys to move a sprite around the grid.

    // Don't forget to call your updateGrid() method!
  }

  //  To test your game, create an object of your game within the main method.
  //  Use an assignment number, your bridges username, your bridges API key, the number
  //  of columns  in your grid, and the number of rows in your grid as arguments
  //  for your bridges game object.
  public static void main(String args[]) {
    // Initialize.
    ControlsTutorial2 sf = new ControlsTutorial2(1, "BRIDGES_USER_ID",
        "BRIDGES_API_KEY", gridColumns, gridRows);
  }

  // my_game constructor
  public ControlsTutorial2(int assid, String userName, String apiKey, int gc, int gr) {
    super(assid, userName, apiKey, gc, gr);
    setTitle("Rubber Ducky");
    setDescription("Test out your controls using the arrow keys to move the duck around.");

    // start the game
    start();
  }
}
