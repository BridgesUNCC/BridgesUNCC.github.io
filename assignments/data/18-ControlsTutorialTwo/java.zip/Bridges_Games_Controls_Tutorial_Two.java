package STUDENT_PACKAGE;

import bridges.base.NamedColor;
import bridges.base.NamedSymbol;
import bridges.games.NonBlockingGame;

public class STUDENT_CLASS_NAME extends NonBlockingGame {

    // Your grid can contain up to 1024 cells. 
    // The largest square grid available is 32 x 32
    static int gridColumns = 30;
    static int gridRows = 30;

    // Create variables for your games colors and symbols.
    NamedColor backgroundColor;
    NamedColor duckColor;
    NamedSymbol duckSymbol;
    
    // Create variables to keep track of the state of your game.
    int duckColumn;
    int duckRow;

    // The initialize function runs once before the game loop begins.
    // Assign your game variables here.
    public void initialize() {
        backgroundColor = NamedColor.blue;
        duckColor = NamedColor.yellow;
        duckSymbol = NamedSymbol.duck;

        // Where will your player start out on the grid?
        // This one will start in the far corner of the grid.
        // Make sure these values fit within your array.
        duckColumn = 0;
        duckRow = 0;  
    }

    // Create your own functions to make changes to your game.
    // This is an example function that sets the background color of
    // each grid cell to your background color and checks for the location
    // of your player so that it appears on your game.
    public void updateGrid() {
        for (int r = 0; r < gridRows; r++) {
            for (int c = 0; c < gridColumns; c++) {
                
                // While iterating through your game grid you can find the cell that matches
                // the row and column of your player. If it does, then draw the sprite. If not, 
                // set the symbol in that cell to none so it's empty.
                if(c == duckColumn && r == duckRow){
                    
                }else{
                    
                }
                
                // Each sell should have your background color in this case.
                // But you can decide using other conditional statements if you
                // want different parts of your background to be different colors.
                setBGColor(r, c, backgroundColor);
            }
        }
    }

    // The game loop runs contiunously. So anything you put here will be called
    // repeatedly until the game ends.
    public void gameLoop() {

        // There are 10 keys that you can use to control your game.
        // In the last tutorial we used them to change colors. This time we will
        // use the arrow keys to move a sprite around the grid.
        if (keyUp()) {
            if(duckColumn > 0){
                duckColumn--;
            }
        }
        if (keyDown()) {
            if(duckColumn < gridColumns){
                
            }
        }
        if (keyLeft()) {
            if(duckRow >= 0){
                
            }
        }
        if (keyRight()) {
            if(duckRow < gridRows){
                
            }
        }
        
        // Don't forget to call your updateGrid() method!
        updateGrid();
    }

    // To test your game, create an object of your game within the main method of your program.
    // Use an assignment number, your bridges username, your bridges API key, the number of columns
    // in your grid, and the number of rows in your grid as arguments for your bridges game object.
    public static void main(String args[]) {
        // Initialize.
        STUDENT_CLASS_NAME sf = new STUDENT_CLASS_NAME(1, "Allie_Beckman", "825604476223", gridColumns, gridRows);
    }

    // Make sure you create this method in your game so that it can be visualized by the bridges server.
    public STUDENT_CLASS_NAME(int assid, String userName, String apiKey, int gc, int gr) {
        super(assid, userName, apiKey, gc, gr);
        setTitle("Rubber Ducky");
        setDescription("Test out your controls using the arrow keys to move the duck around.");
        // start running the game
        start();
    }
}
