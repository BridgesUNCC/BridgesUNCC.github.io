#include <NonBlockingGame.h>
#include <iostream>

using namespace bridges::game;

//
//  To teach students the functions that allow them to interact with their games.
//  In tutorial two, students will move a sprite around the grid.
//
//  Relevant classes: NonBlockingGame, NamedColor, NamedSymbol
struct my_game : public NonBlockingGame {
  NamedColor backgroundColor;

  // sprite properties
  NamedColor duckColor;
  NamedSymbol duckSymbol;

  // sprite position
  int duckColumn;
  int duckRow;

  my_game(int assID, std::string username, std::string apikey)
    : NonBlockingGame (0, username, apikey, 30, 30) {
    setTitle("Rubber Ducky");
    setDescription("Test out your controls using the arrow keys to move the duck around");
  }

  virtual void initialize() override {
    // some initializations for the sprite
    // sprite color, symbol, background color
    // initial position of sprite
  }

  void updateGrid() {
    // redraw method
    // update the sprite position and then paint background
  }

  virtual void gameLoop() override {
    // Take user input and alter the board in some way
    // use the arrow key functions to move the sprite around
    // make sure to not go off the grid!

    // then repaint the grid

  }
};

// Initialize your game
// Call your game class with your assignment id, username, and api key
int main (int argc, char** argv) {
  my_game g(118, "BRIDGES_USER_ID", "BRIDGES_API_KEY");

  g.start();
}
