import java.util.Map;
import java.util.HashMap;
import java.util.PriorityQueue;
import java.util.Comparator;

import bridges.base.Element;
import bridges.base.SLelement;
import bridges.base.GraphAdjList;
import bridges.base.Edge;
import bridges.base.Color;
import bridges.base.ElementVisualizer;
import bridges.base.LinkVisualizer;
import bridges.connect.Bridges;
import bridges.connect.DataSource;
import bridges.data_src_dependent.OsmData;
import bridges.data_src_dependent.OsmVertex;
import bridges.data_src_dependent.OsmEdge;



public class osm {

  //returns the relative difference between two double. Useful to
  //compare equality between doubles.
  public static double RelDif(double a, double b) {
    double c = Math.abs(a);
    double d = Math.abs(b);

    d = Math.max(c, d);

    return d == 0.0 ? 0.0 : Math.abs(a - b) / d;
  }


  //shortest path algorithm
  public static void shortestPath (GraphAdjList<Integer, OsmVertex, Double> gr,
                               int source,
                               HashMap<Integer, Double> distance,
			       HashMap<Integer, Integer> parent) {

      //TODO
  }


  // return the vertex from the graph that is the closest to (lat,lon)
  public static int getClosestVertex(GraphAdjList<Integer, OsmVertex, Double> graph, double lat, double lon) {
    //TODO
    return -1;
  }

  //this function is used to style vertices based on their distance to the source
  public static void styleDistance(GraphAdjList<Integer, OsmVertex, Double> graph,
                                   HashMap<Integer, Double> distance) {
    //TODO

    //Find max distance. (Beware of unreachable vertices with a distance of Double.MAX_VALUE)

    //color vertices based on distances

    //optional: style edges if they are shortest path edges. (Beware of back edges)

  }

  //style the graph by greying out all vertices and edges except
  //those on the SP between the source and destinatin. (No need to
  //pass the source since all parent chase go there.)
  public static void styleParent(GraphAdjList<Integer, OsmVertex, Double> graph,
                                 HashMap<Integer, Double> distance,
                                 HashMap<Integer, Integer> parent,
                                 int dest
                                ) {
    //TODO

    //set all edges to transparent

    //set all vertices to transparent

    //for each edge on the SP from source to dest
    ////Style vertex on the path

    ////style edge on the path (beware of potential back edges)
  }

  //style the root of the shortest path
  public static void styleRoot(GraphAdjList<Integer, OsmVertex, Double> graph,
                               int root) {
    //TODO
  }

  public static void main(String[] args) throws Exception {

    //create the Bridges object, set credentials
    Bridges bridges = new Bridges(9, "BRIDGES_USER_ID", "BRIDGES_API_KEY");
    bridges.setTitle("Graph : OpenStreet Map Example");
    bridges.setDescription ("Charlotte: Color of vertices is based on distance from center of the city");

    //Getting Data
    int closest;
    double latc, lonc;
    int dest;

    //TODO: Get data!
    DataSource ds = bridges.getDataSource();
    //OsmData osm_data = ds.getOsmData("Charlotte, North Carolina", "primary");
    //OsmData osm_data = ds.getOsmData("Charlotte, North Carolina", "secondary");
  
    OsmData osm_data = ds.getOsmData(35.28, -80.8, 35.34, -80.7, "tertiary"); //UNCC Campus
    
    //OsmData osm_data = ds.getOsmData(39.85, -83.14, 40.12, -82.85, "secondary"); //Columbus, OH
    //OsmData osm_data = ds.getOsmData(39.121, -77.055, 39.208, -76.805); //Baltimore, MD

    
    GraphAdjList<Integer, OsmVertex, Double> graph = osm_data.getGraph ();
    graph.forceLargeVisualization(true);
    
    
    ////TODO: Uncomment for part 2
    // double[] latr = new double[2];
    // double[] lonr = new double[2];
    // osm_data.getLatLongRange(latr, lonr);
    ////Getting source vertex (Using center of the map)
    // closest = getClosestVertex(graph,
    //         latr[0]+(latr[1]-latr[0])/2.,
    //         lonr[0]+(lonr[1]-lonr[0])/2.);

    // dest = getClosestVertex(graph,
    //      latr[0]+(latr[1]-latr[0])/4.,
    //      lonr[0]+(lonr[1]-lonr[0])/4.);
    // styleRoot(graph, closest);
    // bridges.setDataStructure(graph);
    // bridges.visualize();

    //TODO: Uncomment for part 3
    ////Running shortest path
    //HashMap<Integer, Double> distance= new HashMap<Integer, Double>();
    //HashMap<Integer, Integer> parent = new HashMap<Integer, Integer>();
    //shortestPath(graph, closest, distance, parent);

    ////Styling
    // styleDistance(graph, distance);
    // bridges.visualize();

    //TODO: Uncomment for part 4
    // styleParent(graph, distance, parent, dest);
    // bridges.visualize();
  }

}

