from bridges import *

class BST(object):
    root = None
    node_count = 0

    def __init__(self):
        root = None
        node_count = 0

    def _insert(self, root, k, it):
        if root == None:
            el = BSTElement(key=k, e=it)
            el.label = el.value.title + " \\n " + el.value.time
            return el

        if k < root.key:
            root.left = self._insert(root.left, k, it)
        else:
            root.right = self._insert(root.right, k, it)

        return root

    def insert(self, k, it):
        self.root = self._insert(self.root, k, it)
        self.node_count += 1

    def highlight_quake_range(self):
        pass
        
    def set_properties(self):
        pass

def main():
    bridges = Bridges(ASSIGNMENT_NUMBER, "BRIDGES_USER_ID", "BRIDGES_API_KEY")
    
    bridges.set_title("Recent Earthquakes (USGIS Data)")
    bridges.set_description("Build a BST based on earthquake data and highlight earthquakes based on magnitude.")

    eq_list = get_earthquake_usgs_data(1000)

    # create a binary search tree - this will be a wrapper around the Bridges binary
	# search tree, which is composed of BSTElement objects; BST can be used to embed various
    bst = BST()

    # TODO: Insert each of the retrieved quake objects (of type EarthquakeUSGS) into
	# the binary search tree.  Use the insert() method (defined in BST). 
	# Insert the retrieved earthquake objects  into the tree, using the quake magnitudes;
	# see the EarthquakeUSGS class for details on all properties of the quake.

    # TODO: Visualize the BST that you have just constructed. The root of the tree
	# is accessible by bst.root, which will be the handle to the 
	# bridges.set_data_structure() method

    bridges.set_data_structure(bst.root)
    bridges.visualize()

    # TODO: There are lots of tiny uninteresting quakes. Select a good number of quakes, but
	# only insert them if they are above a threshold magnitude. Play with the magnitude to
	# look at quakes further back in time. Adjust MaxElements accordingly. Then Visualize again.

	# TODO: Now, you will write some simple recursive algorithms on the tree itself (BST);
	# you will find function stubs in BST
	# First, highlight the quakes by magnitude. Quakes are usually in the range 0-8 (above that
	# can be really bad! Pick a few colors (say green towards red) and set the node colors
	# by their magnitude range.

if __name__ == '__main__':
    main()