
#include <string>
#include <iostream>
#include <fstream>

using namespace std;

#include "Bridges.h"
#include "DataSource.h"
#include "data_src/EarthquakeUSGS.h"
#include "BSTElement.h"
#include "bst.h"

//
// Driver to illustrate importing USGS earthquake data and inserting it into a binary search tree
// and running traversal algorithms to highlight quakes by their range, location, etc
//



using namespace bridges;

int MAX_QUAKES = 1000;   // can go up to 10000

int main() {
  // Instantiate a Bridges object , plug in your credentials
  Bridges bridges(105, "BRIDGES_USER_ID", "BRIDGES_API_KEY");

  // set a title for the visualization
  bridges.setTitle("Recent Earthquakes (USGIS Data)");

  // Retrieve a list of (maxElements) Earthquake Tweets
  DataSource ds;
  vector<EarthquakeUSGS> eq_list = ds.getEarthquakeUSGSData(MAX_QUAKES);

  // create a binary search tree - this will be a wrapper around the Bridges binary
  // search tree, which is composed of BSTElement objects; BST can be used to embed various
  // search tree algorithms - see bst.h
  BST<float, EarthquakeUSGS> *bst = new BST<float, EarthquakeUSGS> ();

  // TODO: Insert each of the retrieved quake objects (of type EarthquakeUSGS) into
  // the binary search tree.  Use the insert() method (defined in bst.h).
  // Insert the retrieved earthquake objects  into the tree, using the quake magnitudes;
  // see the EarthquakeUSGS class for details on all properties of the quake.

  // TODO: Visualize the BST that you have just constructed. The root of the tree
  // is accessible by bst->getTreeRoot(), which will be the handle to the
  // bridges.setDataStructure() method

  bridges.setDataStructure(bst->getTreeRoot());
  bridges.visualize();

  // TODO: There are lots of tiny uninteresting quakes. Select a good number of quakes, but
  // only insert them if they are above a threshold magnitude. Play with hte magnitude to
  // look at quakes further back in time. Adjust MaxElements accordingly. Then Visualize again.


  // TODO: Now, you will write some simple recursive algorithms on the tree itself (BST.h);
  // you will find function stubs in bst.h
  // First, highlight the quakes by magnitude. Quakes are usually in the range 0-8 (above that
  // can be really bad! Pick a few colors (say green towards red) and set the node colors
  // by their magnitude range.


  bst->findAndHighlightQuakeRange(bst->getTreeRoot());

  // TODO: Visualize again

  // TODO: (Optional, if you have more time): You may try to identify and highlight
  // nodes by their location;
  // Alaska and Hawaii usually have lots of quakes, so match the location string to find
  // these locations and highlight them in a specific color, can do multiple such locations,
  // etc. See the function stubs at the end of BST.h for additional exercises.

  // TODO(Optional): Consider modifying the insert() or find method to highlight the path taken by
  // search algorithm prior to insertion or find. Use the getVisualizer() and getLinkVisualizer()
  // methods to mark the path.

  return 0;
}
