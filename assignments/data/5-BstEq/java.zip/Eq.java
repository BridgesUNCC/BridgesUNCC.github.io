
//
// Driver to illustrate importing USGS earthquake data and inserting it into a binary search tree
// and running traversal algorithms to highlight quakes by their range, location, etc
//

import bridges.connect.Bridges;
import bridges.base.BSTElement;
import bridges.data_src_dependent.EarthquakeUSGS;
import bridges.data_src_dependent.Tweet;
import bridges.data_src_dependent.USGSaccount;
import java.util.List;

public class Eq {
  public static final int maxElements = 1000; //number of tweets

  public static void main(String[] args) throws Exception {

    // Instantiate a Bridges object , plug in your credentials
    Bridges bridges = new Bridges (5, "BRIDGES_USER_ID", "BRIDGES_API_KEY");


    // set a title for the visualization
    bridges.setTitle("Recent Earthquakes(USGIS Data)");
    bridges.setDescription("Build a BST based on earthquake data and highlight earthquakes based on magnitude.");

    // Retrieve a list of (maxElements) Tweets
    List<EarthquakeUSGS> eq_list = bridges.getDataSource().getEarthquakeUSGSData(maxElements );

    // create a binary search tree - this will be a wrapper around the Bridges binary
    // search tree, which is composed of BSTElement objects; BST can be used to embed various
    // search tree algorithms
    BST<Double, EarthquakeUSGS>  bst = new BST<Double, EarthquakeUSGS>();

    // TODO: Insert each of the retrieved quake objects (of type EarthquakeUSGS) into
    // the binary search tree.  Use the insert() method (defined in BST.h). Use the quake
    // insert the retrieved earthquake objects  into the tree, using the quake magnitudes;
    // see the EarthquakeUSGS class for details on all properties of the quake.

    // TODO: Visualize the BST that you have just constructed. The root of the tree
    // is accessible by bst.getTreeRoot(), which will be the handle to the bridges.setDataStructure()
    // method

    bridges.setDataStructure(bst.getTreeRoot());
    bridges.visualize();

    // TODO: There are lots of tiny uninteresting quakes. Select a good number of quakes, but
    // only insert them if they are above a threshold magnitude. Play with hte magnitude to
    // look at quakes further back in time.
    for ( int i = 0; i < eq_list.size(); i++ ) {
    }

    // TODO: Visualize again
    bridges.setDataStructure(bst.getTreeRoot());
    bridges.visualize();

    // Now, you will write some simple recursive algorithms on the tree itself (BST.h);
    // you will find function stubs in BST.h
    // First, highlight the quakes by magnitude. Quakes are usually in the range 0-8 (above that
    // can be really bad! Pick a few colors (say green towards red) and set the node colors
    // by their magnitude range.

    bst.findAndHighlightQuakeRange(bst.getTreeRoot(), 0.0f, 8.0f);

    // TODO: Visualize again
    bridges.setDataStructure(bst.getTreeRoot());
    bridges.visualize();

    // TODO(Optional, if you have more time): You may try to identify and highlight
    // nodes by their location;
    // Alaska and Hawaii usually have lots of quakes, so match the location string to find
    // these locations and highlight them in a specific color, can do multiple such locations,
    // etc. See the function stubs at the end of BST.h for additional exercises.

    // TODO(Optional): Consider modifying the insert() or find method to highlight the path taken by
    // search algorithm prior to insertion or find. Use the getVisualizer() and getLinkVisualizer()
    // methods to mark the path.


  }
}
