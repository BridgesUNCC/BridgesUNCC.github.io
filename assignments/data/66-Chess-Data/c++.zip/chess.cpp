#include "Bridges.h"
#include "GraphAdjList.h"
#include "GameJSON.h"

using namespace std;
using namespace bridges;

int main(){
	Bridges bridges (166, "USERNAME", "APIKEY");
	bridges.setTitle("Alireza2003 matchup visualization");
	GameJSON game;
	
	GraphAdjList<string, string, int> graph;
	graph.addVertex("alireza2003");
	
	//TODO: Visualize alireza2003's matchups

	bridges.setDataStructure(graph);
	bridges.visualize();
	return 0;
}
