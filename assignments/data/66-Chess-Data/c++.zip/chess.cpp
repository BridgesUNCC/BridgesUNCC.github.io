#include "Bridges.h"
#include "GraphAdjList.h"
#include "GameJSON.h"

using namespace std;
using namespace bridges;

int main(){
	Bridges bridges (166, "USERNAME", "APIKEY");
	bridges.setTitle("Alireza2003 matchup visualization");
        bridges.setDescription("Determine how many games Alireza2003 (the number one player on Lichess.org) won/lost/drew out of his last 50.");
	GameJSON game;
	
	GraphAdjList<string, string, int> graph;
	graph.addVertex("alireza2003");
	
	//TODO: Visualize alireza2003's matchups

	bridges.setDataStructure(graph);
	bridges.visualize();
	return 0;
}
