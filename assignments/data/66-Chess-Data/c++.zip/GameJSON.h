#include "json/single_include/nlohmann/json.hpp"
#include <fstream>


using namespace std;
using json = nlohmann::json;

class GameJSON{
	private:
		json data;
	public:
		GameJSON(){
			//NOTE: UPDATE games.json LOCATION OR THIS WILL FAIL
			ifstream f("games.json");
			data = json::parse(f);
		}
		
		json getGame(int i){
			return data[i];
		}
		
		string getWhiteUsername(int i){
			return data[i]["players"]["white"]["user"]["name"];
		}
		
		string getBlackUsername(int i){
			return data[i]["players"]["black"]["user"]["name"];
		}

		string getWinner(int i){
			if(data[i].contains("winner")){
				return data[i]["winner"];
			} else {
				return "draw";
			}
		}
};