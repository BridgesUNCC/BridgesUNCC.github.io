import json

from bridges import GraphAdjList, Bridges


def assignment():
    # create the Bridges object, set credentials
    bridges = Bridges(266, "BRIGES_USERNAME", "BRIDGES_APIKEY")
    # set title
    bridges.set_title("Games History for User: Alireza2003")
    bridges.set_description("Determine how many games Alireza2003 (the number one player on Lichess.org) won/lost/drew out of his last 50.")

    # read data file
    # WILL NEED TO UPDATE FOR NEW games.json LOCATION
    file = open('games.json')
    data = json.load(file)

    # create graph
    graph = GraphAdjList()
    graph.add_vertex('alireza2003')
    graph.get_visualizer('alireza2003').color = 'blue'
    # for each object (game) in data file
    for o in data:
        # TODO: visualize alireza2003's wins, losses, and draws via graph vertexes and edges
    # set graph as datastructure and visualize
    bridges.set_data_structure(graph)
    bridges.visualize()


if __name__ == '__main__':
    assignment()
