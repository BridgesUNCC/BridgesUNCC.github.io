import java.io.IOException;
import bridges.base.GraphAdjListSimple;
import bridges.connect.Bridges;
import bridges.validation.RateLimitException;
import org.json.JSONException;

public class Chess {
    public static void main(String[] args) throws IOException, JSONException, RateLimitException {
        Bridges bridges = new Bridges(66, "USERNAME", "APIKEY");
        // Create graph
        GraphAdjListSimple<String> graph = new GraphAdjListSimple<>();
        // Add our user vertex, alireza2003 is the user whose games have been exported for this assignment
        graph.addVertex("alireza2003", "alireza2003");
        // Access the Game JSON, UPDATE FILE LOCATION
        GameJSON game = new GameJSON("../data/games.json");
        // For each one of alireza2003's games (50)
        for(int i = 0; i < 50; i++){
            
        }
        bridges.setDataStructure(graph);
        bridges.visualize();
    }
}
