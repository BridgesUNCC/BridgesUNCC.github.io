import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class GameJSON {
    private JSONArray arr;
    public GameJSON(String file) throws FileNotFoundException, JSONException {
        File data = new File(file);
        Scanner input = new Scanner(data);

        StringBuilder games = new StringBuilder();
        while(input.hasNextLine()){
            games.append(input.nextLine());
        }
        setJSONArray(games.toString());
    }

    private void setJSONArray(String s) throws JSONException {
       arr = new JSONArray(s);
    }

    public JSONObject getGame(int i) throws JSONException {
        return (JSONObject) arr.get(i);
    }

    public String getWhiteUsername(int i) throws JSONException {
        JSONObject game = getGame(i);
        JSONObject players = (JSONObject) game.get("players");
        JSONObject white = (JSONObject) players.get("white");
        JSONObject whiteUser = (JSONObject) white.get("user");
        return (String) whiteUser.get("name");
    }

    public String getBlackUsername(int i) throws JSONException {
        JSONObject game = getGame(i);
        JSONObject players = (JSONObject) game.get("players");
        JSONObject black = (JSONObject) players.get("black");
        JSONObject blackUser = (JSONObject) black.get("user");
        return (String) blackUser.get("name");
    }

    public String getWinner(int i) throws JSONException {
        JSONObject game = getGame(i);
        if(game.has("winner")){
            return (String) game.get("winner");
        } else {
            return "draw";
        }
    }
}
