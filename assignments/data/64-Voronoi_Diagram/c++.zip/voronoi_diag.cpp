#include "Bridges.h"
#include "ColorGrid.h"

#include <random>
#include <sstream>
#include <string>
#include <vector>
#include <utility>

using namespace std;
using namespace bridges;

// This program computes the Voronoi regsions using a brute force algorithm
// and uses the ColorGrid to display the output. See the README.md for a
// detailed description


int main() {

	// set the number of sites and size of your 2D grid (plane)
	const int num_sites = 25,
			grid_size = 500;


	// generate a set of 2D random points  to represent the Voronoi sites
	// reference: https://en.cppreference.com/w/cpp/numeric/random
	
	// keep the points in a list  (you can use the pair<int, int> class)

	// generate the Voronoi regions using a brute force approach

	// display the Voronoi regions using a Bridges ColorGrid

	return 0;
}

// this function generates the Voronoi regions using a brute force approach,
// i.e. it computes each points distance from every site and keeps an id of
// of the closest site it belongs to. The function can return a 2D map containing
// the site ids
unordered_map<int, int> generateVoronoiRegions (
		vector<pair<int, int>> sites, const int grid_size) {

	
	unordered_map<int, int> voronoi_regions;

	// initialize region map to some initial value


	// must maintain a distance image that keeps track of smallest distance
	// at each point to any site, must initialize

	// computing the voronoi region ids
	// iterate through the whole grid and for each point compute its
	// distance from each site and keep the smallest distance and also
	// update the voronoi region id

	return voronoi_regions;
}

// this function returns the distance between two points
int getDistanceSquared(int i, int j, pair<int, int> site) {

	int d = 0;

	return 0;
}

// visualize the Voronoi regions and sites
void displayVoronoiRegions(unordered_map<int, int> regions, int grid_size,
								vector<pair<int, int>> sites) {

	Bridges bridges(1, "BRIDGES_USER_ID", "BRIDGES_API_KEY");
	bridges.setTitle ("Voronoi Diagram (Brute Force)");

	// visualize the voronoi regions using a ColorGrid
	ColorGrid cg (grid_size, grid_size);

	// generate random colors for the regions
	// use a random number generator to create each region's colors (r,g,b)	

	// iterate through each pixel and set its color based on the site that it
	// is closes to

	// also mark the sites
	// use small square regions to mark each site, make sure you dont run off
	// the bounds of the grid!
	bridges.setDataStructure(cg);
	bridges.visualize();
}
