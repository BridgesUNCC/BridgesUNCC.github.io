import bridges.connect.Bridges;
import bridges.base.Color;
import bridges.base.ColorGrid;

import java.util.Vector;
import java.util.HashMap;
import java.util.Map;
import java.util.ArrayList;

// This program computes the Voronoi regsions using a brute force algorithm
// and uses the ColorGrid to display the output. See the README.md for a
// detailed description


public class voronoi_diag {

	public static void main(String[] args) throws Exception {

		// set the number of sites and size of your 2D grid (plane)
		int num_sites = 30, grid_size = 500;

		// specify voronoi sites as 2D points, chosen at random 
		// Reference: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html

		// generate a set of 2D random points  to represent the Voronoi sites
		// reference: https://en.cppreference.com/w/cpp/numeric/random
    
		// keep the points in a list 

		// generate the Voronoi regions using a brute force approach


		// display the Voronoi regions using a Bridges ColorGrid
	}

	// this function generates the map of the voronoi regions, i.e, each
	// image position contains a region code
	// using a brute force algorithm! Arghh! But its simple
	// returns a HashMap
	public static HashMap<Integer, Integer> generateVoronoiRegions (
			Vector<Integer> sites, int grid_size) {

		HashMap<Integer, Integer> voronoi_regions = new HashMap<>();

		// initialize map to a negative (invalid) value
		// the entry will finally contain an id for the region

		// must maintain a distance image that keeps track of smallest distance
		// at each point to any site, must initialize
		
		// computing the voronoi region ids
		// iterate through the whole grid and for each point compute its
		// distance from each site and keep the smallest distance and also
		// update the voronoi region id


		return voronoi_regions;

	}

	// this function returns the distance between two points
	public static int getDistanceSquared(int i, int j, int s1, int s2) {
		
		int dist = 0;
		return dist;
	}

	public static void displayVoronoiRegions(HashMap<Integer, Integer> 
				regions, int grid_size, Vector<Integer> sites) 
						throws Exception {
	
		// bridges object initialization
		Bridges bridges = new Bridges(64, "BRIDGES_USER_ID", "BRIDGES_API_KEY");
		bridges.setTitle ("Voronoi Diagram (Brute Force)");
	
		// visualize the voronoi regions using a ColorGrid
		ColorGrid cg = new ColorGrid (grid_size, grid_size);

		// generate random colors for the regions
		// use a random number generator to create each region's colors (r,g,b) 

		// iterate through each pixel and set its color based on the site that it
		// is closes to

		// also mark the sites
		// use small square regions to mark each site, make sure you dont run off
		// the bounds of the grid!

		bridges.setDataStructure(cg);
		bridges.visualize();
	}
	
}
