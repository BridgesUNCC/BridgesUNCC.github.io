from bridges.bridges import *
from bridges.color_grid import *
from bridges.color import *

import random
import math

# This program computes the Voronoi regsions using a brute force algorithm
# and uses the ColorGrid to display the output. See the README.md for a
# detailed description

def generate_voronoi_regions(sites, grid_size):

	
	voronoi_regions = []

	# initialize region map to some initial value


	# must maintain a distance image that keeps track of smallest distance
	# at each point to any site, must initialize

	# computing the voronoi region ids
	# iterate through the whole grid and for each point compute its
	# distance from each site and keep the smallest distance and also
	# update the voronoi region id

	return voronoi_regions;
	


def get_distance_squared(i, j, site_x, site_y):

	#this function returns the distance between two points

	dist = 0
	return dist

def display_voronoi_regions(regions, grid_size, sites):

	bridges = Bridges(264, "BRIDGES_USER_ID", "BRIDGES_API_KEY")
	bridges.set_title ("Voronoi Diagram (Brute Force)")
	bridges.set_description("In this project, you are building a Voronoi Diagram of a set of sites in the 2D planeusing a brute-force approach.")

	# visualize the voronoi regions using a ColorGrid
	cg = ColorGrid(grid_size, grid_size)

	# generate random colors for the regions

	# generate random colors for the regions
	# use a random number generator to create each region's colors (r,g,b) 

	# iterate through each pixel and set its color based on the site that it
	# is closes to

	#also mark the sites
	#use small square regions to mark each site, make sure you dont run off
	#the bounds of the grid!

	bridges.set_data_structure(cg)
	bridges.visualize()

def  main():

	# set number of sites, grid size
	num_sites = 10
	grid_size = 500

	voronoi_sites = []
	# specify voronoi sites as 2D points, chosen at random, can use a list
	# use random number generator (random.random() returns in the range (0-1)


	# map each grid point to a voronoi region
	voronoi_regions = generate_voronoi_regions (voronoi_sites, grid_size)

	# visualize  the voronoi regions
	display_voronoi_regions(voronoi_regions, grid_size, voronoi_sites)

if __name__ == '__main__':
        main()
