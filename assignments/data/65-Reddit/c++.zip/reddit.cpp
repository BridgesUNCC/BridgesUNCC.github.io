 #include "Bridges.h"
#include "DataSource.h"
#include "data_src/Reddit.h"
#include <iostream>
#include <algorithm>
#include <vector>
#include <string>
#include <time.h>
#include <string>
#include "LineChart.h"

using namespace std;
using namespace bridges;

vector<double> generateSeries(vector<Reddit> subredditData){
    vector<double> yList;
    /**
     * TODO: write student code here
     * 
     * Iterate over the lsit of redit data
     *      Get the hour of the Post
     *      Hint #1: Reddit objects have a method getPostTime()
     *      Hint #2: this is a unix timestamp (seconds since the Epoch(January 1st 1970))
     *      Hint #3: if we use the struct tm and the function localtime() we can get the hour
     *      increment the number on the Y-axis 
    */
    return yList;
}

/**
 * Generates a lineplot given a vector of strings (which subreddits to pull) and a datasource 
 * uses the generateSeries method
 * returns a LineChart to be visualized
*/
LineChart generateLinePlot(vector<string> subreddits, DataSource d) {
    LineChart plot = LineChart();
    vector<double> xList;
    for(double i=0.0; i <= 23.0; i++){
        xList.push_back(i);
    }
    std::cout << xList.size() << std::endl;
    for (string subreddit : subreddits){
        std::cout << subreddit << std::endl;
        vector<double> series = generateSeries(d.getRedditData(subreddit));
        plot.setDataSeries(subreddit, xList, series);
    }
    return plot;
}

int main(){
    Bridges bridges(64, "bridges ID", "bridges API Key");
    DataSource datasource(bridges);
    vector<string> subreddits = datasource.getAvailableSubreddits();
    //Might want to reduce the number of subreddits
    LineChart p = generateLinePlot(subreddits, datasource);
    bridges.setDataStructure(p);
    bridges.visualize();
}