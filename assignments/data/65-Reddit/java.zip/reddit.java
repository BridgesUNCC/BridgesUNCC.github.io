import java.util.Arrays;
import java.util.List;
import java.sql.Time;
import bridges.base.*;
import bridges.data_source.*;

public class reddit{
    //Create a series for the line chart given a list of reddit posts
    public static int[] generateSeries(Reddit[] subredditData){
        int[] yValues = new int[25]; //creates an array with 24 slots (24 hour time)
        /*
         * TODO: write user code here
         * Iterate over the list of reddit data given
         *      get the hour of the post
         *       Hint 1: Reddit objects have an attribute post_time which is an unix timestamp
         *       Hint 2: Time.valueOf(timestamp).hour
         *       Hint 3: will look smth like int hour = Time.valueOf(post.post_time).hour
         */

        return yValues;
    }
    //Generates the LinePlot for each string in the array passed in
    public static LineChart generateLinePlot(String[] subreddits){
        LineChart plot = LineChart();
        for(String subreddit : subreddits){
            int[] yData = generateSeries(data_source.reddit_data(subreddit));
            int[] xData = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23]
            plot.set_data_series(subreddit, xData, yData);
        }
        return plot;
    }
    public static main(String[] args){
        Bridges bridges = new Bridges(64, "Bridges Username", "bridgesAPIkey");
        String[] subreddits = data_source.available_subreddits();
        LineChart p = generateLinePlot(subreddits);
        bridges.set_data_structure(p);
        bridges.visualize();
    }
}