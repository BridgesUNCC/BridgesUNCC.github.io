import java.util.Arrays;
import java.util.ArrayList;
import java.time.*;
import java.io.IOException;
import bridges.connect.Bridges;
import bridges.base.LineChart;
import bridges.data_src_dependent.Reddit;
import bridges.connect.DataSource;

public class reddit{
    //Create a series for the line chart given a list of reddit posts
    public static double[] generateSeries(ArrayList<Reddit> subredditData){
        double[] yValues = new double[24]; //creates an array with 24 slots (24 hour time)
        /*
         * TODO: write user code here
         * Iterate over the list of reddit data given
         *      get the hour of the post
         *       Hint 1: Reddit objects have an attribute post_time which is an unix timestamp
         *       Hint 2: Time.valueOf(timestamp).hour
         *       Hint 3: will look smth like int hour = Time.valueOf(post.post_time).hour
         */

        return yValues;
    }
    //Generates the LinePlot for each string in the array passed in
    public static LineChart generateLinePlot(DataSource ds, ArrayList<String> subreddits) throws IOException{
        LineChart plot = new LineChart();
        for(String subreddit : subreddits){
            double[] yData = generateSeries(ds.getRedditData(subreddit));
	    double[] xData = new double[24];
	    for (int k = 0; k < 24; k++)	// for 24 hours
            	xData[k] = k;

            plot.setDataSeries(subreddit, xData, yData);
        }
        return plot;
    }
    public static void main(String[] args) throws Exception {
        Bridges bridges = new Bridges(65, "Bridges Username", "bridgesAPIkey");
	DataSource ds = bridges.getDataSource();
        ArrayList<String> subreddits = ds.getAvailableSubreddits();
        LineChart p = generateLinePlot(ds, subreddits);
        bridges.setDataStructure(p);
        bridges.visualize();
    }
}
