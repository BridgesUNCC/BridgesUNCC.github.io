#Scaffolding for the Reddit Assignment

#imports
from bridges.bridges import *
from bridges import *
from bridges.data_src_dependent import data_source
import datetime

#Create a series for the line chart given a list of redit posts
def generateSeries(subredditData: List[Reddit]) -> List[int]:
    #0-24 (24 hour time)
    yList = [0] * 24 #pre filling an array(python List) with 24 0's

    #TODO: write user code here
    # Iterate over the list of reddit data given
        # Get the Hour of the post
        # Hint 1: Reddit objects have an attribute post_time which is an unix timestamp
        # Hint 2: datetime.datetime.fromtimestamp(timestamp).hour
        # Hint 3: will look smth like hour = datetime.datetime.fromtimestamp(post.post_time).hour
        # Increment the value on the Y-axis by 1
    
    return yList #return the series X and Y

#Takes in a list of strings (the names of the subreddits being looked at)
def generateLinePlot(subreddits: List[str]):
    plot = LineChart() #initialize a line chart 
    for subreddit in subreddits: # iterate over the list of subreddits 
        series = generateSeries(data_source.reddit_data(subreddit)) # get the data from the API
        plot.set_data_series(subreddit, list(range(0, 25)), series[1]) # Create a series using generateSeries()
    return plot

if __name__ == '__main__':
    bridges = Bridges(265, "Bridges Username", "bridgesAPIkey")
    bridges.set_title("Reddit Data")
    bridges.set_description("Students will write code to itterate over a collection of Reddit posts. Their code will count the number of posts in each hour.")
    subreddits = data_source.available_subreddits() # comment this line out if using the next one
    # subreddits = [showerthoughts, blog, art] #Use this line if you want to pick specific avaliable subredits
    # see http://bridges-data-server-reddit.bridgesuncc.org/list
    p = generateLinePlot(subreddits)
    bridges.set_data_structure(p)
    bridges.visualize()
