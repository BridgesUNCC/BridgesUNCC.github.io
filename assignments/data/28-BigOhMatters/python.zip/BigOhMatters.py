from bridges import *

def task1(bridges):
    lc = LineChart()
    lc.title = "Something"
    lc.x_label = "n"
    lc.y_label = "Time in seconds"

    xdata = []
    ydata = []

    # TODO Add lines according to task 1 instructions

def task2(bridges):
    lc = LineChart()
    lc.title = "Something"
    lc.x_label = "n"
    lc.y_label = "Time in seconds"

    xdata = []
    ydata = []

    # TODO Add lines according to task 2 instructions

def task3(bridges):
    lc = LineChart()
    lc.title = "Something"
    lc.x_label = "n"
    lc.y_label = "Time in seconds"

    xdata = []
    ydata = []

    # TODO Add lines according to task 3 instructions



def main():
    bridges = Bridges(ASSIGNMENT_NUMBER, "BRIDGES_USER_ID", "BRIDGES_API_KEY")
    bridges.connector.set_server_url("clone")

    bridges.set_title("Big Oh Matters")
    bridges.set_description("Plot Big Oh runtimes on a Bridges Line Chart.")

    task1(bridges)
    task2(bridges)
    task3(bridges)

if __name__ == '__main__':
    main()