#include <iostream>
#include <vector>
#include <cmath>
#include "LineChart.h"
#include "Bridges.h"

using namespace std;
using namespace bridges;

void task1(Bridges * bridges) {
  LineChart lc = LineChart();
  lc.setTitle("Something");
  lc.setXLabel("n");
  lc.setYLabel("Time in Seconds");

  vector<double> xData;
  vector<double> yData;

  // create the function y = 10^4n, assuming 1 Mhz clock
  // Here is an example
  for (int i = 1; i < 100000; i += 1000) {
    double n = (double)i;
    double t = (double)10000.0 * i / (1000.0 * 1000.0);
    xData.push_back(i);
    yData.push_back(t);
  }

  lc.setDataSeries("10^4 n at 1MHz", xData, yData);

  xData.clear();
  yData.clear();

  // create the function y = 5*10^4n, assuming 1 Mhz clock

  // create the function y = 100*n^2, assuming 1 Mhz clock

  bridges->setDataStructure(lc);
  bridges->visualize();
}

void task2(Bridges * bridges) {

  LineChart lc = LineChart();
  // create the function y = 10^4n, assuming 1 Mhz clock

  // create the function y = 100*n^2, assuming 100 Mhz clock

  // create the function y = n^4, assuming 10 Ghz clock

  bridges->setDataStructure(lc);
  bridges->visualize();
}

void task3(Bridges * bridges) {
  LineChart lc = LineChart();

  // create the function y = 10^4*n, assuming 1 Mhz clock

  // create the function y = n^4, assuming 10 Ghz clock

  // create the function y = 2^n, assuming 1 Phz clock

  bridges->setDataStructure(lc);
  bridges->visualize();
}


int main() {
  // initialize BRIDGES
  Bridges *bridges = new Bridges(128, "BRIDGES_USER_ID", "BRIDGES_API_KEY");

  bridges->setTitle("Big Oh Matters");
  bridges->setDescription("Plotting the complexity of different function on different machines");

  // call the tasks


  return 0;
}
