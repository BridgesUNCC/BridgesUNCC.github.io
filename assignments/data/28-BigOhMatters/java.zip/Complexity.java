import bridges.connect.Bridges;
import bridges.base.LineChart;
import java.util.ArrayList;
import java.lang.Math;


class Complexity {

  public static void task1(Bridges bridges) throws Exception {
      //TODO: replace the example with the requested plots
    //Example of how to use LineChart
    LineChart lc = new LineChart();
    lc.setTitle("Something");
    lc.setXLabel("SomethingLabel");
    lc.setYLabel("SomethingElseLabel");

    {
      ArrayList<Double> xdata = new ArrayList<Double>();
      ArrayList<Double> ydata = new ArrayList<Double>();
      for (int i = 1; i < 10; i++) {
	double x = i;
	double y = x*x;
        xdata.add(x);
        ydata.add(y);
      }
      lc.setDataSeries("y=x^2", xdata, ydata);
    }

    bridges.setDataStructure(lc);
    bridges.visualize();
  }

  public static void task2(Bridges bridges) throws Exception {
      //TODO: fill with the requested plots
  }

  public static void task3(Bridges bridges) throws Exception {
      //TODO: fill with the requested plots
  }


  public static void main(String args[]) throws Exception {
    Bridges bridges = new Bridges(28, "BRIDGES_USER_ID", "BRIDGES_API_KEY");
    bridges.setServer("clone");

    task1(bridges);
    task2(bridges);
    task3(bridges);
  }
}
