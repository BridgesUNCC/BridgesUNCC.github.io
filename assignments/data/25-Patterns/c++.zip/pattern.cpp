#include "Bridges.h"
#include "ColorGrid.h"

using namespace bridges;

//
// using color grid to generate  patterns
//
// Useful classes: ColorGrid, Color

int main() {
  Bridges bridges(125, "BRIDGES_USER_ID", "BRIDGES_API_KEY");

  bridges.setTitle("Image Pattern");
  bridges.setDescription("Create simple image pattern with Bridges ColorGrid.");

  ColorGrid grid = ColorGrid(15, 15);

  // TODO : Draw a pattern to the grid
  // could be a checkerboard, or something you fancy.  Use
  // Color grid's methods to set background, draw symbols and
  // the choice of colors and symbols to draw something interesting.


  // set the data type and visualize
  bridges.setDataStructure(&grid);
  bridges.visualize();

  return 1;
}
