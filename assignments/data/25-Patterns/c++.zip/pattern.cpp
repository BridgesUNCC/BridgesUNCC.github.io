#include "Bridges.h"
#include "ColorGrid.h"

using namespace bridges;

//
// using color grid to generate  patterns
// 
// Useful classes: ColorGrid, Color

int main() {
    Bridges bridges(25, "BRIDGES_USER_ID", "BRIDGES_API_KEY");

    ColorGrid grid = ColorGrid(15, 15);

    // TODO : Draw a pattern to the grid


	// set the data type and visualize
    bridges.setDataStructure(&grid);
	bridges.visualize();

    return 1;
}
