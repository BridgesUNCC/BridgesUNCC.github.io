#include "Bridges.h"
#include "ColorGrid.h"

using namespace bridges;

int main() {
    Bridges * bridges = new Bridges(25, "user", "auth");

    ColorGrid grid = ColorGrid(15, 15);

    # Draw a pattern to the grid

    bridges->setDataStructure(grid);
    return 1;
}