from bridges import *;

def main():
    bridges = Bridges(25, 'user', 'auth')

    grid = ColorGrid(15, 15)

    bridges.set_data_structure(grid)

    # TODO: Draw a pattern to the grid

    bridges.visualize()

if __name__ == '__main__':
    main()
