from bridges import *;

def main():
    bridges = Bridges(ASSIGNMENT_NUMBER, "BRIDGES_USER_ID", "BRIDGES_API_KEY")

    bridges.set_title("Image Pattern")
    bridges.set_description("Create simple image pattern with Bridges ColorGrid.")

    grid = ColorGrid(15, 15)

    bridges.set_data_structure(grid)

    # TODO: Draw a pattern to the grid

    bridges.visualize()

if __name__ == '__main__':
    main()
