import bridges.connect.Bridges;
import bridges.validation.RateLimitException;

import java.io.IOException;

import bridges.base.Color;
import bridges.base.ColorGrid;

public class Pattern {
	public static void main(String[] args) throws RateLimitException, IOException {
		Bridges bridges = new Bridges(25, "user", "auth");
		
		ColorGrid grid = new ColorGrid(15, 15);
		
		// TODO: Display a pattern to the grid
		
		bridges.setDataStructure(grid);
		bridges.visualize();
	}
}
