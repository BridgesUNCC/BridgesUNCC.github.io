import bridges.connect.Bridges;
import bridges.validation.RateLimitException;

import java.io.IOException;

import bridges.base.Color;
import bridges.base.ColorGrid;

//
// using color grid to generate a checkerboard pattern
//
// Useful classes: ColorGrid, Color
//


public class Pattern {
  public static void main(String[] args) throws RateLimitException, IOException {
    Bridges bridges = new Bridges(25, "BRIDGES_USER_ID", "BRIDGES_APIKEY");

    bridges.setTitle("Image Pattern");
    bridges.setDescription("Create simple image pattern with Bridges ColorGrid.");

    ColorGrid grid = new ColorGrid(15, 15);

    // TODO: Generate a pattern using the color grid

    bridges.setDataStructure(grid);
    bridges.visualize();
  }
}
