import bridges.connect.Bridges;
import bridges.validation.RateLimitException;
import bridges.base.Array;
import bridges.base.SymbolCollection;
import bridges.base.Rectangle;
import java.util.ArrayList;
import java.io.IOException;
import java.lang.Math;

class TOHData {
  /* Initialize a Bridges connection with your credentials */
  Bridges bridges = new Bridges(26, "BRIDGES_USER_ID", "BRIDGES_API_KEY");

  SymbolCollection sc = new SymbolCollection();

  Rectangle disk1 = new Rectangle(-50, 10, 20, 10);
  Rectangle disk2 = new Rectangle(-50, 0, 30, 10);
  Rectangle disk3 = new Rectangle(-50, -10, 40, 10);

  ArrayList<Integer> src = new ArrayList<Integer>();
  ArrayList<Integer> dest = new ArrayList<Integer>();
  ArrayList<Integer> aux = new ArrayList<Integer>();
}

public class toh {
  static void makePegs(SymbolCollection sc) {
    Rectangle src_peg = new Rectangle(-50, 0, 10, 30);
    sc.addSymbol(src_peg);
    Rectangle dest_peg = new Rectangle(0, 0, 10, 30);
    sc.addSymbol(dest_peg);
    Rectangle aux_peg = new Rectangle(50, 0, 10, 30);
    sc.addSymbol(aux_peg);
  }

  static void tohInter(TOHData dat) {
    // TODO:
    // Complete the towers of hanoi problem
    // Do not brute force the solution
    // Find a way to use loops to solve the puzzle

    // There are 3 pegs src, dest, and aux
    // There are 3 disks that sit on the pegs
    // Start with all three disks stacked on src peg

    // The rules are...
    // Only the top disk can be moved from a peg
    // Only one disk can be moved from a peg in one turn
    // Only smaller disks can be placed on top of larger disks

    // The goal is to move all disks to another peg

    // Call bridges.visualize after each step to visualize the process
  }

  public static void main(String[] args) throws Exception {
    TOHData dat = new TOHData();

    dat.bridges.setTitle("Towers of Hanoi");
    dat.bridges.setDescription("Solve the towers of hanoi problem with loops.");

    makePegs(dat.sc);

    dat.sc.addSymbol(dat.disk1);
    dat.sc.addSymbol(dat.disk2);
    dat.sc.addSymbol(dat.disk3);

    tohInter(dat);
  }
}