import bridges.connect.Bridges;
import java.util.ArrayList;


public class newtoh {
	public static void main(String[] args) throws Exception {

		//create Bridges object
		Bridges bridges = new Bridges(26, "YOUR_USER_ID",
			"YOUR_API_KEY");
		// title, description
		bridges.setTitle("Towers of Hanoi");
		bridges.setDescription("Towers of Hanoi");

		Hanoi nt = new Hanoi(5, bridges);

		//TODO
		//move the stack on peg1 to another stack

		
		// nt.move(1,2); // here is how you move the top disk from peg1 to peg2, asssuming it is allowed
		
	}
}
