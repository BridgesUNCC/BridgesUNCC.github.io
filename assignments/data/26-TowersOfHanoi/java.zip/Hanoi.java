import bridges.connect.Bridges;
import bridges.base.SymbolCollection;
import bridges.base.Rectangle;
import bridges.base.Circle;
import bridges.base.Text;
import bridges.base.Polyline;
import bridges.base.Polygon;
import bridges.base.Color;
import bridges.base.SymbolGroup;
import java.util.ArrayList;

public class Hanoi {

    private ArrayList<Integer> d1;
    private ArrayList<Integer> d2;
    private ArrayList<Integer> d3;
    private int nbdisk;

    private Bridges br;
    
    public Hanoi(int nbdisk, Bridges b) {
	d1 = new ArrayList<Integer>();
	d2 = new ArrayList<Integer>();
	d3 = new ArrayList<Integer>();
	
	this.nbdisk = nbdisk;
	for (int i=0; i<nbdisk; ++i) {
	    d1.add(nbdisk-i);
	}

	br = b;
	
    }

    public void move(int src, int dst) {

	int d = -1;
	ArrayList<Integer> srcal = null;
	ArrayList<Integer> dstal = null;
	if (src == 1) {
	    srcal = d1;
	}
	if (src == 2) {
	    srcal = d2;
	}
	if (src == 3) {
	    srcal = d3;
	}
	//
	if (dst == 1) {
	    dstal = d1;
	}	
	if (dst == 2) {
	    dstal = d2;
	}	
	if (dst == 3) {
	    dstal = d3;
	}

	//TODO: should throw exception if the move is invalid
	
	if (dstal.size()>0
	    && srcal.get(srcal.size()-1) > dstal.get(dstal.size()-1))
	    throw new java.lang.IllegalArgumentException("Illegal Move");


	
	//pop
	d = srcal.get(srcal.size()-1);
	srcal.remove(srcal.size()-1);
	//push
	dstal.add(d);

	// set visualizer type
	br.setDataStructure(getVisual());
	// visualize the JSON and Collection
	try {
	    br.visualize();
	} catch (Exception e) {
	    System.err.println(e.getMessage());
	}

    }
    

    public SymbolCollection getVisual() {
	SymbolCollection sc = new SymbolCollection();
	
	float diskheight = 10;
	float diskunitwidth = 20;
	float pegheight = (nbdisk+1) * diskheight;
	float pegspacing = (nbdisk+3)*diskunitwidth;


	sc.setViewport(-10.f-nbdisk*diskunitwidth, 10.f-nbdisk*diskunitwidth+3*pegspacing,
		       -10.f, pegheight+20.f);

	
	//peg
	Rectangle p1 = new Rectangle(-1.0f, 0.0f, 2.0f, pegheight);
	p1.setFillColor("black");
	sc.addSymbol(p1);

	Rectangle p2 = new Rectangle(-1.0f+pegspacing, 0.0f, 2.0f, pegheight);
	p2.setFillColor("black");
	sc.addSymbol(p2);

	Rectangle p3 = new Rectangle(-1.0f+2*pegspacing, 0.0f, 2.0f, pegheight);
	p3.setFillColor("black");
	sc.addSymbol(p3);

	//disks
	//peg1
	for (int i=0; i<d1.size(); ++i) {
	    int disksize = d1.get(i);
	    Rectangle disk = new Rectangle(-1.0f-disksize/2.f*diskunitwidth, 0.0f+diskheight*i, diskunitwidth*disksize, diskheight);
	    disk.setFillColor("black");
	    sc.addSymbol(disk);
	}

	//peg2
	for (int i=0; i<d2.size(); ++i) {
	    int disksize = d2.get(i);
	    Rectangle disk = new Rectangle(-1.0f-disksize/2.f*diskunitwidth+pegspacing, 0.0f+diskheight*i, diskunitwidth*disksize, diskheight);
	    disk.setFillColor("black");
	    sc.addSymbol(disk);
	}

	//peg3
	for (int i=0; i<d3.size(); ++i) {
	    int disksize = d3.get(i);
	    Rectangle disk = new Rectangle(-1.0f-disksize/2.f*diskunitwidth+2*pegspacing, 0.0f+diskheight*i, diskunitwidth*disksize, diskheight);
	    disk.setFillColor("black");
	    sc.addSymbol(disk);
	}

	
	return sc;
    }
}
