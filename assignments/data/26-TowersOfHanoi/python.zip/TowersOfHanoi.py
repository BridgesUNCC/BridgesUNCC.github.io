# First import the relevant Bridges classes
from bridges.bridges import *
from bridges.symbol_collection import *
from bridges.rectangle import *

bridges = Bridges(226, "BRIDGES_USER_ID", "BRIDGES_API_KEY")
sc = SymbolCollection()

disk1 = Rectangle(w=20, h=10, locx=-50, locy=10)
disk2 = Rectangle(w=30, h=10, locx=-50, locy=0)
disk3 = Rectangle(w=40, h=10, locx=-50, locy=-10)

src = []
dest = []
aux = []

def makePegs(size):
    src_peg = Rectangle(w=10, h=30, locx=-50, locy=0)
    sc.add_symbol(src_peg)
    dest_peg = Rectangle(w=10, h=30, locx=0, locy=0)
    sc.add_symbol(dest_peg)
    aux_peg = Rectangle(w=10, h=30, locx=50, locy=0)
    sc.add_symbol(aux_peg)

def makeDisks(size):
    sc.add_symbol(disk1)
    sc.add_symbol(disk2)
    sc.add_symbol(disk3)

def toh_inter(numDisks, src, aux, dest):
    # TODO:
    # Complete the towers of hanoi problem
    # Do not brute force the solution
    # Find a way to use loops to solve the puzzle

    # There are 3 pegs src, dest, and aux
    # There are 3 disks that sit on the pegs
    # Start with all three disks stacked on src peg
    
    # The rules are...
    # Only the top disk can be moved from a peg
    # Only one disk can be moved from a peg in one turn
    # Only smaller disks can be placed on top of larger disks

    # The goal is to move all disks to another peg

    # Call bridges.visualize after each step to visualize the process


def main():
    numbDisks = 3

    makePegs(numbDisks)
    makeDisks(numbDisks)

    toh_inter(numbDisks, src, aux, dest)


if __name__ == '__main__':
    main()