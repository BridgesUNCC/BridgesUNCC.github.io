#include "Bridges.h"
#include "SymbolCollection.h"
#include "Rectangle.h"
#include <vector>
#include <iostream>
#include <math.h>

using namespace std;
using namespace bridges;

class TOHData {
  public:
    Bridges bridges = Bridges(126, "BRIDGES_USER_ID", "BRIDGES_API_KEY");

    bridges.setTitle("Towers of Hanoi");
    bridges.setDescription("Solve the towers of hanoi problem with loops.");

    SymbolCollection sc = SymbolCollection();

    // Make Pegs
    Rectangle srcPeg = Rectangle(-50, 0, 10, 30);
    Rectangle destPeg = Rectangle(0, 0, 10, 30);
    Rectangle auxPeg = Rectangle(50, 0, 10, 30);

    // Make Disks
    Rectangle disk1 = Rectangle(-50, 10, 20, 10);
    Rectangle disk2 = Rectangle(-50, 0, 30, 10);
    Rectangle disk3 = Rectangle(-50, -10, 40, 10);

    TOHData() {
      sc.addSymbol(&srcPeg);
      sc.addSymbol(&destPeg);
      sc.addSymbol(&auxPeg);

      sc.addSymbol(&disk1);
      sc.addSymbol(&disk2);
      sc.addSymbol(&disk3);
    }

    void tohInter() {
      // TODO:
      // Complete the towers of hanoi problem
      // Do not brute force the solution
      // Find a way to use loops to solve the puzzle

      // There are 3 pegs src, dest, and aux
      // There are 3 disks that sit on the pegs
      // Start with all three disks stacked on src peg

      // The rules are...
      // Only the top disk can be moved from a peg
      // Only one disk can be moved from a peg in one turn
      // Only smaller disks can be placed on top of larger disks

      // The goal is to move all disks to another peg

      // Call bridges.visualize after each step to visualize the process
    }
};

int main() {
  TOHData data = TOHData();

  data.tohInter();

  return 0;
}
