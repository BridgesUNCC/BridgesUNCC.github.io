
import bridges.connect.Bridges;
import bridges.validation.RateLimitException;

import java.io.IOException;

import bridges.base.Color;
import bridges.base.ColorGrid;

// This assignment generates the Mandelbrot set and displays it on a ColorGrid
// uses complex number arithmetic, specifically
// z1 + z2 = x1 + x2 + i(y1 + y2)
// z1.z2 = x1*x2 - y1*y2 + i(x1y2 + x2y1)
// 
// where z1 = x1 + i*y1, z2 = x2 + i*y2

public class Mandelbrot {

	static final int WIDTH = 1024;
	static final int HEIGHT = 1024;

	public static void main(String[] args) throws RateLimitException, 
					IOException{
        Bridges bridges = new Bridges(74, "BRIDGES_USER_ID", "BRIDGES_API_KEY");

		bridges.setTitle("Generating the Mandelbrot Set");

		ColorGrid grid = new ColorGrid(WIDTH, HEIGHT);

		//TODO: Implement the Mandelbrot set and display it on a color grid
		Mandelbrot (grid);
		
        bridges.setDataStructure(grid);
        bridges.visualize();
    }
	public static void Mandelbrot (ColorGrid cg) {
		// TODO
		// Review Complex numbers and their arithmetic (addition, product)
		// this is needed to implement the mandelbrot set (see above comments)

		// see the Wikipedia page on Mandelbrot set
		// https://en.wikipedia.org/wiki/Mandelbrot_set
		//
		// you are essentially iterating on the function z = z^2 + c, where
		// z is a complex number

		// To implement it within the grid, you can use a range from -1.5 to +1.5
		// and divide up the intervals based on grid width
		// Use a max iteration of 500 or so if the iterations dont converge.
		// The constant c  is the grid starting point - start point of
		// the iteration, i.e., (cx, cy) -> ranges from -1.5 to +1.5 in x and y

		// Color assignment:
		// The iteration will converge with a value v, which if less than 4.
		// can then be assigned a color as follows:
		// v  = std::min<float>(v, 1.0);
                // mapping to colors
		// int r = std::min<float>(255, v*255);
		// int g = (0.4*sin(M_PI*v/180.)+ 1.)*255;
		// int b = (1.- v)*255;

		// must check for values that exceed 255!
	}
}
