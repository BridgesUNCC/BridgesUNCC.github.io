import bridges.connect.Bridges;
import bridges.connect.DataSource;
import bridges.data_src_dependent.EarthquakeUSGS;
import java.util.List;
import bridges.base.Element;
import bridges.base.SLelement;
import bridges.base.GraphAdjList;
import bridges.base.Edge;
import bridges.base.Color;
import bridges.base.WorldMap;

public class geological_survey {

    public static double dist(double latA, double longA, double latB, double longB) {
	return (latA-latB)*(latA-latB)+(longA-longB)*(longA-longB);
    }


    public static void main(String[] args) throws Exception {
	
	//create the Bridges object
	Bridges bridges = new Bridges(38, "BRIDGES_USER_ID", "BRIDGES_API_KEY");
	
	// set title, description
	bridges.setTitle("Geological Survey");
	bridges.setDescription("From the red square, visit all the vertices to minimize total travelled distance. This is a greedy version.");

	bridges.setMap(new WorldMap());

	
	// set max quakes for this example
	final int MaxQuakes = 70;
	
	// Retrieve a list of MaxQuakes earthquake records 
	// from USGS using BRIDGES
	DataSource ds = bridges.getDataSource();
	List<EarthquakeUSGS> eqlist = ds.getEarthquakeUSGSData(MaxQuakes);

	// build empty graph with earthquake locations
	GraphAdjList<Integer, String, String> graph = new GraphAdjList<Integer, String, String>();
	for (int k = 0; k < eqlist.size(); k++) {
	    graph.addVertex(k, eqlist.get(k).getTitle());
	    graph.getVertex(k).setLocation(eqlist.get(k).getLatit(), eqlist.get(k).getLongit());
	    graph.getVertex(k).setLabel(eqlist.get(k).getTitle());
	}


	//TODO
	//Compute a path through all the earthquake.
	//You can add an edge between two earthquake to visualize it with:
	//
	//graph.addEdge(from, to);
	//
	// You can compute the distance between two earthquakes with:
	//
	//dist(eqlist.get(from).getLatit(), eqlist.get(from).getLongit(),
	//eqlist.get(to).getLatit(), eqlist.get(to).getLongit());

	// ...


	
	
	//generate graphical tour
	bridges.setDataStructure(graph);
	bridges.visualize();
    }
}
