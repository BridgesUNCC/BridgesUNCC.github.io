#include <string>
#include "Bridges.h"
#include "DataSource.h"
#include "data_src/EarthquakeUSGS.h"
#include "GraphAdjList.h"

using namespace std;
using namespace bridges;
using namespace bridges::dataset;


int max_quakes = 70;

double dist(double latA, double longA, double latB, double longB) {
  return (latA-latB)*(latA-latB)+(longA-longB)*(longA-longB);
}

int main(int argc, char **argv) {
	// create Bridges object
	// command line args provide credentials and server to test on
	Bridges bridges (138, "BRIDGES_USER_ID", "BRIDGES_API_KEY");

	// set title, description
	bridges.setTitle("Geological Survey");
	bridges.setDescription("From the red square, visit all the vertices to minimize total travelled distance. This is a greedy version.");

	bridges.setCoordSystemType("equirectangular");
	bridges.setMap("world", "all");
	bridges.setMapOverlay(true);
	
	// get earthquake data
	DataSource ds (bridges);
	vector<EarthquakeUSGS> eq_list = ds.getEarthquakeUSGSData(max_quakes);

	//Graph
	GraphAdjList<int, std::string> g;
	
	// build empty graph with earthquake locations
	for (int k = 0; k < eq_list.size(); k++) {
	  EarthquakeUSGS eq = eq_list[k];
	  g.addVertex(k, eq.getTitle());
	  cout << eq.getTitle() << endl;
	  g.getVertex(k)->setLocation(eq.getLongit(), eq.getLatit());
	  g.getVertex(k)->setLabel(eq.getTitle());
	}

	//TODO
	//Compute a path through all the earthquake.
	//You can add an edge between two earthquake to visualize it with:
	//
	//	  g.addEdge(from, to);
	//
	// You can compute the distance between two earthquakes with:
	//
	//  dist(eq_list[from].getLatit(), eq_list[from].getLongit(),
	//eq_list[to].getLatit(), eq_list[to].getLongit());

	// ...
	
	// visualize the tour
	bridges.setDataStructure(g);
	bridges.visualize();

	return 0;
}

