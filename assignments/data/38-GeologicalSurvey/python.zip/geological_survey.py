from bridges.bridges import *
from bridges.data_src_dependent.data_source import *


def dist(latA, longA, latB, longB):
    return (latA-latB)*(latA-latB) + (longA-longB)*(longA-longB)


def main():
    bridges = Bridges(238, "BRIDGES_USER_ID", "BRIDGES_API_KEY")
    # bridges.set_coord_system_type("equirectangular")
    # bridges.set_map_overlay(True)
    bridges.set_title("Geological Survey")
    bridges.set_description("From the red square, visit all the vertices to minimize total travelled distance. This is the greedy verison.")

    #set max quakes for this example
    max_quakes = 700

    #retrieve a list of  max quakes earchquakes records
    #from usgs using BRIDGES
    eqlist = get_earthquake_usgs_data(max_quakes)

    #build empty graph with earthquake locations
    graph = GraphAdjList()
    for k in range(len(eqlist)):
        graph.add_vertex(str(k), eqlist[k].title)
        graph.get_vertex(str(k)).set_location(eqlist[k].longit, eqlist[k].latit)
        graph.get_vertex(str(k)).label = eqlist[k].title


    bridges.set_coord_system_type("equirectangular")
    bridges.map = ["world", "all"]
    bridges.set_map_overlay(True)



    # TODO
    # Compute a path through all the earthquake.
    # You can add an edge between two earthquake to visualize it with:
    # 
    # graph.add_edge(str(from), str(to))
    # 
    #  You can compute the distance between two earthquakes with:
    # 
    # dist(eqlist[from].latit, eqlist[from].longit, eqlist[to].latit, eqlist[to].longit)

    #  ...




    # push a visualization out
    bridges.set_data_structure(graph)
    bridges.visualize()


if __name__ == '__main__':
    main()



