#include "Bridges.h"
#include "ColorGrid.h"

using namespace bridges;

void createGermanFlag (ColorGrid& cg);
void createFranceFlag(ColorGrid& cg);


int main (int argc, char **argv) {
	try {
		//create the Bridges object, set credentials
		Bridges bridges(162, "BRIDGES_USER_ID", "BRIDGES_API_KEY");

        bridges.setTitle("Creating Flags of Countries: German, France");

		// german flag
        bridges.setDescription("German National Flag");

		// create color grid
		ColorGrid cg(480, 640, Color("white"));

		// create German flag
		// look up and find the colors of the german flag -- its 3 horizontal
		// strips of equal size

		bridges.setDataStructure (cg);
		bridges.visualize();

		// french flag
		// similarly create the French flag
		// look up and find the colors of the french flag -- its 3 vertical 
		// strips of equal size

		bridges.setDataStructure (cg);
		bridges.visualize();

	}
	catch (std::string s) {
		std::cerr << s << std::endl;
	}

	return 0;
}
