from bridges.color_grid import *
from bridges.bridges import *
from bridges.color import *
import sys

def main():
    # This example illustrates using the Bridges color grid
    # We will build a checker grid using two different colors


    # create the Bridges object, set credentials
    # command line args provide credentials and server to test on
    bridges = Bridges(263, "BRIDGES_USER_ID", "BRIDGES_API_KEY")

    # title, description
    bridges.set_title("Creating Flags")
    bridges.set_description("This is an example of using the color grid to create a German National Flag")

    cg = ColorGrid(480, 640, Color(col_name = "black"))

    bridges.set_data_structure(cg)
    bridges.visualize()

    # create German flag
    # look up and find the colors of the german flag -- its 3 horizontal
    #    strips of equal size

    # create French flag
    # look up and find the colors of the french flag -- its 3 vertical 
    # strips of equal size

    bridges.set_data_structure(cg)
    bridges.visualize()


if __name__ == '__main__':
    main()
