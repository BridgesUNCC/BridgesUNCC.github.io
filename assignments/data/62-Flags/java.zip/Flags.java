
import bridges.connect.Bridges;
import bridges.base.Color;
import bridges.base.ColorGrid;

public class Flags {

    public static void main(String[] args) {
        try {
            // create the Bridges object, set credentials
            Bridges bridges = new Bridges(62, "BRIDGES_USER_ID", "BRIDGES_API_KEY");

            bridges.setTitle("Creating Flags of Countries");

			// create a color grid
			ColorGrid cg = new ColorGrid(480,640, new Color("black"));

            // German flag
            bridges.setDescription("German National Flag");

			// create German flag
			// look up and find the colors of the german flag -- its 3 
			// horizontal strips of equal size

			// visualize
            bridges.setDataStructure(cg);
            bridges.visualize();

			// french flag
			// similarly create the French flag
			// look up and find the colors of the french flag -- its 3 vertical 
			// strips of equal size

			// visualize
            bridges.setDataStructure(cg);
            bridges.visualize();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
