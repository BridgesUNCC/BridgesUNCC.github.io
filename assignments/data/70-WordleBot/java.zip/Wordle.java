import bridges.base.*;
import bridges.games.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

/**
 * @author Mack Larson
 *	Wordle Extends NonBlockingGame and implements gameLoop and initialize
 *	It is a class that creates a wordle game using NonblockingGame, 
 *  then uses a Model-Based Reflex Agent to try to solve the goal word
 */

public class Wordle extends NonBlockingGame {
	
	public ArrayList<String> wordDictionary = new ArrayList<String>();
	String goalWord = ""; 
	public String word = ""; //current word
	String lastWord = "";
	int enteredWords = 0; //amount of words tried, used for checker array / setBGColor
	
	String[][] checkerArray = new String[6][5];
	
	HashMap<String, NamedSymbol> drawer = new HashMap<String, NamedSymbol>(26);
	/*
	 *  Constructor for the Wordle class. Calls super constructor to make the game, using your credentials.
	 *  Creates game grid with 6 rows and 5 columns		
	 */
	Wordle() {
		super(70, "BridgesUser",  "BridgesAPIKey", 6, 5);
		
	}
	/** Executed every frame, Main goal is to draw and check the words as they are passed from the bot. 
	 * 	it only changes the gamestate when a new word is available, and the person presses space.
	 *  Create a char array of the word for checking purposes, then checks each Char against goal word
	 *  draws box green if char is in right place, yellow if in word but not right place, and DarkBlue if isn't 
	 *  in word. It then increases entered words, calls CullWords Method, and then gets a new word.
	 *  Also terminates game if no more guesses are allowed or goalWord is found.
	 */
	@Override
	protected void gameLoop() {
		
		
		if( keySpaceFire()) {
			
			
			if(enteredWords > 6) {
				quit();
			}
			
			System.out.println(word);
			for(int i = 0; i < 5; i++) {
				
				if(word.charAt(i) == goalWord.charAt(i)) {
					this.checkerArray[enteredWords][i] = "green";
					
				}
				else {
					for(int c = 0; c < 5; c++) {
						if(this.checkerArray[enteredWords][c] != "green" && word.charAt(i) == goalWord.charAt(c)) {
							this.checkerArray[enteredWords][i] = "orange";
						}
					}	
				}
				if(checkerArray[enteredWords][i] != "green" && checkerArray[enteredWords][i] != "orange") {
					checkerArray[enteredWords][i] = "blue";
				}
				
				
			}
			
			drawBoard();
			
			System.out.print(word);
			lastWord = word;
			this.cullWords();
			if(word != goalWord) {
				this.cullWords();	
				word = getNewWord();
			}
			else {
				quit();
			}
			
			
			enteredWords++;
		}
			
		
			

			
			
		
		
		
	}
	
	
	/** Called at start of wordle game. It initializes the word dictionary,
	 * then gets both the goal word and the first word to check. 
	 */
	@Override
	protected void initialize() {
		
		String basePath = new File("").getAbsolutePath();
	    System.out.println(basePath);
	    
		File text = new File("../data/dictionary.txt");
		Scanner sc = null;
		try {
			sc = new Scanner(text);
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		}
		
		while(sc.hasNextLine()) {
			wordDictionary.add(sc.nextLine());
		}
		
		goalWord = wordDictionary.get((int)(Math.random() * wordDictionary.size()));
		word = getNewWord();
		
		
		//Draws start board
		
		initBoard();
		
		//Sets cooldown of  getting another guess for the word
		this.keySpaceSetupFire(5);
		
		//Initializes the Drawer Hashmap
		
		drawer.put("a", NamedSymbol.A);
		drawer.put("b", NamedSymbol.B);
		drawer.put("c", NamedSymbol.C);
		drawer.put("d", NamedSymbol.D);
		drawer.put("e", NamedSymbol.E);
		drawer.put("f", NamedSymbol.F);
		drawer.put("g", NamedSymbol.G);
		drawer.put("h", NamedSymbol.H);
		drawer.put("i", NamedSymbol.I);
		drawer.put("j", NamedSymbol.J);
		drawer.put("k", NamedSymbol.K);
		drawer.put("l", NamedSymbol.L);
		drawer.put("m", NamedSymbol.M);
		drawer.put("n", NamedSymbol.N);
		drawer.put("o", NamedSymbol.O);
		drawer.put("p", NamedSymbol.P);
		drawer.put("q", NamedSymbol.Q);
		drawer.put("r", NamedSymbol.R);
		drawer.put("s", NamedSymbol.S);
		drawer.put("t", NamedSymbol.T);
		drawer.put("u", NamedSymbol.U);
		drawer.put("v", NamedSymbol.V);
		drawer.put("w", NamedSymbol.W);
		drawer.put("x", NamedSymbol.X);
		drawer.put("y", NamedSymbol.Y);
		drawer.put("z", NamedSymbol.Z);
		
	}
		 
		 
		
		 
	
	
	/** gets a new word from the dictionary for the bot to guess
	 * 
	 * @return new word guess
	 */
	public String getNewWord() {
		
		//TODO get new word from dictionary, can be done using Math.Random() to get index. 
		
		return null;
	}
	
	/* Takes out words from the dictionary that are not possible given the colors executed on LastEnteredWord
	*/
	public void cullWords() {
		
		//TODO Loop through the dictionary, calling isWordPossible to check each word of the dictionary. 
		// If it returns False, take word out of dictionary and decrease index by 1
		
		
			
	}
	
	/* Checks if the entire word is possible.
	 * @param wordChecked: The word from dictionary to be tested 
	 * @return boolean: true if word is still possible, false otherwise
	 */
	public boolean isWordPossible(String wordChecked) {

		//TODO Check if a entire word from the dictionary satisfies requirements from last entered word's colors in checkerArray
		// Use isCharPossible to check individual letters
		return true;
	}
	
	/* Decides whether the passed letter is possible in a specific position
	 * @param letter: Word from dictionary, Index: current index of word, color: color of corresponding letter from checkerArray	
	 * This implementation is heuristic, it only focuses on the previous word and its coloring. 
	 * It doesn't consider combining information from all previous words. 
	 * @return Boolean: true if character position is possible, false otherwise
	 */
	public boolean isCharPossible(String dictionaryWord, int index, String color) {
		char indexCharacter = word.toLowerCase().charAt(index);
		//TODO For a given word and index of that word, using CharAt, check against last entered word
		// Depends on the color of last entered word at index.
		// Green should make sure that word has the right word at that location
		// Orange should make sure the word has that letter at another index
		// Blue should make sure that the word doesn't have that letter at all
		
		return true;
	}
	/**
	 * Draws the board each time a new word is picked out of the dictionary.
	 */
	public void drawBoard() {
		for(int i = 0; i < 5; i++) {
			this.drawSymbol(enteredWords, i, drawer.get(word.substring(i, i+1)), NamedColor.white);
			
			switch (checkerArray[enteredWords][i]) {
				case ("green"):
					setBGColor(enteredWords, i, NamedColor.green);
					break;
				case("blue"): 
					setBGColor(enteredWords, i, NamedColor.blue);
					break;
				case ("orange"):
					setBGColor(enteredWords, i, NamedColor.orange);
					break;
			}
		}
	}
	
	/**
	 * Draws the board at the start of the game
	 */
	public void initBoard() {
		for(int i = 0; i < 6; i++) {
			for(int j = 0; j < 5; j++) {
				setBGColor(i, j, NamedColor.ivory);
				drawSymbol(i, j, NamedSymbol.none, NamedColor.white);
			}
		}
	}
	/* Main method, starts game and set descriptors
	 */
	public static void main(String[] args) {
		
		Wordle game = new Wordle();
		
		game.setTitle("WordleBot");
		game.setDescription("blue for not in word. Green is for in right spot. Orange is for in word, but not in the right spot.");
		game.start();
		
	}


	

}
