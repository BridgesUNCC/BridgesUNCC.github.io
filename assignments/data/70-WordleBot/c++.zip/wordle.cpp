
#include <NonBlockingGame.h>

#include <list>
#include <string>
#include <fstream>
#include <iostream>
#include <unordered_map>

using namespace std;
using namespace bridges::game;

/**
 * Welcome to Bridges Wordle Bot Assignment.
 */

struct Wordle: public NonBlockingGame {

	// create your data structures you will need to keep the 
	// dictionary of words, a symbol map  that will be used to draw the board
	// with the guessed words, and other local variables
	// can use a vector or list for the dictionary

	int tries;
	const int MaxAttempts = 6;

	// constructor that sets credentials
	Wordle(int assign_id, string user_name, string api_key)
			: NonBlockingGame(assign_id, user_name, api_key, 6, 5) {
	}

	// this function does all of the initializations
	// including reading the dictionary of 5 letter words, getting
	// a goal word, random number generator initialization
	// draw the initial board and setting up the symbol map
	virtual void initialize() override {
	}

	virtual void gameLoop() override {
		if (keySpaceFire()) { 
			// check the number of attempts, usually limited to 6
			if (tries < MaxAttempts) {
				// get a word, update the board, check if we are done
				

				tries++;
			}

			// cull words based on the answer and the guessed word
		}
	}

	string  getNewWord(list<string>&  dict) {
		// returns a new word (pick at random) from the dictionary
		string word;

		return word;
	}

	void initBoard() {
		// draw the empty empty board
	}

	void updateBoard(string word, string answer, int attempt) {
		// updates the board with the newest word and drawn in the 
		// right color, by comparing with the answer
	}

	void cullDictionary (string curr_wd, string answer, list<string>& dict) {
		// we will remove words that either are not part of the answer or those
		// indicated by the guessed word

		// Must consider 3 different cases for culling words from the dictionary
		// 1. A letter in the word matches the answer in the same position:
		//    Remove all words that dont have that letter in that position
		// 2. A letter is in the answer but not in the right position:
		//    Remove all words that dont have this letter in their word
		// 3. A letter in the guessed word that does not exist in the answer
		//	  Remove all words with this letter in the dictionary
	}
};


int main(int argc, char **argv) {
//	Wordle wordle_bot(170, "BRIDGES_USER_ID", "BRIDGES_API_KEY");
	Wordle wordle_bot(170, "kalpathi60", "486749122386");
	wordle_bot.start();
}

