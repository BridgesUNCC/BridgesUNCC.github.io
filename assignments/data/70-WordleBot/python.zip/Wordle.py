
from bridges import NonBlockingGame
import bridges
from bridges.named_symbol import NamedSymbol
from bridges.named_color import NamedColor

import random


'''
@author Mack Larson
Wordle Extends NonBlockingGame and implements gameLoop and initialize
It is a class that creates a Wordle game using NonblockingGame, 
then uses a Model-Based Reflex Agent to try to solve the goal word
 '''
class Wordle(NonBlockingGame):
    
    word_dictionary = []
    goal_word = ""
    word = ""
    last_word = ""
    entered_words = 0
    
    checker_array = [[0 for i in range(5)] for j in range(6)]
    drawer = {
        "a" : NamedSymbol.a,
        "b" : NamedSymbol.b,
        "c" : NamedSymbol.c,
        "d" : NamedSymbol.d,
        "e" : NamedSymbol.e,
        "f" : NamedSymbol.f,
        "g" : NamedSymbol.g,
        "h" : NamedSymbol.h,
        "i" : NamedSymbol.i,
        "j" : NamedSymbol.j,
        "k" : NamedSymbol.k,
        "l" : NamedSymbol.l,
        "m" : NamedSymbol.m,
        "n" : NamedSymbol.n,
        "o" : NamedSymbol.o,
        "p" : NamedSymbol.p,
        "q" : NamedSymbol.q,
        "r" : NamedSymbol.r,
        "s" : NamedSymbol.s,
        "t" : NamedSymbol.t,
        "u" : NamedSymbol.u,
        "v" : NamedSymbol.v,
        "w" : NamedSymbol.w,
        "x" : NamedSymbol.x,
        "y" : NamedSymbol.y,
        "z" : NamedSymbol.z,
        
        }
    '''
    excuted every frame, calls other methods to update the grid and is the main hub for the methods.
    if there is room for another word, updates board, draws, calls cullwords, get new word if word 
    isnt goal word. also checks to see if game needs to exit.
    '''
    def game_loop(self):
        
        if self.key_space_just_pressed() and self.entered_words < 6:
            
            # checks word against goal word
            self.update_board()

            # Updates the visual gameBoard
            self.draw_board()
           
           
            self.last_word = self.word

            #updates Word Dictionary
            self.cull_words()

            if self.word != self.goal_word :
                self.word = self.get_new_word()
            self.entered_words += 1
        # quits if 6 entered words, or word is goal word, activates if lastword = word
        elif((self.entered_words > 5 or self.goal_word == self.word)):
            self.quit()
       
    '''
    Initilizes the Wordle class, passing to the NonBlockingGame class to create a game
    @params: assign_num: the assignment number of bridges, bridges_user: user's username,
    bridges_api_key: the user's api key.
    @returns: none

    '''           
    def __init__(self, assign_num, bridges_user, bridges_api_key):
        super().__init__(assign_num, bridges_user, bridges_api_key, 6, 5)
    
    '''
    initializes the dictionary, gets the goal word, get first word, and initializes the board.
    @params: none
    @returns: none
    '''
    def initialize(self):
        
        with open('../data/dictionary.txt') as file:
            for line in file:
                self.word_dictionary.append(line.rstrip())
                
        self.goal_word = self.word_dictionary[random.randrange(len(self.word_dictionary))]        
        self.goal_word_char_array = list(self.goal_word.lower())
        self.word = self.get_new_word()
        
        self.init_board()
    
    '''
    updates the board according to the last entered word vs the goal word
    its main goal is to provide feeback for the draw_board and cull_words functions by editing the checkerArray
    @params: none
    @returns: none
    '''
    def update_board(self):
        for i in range(5):
                
                if(self.word[i:i+1] == self.goal_word[i:i+1]):
                    
                    self.checker_array[self.entered_words][i] = "green"
                    
                else:
                    for c in range(5):
                        if self.checker_array[self.entered_words][c] != "green" and self.word[i:i+1] == self.goal_word[c:c+1]:
                            
                            self.checker_array[self.entered_words][i] = "orange"
                if self.checker_array[self.entered_words][i] != "green" and self.checker_array[self.entered_words][i] != "orange":
                    self.checker_array[self.entered_words][i] = "blue"
    '''
    gets a new word from the dictionary, after the dictionary has been cut down from the last entered word
    @params: none
    @returns: new_word: the new word for the bot to guess
    '''
    def get_new_word(self):
        ### Get new word by randomly getting a word from the dictionary list (random.randrange)
        
        return null
    '''
    culls word from the dictionary based on what colors the last entered word has gotten
    @params: none
    @returns: none
    '''
    def cull_words(self):
        ### loop through dictionary using while loop, checking each word using is_word_possible.
        ### if it isnt possible, remove it and decrease index by one.
    '''
    draws the board for each word based on the checker array, also uses the drawer dictionary for the NamedSymbol
    @params: none
    @returns: none
    '''
    def draw_board(self) :

        for i in range(5):
            self.draw_symbol(self.entered_words, i, self.drawer[self.word[i:i+1]], NamedColor.white)
            if self.checker_array[self.entered_words][i] == "green":
                self.set_bg_color(self.entered_words, i, NamedColor.green)
            elif self.checker_array[self.entered_words][i] == "orange":
                self.set_bg_color(self.entered_words, i, NamedColor.orange )
            elif self.checker_array[self.entered_words][i] == "blue":
                self.set_bg_color(self.entered_words, i, NamedColor.blue )
    '''
    checks to see if entire word is possible
    @params: word_checked: word from dictionary to be checked
    @returns: boolean: true if possible, otherwise false
    '''
    def is_word_possible(self, word_checked: str):
    
        
        ### checks if entire word satifies last word color code. 
        ### uses is_char_possible to check individual characters
    '''
    checks to see if each character in a word is possible
    @params: dictionary_word: full word that has character in it, index: index of char, color: color string from checkerArray
    returns: boolean: true if character possible, otherwsie false
    '''
    def is_char_possible(self, dictionary_word: str, index: str, color: str):
        ### for a given word, index, and color, tell whether the character could be in the right place based on last entered word
        ### for green, compare index in last word to index of dictionary
        ### for orange, check if that character is anywhere but the same index in dictionary word
        ### for blue, make sure that letter isnt in dictionary word

    '''
    initializes the visual board.
    '''
    def init_board(self):
        for i in range(6):
            for j in range(5):
                self.set_bg_color(i, j, NamedColor.ivory)
                self.draw_symbol(i, j, NamedSymbol.none, NamedColor.white)
'''
main method, used to initialize and start game, and change description
'''
def main():
    #enter credentials for wordle
    game = Wordle(assign_number, "bridges_user", "bridges_api_key")
    game.set_title("WordleBot")
    game.set_description("Blue for not in word. Green is for in right spot in word. Orange is for in word, but not in the right spot.")
    game.start()
        
        


'''
calls main method
'''
if __name__ == '__main__':
    main()