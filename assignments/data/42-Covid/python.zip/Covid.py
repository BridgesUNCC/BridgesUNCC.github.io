from bridges import *
from bridges.world_map import *
# import pandas as pd
# import numpy as np

NUM_DAYS = 5


def main() -> None:
    bridges = Bridges(42, "BRIDGES_USER_ID", "BRIDGES_API_KEY")
    bridges.set_map(WorldMap())

    bridges.set_title("Covid")
    bridges.set_description("This program is designed to read COVID-19 confirmed cases data from a CSV file, process the data, and generate a graph using the BRIDGES library for visualization.")

    # Read COVID-19 time series data from a CSV file using pandas.
    # Find the maximum number of cases across all dates and countries.
    # Iterate through the last NUM_DAYS days in the data set to create a graph for each day.
    # Initialize a graph as an adjacency list.
    # Iterate through rows in the data set, adding vertices for each country with relevant information.
    # Set vertex labels, locations, shapes, colors, and sizes based on COVID-19 cases.
    # Set the data structure of Bridges to the graph and visualize it.
    # Calculate daily sums of COVID-19 cases and create a line chart.
    # Iterate through columns representing dates, summing cases for each day.
    # Create a LineChart object and set data series using date columns and corresponding daily sums.
    # Set the data structure of Bridges to the line chart and visualize it.

    bridges.visualize()


if __name__ == '__main__':
    main()
