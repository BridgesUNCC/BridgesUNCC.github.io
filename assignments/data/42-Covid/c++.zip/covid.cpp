#include <fstream>
#include <sstream>
#include <iostream>
#include <unordered_map>
#include <vector>
#include <string>
#include <utility>


#include "Bridges.h"
#include "WorldMap.h"
#include "GraphAdjList.h"

using namespace std;
using namespace bridges;

struct CovidCases {
	vector<string> header;
	unordered_map<string, vector<int>> counts;
	vector<string> country;
	vector<pair<float, float>> location; 
};

void readCovidData(string file_name, CovidCases& covid_cases);
void visualizeCovidCases(Bridges& bridges, CovidCases& covid_cases, int num_days);

// This program reads covid case data from a data file for 77  days covering
// most countries in the world. The goal is to create a visualization of
// the case data for each day by plotting a circle suitably scaled across
// each country, using hte provided lat/long values and the Bridges world map
// visualization features.

int main() {
	Bridges bridges (42, "BRIDGES_USER_ID", "BRIDGES_API_KEY");
	bridges.setTitle("Covid Cases around the world");
	bridges.setTitle("Read and process COVID-19 confirmed cases data and generate a World Map visualization.");

	WorldMap wm;
	bridges.setMap(wm);

	unordered_map<string, vector<float>> data;
	vector<string> header;
	CovidCases covid_cases;
	string infile_name;
	readCovidData (infile_name, covid_cases);
	
	visualizeCovidCases(bridges, covid_cases, 75);

	return 0;
}

// reads the data file and returns the covid data
void readCovidData(string file_name, CovidCases& covid_cases) {

	// Todo
	// read the data from the input file and store that in the CovidCases
	// or some data structure and return that.
}


void visualizeCovidCases(Bridges& bridges, CovidCases& covid_cases, int num_days){

	// Todo:
	// create the graph. The vertices need to be created and located just once.
	// their size is changing each day based on the case counts
	// You will need to find and scale the size of the bubbles for each day
	// You can use circles for representing the #cases.
	// Use bridges to visualize for each day by repeatedly calling visualize()
	// for each day after updating the case data in the graph

	// bridges.setDataStructure(graph);
	// bridges.visualize()
};
