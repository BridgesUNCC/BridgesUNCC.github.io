import bridges.connect.Bridges;
import bridges.base.GraphAdjList;
import bridges.base.LineChart;
import bridges.base.WorldMap;

import java.io.BufferedReader;
import java.io.FileReader;

import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;

public class Covid {

    public static void main(String[] args) throws Exception {
        Bridges bridges = new Bridges(42, "BRIDGES_USER_ID", "BRIDGES_API_KEY");
        bridges.setMap(new WorldMap());

        bridges.setTitle("Covid");
	    bridges.setDescription("This program is designed to read COVID-19 confirmed cases data from a CSV file, process the data, and generate a graph using the BRIDGES library for visualization.");

        String filepath = "../data/time_series_covid_19_confirmed.csv";

        //Uncomment these lines after finishing the readData and makeGraph methods
        // ArrayList<ArrayList<String>> data = readData(filepath);
        // makeGraph(bridges, data, 5); //creates the graph, and sets a maximum number of days to visualize. The visualization will end with the last day in the data, and will start at numCols-numDays.  

        //Uncomment this line after finishing the visualizeTotalCases method
        // visualizeTotalCases(bridges, data);
    }

    private static ArrayList<ArrayList<String>> readData(String path) throws Exception {
        ArrayList<ArrayList<String>> data = new ArrayList<ArrayList<String>>();
        // Create a BufferedReader to read the contents of the specified CSV file.
        // Initialize variables, including an ArrayList to store the CSV data.
        // Read each line from the CSV file and handle cases where the line contains double quotes.
        // Split each line into an array, remove double quotes, and convert it into a List.
        // Add the List to the ArrayList to store the CSV data.
        return data;
    }

    private static void makeGraph(Bridges bridges, String path, int numDays) throws Exception {
        // Determine the number of rows and columns in the CSV data.
        // Find the maximum number of cases within the specified recent days for scaling purposes.
        // Create a graph for each recent day, setting vertices' locations, colors, and sizes based on the data.
        GraphAdjList<Integer, String, String> graph = new GraphAdjList();
        bridges.setDataStructure(graph);
        bridges.visualize();
    }

    private static void visualizeTotalCases(Bridges bridges, ArrayList<ArrayList<String>> data) throws Exception {
        LineChart chart = new LineChart();
        //Create a line chart, sum the count of cases each day, and plot the change day to day.
        bridges.setDataStructure(chart);
        bridges.visualize();
    }
}
