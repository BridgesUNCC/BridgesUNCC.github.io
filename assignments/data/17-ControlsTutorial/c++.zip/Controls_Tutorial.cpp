#include <NonBlockingGame.h>
#include <iostream>

using namespace bridges::game;

struct my_game : public NonBlockingGame {
  // defaults for background color, symbol color, symbol
  NamedColor myBackgroundColor;
  NamedColor mySymbolColor;
  NamedSymbol mySymbol;

  // constructor
  my_game(int assID, std::string username, std::string apikey)
    : NonBlockingGame (117, username, apikey, 20, 20) {
    setTitle("My First Game!");
    setDescription("Test out your controls here. Use the four arrow keys.");
  }

  // to be written by the user for each game
  // set defaults for class variables
  virtual void initialize() override {
  }

  // updates the color of each cell in the grid
  // use the setBGColor() method
  void updateGridColor() {
  }

  // updates the symbol of each cell in the grid
  // use the drawSymbol() method
  void updateGridSymbols() {
  }


  // the main game loop with user interaction
  virtual void gameLoop() override {
    // Take user input and alter the board in some way
    // A number keyboard interactions are possible - use
    // these to change color, symbol that is drawn on the board


    // after the interaction, update the color and symbols of the board
    // using the functions you wrote above
  }
};

// Initialize your game
// Call your game class with your assignment id, username, and api key
int main (int argc, char** argv) {
  my_game g(117, "BRIDGES_USER_ID", "BRIDGES_API_KEY");

  g.start();
}
