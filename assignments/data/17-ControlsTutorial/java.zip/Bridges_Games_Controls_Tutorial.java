package STUDENT_PACKAGE;

import bridges.base.NamedColor;
import bridges.base.NamedSymbol;
import bridges.games.NonBlockingGame;

public class STUDENT_CLASS_NAME extends NonBlockingGame {

    // Your grid can contain up to 1024 cells. 
    // The largest square grid available is 32 x 32
    static int gridColumns = 30;
    static int gridRows = 20;

    // Create variables for your games colors and symbols.
    NamedColor myBackgroundColor;
    NamedColor mySymbolColor;
    NamedSymbol mySymbol;

    // The initialize function runs once before the game loop begins.
    // Assign your game variables here.
    public void initialize() {
        myBackgroundColor = NamedColor.blue;
        mySymbolColor = NamedColor.white;
        mySymbol = NamedSymbol.duck;
    }

    // Create your own functions to make changes to your game.
    // This is an example function that sets the background color of
    // each grid cell to your background color.
    public void updateGridColor() {
        for (int r = 0; r < gridRows; r++) {
            for (int c = 0; c < gridColumns; c++) {
                setBGColor(r, c, myBackgroundColor);
            }
        }
    }

    // Create your own functions to make changes to your game.
    // This is an example function that draws a symbol on each cell of the grid.
    public void updateGridSymbols() {
        for (int r = 0; r < gridRows; r++) {
            for (int c = 0; c < gridColumns; c++) {
                drawObject(r, c, mySymbol, mySymbolColor);
            }
        }
    }

    // The game loop runs contiunously. So anything you put here will be called
    // repeatedly until the game ends.
    public void gameLoop() {

        // There are 10 keys that you can use to control your game.
        // Placing them into an if statement means the game will check to see if the button is
        // being pressed. If true, the code you place inside the if statement will be executed.
        // Here we used the up, down, left, and right arrow keys to change the background color.
        // Then we used the W, S, A, and D keys to change the symbol.
        // The Q and Spacebar keys will change the symbol color.
        if (keyUp()) {
            
        }
        if (keyDown()) {
            
        }
        if (keyLeft()) {
            
        }
        if (keyRight()) {
            
        }
        if (keyW()) {
            
        }
        if (keyS()) {
            
        }
        if (keyA()) {
            
        }
        if (keyD()) {
            
        }
        if (keyQ()) {
            
        }
        if (keySpace()) {
            
        }
        
        // Now, if someone pressed a button the colors or symbols on your grid need to be
        // updated. So send them to the functions we created to update your game.
        updateGridColor();
        updateGridSymbols();
    }

    // To test your game, create an object of your game within the main method of your program.
    // Use an assignment number, your bridges username, your bridges API key, the number of columns
    // in your grid, and the number of rows in your grid as arguments for your bridges game object.
    public static void main(String args[]) {
        // Initialize.
        STUDENT_CLASS_NAME sf = new STUDENT_CLASS_NAME(1, "Allie_Beckman", "825604476223", gridColumns, gridRows);
    }

    // Make sure you create this method in your game so that it can be visualized by the bridges server.
    public STUDENT_CLASS_NAME(int assid, String userName, String apiKey, int gc, int gr) {
        super(assid, userName, apiKey, gc, gr);
        setTitle("Your First Game!");
        setDescription("Test out your controls. W, S, A, D. Arrow keys, Q, and Spacebar");
        // start running the game
        start();
    }
}
