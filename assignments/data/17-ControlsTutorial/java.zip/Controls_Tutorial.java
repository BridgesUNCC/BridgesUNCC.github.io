import bridges.base.NamedColor;
import bridges.base.NamedSymbol;
import bridges.games.NonBlockingGame;

public class Controls_Tutorial extends NonBlockingGame {

    // Set Grid size; your grid can contain up to 1024 cells. 
    // The largest square grid available is 32 x 32
	static int gridColumns = 20;
	static int gridRows = 20;


    // Create variables for your games colors (background, symbol)  and symbols.


    //  Constructor. This method sets needed BRIDGES credentials for the game,
	//  calls the start() method to start the game; 
	//	create this method in your game so that it can 
	// 	be visualized by the bridges server.
    public Controls_Tutorial(int assid, String userName, String apiKey, int gc, int gr) {
        super(assid, userName, apiKey, gc, gr);
        setTitle("BUGSTOMP!");
        setDescription("Controls: The 4 Arrow keys.");

        // start running the game
        start();
    }

    // The initialize function runs once before the game loop begins.
    // Assign your game variables (colors, symbols) here.
    public void initialize() {
    }

    // Create your own functions to make changes to your game, such
	// updating colors and symbols of your board



    // The game loop runs contiunously. So anything you put here will be called
    // repeatedly until the game ends.
    public void gameLoop() {

        // There are 10 keys that you can use to control your game.
		// Refer to the NonBlockingGame documentation for more details
        // Placing them into an if statement means the game will check to see if the button is
        // being pressed. If true, the code you place inside the if statement will be executed.
        // Here we used the up, down, left, and right arrow keys to change the background color.
        // Then we used the W, S, A, and D keys to change the symbol.
        // The Q and Spacebar keys will change the symbol color.

        
        // Now, if someone pressed a button the colors or symbols on your grid need to be
        // updated. So send them to the functions you created to update your game grid.
    }

    // To test your game, create an object of your game within the main method of your program.
    // Use an assignment number, your bridges username, your bridges API key, the number of columns
    // in your grid, and the number of rows in your grid as arguments for your bridges game object.
    public static void main(String args[]) {
        // Initialize
		Controls_Tutorial sf = new Controls_Tutorial(ASSIGNMENT_NUMBER, "BRIDGES_USER_ID", "BRIDGES_API_KEY", gridColumns, gridRows);
    }

}
