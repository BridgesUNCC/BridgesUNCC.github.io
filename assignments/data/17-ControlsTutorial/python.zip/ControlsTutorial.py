from bridges import *


class ControlsTutorial(NonBlockingGame):

    gridColumns = 0
    gridRows = 0

    myBackgroundColor = NamedColor.blue
    mySymbolColor = NamedColor.green
    mySymbol = NamedSymbol.circle

    def initialize(self):
        self.myBackgroundColor = NamedColor.blue
        self.mySymbolColor = NamedColor.blueviolet
        self.mySymbol = NamedSymbol.circle

    # fill the grid with a background color using set_bg_color()
    def update_grid_color(self):
        pass


    # fill the grid with symbols - use draw_symbol()
    def update_grid_symbols(self):
        pass

    # use the input keys to change symbols or colors in the grid
    def game_loop(self):
        if self.key_up():
            pass

        if self.key_down():
            pass
            
        if self.key_left():
            pass
            
        if self.key_right():
            pass
            
        if self.key_w():
            pass
            
        if self.key_s():
            pass
            
        if self.key_a():
            self.mySymbol = NamedSymbol.sloth
        if self.key_d():
            pass
            
        if self.key_q():
            pass
            
        if self.key_space():
            self.mySymbolColor = NamedColor.darksalmon

        self.update_grid_color()
        self.update_grid_symbols()

    #constructor
    def __init__(self, assid, login, apikey, cols, rows):
        super(ControlsTutorial, self).__init__(assid, login, apikey, cols, rows)
        self.gridColumns = cols
        self.gridRows = rows


def main():
    my_game = ControlsTutorial(217, "BRIDGES_USER_ID", "BRIDGES_API_KEY", 30, 30)
    my_game.start()


if __name__ == '__main__':
    main()
