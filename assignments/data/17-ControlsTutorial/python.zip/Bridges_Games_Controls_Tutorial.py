from bridges import *


class StudentClass(NonBlockingGame):

    gridColumns = 0
    gridRows = 0

    myBackgroundColor = NamedColor.blue
    mySymbolColor = NamedColor.green
    mySymbol = NamedSymbol.circle

    def initialize(self):
        self.myBackgroundColor = NamedColor.blue
        self.mySymbolColor = NamedColor.blueviolet
        self.mySymbol = NamedSymbol.circle

    def update_grid_color(self):
        col = 0
        row = 0
        while col < self.gridColumns:
            rows = 0
            while row < self.gridRows:
                self.set_bg_color(col, row, self.myBackgroundColor)
                row+=1
            col+=1

    def update_grid_symbols(self):
        col = 0
        row = 0
        while col < self.gridColumns:
            row = 0
            while row < self.gridRows:
                self.draw_object(col, row, self.mySymbol, self.mySymbolColor)
                row+=1
            col+=1

    def game_loop(self):
        if self.key_up():
            self.myBackgroundColor = NamedColor.green
        if self.key_down():
            
        if self.key_left():
            
        if self.key_right():
            
        if self.key_w():
            
        if self.key_s():
            
        if self.key_a():
            self.mySymbol = NamedSymbol.sloth
        if self.key_d():
            
        if self.key_q():
            
        if self.key_space():
            self.mySymbolColor = NamedColor.darksalmon

        self.update_grid_color()
        self.update_grid_symbols()

    def __init__(self, assid, login, apikey, cols, rows):
        super(StudentClass, self).__init__(assid, login, apikey, cols, rows)
        self.gridColumns = cols
        self.gridRows = rows


def main():
    my_game = StudentClass(80, "STUDENT_USERNAME", "STUDENT_API_KEY", 30, 30)
    my_game.start()


if __name__ == '__main__':
    main()
