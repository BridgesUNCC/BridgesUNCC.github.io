package scaffold;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import bridges.connect.Bridges;
import bridges.validation.RateLimitException;

import java.io.IOException;
import bridges.base.Color;
import bridges.base.ColorGrid;

/**
 * Assignment in which students take an audio file (WAV)
 * and display its wave form by taking averages of
 * the audio's samples
 * 
 */
public class AudioWave {
    
    // FIELDS
    
    // use a collection to keep all of your averages in
    

    public AudioWave() {
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException, RateLimitException {
        // Initialize BRIDGES
        Bridges bridges = new Bridges(52, "USER_ID", "API_KEY");
        
        // set title and description
        bridges.setTitle("Audio Wave");
        bridges.setDescription("Create the wave form of an audio file.");
        /*
        use different colors for the background of the color grid and the wave
        */ 
        ColorGrid cg = new ColorGrid(1080, 1920);
        
        /*
        get the audio file by using its name
        */
        
        // get samples from the audio file
        
            
        /*
        average the samples.
        
        keep in mind that the audio's sampling rate
        is given in samples per second
        
        samples range from -1 to 1
        */
        
        /*
        plot the averages onto the color grid to 
        create the wave form of the audio
        
        keep in mind that the origin of the color grid
        is on the top left corner with y increasing 
        downwards
        */
        
        /*
        fill the wave form starting from the middle of the grid
        to the point that was plotted earlier
        */
       
       // visualization
        bridges.setDataStructure(cg);
        bridges.visualize();
        
    }
    
   
    
    
}
