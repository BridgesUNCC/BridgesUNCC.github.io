import bridges.connect.Bridges;
import bridges.validation.RateLimitException;
import bridges.base.AudioClip;
import java.io.IOException;
import java.util.ArrayList;
import bridges.base.Color;
import bridges.base.ColorGrid;

/**
 * Assignment to visualize a WAV file
 * 
 */
public class AudioWave {
    
   static ArrayList<Integer> averages = new ArrayList<>();

    public static void main(String[] args) throws IOException, RateLimitException {
        // Initialize BRIDGES
        Bridges bridges = new Bridges(52, "USER_ID", "API_KEY");
        
        // set title and description
        bridges.setTitle("Audio Wave");
        bridges.setDescription("Create the wave form of an audio file.");
        
        Color black = new Color("black"); // background color
        Color white = new Color("white"); // wave form color
        ColorGrid cg = new ColorGrid(1080, 1920, black);
        
        // Get the audio file by using its name
        
        // Get samples from the audio file
        
        // Get the averages of samples every 1/7 seconds of the song  
        
        // Make the wave form
       
       // visualization
        bridges.setDataStructure(cg);
        bridges.visualize();
        
    }
}
