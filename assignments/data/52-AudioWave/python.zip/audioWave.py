from bridges import Bridges
from bridges import Color
from bridges import ColorGrid
from bridges import AudioClip


def main():

    # initialize bridges
    bridges = Bridges(252, "BRIDGES_USER_ID", "BRIDGES_API_KEY")

    # set title and description
    bridges.set_title("Audio Wave")
    bridges.set_description("Create the wave form of an audio file")

    # use different colors for the background of the grid and the wave

    # cg = ColorGrid(1080, 1920, black)

    # get the audio file by using its name

    # get the samples of the audio file

    # average the samples
    # keep in mind that samples can be negative and positive

    # plot the averages onto the color grid to create the wave from of the audio
    # keep in mind that the origin of the color grid is on the top left corner
    # with y increasing downwards

    # fill the wave form starting from the middle of the grid to the point
    # that was plotted earlier

    # bridges.set_data_structure(cg)
    bridges.visualize()


if __name__ == "__main__":
    main()
