from bridges import Bridges
from bridges import Color
from bridges import ColorGrid
from bridges import AudioClip


def main():

    # initialize bridges
    bridges = Bridges(252, "BRIDGES_USER_ID", "BRIDGES_API_KEY")

    # set title and description
    bridges.set_title("Audio Wave")
    bridges.set_description("Create the wave form of an audio file")

    # use different colors for the background of the grid and the wave

    # cg = ColorGrid(1080, 1920, black)

    # get the audio file by using its name

    # get the samples of the audio file

    # process the samples to create a moving window average with a window
    # size chosen to ensure the max samples is equal to the color grid width

    # next subsample the signal, picking a sample every window-size number of
    # samples

    # keep in mind that samples can be negative and positive

    # scale the samples to a range so that it can fit within the grid height,
    # say half its height

    # Map the signal values to the grid. As the color grid is an image
    # you can simply color the pixels at each sample point all the way
    # to the axis -- a crude way to draw teh wave.

    bridges.set_data_structure(cg)
    bridges.visualize()


if __name__ == '__main__':
    main()
