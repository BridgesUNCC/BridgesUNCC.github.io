import bridges.data_src_dependent.OsmVertex;

public class OsmVertexLocation implements Location<OsmVertex> {
    public double getX(OsmVertex e) {
	return e.getLatitude();
    }
    public double getY(OsmVertex e) {
	return e.getLongitude();
    }
}
