import bridges.connect.Bridges;
import bridges.connect.DataSource;
import bridges.data_src_dependent.OsmData;
import bridges.data_src_dependent.OsmVertex;
import bridges.data_src_dependent.OsmEdge;
import bridges.base.GraphAdjList;



public class SpatialIndexing{
    public static void main(String args[]) {
	//create the Bridges object, set credentials
	Bridges bridges = new Bridges(43, "BRIDGES_USER_NAME", "BRIDGES_API_KEY");
	bridges.setTitle("Spatial Indexing");
	bridges.setDescription("Computes the closest point from a given point, using Open Street Map Data");
	
	try{
	    
	    DataSource ds = bridges.getDataSource();
	    OsmData osm_data = ds.getOsmData("New York, New York", "secondary");
	    OsmVertex[] ov = osm_data.getVertices();
	    
	    //This is just to look at what the data looks like. You can set it to false to avoid regenerating the picture every time.
	    if (true) {
		System.err.println("Size of the index: "+ov.length);
		
		GraphAdjList<Integer, String, String> graph = new GraphAdjList<Integer, String, String>();
		graph.forceLargeVisualization(true);
		for (int i=0; i<ov.length; ++i) {
		    graph.addVertex(i, "");
		    graph.getVisualizer(i).setLocation(ov[i].getLongitude(), ov[i].getLatitude());
		}
		bridges.setDataStructure(graph);
		bridges.visualize();
	    }

	    SpatialIndex<OsmVertex, OsmVertexLocation> nsi = new SomeSpatialIndex<OsmVertex, OsmVertexLocation> (ov, new OsmVertexLocation());

	    long startTime = System.nanoTime();

	    for (int i=0; i< 1000; ++i) {
		int a = nsi.getNearestNeighboor(ov[i].getLongitude(), ov[i].getLongitude());
		if (i%10 == 0) {
		    System.err.println(a);
		}
	    }
	    
	    long endTime = System.nanoTime();
	    
	    double duration = (endTime - startTime)/(1000.*1000.*1000.); 
	    System.out.println( "Elapsed time: " +duration +" s");

	    
	} catch(java.lang.Exception e) {
	    System.err.println(e);
	}
	

	
	
    }
}
