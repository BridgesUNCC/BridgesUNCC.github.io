
public class SomeSpatialIndex<E, CompE extends Location<E> > extends SpatialIndex<E, CompE > {

    public SomeSpatialIndex (E[] e, CompE ce) {
	super(e, ce);
    }
    
    
    public int getNearestNeighboor (double x, double y) {
	//TODO

	//you can access location of the ith object with locator.getX(index[i]) and locator.gety(index[i])
	
	return -1;
    }
    
}
