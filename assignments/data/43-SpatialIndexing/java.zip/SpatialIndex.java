
public abstract class SpatialIndex<E, CompE extends Location<E> > {

    protected E[] index;
    protected CompE locator;
    
    public SpatialIndex (E[] e, CompE ce) {
	index = e;
	ce = locator;
    }
    
    protected double distancesquared(double x1, double y1,
			   double x2, double y2) {
	return (x1-x2)*(x1-x2)+(y1-y2)*(y1-y2);
    }

    
    public abstract int getNearestNeighboor (double x, double y);
    
}
