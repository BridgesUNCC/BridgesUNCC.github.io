
public interface Location<E> {
    public double getX(E e);
    public double getY(E e);
}
