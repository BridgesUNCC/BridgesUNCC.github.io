#include "Bridges.h"
#include "DataSource.h"
#include <iostream>
#include <string>
#include <unordered_map>
#include <fstream>
#include <data_src/OSMData.h>
#include <queue>
#include <algorithm>
#include "spatialindex2d.hpp"



using namespace bridges;

template <typename E, typename CompE>
class SomeSpatialIndex2D : public SpatialIndex2D<E,CompE> {
public:
  SomeSpatialIndex2D(const vector<E>& v, CompE c)
    :SpatialIndex2D<E,CompE> (v, c) {
  }

  //returns the index in the vector used to construct of the object the closest to the given coordinate
  virtual size_t getClosest(double x, double y) {
    //TODO
    return -1;    
  }
};








class CompE {
public:
  double getX(const OSMVertex & v) const {return v.getLongitude();}
  double getY(const OSMVertex & v) const {return v.getLatitude();}
};

int main(int argc, char **argv) {

  try {
    //create the Bridges object, set credentials
    Bridges bridges(143, "BRIDGES_USERNAME", "BRIDGES_API_KEY");

    bridges.setTitle("Spatial Indexing");
    bridges.setDescription("");

    DataSource ds (&bridges);
    OSMData osm_data = ds.getOSMData("New York, New York", "secondary");

    const vector< OSMVertex > & vert = osm_data.getVertices();

    CompE ce;
    
    if (1) {
      std::cerr<<"Size of Index: "<<vert.size()<<"\n";
      
      GraphAdjList<int> g;
      for (size_t i=0; i<vert.size(); ++i) {
	g.addVertex(i);
	g.getVertex(i)->setLocation(vert[i].getLongitude(),vert[i].getLatitude());
      }
      bridges.setDataStructure(g);
      bridges.visualize();
    }
    
    SomeSpatialIndex2D<OSMVertex, CompE> nsi(vert, ce);
    

    
    auto start = std::chrono::steady_clock::now();

    for (int i=0; i< 1000; ++i) {
      auto a = nsi.getClosest(vert[i].getLongitude(), vert[i].getLatitude());
      if (i % 10 == 0)
	std::cout<<a<<"\n";
    }

    auto end = std::chrono::steady_clock::now();
    std::chrono::duration<double> elapsed_seconds = end-start;
    std::cout << "elapsed time: " << elapsed_seconds.count() << "s\n";
    
  }
  catch (std::string s) {
    std::cerr << s << std::endl;
  }
  return 0;
}
