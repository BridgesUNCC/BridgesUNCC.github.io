#ifndef SPATIALINDEX2D
#define SPATIALINDEX2D

//The semantic is that CompE defines a getX(E) and a getY(E) that return a double
template <typename E, typename CompE>
class SpatialIndex2D {
protected:
  const vector<E>& ve;
  CompE ce;

  static double distancesquared(double x1, double y1,
				double x2, double y2) {
    return (x1-x2)*(x1-x2)+(y1-y2)*(y1-y2);
  }
  
public:
  SpatialIndex2D(const vector<E>& v, CompE c)
    :ve(v), ce(c) {
  }

  //returns the index in the vector used to construct of the object the closest to the given coordinate
  virtual size_t getClosest(double x, double y) = 0;
};

#endif
