import time
from bridges.color import *
from bridges.data_src_dependent import data_source
from bridges.bridges import Bridges
from bridges.graph_adj_list import GraphAdjList
import os

class osmloc:
    def getX(self, osmv):
        return osmv.latitude

    def getY(self, osmv):
        return osmv.longitude

class spatial_index:
    def __init__(self, index, loc):
        self._index = index
        self._loc = loc

    def distance_squared(self, x1, x2, y1, y2):
        return (x1-x2)*(x1-x2)+(y1-y2)*(y1-y2)

    def get_nearest(self, x, y):
        pass

class some_spatial_index(spatial_index):
    
    def get_nearest(self, x, y):
        #TODO
        
        ##you can access the location of the ith object with self._loc.getX(self._index[i]) and self._loc.getY(self._index[i])
        
        return -1


    

def main():
    # Set bridges credentials
    bridges = Bridges(243, "BRIDGES_USER_NAME", "BRIDGES_API_KEY")

    bridges.set_title("Spatial Indexing")
    bridges.set_description("")

    osm_vertices = data_source.get_osm_data("New York, New York", "secondary").vertices

    #this is purely to get a sense of the data, this can be set to False to avoid regenerating the visualization every time
    if (True):
        gr = GraphAdjList()
        gr.force_large_visualization(True)

        for i in range(0,len(osm_vertices)):
            gr.add_vertex(i);
            gr.get_visualizer(i).set_location(osm_vertices[i].longitude, osm_vertices[i].latitude)
            
        bridges.set_data_structure(gr)
        bridges.visualize()


    nsi = some_spatial_index(osm_vertices, osmloc())

    start = time.time()

    for i in range (0,1000):
        a = nsi.get_nearest(osm_vertices[i].longitude, osm_vertices[i].latitude)
        if (i % 10 == 0):
            print (a)
        
    end = time.time()
    print(end - start)

    

if __name__ == '__main__':
    main()
