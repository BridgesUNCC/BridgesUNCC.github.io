import bridges.games.*;
import bridges.base.*;

class GameTutorial extends NonBlockingGame {
    public GameTutorial(int assignmentnumber, String username, String apikey) {
        super (assignmentnumber, username,  apikey, 10, 10);
	    setTitle("Game Tutorials");
            setDescription("Upon a key press, display a different message!");
	//this created a game board of 10x10 into assignment 1
    }

	// this runs exactly once
    public void initialize() {
	for (int i=0; i<getBoardHeight(); ++i)
	    for (int j=0; j<getBoardWidth(); ++j)
		setBGColor(i, j, NamedColor.ivory);

		// draw some symbols on the screen
        // for instance,  HELLO

    }

    public void gameLoop() {
		//This function is executed each frame of the game
        // use the input key methods to make a message appear and disappear
        // for instance, keyUp(), keyDown(), etc
        // use the drawSymbol() method to put symbols in the board
        // Put up a message  "SIGCSE 2020 BRIDGES Workshop" or something interesting

    }


    public static void main (String args[]) {
		// create the game object
  		GameTutorial g  = new GameTutorial(34, "YOUR_USER_ID", "YOUR_API_KEY");

		// start the game
		g.start();
    }
}
