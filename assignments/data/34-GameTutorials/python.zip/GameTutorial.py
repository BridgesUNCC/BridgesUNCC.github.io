from bridges import *

class GameTutorial (NonBlockingGame):
    def	 __init__(self, assid, user_id, api_key):
        # substitute your username and api key
        # create a game board of 10x10
        super().__init__(assid, user_id,  api_key, 10, 10)
        super(GameTutorial, self).set_title("Game Tutorials")
        super(GameTutorial, self).set_description("Upon a key press, display a different message!")

    def initialize(self):
        #TODO
        # this gets executed once
        # fill the board with a background color - use set_bg_color() method
        #TODO
        #draw symbols - HELLO on the board. Use the draw_symbol() method
        pass

    def	game_loop(self):
        # this gets executed every frame
        # TODO
        #This function is executed each frame of the game
        # use the input key methods to make a message appear and disappear
        # for instance, keyUp(), keyDown(), etc
        # use the drawSymbol() method to put symbols in the board
        # Put up a message  "SIGCSE 2020 BRIDGES Workshop" or something interesting
        pass

def	main():
    #put  in BRIDGES credentials
	game = GameTutorial(234, "BRIDGES_USER_ID", "BRIDGES_API_KEY")

	# start the game
	game.start()

if __name__ == '__main__':
	main()
