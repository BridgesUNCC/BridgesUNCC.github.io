#include <fstream>
#include <string>
#include <algorithm>
#include <sstream>
#include <vector>
#include "hurricane.h"

using namespace std;

Hurricane::Hurricane() {
    // TODO read a csv file line and set the initial values for this hurricane
}

double Hurricane::getLatitude() {
    return latitude;
}

double Hurricane::getLongitude() {
    return longitude;
}

int Hurricane::getCategory() {
    // TODO return category based on windspeed
}
