#ifndef HURRICANE_H
#define HURRICANE_H

#include <sstream>
#include <vector>
#include "Bridges.h"
#include "GraphAdjList.h"
#include "Color.h"

using namespace std;
using namespace bridges;

class Hurricane {
        double latitude;
        double longitude;
        double windSpeed;
    public:
        Hurricane(); // TODO Add paramaters as needed
        double getLatitude();
        double getLongitude();
        int getCategory();
};

#endif
