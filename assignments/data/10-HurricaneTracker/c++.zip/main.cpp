#include "hurricane.h"
#include "Bridges.h"

using namespace bridges;
using namespace std;

int main() {
  // Display img to bridges
  Bridges bridges(110, "BRIDGES_USER_ID", "BRIDGES_API_KEY");
  bridges.setTitle("Hurricane Tracker");
  bridges.setDescription("Hurricane location data from a csv file.");
  bridges.setMapOverlay(true);
  bridges.setCoordSystemType("equirectangular");

  // TODO Read data files and add points to GraphAdjList

  // set bridges data structure (will be a graph
  bridges.visualize();

  return 0;
}
