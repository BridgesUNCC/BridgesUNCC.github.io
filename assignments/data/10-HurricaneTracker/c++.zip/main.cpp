#include "hurricane.h"
#include "Bridges.h"

using namespace bridges;
using namespace std;

int main() {
    // Display img to bridges
    Bridges bridges(1, "user", "key");
    bridges.setTitle("Hurricane Tracker");
    bridges.setMapOverlay(true);
    bridges.setCoordSystemType("equirectangular");

    // TODO Read data files and add points to GraphAdjList

    bridges.visualize();

    return 0;
}
