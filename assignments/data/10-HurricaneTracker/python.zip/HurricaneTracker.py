from bridges import *
import string

# Read hurricane data from csv in the order
# DATE, TIME, LATITUDE, LONGITUDE, WIND, PRESSURE, TYPE, CATEGORY
class HurricaneData(object):
    def __init__(self, path):
        # TODO:
        # Read the data from path and convert it to a 2d array
        pass
    
    def data_length(self):
        # Return the lenght of the data array
        pass

    def get_latitude(self, index):
        # Return the latitude of the hurricane at index
        # Index refers to the line in the csv file
        pass

    def get_longitude(self, index):
        # Return the longitude of the hurricane at index
        # Index refers to the line in the csv file
        pass

    def get_category(self, index):
        # Return the category of the hurricane at index
        # Index refers to the line in the csv file
        pass
        

CATEGORY_COLOR = [
    [92, 244, 66, 200/255],
    [226, 244, 65, 200/255],
    [244, 220, 65, 200/255],
    [244, 169, 65, 200/255],
    [244, 127, 65, 200/255],
    [244, 65, 65, 200/255]
]

def diag_distance(x0, y0, x1, y1):
    """ Helper method gets the max distance between x's 
        of two points or y's of two points
    """
    return max(abs(x1 - x0), abs(y1 - y0))

def main():
    bridges = Bridges(210, "BRIDGES_USER_ID", "BRIDGES_API_KEY")
    bridges.set_map_overlay(True)
    bridges.set_coord_system_type("equirectangular")

    bridges.set_title("Hurricane Tracker")
    bridges.set_description("Hurricane location data from a csv file.")

    # TODO Create the HurricaneData constructor and create an instance

    # TODO
    # Create a graph adjacency list and set the vertex's to the lon/lat of the hurricane at each point
    # Then limit the number of points drawn by a certain distance on the map, whatever you feel looks good
    # Set the color of each vertex to the category color of the hurricane at that point using CATEGORY_COLOR
    # Connect the vertexes together based on time start -> end

    # TODO
    # Set the data structure for bridges to the graph

    bridges.visualize()
    
if __name__ == '__main__':
    main()
