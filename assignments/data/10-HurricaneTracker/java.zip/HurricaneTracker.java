import java.io.FileReader;
import java.io.IOException;
import java.io.BufferedReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import bridges.connect.Bridges;
import bridges.validation.RateLimitException;
import bridges.base.GraphAdjList;
import bridges.base.Color;

// Read hurricane data from csv in the order
// DATE, TIME, LATITUDE, LONGITUDE, WIND, PRESSURE, TYPE, CATEGORY
class HurricaneData {
	static public int[][] CATEGORY_COLOR = {
	      { 92, 244, 66 },
	      { 226, 244, 65 },
	      { 244, 220, 65 },
	      { 244, 169, 65 },
	      { 244, 127, 65 },
	      { 244, 65, 65 },
	};
	
	HurricaneData(String path) throws IOException {
		//TODO read the data from the csv file at path and store it in this class
	}
	
	public int dataLength() {
		return data.size();
	}
	
	public float getLatitude(int index) {
		// TODO return the latitude of the hurricane at index
	}
	
	public float getLongitude(int index) {
		// TODO return the longitude of the hurricane at index
	}
	
	public int getCategory(int index) {
		// TODO return the category of the hurricane at index
	}
}

public class HurricaneTracker {

	// Helper method gets the max distance between x's 
	// of two points or y's of two points
	static private float diag_distance(float x0, float y0, float x1, float y1) {
	    return Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0));
	}
	    		
	public static void main(String[] args) throws IOException, RateLimitException {
		Bridges bridges = new Bridges(15, "user", "auth");
		bridges.setTitle("Hurricane Tracker");
		bridges.setMapOverlay(true);
		bridges.setCoordSystemType("equirectangular");
		
		// TODO Create a hurricane data object from a hurricane csv file
		
		// TODO loop through the hurricanes points and add them to a GraphAdjList
		// set the points color to the category color provided by the HurricaneData class
		// Add an edge between each point in chronological order
		
		// TODO set the datastructure to the GraphAdjList and visualize to bridges
	}
}
