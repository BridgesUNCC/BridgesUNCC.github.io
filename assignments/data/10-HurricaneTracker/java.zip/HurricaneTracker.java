import java.io.FileReader;
import java.io.IOException;
import java.io.BufferedReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import bridges.connect.Bridges;
import bridges.validation.RateLimitException;
import bridges.base.GraphAdjListSimple;
import bridges.base.Color;

// Read hurricane data from csv in the order
// DATE, TIME, LATITUDE, LONGITUDE, WIND, PRESSURE, TYPE, CATEGORY
class HurricaneData {
  static public int[][] CATEGORY_COLOR = {
    { 92, 244, 66 },
    { 226, 244, 65 },
    { 244, 220, 65 },
    { 244, 169, 65 },
    { 244, 127, 65 },
    { 244, 65, 65 },
  };

  HurricaneData(String path) throws IOException {
    //TODO read the data from the csv file at path and store it in this class
  }

  public int dataLength() {
    // TODO return data size

    return 0;
  }

  public float getLatitude(int index) {
    // TODO return the latitude of the hurricane at index

    return 0.0f;
  }

  public float getLongitude(int index) {
    // TODO return the longitude of the hurricane at index
    return 0.0f;
  }

  public int getCategory(int index) {
    // TODO return the category of the hurricane at index
    return 0;
  }
}

public class HurricaneTracker {

  // Helper method gets the max distance between x's
  // of two points or y's of two points
  static private float diag_distance(float x0, float y0, float x1, float y1) {
    return Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0));
  }

  public static void main(String[] args) throws IOException, RateLimitException {
    Bridges bridges = new Bridges(10, "BRIDGES_USER_ID", "BRIDGES_API_KEY");
    bridges.setTitle("Hurricane Tracker");
    bridges.setDescription("Hurricane location data from a csv file.");
    bridges.setMapOverlay(true);
    bridges.setCoordSystemType("equirectangular");

    // create a graph object
    GraphAdjListSimple<Integer> g = new GraphAdjListSimple<Integer>();

    // TODO Create a hurricane data object from a hurricane csv file

    // TODO loop through the hurricanes points and add them to a GraphAdjListSimple object
    // set the points color to the category color provided by the HurricaneData class
    // Add an edge between each point in chronological order
    // Set the size of the points

    // TODO set the datastructure to the GraphAdjListSimple and visualize using bridges
    bridges.setDataStructure (g);
    bridges.visualize();
  }
}
