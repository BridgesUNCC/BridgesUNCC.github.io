#include "NonBlockingGame.h"

using namespace bridges::game;

class RaceCar : public NonBlockingGame {
  public:
    RaceCar(int assignmentID, std::string username, std::string apikey)
      : NonBlockingGame(assignmentID, username, apikey, 30, 30) {}

    virtual void initialize() override {
      // Set a seed based on the current time
      srand(time(NULL));

      setTitle("Race Car");
      setDescription("");

      // TODO:
      // Set the initial car and road positions
    }

    void handleInput() {
      // TODO:
      // Move the car left and right on input
    }

    void checkCollision() {
      // TODO:
      // If the car collides with either wall end the game
    }

    void moveRoad() {
      // TODO:
      // Move the road left and right so that the player
      // has to move the car to stay on the road
    }

    void draw() {
      // TODO:
      // Draw the background, road, and car
    }

    virtual void gameLoop() override {
      handleInput();
      checkCollision();
      moveRoad();
      checkCollision();
      draw();
    }

};

int main() {
  RaceCar nbg(121, "BRIDGES_USER_ID", "BRIDGES_API_KEY");

  nbg.start();

  return 0;
}
