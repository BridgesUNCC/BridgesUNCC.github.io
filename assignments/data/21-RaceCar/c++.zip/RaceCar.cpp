#include "NonBlockingGame.h"

using namespace bridges::game;

class RaceCar : public NonBlockingGame {
public:
	RaceCar(int assignmentID, std::string username, std::string apikey)
		: NonBlockingGame(assignmentID, username, apikey, 30, 30) {}

	virtual void initialize() override {
        // Set a seed based on the current time
        srand(time(NULL));

        setTitle("Race Car");
    }

    void handleInput() {
    }

    void checkCollision() {
    }

    void die() {
        exit(0);
    }

    void moveRoad() {
    }

    void draw() {
    }

    virtual void gameLoop() override {
		handleInput();
        checkCollision();
        moveRoad();
        checkCollision();
        draw();
	}

};

int main() {
    RaceCar nbg(21, "user", "auth");

	nbg.start();

    return 0;
}