package STUDENT_PACKAGE;

import bridges.base.NamedColor;
import bridges.base.NamedSymbol;
import bridges.games.NonBlockingGame;

class STUDENT_CLASS_NAME extends NonBlockingGame {

    static int gridCol = 30;
    static int gridRow = 30;


    public STUDENT_CLASS_NAME(int assid, String login, String apiKey, int c, int r) {
        super(assid, login, apiKey, c, r);
        // start running the game
        start();
    }

    public void initialize() {

    }

    public void handleInput() {

    }

    public void die() {
        System.exit(0);
    }

    public void checkCollision() {

    }

    public void paintScreen() {

    }

    private void moveRoad() {

    }

    public void gameLoop() {
        handleInput();

        checkCollision();

        moveRoad();

        checkCollision();

        paintScreen();
    }

    public static void main(String[] args) throws Exception {
        STUDENT_CLASS_NAME game = new STUDENT_CLASS_NAME(ASSIGNMENT_NUMBER, "Bridges_Username", "Profile_APIKey", gridCol, gridRow);
    }

}