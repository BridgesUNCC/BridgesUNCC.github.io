import bridges.base.NamedColor;
import bridges.base.NamedSymbol;
import bridges.games.NonBlockingGame;

class Racecar extends NonBlockingGame {

  static int gridCol = 30;
  static int gridRow = 30;


  public Racecar(int assid, String login, String apiKey, int c, int r) {
    super(assid, login, apiKey, c, r);
    // start running the game
    start();
  }

  public void initialize() {
    // TODO:
    // Set the initial car and road positions
  }

  public void handleInput() {
    // TODO:
    // Move the car left and right on input
  }

  public void die() {
    System.exit(0);
  }

  public void checkCollision() {
    // TODO:
    // If the car collides with either wall end the game
  }

  public void paintScreen() {
    // TODO:
    // Draw the background, road, and car
  }

  private void moveRoad() {
    // TODO:
    // Move the road left and right so that the player
    // has to move the car to stay on the road
  }

  public void gameLoop() {
    handleInput();
    checkCollision();
    moveRoad();
    checkCollision();
    paintScreen();
  }

  public static void main(String[] args) throws Exception {
    Racecar game = new Racecar(21, "BRIDGES_USER_ID", "BRIDGES_API_KEY", gridCol, gridRow);
  }

}
