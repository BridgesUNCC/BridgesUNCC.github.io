from bridges import *

import random
from datetime import datetime

class RaceCar(NonBlockingGame):
    def __init__(self, assid, login, apikey):
        super(RaceCar, self).__init__(assid, login, apikey, 30, 30)
    
    def initialize(self):
        random.seed(datetime.now())
        self.set_title("Race Car")

        # Do any initial setup here

    def draw(self):
        # Draw the board, should include a car, road, and obsticles

    def handle_input(self):
        # Take user input and move the car

    def game_loop(self):
        self.handle_input()
        # Handle game logic here
        self.draw()

def main():
    game = RaceCar(ASSIGNMENT_NUMBER, "BRIDGES_USER_ID", "BRIDGES_API_KEY")

    # Start the game
    game.start()

if __name__ == '__main__':
    main()