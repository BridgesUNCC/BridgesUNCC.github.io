from bridges import *

import random
from datetime import datetime

class RaceCar(NonBlockingGame):
    def __init__(self, assid, login, apikey):
        super(RaceCar, self).__init__(assid, login, apikey, 30, 30)
    
    def initialize(self):
        random.seed(time.time())
        self.set_title("Race Car")
        self.set_description("")

        # TODO:
        # Set the initial car and road positions
        pass

    def draw(self):
        # TODO:
        # Draw the background, road, and car
        pass

    def handle_input(self):
        # TODO:
        # Move the car left and right on input
        pass

    def move_road(self):
        # TODO:
        # Move the road left and right so that the player
        # has to move the car to stay on the road
        pass

    def game_loop(self):
        self.handle_input()
        # Handle game logic here
        self.draw()

def main():
    game = RaceCar(221, "BRIDGES_USER_ID", "BRIDGES_API_KEY")

    # Start the game
    game.start()

if __name__ == '__main__':
    main()
