import java.util.List;

// Import Bridges and relevant data source 
import bridges.connect.Bridges;
import bridges.base.SLelement;
import bridges.data_src_dependent.ActorMovieIMDB;
import bridges.connect.DataSource;

//
// This example illustrates how to access the IMDB dataset of actors and movies
// 
public class ListIMDB {

	public static void main(String[] args) throws Exception {

		// Initialize a Bridges connection with your credentials 
		Bridges bridges = new Bridges(1, "kalpathi60", "486749122386");

		//	 Set an assignment title 
		bridges.setTitle("ListIMDB Example");

		// TODO:  access teh IMDB dataset - use the data source object within BRIDGES and call
		// its getActorMovieIMDBData() method 
		// this will return a list (vector) of actor-movie objects of type 
		// ActorMovieIMDB - refer to the docs for that object and its attributes


		// TODO: build a linked list, using singly linked list elements, 
		//	SLElement<ActorMovieIMDB>
		// where the actormovie object is a generic parameter that 
		// iterate through the vector and put each of the actor movie names into the label
		// field of the SLelement (using the setLabel() method of the element) - 
		//  this will show up in the visualization when you do a moouse  over the node

		// head of the list
		SLelement<ActorMovieIMDB> head = null;

		//	 Pass the head of the list to Bridges 
		bridges.setDataStructure(head);

		//	 Visualize the list 
		bridges.visualize();
	}
}
