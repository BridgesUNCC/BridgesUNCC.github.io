from bridges import *

def main():
    #create the Bridges object, set credentials
    bridges = Bridges(1, "user", "password")

    bridges.set_title("List IMDB")

    data = get_actor_movie_imdb_data()

    for d in data:
        print("%s %s" % (d.get_actor(), d.get_movie()))

    # Set up a prev and head elemen
    # TODO: Build a list of all actor movie pair
    head = SLelement()
    sec = SLelement()
    head.set_value(0)
    head.set_label("First")
    sec.set_value(1)
    sec.set_label("Second")
    head.set_next(sec)

    # tell Bridges what data structure to visualize
    bridges.set_data_structure(head)

    # visualize the list
    bridges.visualize()

if __name__ == '__main__':
    main()