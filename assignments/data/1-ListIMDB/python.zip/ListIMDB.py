from bridges import *

def main():
    # Create the Bridges object, set the user credentials
    bridges = Bridges(201, "BRIDGES_USER_ID", "BRIDGES_API_KEY")

    bridges.set_title("List IMDB")
    bridges.set_description("Create a linked list of elements that hold pairs of (Actor, Movie) data")
    
    # TODO:  get the IMDB data set using the DataSource object and then call
    #  its get_actor_movie_imdb_data() method; this will return a list of
    #  actor movie objects of type ActorMovieIMDB (refer to the docs for details)

    # TODO: Populate a linked list of all actor movie pair using SLelement object
    # Make each element's label a concatination of the Actor and Movie
    # use the set_label() method of the element 

    # Tell Bridges what data structure to visualize
    bridges.set_data_structure(head)

    # Visualize the linked list
    bridges.visualize()

if __name__ == '__main__':
    main()
