#include "Bridges.h"
#include "DataSource.h"
#include "Array.h"
#include "SLelement.h"


using namespace bridges;

int main() {

	//create the Bridges object, set credentials
	Bridges bridges(1, "bridges_workshop", "1298385986627");
	
	bridges.setTitle("List IMDB");

	DataSource ds;
	std::vector< ActorMovieIMDB > ami = ds.getActorMovieIMDBData(10);

	// Printing actor movie pairs for debugging purposes
	for (auto im : ami) {
	  std::cout<<im.getActor()<< " - "<< im.getMovie()<<std::endl;
	}
	
	//building linked list
	/*TODO: make a linked list with all movie actor pair */
	SLelement<int>* head = new SLelement<int> (0, "First");
	SLelement<int>* sec = new SLelement<int> (1, "Second");

	head->setNext(sec);
	
	// tell Bridges what data structure to visualize
	bridges.setDataStructure(head);

	// visualize the list
	bridges.visualize();

	//free memory
	delete head;
	delete sec;
	
	return 0;
}
