#include "Bridges.h"
#include <queue>
#include "Note.cpp"
#include <iostream>
#include <fstream>
#include <cstring>
#include <string>

using namespace bridges;
using namespace std;

/**
 * loads the song from the file
*/
queue<Note> loadSong(string file_name) {
    queue<Note> song;

	// read input song notes from file and store it in 
	// vector of song notes

	// if the pitch symbol is a repeat then the following notes must
	// be repeated until teh flag is turned off


    ifstream infile (file_name);
	vector<Note> song_notes;

	infile.close();

	// add to queue
	for (auto& n: song_notes) 
		song.push(n);
    return song;
}

int main(){
    Bridges bridges(1, "BRIDGES_USER_ID", "BRIDGES_API_KEY");
    bridges.setTitle("Music Notes");
    bridges.setDescription("This assignment is a good introduction to queues, as well as reading from a file.");
     queue<Note> song = loadSong("../music/TwinkleTwinkleLittleStar.txt");
    // queue<Note> song = loadSong("../music/happybirthday.txt");

    float LENGTH = 0;
    int SAMPLE_FREQ = 44100;

	// get the total length of the sequence by adding up the #samples from
	// each song note -- check  the Note class that keeps the length


	// sample count is length * sample freq (44100)
    int SAMPLE_COUNT = (int) (LENGTH*SAMPLE_FREQ); 

	// create audio clip at the sample frequency
    bridges::AudioClip ac(SAMPLE_COUNT, 1, 32, SAMPLE_FREQ);

    double start = 0;

	// add each note to the audio clip
	// must specify the starting point for each point in the samples
	/// use addToClip() method

    bridges.setDataStructure(ac);
    bridges.visualize();
}
