#include "AudioClip.h"
#include <math.h>       /* pow */
#include <cstring>
#include <limits>
#include <iostream>

using namespace std;
using namespace bridges;

//
// This class handles everything relating to the song notes
//
class Note {
	private:
		char pitch_symbol; 
		double length;
		int octave;
		string  accidental_val;
		unordered_map<char, double> pitch_freq;

		// gets the frequency from the pitch, accidental value and octave
		double getFrequency() {
			int v = ((int) (pitch_freq[pitch_symbol]))/100;	
			if (accidental_val == "NATURAL") 
				return  v*pow(2, octave);
			else if (accidental_val == "FLAT") 
				return (v - 1) * pow(2, octave);
			else if (accidental_val == "SHARP")
				return (v + 1) * pow(2, octave);
			else return 0.0;
		}

    public:
		Note() {
		 length = 0.; pitch_symbol = '\0'; octave = 0; accidental_val = ""; 
		}

        Note(double length, char pitch_symb, int octave, string 
								accidental_val) {
			Note::length = length;
			Note::pitch_symbol = pitch_symb;
			Note::octave = octave;
			Note::accidental_val = accidental_val;
			
			// load the pitch freq map
			pitch_freq['C'] = 1635.;
			pitch_freq['D'] = 1835.;
			pitch_freq['E'] = 2060.;
			pitch_freq['F'] = 2183.;
			pitch_freq['G'] = 2450.;
			pitch_freq['A'] = 2750.;
			pitch_freq['B'] = 3087.;
			pitch_freq['R'] = 0.;
		}

		double getLength() {
			return length;
		}

        // Add the note to an audio clip using the frequency  values
		void addToClip(AudioClip& ac, double start, double volume){
			double amplitudeMultiplier = ((pow(2,32)/2.0)-1.0)*volume;
			double frequency = getFrequency();
			double period = ac.getSampleRate()/frequency;
			double end = start + length;
			int firstSample = (int)(start * ac.getSampleRate());
			int lastSample = (int)(end * ac.getSampleRate()) - 1;
			for (int i = firstSample; i < lastSample; i++){
				double time = (double)i/ac.getSampleRate();
				// check if freq is zero -- could be a rest period
				int sampleValue = 0;
				if (frequency) {
					// generate a sine sample
					double val = sin((2*M_PI) * frequency * time);
					sampleValue = (int) (val * amplitudeMultiplier);
				}
				// add sample to clip
				ac.setSample(0, i, sampleValue);
			}

			//Last sample should always be 0 to prevent popping noises
			lastSample = (int) (period * floor(lastSample/period));
			ac.setSample(0, (int) (end*ac.getSampleRate()), lastSample);
		}
};
