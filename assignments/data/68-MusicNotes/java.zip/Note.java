import bridges.base.AudioClip;

/**
 * The Note Class is a helper class provided by bridges, this class handles all the math and music theory behind
 * turning notes into a bridges audio clip
 */
public class Note {
    /**
     * This Enum is for notes, and has a getHZ method which figures out what hz the sine wave needs to be to recreate the note
     */
    public enum NoteFreq{
        C(16.35),
        D(18.35),
        E(20.60),
        F(21.83),
        G(24.50),
        A(27.50),
        B(30.87),
        R(0); // Rest

        private double Hz;

        /**
         * gets the HZ from one of the enum values
         * @param octave which octave the note should be in
         * @param accidental Sharp, Natural, or Flat
         * @return HZ for the note with those characteristics
         */
        public double getHz(int octave, Accidental accidental){
            switch (accidental){
                case NATURAL:
                    return Hz * Math.pow(2, octave); // every octave doubles the HZ of the previous one
                case FLAT:
                    return (Hz - 1) * Math.pow(2, octave); // Flat is ~1 HZ less in octave 0
                case SHARP:
                    return (Hz + 1) * Math.pow(2, octave); // Sharp is ~1 HZ more in octave 0
                default:
                    return 0;
            }

        }

        NoteFreq(double Hz) {
            this.Hz = Hz;
        }
    }

    /**
     * another ENUM to distinguish Sharp, Natural and FLat
     */
    public enum Accidental{
        NATURAL,
        SHARP,
        FLAT
    }
    final private NoteFreq note;
    final private double length;
    final private int octave;
    final private Accidental accidental;
    final private boolean repeat;

    /**
     * Construct a Note
     * @param length duration of the note in seconds
     * @param note which musical note
     * @param octave which octave
     * @param accidental SHARP, NATURAL, or FLAT
     * @param repeat doesn't do anything right now, but is needed to match NIFTY songs
     */
    public Note(double length, NoteFreq note, int octave, Accidental accidental, boolean repeat) {
        this.note = note;
        this.length = length;
        this.repeat = repeat;
        this.octave = octave;
        this.accidental = accidental;
    }

    /**
     *
     * @return the HZ value for the note
     */
    private double getHz(){
        return note.getHz(octave, accidental);
    }

    /**
     *
     * @return length in seconds
     */
    public double getLength() {
        return length;
    }

    /**
     * given a time value, get what the value of the sine wave is
     * @param amplitude of the sine wave
     * @param time the time to sample
     * @return height of a sine wave of the amplitude at the time
     */
    private int generateSineSample(double amplitude, double time){
        double frequency = getHz();
        double val = Math.sin((2 * Math.PI)  * frequency * time);
        // Scales it by the amplitude value
        return (int) (val * amplitude);
    }

    /**
     * a method to add the note to an audio clip
     * @param ac the audio clip to add to
     * @param start where in the audio clip to start
     * @param volume how loud to play this note
     */
    public void addToClip(AudioClip ac, double start, double volume){
        double amplitudeMultiplier = ((Math.pow(2, 32) / 2.0) - 1.0)*volume; // this scales volume from a 0-1, to an amplitude
        double frequency = getHz();
        double period = ac.getSampleRate() / frequency;
        double end = start + length;
        int firstSample = (int)(start * ac.getSampleRate());
        int lastSample = (int)(end * ac.getSampleRate()) - 1;

        for (int i = firstSample; i < lastSample; i++) {

            // The current second (with decimals) of the clip
            double time = (double)i / ac.getSampleRate();
            int sampleValue = generateSineSample(amplitudeMultiplier, time);
            // Set the sample at i to the new value
            ac.setSample(0, i, sampleValue);
        }
        lastSample = (int) (period * (Math.floor(lastSample/period)));
        // setting the last sample to 0 prevents the interface popping
        ac.setSample(0, (int) (end*ac.getSampleRate()), lastSample);
    }
}