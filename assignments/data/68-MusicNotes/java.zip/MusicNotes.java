import bridges.connect.Bridges;
import bridges.base.AudioClip;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.concurrent.ArrayBlockingQueue;

/**
 * This is the music note class, this handles loading the song and the bridges visualization
 */
public class MusicNotes {

    /**
     * This iterates through a song file and adds the notes to the queue
     * @return returns a queue of type Note (this is the song loaded from the file)
     */
    public static ArrayBlockingQueue<Note> loadSong(){
        /*
         * This Method has two important components:
         * a) reads from the file
         * b) creates Notes and enqueues the note onto the song
         */

        // We use an Array Based Blocking Queue because it fits the requirements of a song the best
        // Array Based <=> allows for easier conversion between this and the array based version of the assignment can be switched with very minor changes
        ArrayBlockingQueue<Note> song = new ArrayBlockingQueue<Note>(100);


        /*
        Student Code goes here

        Student code will:
            * Open A File (some example files bundled with assignment)
            * Initialize a Scanner on the file
            * Loop over every line
            * read in the duration and the pitch
                * if the pitch is a rest
                    * fill the octave and accidental in
                    * get the repeat boolean
                * else
                    * get the octave
                    * get the accidental value
                    * get the boolean repeat
        Hint 1: you will need to wrap opening the file in a try catch block
        Hint 1.5: you only want to catch FileNotFoundExceptions... anything else will result in it hiding valuable info
        Hint 2: you can use .valueOf for an enum to compare text to enum values
        Hint 3: you might want to use absolute paths if java is not able to find a file
        Hint 4: you will find the .hasNextLine() method of a scanner to be super beneficial

        */
        return song;
    }

    public static void main(String[] args) throws Exception{
        // create the Bridges object, set credentials
        Bridges bridges = new Bridges(55, "BRIDGES_USER_ID", "BRIDGES_API_KEY");
        bridges.setTitle("FreqPlayer");
        bridges.setDescription("This assignment is a good introduction to queues, as well as reading from a file.");
        //create our song array by calling the load song method
        ArrayBlockingQueue<Note> song = loadSong();

        final int SAMPLE_FREQ = 44100;
        // Length of the clip in seconds
        float LENGTH = 0;

        // student work

        /*
            In order to make a Bridges Audio Clip, we need to figure out how long its going to be

            We can do this by iterating through the queue and using the .getLength() method on our note

            Hint 1: adding one to the end will prevent some errors later on
         */

        // end student work

        // calculates the number of samples based on the length calculated above
        final int SAMPLE_COUNT = (int) (LENGTH*SAMPLE_FREQ);
        // creates the bridges AudioClip
        AudioClip ac = new AudioClip(SAMPLE_COUNT, 1, 32, SAMPLE_FREQ);


        //student work

        /*
            We need to add every note to the audio clip
            Thankfully, the Note class has a super handy method to handle this, .addToClip()
            this method takes the audio clip we are adding it to, the seconds into the clip it starts, and a volume

            Hint 1:
                We want to iterate over the notes in the song again
            Hint 2:
                Using an additional variable to keep track of where to start will help
            Hint 3:
                you can use the getLength method again
         */

        // end student work

        bridges.setDataStructure(ac);
        bridges.visualize();
    }
}
