from bridges import Bridges, AudioClip

from note import Note

from queue import Queue

def loadSong() -> Queue:
    """Loads a song from a file

    Returns:
        Queue: a queue of notes
    """
    song = Queue()
    repeat = Queue()
    
    """Student Code here

        it needs to:
            * Open a file with a song, bridges packages some song files with this assignment
            * for each line in the file, make a Note and add it to the song queue
            * return the queue
        
        helpful hints:
            dont forget to look through the Note class, there are lots of helpful functions in there (like ValueOf()) that will make this much easier 
    """
    
    return song

if __name__ == '__main__':
    #run only when this file is directly run
    
    #create a bridges instance
    bridges = Bridges(268, "BRIDGES_USER_ID", "BRIDGES_API_KEY")
    bridges.set_title("Music Notes")
    bridges.set_description("This assignment is a good introduction to queues, as well as reading from a file.")
    
    #load the song
    song = loadSong()
    
    #defining a sample frequency
    SAMPLE_FREQ = 44100
    
    length = 0

    """Student Code Here:
        It needs to;
            - figure out the total length and put it in the length variable

        Hint:
            - How do you iterate over a queue? 
    """
    
    #total samples
    SAMPLE_COUNT = int(length*SAMPLE_FREQ)
    
    #create an audio clip with desiered attributes
    ac = AudioClip(sample_count=SAMPLE_COUNT, num_channels=1, sample_bits=32, sample_rate=SAMPLE_FREQ)
    
    start = 0
    
    """TODO: Student Code Here
        code should
            itterate over the queue and add the note to the audio clip
    """
    
    #visualize
    bridges.set_data_structure(ac)
    bridges.visualize()
    
