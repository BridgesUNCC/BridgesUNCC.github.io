import bridges.games.NonBlockingGame;
import bridges.base.NamedColor;
import bridges.base.NamedSymbol;

//
// this is the classic bug stomping game implemented in BRIDGES
//
public class BugStomp extends NonBlockingGame {

    int[] loc = {0, 0}; // row, col
    static int[] boardSize = {20, 20};
    int[] bug;
    int bugttl = 100;
    int score = 0;
    NamedColor bugColor;

    static java.util.Random randomizer;

    public static void main(String args[]) {
        // Initialize our nonblocking game
        BugStomp  mg = new BugStomp(ASSIGNMENT_NUMBER, "BRIDGES_USER_ID", "BRIDGES_API_KEY", boardSize[0], boardSize[1]);
    }

	// constructor - setting up Bridges credentials, grid size
    public BugStomp(int assid, String login, String apiKey, int c, int r) {
        super(assid, login, apiKey, c, r);

        // Give a title and description of your game.
        setTitle("BUG STOMP");
        setDescription("Use the arrow keys to move the person over the bugs - don't let them escape!");

        // start running the game
        start();
    }

	// initialize board, create a bug object (which is its position), color 
	//  	-- see symbol shapes for that
	// use random position for bug each time
    public void initialize() {
    }

	// movement of the player (human) - UI using arrow keys 
	// make sure to check for edge cases
    public void handleInput() {
    }

	// move bug after a set interval (#frames) if it has not been squashed
    // check for stomp
    public void handlebug() {
    }

	// check if the bug is squashed
    public Boolean overlap(int[] bug, int[] loc) {
		return true;
    }

	// redraw the screen with updated positions of players,
	// check and paint current score on the screen
	// if win, then paint the winner on screen
    public void paintScreen() {
    }

	// paint a win message - use the alphabetic symbols
    public void win() {
	}

	
	// write  current score on screen
    public void paintScore(int score) {
    }

	// game loop, update bug, player input, 
	// check if game ended, else redraw
    public void gameLoop() {
        if (score >= 10) {
            System.exit(0);
        }
        handlebug();
        handleInput();
        paintScreen();
	}
}

