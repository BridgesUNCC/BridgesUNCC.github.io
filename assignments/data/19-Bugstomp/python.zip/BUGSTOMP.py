import random

from bridges import *


class BugStomp(NonBlockingGame):
    # player, bug locations, board size
    loc = [2, 2]
    boardSize = [30, 30]
    bug = [5, 5]
    bugtt = 100
    score = 0
    bugColor = NamedColor.green
    randomNumber = random.randrange(1, 10, 1)
    my_game = 10

    # this runs exactly once
    def initialize(self):
        pass

    # player navigation
    def handle_input(self):
        pass

    # check for overlap between player and bug
    def overlap(self):
        return True

    #update bug lifetime, score, check edge cases
    def handle_bug(self):
        pass

    # write a winning message on board, using the supported symbols
    def win(self):
        pass

    def print_score(self):
        pass

    # redraw method
    def print_screen(self):
        pass

    # this method runs continuously
    def game_loop(self):
        self.handle_input()
        self.handle_bug()
        self.print_screen()

    def __init__(self, assid, login, apikey, cols, rows):
        super(BugStomp, self).__init__(assid, login, apikey, cols, rows)
        self.boardSize[0] = cols
        self.boardSize[1] = rows


def main():
    my_game = BugStomp(219, "BRIDGES_USER_ID", "BRIDGES_API_KEY", 30, 30)

    my_game.set_title("BUG STOMP")
    my_game.set_description("Use the arrow keys to move the person over the bugs - don't let them escape!")
    
    my_game.start()


if __name__ == '__main__':
    main()
