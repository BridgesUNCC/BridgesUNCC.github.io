import random

from bridges import *


class StudentClass(NonBlockingGame):
    loc = [0, 0]
    boardSize = [30, 30]
    bug = [5, 5]
    bugtt = 100
    score = 0
    bugColor = NamedColor.green
    randomNumber = random.randrange(1, 10, 1)
    my_game = 10

    def initialize(self):
        self.randomNumber = random.randrange(0, self.boardSize[0], 1)
        self.bugColor = random.choice(list(NamedColor.class_method))

        for i in range(self.boardSize[0]):
            for j in range(self.boardSize[1]):
                self.set_bg_color(i, j, NamedColor.white)
                self.draw_object(i, j, NamedSymbol.none, NamedColor.white)

        self.bug = {(random.randrange(0, self.boardSize[0] - 1, 1)), (random.randrange(0, self.boardSize[1] - 1) + 1)}

    def handle_input(self):
        if self.key_left():
            

        if self.key_right():
            

        if self.key_up():
            self.loc[0] = self.loc[0] - 1

        if self.key_down():
            self.loc[0] = self.loc[0] + 1

        if self.loc[0] < 1:
            

        if self.loc[0] > self.boardSize[0] - 1:
            

        if self.loc[1] < 0:
            

        if self.loc[1] > self.boardSize[1] - 1:
            

    def overlap(self):
        

    def handle_bug(self):
        

    def win(self):
        

    def print_score(self):
        

    def print_screen(self):
        for i in range(self.boardSize[0]):
            for j in range(self.boardSize[1]):
                self.set_bg_color(i, j, NamedColor.black)
                self.draw_object(i, j, NamedSymbol.none, NamedColor.white)

        self.draw_object(self.bug[0], self.bug[1], NamedSymbol.bug3, self.bugColor)

        self.draw_object(self.loc[0], self.loc[1], NamedSymbol.man, NamedColor.white)

    def game_loop(self):
        

    def __init__(self, assid, login, apikey, cols, rows):
        super(StudentClass, self).__init__(assid, login, apikey, cols, rows)
        self.boardSize[0] = cols
        self.boardSize[1] = rows


def main():
    my_game = StudentClass(80, "STUDENT_USERNAME", "STUDENT_API_KEY", 30, 30)
    my_game.start()


if __name__ == '__main__':
    main()
