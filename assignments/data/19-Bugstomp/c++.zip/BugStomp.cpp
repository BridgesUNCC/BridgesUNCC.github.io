#include <NonBlockingGame.h>
#include <iostream>
#include <time.h>

using namespace bridges::game;
using namespace std;

//
// this is the classic bug stomping game implemented in BRIDGES
//

struct my_game : public NonBlockingGame {
  // set up needed variables (bug position, bug interval to move positions, score

  // constructor - setting up Bridges credentials, grid size
  my_game(int assID, std::string username, std::string apikey)
    : NonBlockingGame (0, username, apikey, 20, 20) {
  }

  // initialize board, create a bug object -- see symbol shapes for that
  // use random positions for bug
  virtual void initialize() override {
  }

  // movement of the player (human) - UI using arrow keys
  // handle edge cases
  void handleInput() {
  }

  // game loop, update bug, player input, redraw
  // check if game is over
  virtual void gameLoop() override {
  }

  // move bug after a set interval if it has not been squashed
  // check for stomp
  void handleBug() {
  }

  // check for squashing the bug
  bool overlap(int * bug, int * loc) {
  }

  // check for win, redraw
  void paintScreen() {
  }

  // write a winning message on the screen
  void win() {
  }
};

// Initialize your game
// Call your game class with your assignment id, username, and api key
int main (int argc, char** argv) {
  my_game g(119, "BRIDGES_USER_ID", "BRIDGES_API_KEY");

  g.start();
}
