struct Goal {
    int xLoc;
    int yLoc;
    
    void initialize(int xLoc, int yLoc){
        this -> xLoc = xLoc;
        this -> yLoc = yLoc;
    }
};