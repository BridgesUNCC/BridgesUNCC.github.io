struct Level {
    std::array<std::array<bool, 15>, 15> obstacleLocations;
    bool doObstaclesMove;
    
    void initialize(std::array<std::array<bool, 15>, 15> obstacleLocations, bool doObstaclesMove){
        this -> obstacleLocations = obstacleLocations;
        this -> doObstaclesMove = doObstaclesMove;
    }
};