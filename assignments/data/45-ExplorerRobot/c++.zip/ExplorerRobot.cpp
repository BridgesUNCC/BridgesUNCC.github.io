#include <vector>
#include <Bridges.h>
#include <NonBlockingGame.h>
#include "Goal.cpp"
#include "Level.cpp"
#include "Robot.cpp"

using namespace bridges::game;

struct ExplorerRobot : public NonBlockingGame {
    Level level = Level();
    Goal goal = Goal();
    Robot robot = Robot();
    int obstacleMoveDelay;
    
    // TODO: Declare any variables you need here
    
    ExplorerRobot(int assID, std::string username, std::string apikey, int cols, int rows)
        : NonBlockingGame (assID, username, apikey, cols, rows) {
            setTitle("Explorer Robot");
            setDescription("An assignment where you make a virtual robot explore its environment");
    }
    
    virtual void initialize() override {
        generateBoardBackground();
        // TODO: Select the level you'd like to attempt by changing the integer passed to this function.
        selectLevel(0);
    }
    
    virtual void gameLoop() override {
        // Redraws the board to match the intended state
        // This happens once every time the code loops, but you can call this function more if you want.
        redrawBoard();
        // Checks for collision between obstacles and the robot, and the goal and the robot
        checkCollision();
        moveObstacles();
        
        // TODO: Create the code to make the robot move below this comment
        // (0,0) is at the top left corner; (15,15) is at the bottom right.
        // level.obstacleLocations is used by checking [y][x] in that order
        
        
    }
    
    // Clears the board, then redraws it appropriately
    public: void redrawBoard() {
        // Clear the board
        for (int i = 0; i < this -> getBoardHeight(); i++){
            for (int j = 0; j < this -> getBoardWidth(); j++){
                drawSymbol(i, j, NamedSymbol::none, NamedColor::blueviolet);
            }
        }
        
        // Place the player sprite at the location indicated by playerX and playerY
        drawSymbol(robot.yLoc, robot.xLoc, NamedSymbol::astro_helmet, NamedColor::blueviolet);
        
        for(int i = 0; i < level.obstacleLocations.size(); i++){
            for (int j = 0; j < level.obstacleLocations[0].size(); j++){
                if (level.obstacleLocations[i][j]) {
                    drawSymbol(i, j, NamedSymbol::square, NamedColor::brown);
                }
            }
        }
        
        drawSymbol(goal.yLoc, goal.xLoc, NamedSymbol::flag, NamedColor::green);
    
    }
    
    public: void generateBoardBackground(){
        for (int i = 0; i < this -> getBoardHeight(); i++){
            for (int j = 0; j < this -> getBoardWidth(); j++){
                // Make a checkerboard pattern
                if ((i + j) % 2 == 0) {
                    setBGColor(i, j, NamedColor::darkgray);
                } else {
                    setBGColor(i, j, NamedColor::lightgray);
                }
            }
        }
    }
    
    public: void selectLevel(int levelNum){
        std::array<std::array<bool, 15>, 15> levelArray = {{{false}}};
        switch(levelNum){
            case 0: default:
                robot.initialize(7, 7);
                goal.initialize(9, 4);
                for (int i = 0; i < this -> getBoardHeight(); i++){
                    for (int j = 0; j < this -> getBoardWidth(); j++){
                        levelArray[i][j] = false;
                    }
                }
                level.initialize(levelArray, false);
                break;
            case 1:
                robot.initialize(7, 10);
                goal.initialize(7, 4);
                levelArray[8][7] = true;
                level.initialize(levelArray, false);
                break;
            case 2:
                robot.initialize(7, 4);
                goal.initialize(3, 12);
                levelArray[8][7] = true;
                levelArray[7][9] = true;
                levelArray[5][6] = true;
                levelArray[6][4] = true;
                levelArray[9][3] = true;
                levelArray[10][5] = true;
                levelArray[11][4] = true;
                level.initialize(levelArray, true);
                break;
        }
    }
    
    /**
     * Checks to see if the robot is in the same place as any obstacle. If it is, ends the game
     */
    public: void checkCollision(){
        // Check for obstacle collision
        if (level.obstacleLocations[robot.getyLoc()][robot.getxLoc()]){
            cout << "The robot collided with an obstacle!";
            this -> quit();
        }
        // Check for goal collision
        if (robot.getxLoc() == goal.xLoc && robot.getyLoc() == goal.yLoc){
            cout << "The robot reached the goal!";
            this -> quit();
        }
    }
    
    /**
     * Moves obstacles randomly from side to side.
     */
    public: void moveObstacles(){
        srand(time(0));
        if (level.doObstaclesMove && obstacleMoveDelay <= 0) {
            for (int i = 0; i < level.obstacleLocations.size(); i++){
                for (int j = 0; j < level.obstacleLocations[0].size(); j++){
                    if (level.obstacleLocations[i][j] && j > 0 && j < 14){
                        // Do a coin flip
                        if (rand() % 2 >= 1){
                            // Move obstacle left
                            level.obstacleLocations[i][j-1] = true;
                            level.obstacleLocations[i][j] = false;
                        } else {
                            // Move obstacle right
                            level.obstacleLocations[i][j+1] = true;
                            level.obstacleLocations[i][j] = false;
                            // Skip to the next row, to avoid moving the same obstacle twice
                            break;
                        }
                    }
                }
            }
            obstacleMoveDelay = 2;
        }
        obstacleMoveDelay--;
    }
    
};

int main (int argc, char** argv) {
    ExplorerRobot er(145, "BRIDGES_USER_ID", "BRIDGES_API_KEY", 15, 15);
    er.start();
}

