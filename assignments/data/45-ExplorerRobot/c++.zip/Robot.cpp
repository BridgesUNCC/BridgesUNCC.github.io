#include <unistd.h>
struct Robot {
    int xLoc;
    int yLoc;
    
    void initialize(int startX, int startY){
        this -> xLoc = startX;
        this -> yLoc = startY;
    }
    
    int getxLoc(){
        return this -> xLoc;
    }
    
    int getyLoc(){
        return this -> yLoc;
    }
    
    // There is no check for out-of-bounds moves, those will throw errors
    void moveUp(){
        yLoc--;
        sleep(500);
    }
    
    void moveDown(){
        yLoc++;
        sleep(500);
    }
    
    void moveRight(){
        xLoc++;
        sleep(500);
    }
    
    void moveLeft(){
        xLoc--;
        sleep(500);
    }
    
    void stop(){
        sleep(500);
    }
    
    // Makes thread sleep for specified time in milliseconds
    private: void sleep(int millis){
        usleep(millis*1000);
    }
};