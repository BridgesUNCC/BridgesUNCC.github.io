import random
from bridges import *
from enum import Enum
from Goal import Goal
from Level import Level
from Robot import Robot

class ExplorerRobot(NonBlockingGame):
    level = None
    goal = None
    robot = None
    obstacleMoveDelay = 0
    # TODO: Declare any variables you need here
    
    def __init__(self, assid, login, apikey, rows, cols):
        super(ExplorerRobot, self).__init__(assid, login, apikey, cols, rows)
    
    def initialize(self):
        self.generate_board_background()
        # TODO: Select the level you'd like to attempt by changing the integer passed to this function.
        self.select_level(0)
    
    def game_loop(self):
        # Redraws the board to match the intended state
        # This happens once every time the code loops, but you can call this function more if you want.
        self.redraw_board()
        # Checks for collision between obstacles and the robot, and the goal and the robot
        self.check_collision()
        self.move_obstacles()
        
        # TODO: Create the code to make the robot move below this comment
        # (0,0) is at the top left corner; (15,15) is at the bottom right.
        # level.obstacleLocations is used by checking [y][x] in that order
        
        
    
    # Clears the board, then redraws it appropriately
    def redraw_board(self):
        # Clear the board
        for i in range(self.board_height):
            for j in range(self.board_width):
                self.draw_symbol(i, j, NamedSymbol.none, NamedColor.blueviolet)
        
        # Place the player sprite at the location indicated by playerX and playerY
        self.draw_symbol(self.robot.getyLoc(), self.robot.getxLoc(), NamedSymbol.astro_helmet, NamedColor.blueviolet)
        
        for i in range(len(self.level.obstacleLocations)):
            for j in range(len(self.level.obstacleLocations[0])):
                if (self.level.obstacleLocations[i][j]):
                    self.draw_symbol(i, j, NamedSymbol.square, NamedColor.brown)
        
        self.draw_symbol(self.goal.getyLoc(), self.goal.getxLoc(), NamedSymbol.flag, NamedColor.green)
    
    def generate_board_background(self):
        for i in range(self.board_height):
            for j in range(self.board_width):
                # Make a checkerboard pattern
                if ((i + j) % 2 == 0):
                    self.set_bg_color(i, j, NamedColor.darkgray)
                else:
                    self.set_bg_color(i, j, NamedColor.lightgray)
    
    def select_level(self, levelNum):
        levelArray = [[False for i in range(self.board_height)] for j in range(self.board_width)]
        if (levelNum == 0):
            self.robot = Robot(7, 7)
            self.goal = Goal(9, 4)
            self.level = Level(levelArray, False)
        elif (levelNum == 1):
            self.robot = Robot(7, 10)
            self.goal = Goal( 7, 4)
            levelArray[8][7] = True
            self.level = Level(levelArray, False)
        elif (levelNum == 2):
            self.robot = Robot(7, 4)
            self.goal = Goal(3, 12)
            levelArray[8][7] = True
            levelArray[7][9] = True
            levelArray[5][6] = True
            levelArray[6][4] = True
            levelArray[9][3] = True
            levelArray[10][5] = True
            levelArray[11][4] = True
            self.level = Level(levelArray, True)
    
    # Checks to see if the robot is in the same place as any obstacle. If it is, ends the game
    def check_collision(self):
        # Check for obstacle collision
        if (self.level.obstacleLocations[self.robot.getyLoc()][self.robot.getxLoc()]):
            print("The robot collided with an obstacle!")
            self.quit()
        # Check for goal collision
        if (self.robot.getxLoc() == self.goal.getxLoc() and self.robot.getyLoc() == self.goal.getyLoc()):
            print("The robot reached the goal!")
            self.quit()
    
    # Moves obstacles randomly from side to side
    def move_obstacles(self):
        if (self.level.doObstaclesMove and self.obstacleMoveDelay <= 0):
            for i in range(len(self.level.obstacleLocations)):
                for j in range(len(self.level.obstacleLocations[0])):
                    if (self.level.obstacleLocations[i][j] and j > 0 and j < 14):
                        # Do a coin flip
                        if (random.random() >= 0.50):
                            # Move obstacle left
                            self.level.obstacleLocations[i][j-1] = True
                            self.level.obstacleLocations[i][j] = False
                        else:
                            # Move obstacle right
                            self.level.obstacleLocations[i][j+1] = True
                            self.level.obstacleLocations[i][j] = False
                            # Skip to the next row, to avoid moving the same obstacle twice
                            break
            self.obstacleMoveDelay = 2
        self.obstacleMoveDelay =- 1
    
def main():
    # Do not change the number of columns or rows
    er = ExplorerRobot(245, "BRIDGES_USER_ID", "BRIDGES_API_KEY", 15, 15)
    er.set_title("Explorer Robot")
    er.set_description("An assignment where you make a virtual robot explore its environment")
    er.start()


if __name__ == '__main__':
    main()
