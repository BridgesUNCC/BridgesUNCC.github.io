import time
class Robot:
    def __init__(self, startX, startY):
        self.__xLoc = startX
        self.__yLoc = startY
    
    def getxLoc(self):
        return self.__xLoc
    
    def getyLoc(self):
        return self.__yLoc
    
    # There is no check for out-of-bounds moves, those will throw errors
    def moveUp(self):
        self.__yLoc -= 1
        self.sleep(500)
    
    def moveDown(self):
        self.__yLoc += 1
        self.sleep(500)
    
    def moveRight(self):
        self.__xLoc += 1
        self.sleep(500)
    
    def moveLeft(self):
        self.__xLoc -= 1
        self.sleep(500)
    
    def stop(self):
        self.sleep(500)
    
    def sleep(self, millis):
        time.sleep(millis/1000)