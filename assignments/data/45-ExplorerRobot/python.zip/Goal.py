class Goal:
    def __init__(self, xLoc, yLoc):
        self.__xLoc = xLoc
        self.__yLoc = yLoc
    
    def getxLoc(self):
        return self.__xLoc
    
    def getyLoc(self):
        return self.__yLoc