class Level:
    def __init__(self, obstacleLocations, doObstaclesMove):
        self.obstacleLocations = obstacleLocations
        self.doObstaclesMove = doObstaclesMove