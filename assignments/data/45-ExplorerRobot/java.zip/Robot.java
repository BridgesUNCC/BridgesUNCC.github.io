public class Robot {
    private int xLoc;
    private int yLoc;

    Robot(int startX, int startY){
        xLoc = startX;
        yLoc = startY;
    }

    public int getxLoc() {
        return xLoc;
    }

    public int getyLoc() {
        return yLoc;
    }

    // There is no check for out-of-bounds moves, those will throw errors.
    public void moveUp(){
        yLoc--;
        sleep(500);
    }

    public void moveDown() {
        yLoc++;
        sleep(500);
    }

    public void moveRight(){
        xLoc++;
        sleep(500);
    }

    public void moveLeft(){
        xLoc--;
        sleep(500);
    }

    public void stop(){
        sleep(500);
    }

    /**
     * Makes thread sleep for specified time and catches associated exception
     * @param millis Length of time to sleep for, in milliseconds
     */
    private void sleep(int millis){
        try {
            Thread.sleep(millis);
        } catch (InterruptedException ie){
            System.out.println("Caught exception " + ie + " in moveBackward()");
        }
    }
}
