public class Level {
    public boolean[][] obstacleLocations;
    public boolean doObstaclesMove;

    public Level(boolean[][] obstacleLocations, boolean doObstaclesMove) {
        this.obstacleLocations = obstacleLocations;
        this.doObstaclesMove = doObstaclesMove;
    }
}
