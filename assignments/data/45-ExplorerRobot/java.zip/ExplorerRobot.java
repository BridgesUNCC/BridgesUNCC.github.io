import bridges.base.NamedColor;
import bridges.base.NamedSymbol;
import bridges.games.*;

public class ExplorerRobot extends NonBlockingGame {
    public Level level;
    public Goal goal;
    public Robot robot;
    public int obstacleMoveDelay;

    // TODO: Declare any variables you need here


    public ExplorerRobot(int assid, String login, String apiKey, int cols, int rows) {
        super (assid, login, apiKey, cols, rows);
    }

    public void initialize() {
        generateBoardBackground();
        // TODO: Select the level you'd like to attempt by changing the integer passed to this function.
        selectLevel(0);
    }

    public void gameLoop() {
        // Redraws the board to match the intended state
        // This happens once every time the code loops, but you can call this function more if you want.
        redrawBoard();
        // Checks for collision between obstacles and the robot, and the goal and the robot
        checkCollision();
        moveObstacles();

        // TODO: Create the code to make the robot move below these comments
        // (0,0) is at the top left corner; (15,15) is at the bottom right.
        // level.obstacleLocations is used by checking [y][x] in that order


    }

    public static void main (String args[]) {
        // Do not change the number of columns or rows
        ExplorerRobot er = new ExplorerRobot(45, "BRIDGES_USER_ID", "BRIDGES_API_KEY", 15, 15);
        er.setTitle("Explorer Robot");
        er.setDescription("An assignment where you make a virtual robot explore its environment");
        er.start();
    }

    // Clears the board, then redraws it appropriately
    public void redrawBoard() {
        // Clear the board
        for (int i = 0; i < this.getBoardHeight(); i++){
            for (int j = 0; j < this.getBoardWidth(); j++){
                drawSymbol(i, j, NamedSymbol.none, NamedColor.blueviolet);
            }
        }

        // Place the player sprite at the location indicated by playerX and playerY
        drawSymbol(robot.getyLoc(), robot.getxLoc(), NamedSymbol.astro_helmet, NamedColor.blueviolet);

        for(int i = 0; i < level.obstacleLocations.length; i++){
            for (int j = 0; j < level.obstacleLocations[0].length; j++){
                if (level.obstacleLocations[i][j]) {
                    drawSymbol(i, j, NamedSymbol.square, NamedColor.brown);
                }
            }
        }

        drawSymbol(goal.getyLoc(), goal.getxLoc(), NamedSymbol.flag, NamedColor.green);

    }

    public void generateBoardBackground(){
        for (int i = 0; i < this.getBoardHeight(); i++){
            for (int j = 0; j < this.getBoardWidth(); j++){
                // Make a checkerboard pattern
                if ((i + j) % 2 == 0) {
                    setBGColor(i, j, NamedColor.darkgray);
                } else {
                    setBGColor(i, j, NamedColor.lightgray);
                }
            }
        }
    }

    public void selectLevel(int levelNum){

        boolean[][] levelArray = new boolean[this.getBoardHeight()][this.getBoardWidth()];
        switch(levelNum){
            case 0: default:
                robot = new Robot(7,7);
                goal = new Goal(9, 4);
                level = new Level(levelArray, false);
                break;
            case 1:
                robot = new Robot (7, 10);
                goal = new Goal(7, 4);
                levelArray[8][7] = true;
                level = new Level(levelArray, false);
                break;
            case 2:
                robot = new Robot(7,4);
                goal = new Goal (3, 12);
                levelArray[8][7] = true;
                levelArray[7][9] = true;
                levelArray[5][6] = true;
                levelArray[6][4] = true;
                levelArray[9][3] = true;
                levelArray[10][5] = true;
                levelArray[11][4] = true;
                level = new Level (levelArray, true);
                break;
        }
    }

    /**
     * Checks to see if the robot is in the same place as any obstacle. If it is, ends the game
     */
    public void checkCollision(){
        // Check for obstacle collision
        if (level.obstacleLocations[robot.getyLoc()][robot.getxLoc()]){
            System.out.println("The robot collided with an obstacle!");
            this.quit();
        }
        // Check for goal collision
        if (robot.getxLoc() == goal.getxLoc() && robot.getyLoc() == goal.getyLoc()){
            System.out.println("The robot reached the goal!");
            this.quit();
        }
    }

    /**
     * Moves obstacles randomly from side to side.
     */
    public void moveObstacles(){
        if (level.doObstaclesMove && obstacleMoveDelay <= 0) {
            for (int i = 0; i < level.obstacleLocations.length; i++){
                for (int j = 0; j < level.obstacleLocations[0].length; j++){
                    if (level.obstacleLocations[i][j] && j > 0 && j < 14){
                        // Do a coin flip
                        if (Math.random() >= 0.50){
                            // Move obstacle left
                            level.obstacleLocations[i][j-1] = true;
                            level.obstacleLocations[i][j] = false;
                        } else {
                            // Move obstacle right
                            level.obstacleLocations[i][j+1] = true;
                            level.obstacleLocations[i][j] = false;
                            // Skip to the next row, to avoid moving the same obstacle twice
                            break;
                        }
                    }
                }
            }
            obstacleMoveDelay = 2;
        }
        obstacleMoveDelay--;
    }
}
