from bridges import *
import math

import random
from datetime import datetime

class Tile(object):
    """ TODO: Create a tile class that holds each game tiles properties.
    Such as the tiles value, size, position etc. Each tile will take up 1/4th of the grid
    """

class Game2048(NonBlockingGame):
    def __init__(self, assid, login, apikey):
        # If using a 24x24 grid each tile will be 6x6
        super(Game2048, self).__init__(assid, login, apikey, 24, 24)

        super(Game2048, self).set_title("2048 Game")
        super(Game2048, self).set_description("Use arrow keys to move blocks in a direction, Stack blocks of the same number and try to achieve the number 2048.")

    def initialize(self):
        random.seed(datetime.now())

        # TODO: Spawn 2 tiles in randomly with a value of 2 or rarely 4
        
    def game_loop(self):
        # TODO: Take user input and move all tiles in a direction based on the input
        # Dont take any input until all tiles have reached a stopping point
		# Merge tiles that have the same value and stop at other tiles and the edge of the grid
		
	    #  Once all tiles are done moving start the next turn

        # Draw the board every frame

    
def main():
    game = Game2048(211, "BRIDGES_USER_ID", "BRIDGES_API_KEY")

    # Start the game
    game.start()

if __name__ == '__main__':
    main()
