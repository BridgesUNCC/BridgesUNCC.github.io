package game;

import bridges.base.NamedColor;
import bridges.base.NamedSymbol;
import game.Vector2;
import java.util.ArrayList;
import game.LBGame;

class Game extends LBGame {
	public Game(int assid, String login, String apiKey) {
		super(assid, login, apiKey);
	}
	
	public static void main(String args[]) {
		Game game = new Game(0, "user", "password");
		game.setTitle("2048");
		game.start();
	}
	
	/**
	 * @return A random cell in the grid that does not have a tile
	 */
	public Vector2 randomOpenCell() {
	}

	@Override
	public void initialize() {
	}
	
	private void draw() {
		// Draw the checkered grid
		for (int y = 0; y < rows; y++) {
			for (int x = 0; x < cols; x++) {
				boolean checker = (
						(int)(x / 6) % 2 == 0 && (int)(y / 6) % 2 == 0 || ((int)(x / 6) % 2 != 0 && (int)(y / 6) % 2 != 0)
						);
				setBGColor(x, y, checker ? NamedColor.white : NamedColor.lightgray);
				drawObject(x, y, NamedSymbol.none);
			}
		}
	}
	
	/**
	 * @param c The cell to check for collision from
	 * @param pos The position to check for collision with c
	 * @return True if there is another cell that is at pos or if the position is outside the grid
	 */
	private boolean checkCollision(Cell c, Vector2 pos) {
	}
	
	/**
	 * @return True if there is no move that the player can make
	 */
	private boolean checkGameOver() {
	}
	
	@Override
	public void process() {
	}
}

// Helper class, represents a 6x6 game tile
class Cell {
	public Vector2 position = new Vector2(0, 0);
	public Vector2 size = new Vector2(6, 6);
	public int value = 2;
	
	public Cell(Vector2 pos) {
		position = pos;
	}
	
	public Cell(Vector2 pos, int value) {
		position = pos;
		this.value =  value;
	}
	
	public boolean hasPosition(Vector2 pos) {
		return pos.x >= position.x && pos.x < position.x + size.x && pos.y >= position.y && pos.y < position.y + size.y;
	}
}
