#include <NonBlockingGame.h>

#include <iostream>
#include <string>

using namespace bridges;
using namespace bridges::game;

// Helper class that represents 2 int values X and Y
// Use for 2D position and size
class Vector2 {
  public:
    int x = 0;
    int y = 0;
    Vector2(int x, int y) : x(x), y(y) {}

    static Vector2 add(Vector2 a, Vector2 b) {
      return Vector2(a.x + b.x, a.y + b.y);
    }

    void add(Vector2 other) {
      this->x += other.x;
      this->y += other.y;
    }

    int times() {
      return x * y;
    }

    bool operator==(const Vector2 &other) const {
      return x == other.x && y == other.y;
    }

    Vector2 operator*(const Vector2 &other) const {
      return Vector2(x * x, y * y);
    }

    Vector2 operator/(const Vector2 &other) const {
      return Vector2(x / other.x, y / other.y);
    }
};


class Tile {
    // TODO:
    // Build a tile object that has a position and size on the grid
    // it also has a value (starts 2 or 4)
    // normally this will take up (1/4, 1/4) of the entire grid size
};

class Game2048 : public NonBlockingGame {
  public:

    Game2048(int assignmentID, std::string username, std::string apikey)
      : NonBlockingGame(assignmentID, username, apikey, 24, 24) {}

  protected:
    virtual void initialize() override {
      // Randomly spawn 2 tiles on the grid with a value of 2 or 4
    }

    // Return a position that does not contain a tile
    Vector2 randomOpenTile() {
      // TODO:
      // Return a random position where a new tile can be instanced
    }

    // Return the tile at position v
    Tile * tileAt(Vector2 v) {
      // TODO: Return a tile at the postion v
    }

    void turnStart() {
      // TODO: Check if the player loses or wins
      // Otherwise spawn 1 more tile on the grid
    }

    void draw() {
      // TODO:
      // Draw a checkered grid
      // Draw the tiles on this grid
    }

    void process() {
      // TODO: Take user input and move all tiles in a direction based on the input
      // Dont take any input until all tiles have reached a stopping point
      // Merge tiles that have the same value and stop at other tiles and the edge of the grid

      // Once all tiles are done moving start the next turn
      turnStart();
    }

    virtual void gameLoop() override {
      static int i = 0;

      draw();
      process();

      i++;
    }
};

int main(int argc, char *argv[]) {
  Game2048 nbg(111, "BRIDGES_USER_ID", "BRIDGES_API_KEY");

  nbg.start();

  return 0;
}
