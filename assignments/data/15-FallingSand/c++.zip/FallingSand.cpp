#include <NonBlockingGame.h>
#include <iostream>
#include <random>
#include <chrono>

using namespace bridges::game;
using namespace std;

/**
 * Welcome to Bridges Falling Sands Game Assignment.
 *
 * The "container" that your elements will be moving around in is a 2D array
 * visualized as a game grid.
 *
 * Try to make the elements react to each other as they would in real life using
 * conditional statements.
 *
 * For example, WATER in a cell should fall down on the condition that the cell
 * below it is empty. Consider how the water should behave if the cell below it
 * is metal.
 *
 * Also consider sand falling into a container of water. In real life, the water
 * will rise and sand will fall through it to the bottom of the container. What
 * kind of movement would values in a 2D array have to make to mirror that
 * behavior?
 */
struct FallingSand : public NonBlockingGame {
    // Your grid can contain up to 1024 cells.
    // The largest square grid available is 32 x 32
    static const int gridColumns = 30;
    static const int gridRows = 30;

    // An array that maps the location of each element
    int container[gridColumns][gridRows];
    // An array that keeps track of the cursors location.
    int cursorOverlay[gridColumns][gridRows];

    int CURSOR = 1;
    
    // Element values
    static const int EMPTY = 0;
    static const int METAL = 1;
    static const int SAND = 2;
    static const int WATER = 3;
    static const int DELETE = 4;

    // Element colors
    NamedColor emptyColor;
    NamedColor metalColor;
    NamedColor sandColor;
    NamedColor waterColor;
    NamedColor deleteColor;
    NamedColor cursorColor;

    // Element symbols
    NamedSymbol emptySymbol;
    NamedSymbol metalSymbol;
    NamedSymbol sandSymbol;
    NamedSymbol waterSymbol;
    NamedSymbol cursorSymbol;

    // Used to control the games frame rate.
    long FRAMERATE = 1000000000 / 15;
    std::chrono::time_point<std::chrono::high_resolution_clock> frameTime = std::chrono::high_resolution_clock::now();

    // Location of the cursor on the grid.
    int cursorCell[2] = {10, 10};

	FallingSand(int assID, std::string username, std::string apikey)
		: NonBlockingGame (assID, username, apikey, gridColumns, gridRows) {
		setTitle("Falling Sand");
        setDescription("Simulate elemental reactions and gravity within a grid. Use the arrow keys to move your cursor. Alternate elements with the A, S, D, and W keys. Press P to place an element at the cursors location.");
	}

    // The initialize function runs once before the game loop begins.
    // Assign your game variables here.
	virtual void initialize() override {

        emptyColor = NamedColor::black;
        metalColor = NamedColor::gray;
        sandColor = NamedColor::sandybrown;
        waterColor = NamedColor::blue;
        deleteColor = NamedColor::red;
        cursorColor = NamedColor::gray;

        emptySymbol = NamedSymbol::none;
        metalSymbol = NamedSymbol::square;
        sandSymbol = NamedSymbol::waves;
        waterSymbol = NamedSymbol::droplet;
        cursorSymbol = NamedSymbol::star;
	}

    // Required method that runs continously while the game is being played.
    // Place game functions in the order they must operate here.
	virtual void gameLoop() override {
        controls(); // User input
        paintBoard(); // Updates game display

        if (std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::high_resolution_clock::now() - frameTime).count() > FRAMERATE) { // Runs when it's time for the next frame.
            frameTime = std::chrono::high_resolution_clock::now();

            // Loops through the 2D array.
            for (int col = 0; col < gridColumns; col++){
                for (int row = gridRows-1; row > -1; row--){
                    // Checks which element exists in each cell and calls the corresponding behavior function.
                    switch(container[col][row]){
                        case WATER:
                            waterBehavior(col, row);
                            break;
                        case METAL:
                            metalBehavior(col, row);
                            break;
                        case SAND:
                            sandBehavior(col, row);
                            break;
                    }
                }
            }
        }
	}

	// Logic for metal in the grid
    void metalBehavior(int col, int row){

    }

	// Logic for water in the grid
    void waterBehavior(int col, int row){
        
    }

    // Logic for sand in the grid
    void sandBehavior(int col, int row) {

    }

    // Restart the game, clear the board and reset the cursor
    void newGame(){
        
    }

    /**
     * Keyboard Controls.
     * 
     * Move the cursor around with the arrow keys.
     * 
     * Register a click with Spacebar.
     * 
     * Element type can be changed with the W, S, A, D keys.
     * akey = metal
     * skey = sand
     * dkey = delete
     * wkey = water
    **/
	void controls() {
        clearCursor(cursorCell[0], cursorCell[1]);
        if(keyA()){
            
        }
        if(keyW()){

        }
        if(keyS()){

        }
        if(keyD()){

        }
        if(keyLeft()&&cursorCell[0]>0){
            cursorCell[0] = cursorCell[0]-1;
        }
        if(keyRight()&&cursorCell[0]<gridColumns-1){
            cursorCell[0] = cursorCell[0]+1;
        }
        if(keyUp()&&cursorCell[1]>0){
            cursorCell[1] = cursorCell[1]-1;
        }
        if(keyDown()&&cursorCell[1]<gridRows-1){
            cursorCell[1] = cursorCell[1]+1;
        }
        if(keyQ()){
            
        }
        if(keySpace()){
            
        }

        placeCursor(cursorCell[0], cursorCell[1]);
    }

    void clearCursor(int col, int row){
        cursorOverlay[col][row] = EMPTY;
    }

    // Place specific element at a location on the grid at specified col/row.
    void placeElement(int element, int col, int row){
        container[col][row]=element;
    }

    // Clears an element from the grid.
    void clearElement(int col, int row){
        container[col][row] = EMPTY;
    }

    // Places the cursor in the specified location of the cursor overlay array.
    void placeCursor(int col, int row){
        cursorOverlay[col][row] = CURSOR;
    }

    // Adds color and symbols to cells in grid based on values in the 2D array.
    void paintBoard() {
        for (int col = 0; col < gridColumns; col++){
            for (int row = 0; row < gridRows; row++){
                switch(container[col][row]) {
                    case SAND:
                        drawSymbol(row, col, sandSymbol, sandColor);
                        break;
                    case WATER:
                        drawSymbol(row, col, waterSymbol, waterColor);
                        break;
                    case METAL:
                        drawSymbol(row, col, metalSymbol, metalColor);
                        break;
                    case EMPTY:
                        drawSymbol(row, col, emptySymbol, emptyColor);
                        break;
                }

                if (cursorOverlay[col][row]==CURSOR) {
                    drawSymbol(row, col, cursorSymbol, cursorColor);
                }
            }
        }
    }
};

// To test your game, create an object of your game within the main method of your program.
// Use an assignment number, your bridges username, your bridges API key, the number of columns
// in your grid, and the number of rows in your grid as arguments for your bridges game object.
int main (int argc, char** argv) {
	FallingSand game(115, "BRIDGES_USER_ID", "BRIDGES_API_KEY");
	game.start();
}
