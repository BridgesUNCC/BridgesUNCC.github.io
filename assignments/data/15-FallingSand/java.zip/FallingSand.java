/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FallingSand;

import babybridges.game.NGCKGame;
import bridges.base.NamedColor;
import bridges.base.NamedSymbol;
import java.util.Random;

/**
 * Welcome to Bridges Falling Sands Game Assignment.
 * 
 * The "container" that your elements will be moving around in is a 2D array visualized 
 * as a game grid.
 * 
 * Try to make the elements react to each other as they would in real life using conditional
 * statements.
 * 
 * For example, WATER in a cell should fall down on the condition that the cell below it is empty. 
 * Consider how the water should behave if the cell below it is metal.
 * 
 * Also consider sand falling into a container of water. In real life, the water will
 * rise and sand will fall through it to the bottom of the container. 
 * What kind of movement would values in a 2D array have to make to mirror that behavior?
 */
public class FallingSand extends NGCKGame {
    
    int gridColumns = grid.getDimensions()[0];
    int gridRows = grid.getDimensions()[1];
    
    // An array that maps the location of each element
    public int container[][] = new int[gridColumns][gridRows];
    // An array that keeps track of the cursors location.
    public int cursorOverlay[][] = new int[gridColumns][gridRows];
    // Location of the cursor on the grid.
    int[] cursorCell = {10, 10};
    
    // Element values
    int CURSOR = 1;
    final int EMPTY = 0;
    final int METAL = 1;
    final int SAND = 2;
    final int WATER = 3;
    final int DELETE = 4;
    
    // Element colors
    NamedColor emptyColor;
    NamedColor metalColor;
    NamedColor sandColor;
    NamedColor waterColor;
    NamedColor deleteColor;
    NamedColor cursorColor;
    
    // Element symbols
    NamedSymbol emptySymbol;
    NamedSymbol metalSymbol;
    NamedSymbol sandSymbol;
    NamedSymbol waterSymbol;
    NamedSymbol cursorSymbol;
    
    // Used to control the games frame rate.
    final long FRAMERATE = 1000000000 / 15;
    long frameTime;
    long nextFrameTime;
    Random r = new Random();
    
    // Logic for water in the grid
    public void waterBehavior(int col, int row){
        
    }
    
    // Logic for metal in the grid
    public void metalBehavior(int col, int row){
        
    }
    
    // Logic for sand in the grid
    public void sandBehavior(int col, int row){
       
    }
    
    // Places the cursor in the specified location of the cursor overlay array.
    private void placeCursor(int col, int row){
        cursorOverlay[col][row] = CURSOR;
    }
    
    // Removes the cursor from the current location in the cursor overlay array.
    private void clearCursor(int col, int row){
        cursorOverlay[col][row] = EMPTY;
    }
    
    // Adds color and symbols to cells in grid based on values in the 2D array.
    public void paintBoard(){
        for (int col = 0; col < gridColumns; col++){
            for (int row = 0; row < gridRows; row++){
                switch(container[col][row]){
                    case SAND:
                        SetFGColor(col, row, sandColor);
                        DrawObject(col, row, sandSymbol);
                        break;
                    case WATER:
                        SetFGColor(col, row, waterColor);
                        DrawObject(col, row, waterSymbol);
                        break;
                    case METAL:
                        SetFGColor(col, row, metalColor);
                        DrawObject(col, row, metalSymbol);
                        break;
                    case EMPTY:
                        SetFGColor(col, row, emptyColor);
                        DrawObject(col, row, emptySymbol);
                        break;
                }
            }
        }
    }
    
    public void controls(){
        clearCursor(cursorCell[0], cursorCell[1]);
        if(Keya()){
            
        }
        if(Keyw()){
            
        }
        if(Keys()){
            
        }
        if(Keyd()){
            
        }
        if(KeyLeft()&&cursorCell[0]>0){
            cursorCell[0] = cursorCell[0]-1;
        }
        if(KeyRight()&&cursorCell[0]<gridColumns-1){
            cursorCell[0] = cursorCell[0]+1;
        }
        if(KeyUp()&&cursorCell[1]>0){
            cursorCell[1] = cursorCell[1]-1;
        }
        if(KeyDown()&&cursorCell[1]<gridRows-1){
            cursorCell[1] = cursorCell[1]+1;
        }
        if(KeyButton1()){
            
        }
        if(KeyButton2()){
            
        }
        placeCursor(cursorCell[0], cursorCell[1]);
    }
    
    // Required method that runs continously while the game is being played.
    // Place game functions in the order they must operate here.
    public void GameLoop(){
        
        paintBoard(); // Updates game display
        controls(); // Updates controls
        
        if (System.nanoTime() > nextFrameTime) { // Runs when it's time for the next frame.
            frameTime = System.nanoTime();
            nextFrameTime = frameTime + FRAMERATE;
            
            // Loops through the 2D array.
            for (int col = 0; col < gridColumns; col++){
                for (int row = gridRows-1; row > -1; row--){
                    // Checks which element exists in each cell and calls the corresponding behavior function.
                    switch(container[col][row]){
                        case WATER:
                            waterBehavior(col, row);
                            break;
                        case METAL:
                            metalBehavior(col, row);
                            break;
                        case SAND:
                            sandBehavior(col, row);
                            break;
                    }
                }
            }
        }
    }
    
    // This method will run once before the game loop starts.
    public void initialize(){
        emptyColor = NamedColor.black;
        metalColor = NamedColor.gray;
        sandColor = NamedColor.sandybrown;
        waterColor = NamedColor.blue;
        deleteColor = NamedColor.red;
        cursorColor = NamedColor.gray;
        
        emptySymbol = NamedSymbol.none;
        metalSymbol = NamedSymbol.square;
        sandSymbol = NamedSymbol.waves;
        waterSymbol = NamedSymbol.droplet;
        cursorSymbol = NamedSymbol.star;
    }
    
    public static void main(String args[]) {
        int assignmentID = 0;
        String userName = "student username";
        String apiKey = "student api key";
        
        // Initialize our nonblocking game
        FallingSand sf = new FallingSand(assignmentID, userName, apiKey);
        sf.setTitle("Falling Sand");
        sf.setDescription("Simulate elemental reactions and gravity within a grid.");
        // start running the game
        sf.start();
    }

    /************** Do not alter the code below this line *******************/
     /**
     * @param assid
     * @param userName
     * @param apiKey
     **/
    public FallingSand(int assid, String userName, String apiKey){
        super(assid, userName, apiKey);
    }
}
