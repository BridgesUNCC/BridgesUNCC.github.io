import bridges.games.NonBlockingGame;
import bridges.base.NamedColor;
import bridges.base.NamedSymbol;
import java.util.Random;

/**
 * Welcome to Bridges Falling Sands Game Assignment.
 *
 * The "container" that your elements will be moving around in is a 2D array
 * visualized as a game grid.
 *
 * Try to make the elements react to each other as they would in real life using
 * conditional statements.
 *
 * For example, WATER in a cell should fall down on the condition that the cell
 * below it is empty. Consider how the water should behave if the cell below it
 * is metal.
 *
 * Also consider sand falling into a container of water. In real life, the water
 * will rise and sand will fall through it to the bottom of the container. What
 * kind of movement would values in a 2D array have to make to mirror that
 * behavior?
 */
public class FallingSand extends NonBlockingGame {

  int gridColumns = 30;
  int gridRows = 30;

  // An array that maps the location of each element
  public int container[][] = new int[gridColumns][gridRows];
  // An array that keeps track of the cursors location.
  public int cursorOverlay[][] = new int[gridColumns][gridRows];

  // Element values
  int CURSOR = 1;
  final int EMPTY = 0;
  final int METAL = 1;
  final int SAND = 2;
  final int WATER = 3;
  final int DELETE = 4;

  // Element colors
  NamedColor emptyColor;
  NamedColor metalColor;
  NamedColor sandColor;
  NamedColor waterColor;
  NamedColor deleteColor;
  NamedColor cursorColor;

  // Element symbols
  NamedSymbol emptySymbol;
  NamedSymbol metalSymbol;
  NamedSymbol sandSymbol;
  NamedSymbol waterSymbol;
  NamedSymbol cursorSymbol;

  // Used to control the games frame rate.
  final long FRAMERATE = 1000000000 / 15;
  long frameTime;
  long nextFrameTime;
  Random r = new Random();

  int cursorCell[];

  // Logic for water in the grid
  public void waterBehavior(int col, int row) {

  }

  // Logic for metal in the grid
  public void metalBehavior(int col, int row) {

  }

  // Logic for sand in the grid
  public void sandBehavior(int col, int row) {

  }

  // Required method that runs continously while the game is being played.
  // Place game functions in the order they must operate here.
  public void gameLoop() {

    controls(); // User input
    paintBoard(); // Updates game display

    if (System.nanoTime() > nextFrameTime) { // Runs when it's time for the next frame.
      frameTime = System.nanoTime();
      nextFrameTime = frameTime + FRAMERATE;

      // Loops through the 2D array.
      for (int col = 0; col < gridColumns; col++) {
        for (int row = gridRows - 1; row > -1; row--) {
          // Checks which element exists in each cell and calls the corresponding behavior function.
          switch (container[col][row]) {
            case WATER:
              waterBehavior(col, row);
              break;
            case METAL:
              metalBehavior(col, row);
              break;
            case SAND:
              sandBehavior(col, row);
              break;
          }
        }
      }
    }
  }

  // This method will run once before the game loop starts.
  public void initialize() {
    emptyColor = NamedColor.black;
    metalColor = NamedColor.gray;
    sandColor = NamedColor.sandybrown;
    waterColor = NamedColor.blue;
    deleteColor = NamedColor.red;
    cursorColor = NamedColor.gray;

    emptySymbol = NamedSymbol.none;
    metalSymbol = NamedSymbol.square;
    sandSymbol = NamedSymbol.waves;
    waterSymbol = NamedSymbol.droplet;
    cursorSymbol = NamedSymbol.star;
  }

  public void newGame() {

  }

  public static void main(String args[]) {
    // Initialize our nonblocking game
    FallingSand sf = new FallingSand(15, "BRIDGES_USER_ID", "BRIDGES_API_KEY");
  }

  // Places the cursor in the specified location of the cursor overlay array.
  private void placeCursor(int col, int row) {
    cursorOverlay[col][row] = CURSOR;
  }

  // Removes the cursor from the current location in the cursor overlay array.
  private void clearCursor(int col, int row) {
    cursorOverlay[col][row] = EMPTY;
  }

  // Place specific element at a location on the grid at specified col/row.
  public void placeElement(int element, int col, int row) {
    container[col][row] = element;
  }

  // Clears an element from the grid.
  public void clearElement(int col, int row) {
    container[col][row] = EMPTY;
  }

  // Retreve element from specified col/row.
  public int getElement(int col, int row) {
    return container[col][row];
  }

  // Returns an array of two values. Value at 0 indicates column, and at 1 row, where cursor is located.
  public int[] getCursorLocation() {
    return cursorCell;
  }

  // Adds color and symbols to cells in grid based on values in the 2D array.
  public void paintBoard() {
    for (int col = 0; col < gridColumns; col++) {
      for (int row = 0; row < gridRows; row++) {
        switch (container[col][row]) {
          case SAND:
            drawSymbol(col, row, sandSymbol, sandColor);
            break;
          case WATER:
            drawSymbol(col, row, waterSymbol, waterColor);
            break;
          case METAL:
            drawSymbol(col, row, metalSymbol, metalColor);
            break;
          case EMPTY:
            drawSymbol(col, row, emptySymbol, emptyColor);
            break;
        }

        if (cursorOverlay[col][row] == CURSOR) {
          drawSymbol(col, row, cursorSymbol, cursorColor);
        }
      }
    }
  }

  /**
   * Keyboard Controls.
   *
   * Move the cursor around with the arrow keys.
   *
   * Register a click with Spacebar.
   *
   * Element type can be changed with the W, S, A, D keys.
   * akey = metal
   * skey = sand
   * dkey = delete
   * wkey = water
  **/
  public void controls() {
    clearCursor(cursorCell[0], cursorCell[1]);
    if (keyA()) {

    }
    if (keyW()) {

    }
    if (keyS()) {

    }
    if (keyD()) {

    }
    if (keyLeft() && cursorCell[0] > 0) {
      cursorCell[0] = cursorCell[0] - 1;
    }
    if (keyRight() && cursorCell[0] < gridColumns - 1) {
      cursorCell[0] = cursorCell[0] + 1;
    }
    if (keyUp() && cursorCell[1] > 0) {
      cursorCell[1] = cursorCell[1] - 1;
    }
    if (keyDown() && cursorCell[1] < gridRows - 1) {
      cursorCell[1] = cursorCell[1] + 1;
    }
    if (keyQ()) {

    }
    if (keySpace()) {

    }

    placeCursor(cursorCell[0], cursorCell[1]);
  }

  public FallingSand(int assid, String userName, String apiKey) {
    super(assid, userName, apiKey, 30, 30);
    setTitle("Falling Sand");
    setDescription("Simulate elemental reactions and gravity within a grid.");
    // start running the game
    start();
  }
}
