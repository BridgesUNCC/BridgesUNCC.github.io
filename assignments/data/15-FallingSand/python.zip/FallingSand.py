import random

from bridges import *


class StudentClass(NonBlockingGame):
    gridColumns = 30
    gridRows = 30

    container = [gridColumns][gridRows]
    cursorOverlay = [gridColumns][gridRows]

    CURSOR = 1
    EMPTY = 0
    METAL = 1
    SAND = 2
    WATER = 3
    DELETE = 4

    emptyColor = NamedColor.none
    metalColor = NamedColor.gray
    sandColor = NamedColor.lightbrown
    waterColor = NamedColor.blue
    deleteColor = NamedColor.red
    cursorColor = NamedColor.orange

    emptySymbol = NamedSymbol.none
    metalSymbol = NamedSymbol.square
    sandSymbol = NamedSymbol.waves
    waterSymbol = NamedSymbol.rain
    cursorSymbol = NamedSymbol.circle

    cursorCell = {10, 10};

    def water_behavior(self, col, row):
        

    def sand_behavior(self, col, row):

    def metal_behavior(self, col, row):
        

    def game_loop(self):
        self.controls()
        self.paint_board()

        col = 0
        row = 0
        board_cleared = False

        while not board_cleared:
            if col < self.gridColumns:
                row = 0
                if row < self.gridRows:
                    if self.container[col][row] == self.WATER:
                        self.water_behavior(col, row)
                    if self.container[col][row] == self.METAL:
                        self.sand_behavior(col, row)
                    row+=1
                col+=1


    def initialize(self):
        self.cursorCell[0] = 10
        self.cursorCell[1] = 10
        self.paint_board()

    def new_game(self):
        col = 0
        row = 0
        board_cleared = False

        while not board_cleared:
            self.initialize()

            while col < self.gridColumns:
                row = 0
                while row < self.gridRows:
                    if self.container[col][row] == self.WATER:
                        
                    if self.container[col][row] == self.SAND:
                        
                    row += 1
                col += 1

    def place_cursor(self,col, row):
        

    def clear_cursor(self, col, row):
        

    def place_element(self, element, col, row):
        

    def clear_element(self, col, row):
        self.container[col][row] = self.EMPTY

    def get_element(self, col, row):
        return self.container[col][row]

    def get_cursor(self, col, row):
        return self.cursorOverlay[col][row]

    def paint_board(self):
        

    def controls(self):
        self.clear_cursor(self.cursorCell[0], self.cursorCell[1])
        if self.key_a():
            self.cursorColor = self.metalColor
            self.CURSOR = self.METAL
        if self.key_w():
            self.cursorColor = self.waterColor
            self.CURSOR = self.WATER
        if self.key_s():
            self.cursorColor = self.sandColor
            self.CURSOR = self.SAND
        if self.key_d():
            self.cursorColor = self.deleteColor
            self.CURSOR = self.DELETE

        if self.key_left() and self.cursorCell[0]>0:
            self.cursorCell[0] = self.cursorCell[0]+1
        if self.key_right() and self.cursorCell[0]<self.gridColumns-1:
            self.cursorCell[0] = self.cursorCell[0]-1
        if self.key_up() and self.cursorCell[1]>0:
            self.cursorCell[1] = self.cursorCell[1]-1
        if self.key_down() and self.cursorCell[1]<self.gridRows-1:
            self.cursorCell[1] = self.cursorCell[1]+1

        if self.key_q():
            self.new_game()
        if self.key_space():
            if self.CURSOR == self.DELETE:
                self.clear_element(self.cursorCell[0], self.cursorCell[1])
            else:
                self.place_element(self.cursorCell[0], self.cursorCell[1])

        self.place_cursor(self.cursorCell[0], self.cursorCell[1])

    def __init__(self, assid, login, apikey, cols, rows):
        super(StudentClass, self).__init__(assid, login, apikey, cols, rows)


def main():
    my_game = StudentClass(80, "STUDENT_USERNAME", "STUDENT_API_KEY", 30, 30)
    my_game.start()


if __name__ == '__main__':
    main()
