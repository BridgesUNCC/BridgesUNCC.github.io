import bridges.connect.Bridges;
import bridges.connect.DataSource;
import bridges.data_src_dependent.*;
import bridges.base.Element;
import bridges.base.SLelement;
import bridges.base.GraphAdjListSimple;
import bridges.base.Edge;
import java.util.*;


public class BookDistance {
    //java -cp .\bridges-java-3.2.2.jar .\BookDistance.java


    public static Map<String, Double> freq_list_gen(int id, String split_text){
        Map<String, Double> hashmap = new HashMap<>();
        
        /* Write the code that will generate
        a map containing each key word from a books
        text along with its associated count
        of how many times it shows up. Add this new 
        map to freq_books with the key being the
        book id.

        */
        return hashmap;
    }

    public static double calc_dist(int b1, int b2, Map<Integer, Map<String, Double>> freq_books){
        Set<String> word_bank = new HashSet<String>();
        word_bank.addAll(freq_books.get(b1).keySet());
        word_bank.addAll(freq_books.get(b2).keySet());

        Double word_dist = 0.0;

        /* Write the code to calculate the 
        distance between two sets of word banks
        and update the word_dist value with 
        the freshly calculated distance.



        */

        return word_dist;
    }

    public static GraphAdjListSimple<String> gen_graph(Double threshhold, GraphAdjListSimple<String> graph, List<ArrayList<Double>> dist_list, Double smallest, List<GutenbergMeta> book_meta){
        /* Write the code that will take
        the entire list of book connections 
        and distances, then generate a graph 
        with said values showing these connections.
        Return the graph you generated.


        */

        return graph;
    }

    public static void main(String[] args) throws Exception {
        Map<Integer, String> book_text = new HashMap<Integer, String>();
        Map<Integer, Map<String, Double>> freq_books = new HashMap<>();
        List<GutenbergMeta> book_meta = new ArrayList<GutenbergMeta>();
        List<ArrayList<Double>> dist_list = new ArrayList<ArrayList<Double>>();
        Double smallest = 100.00;


        Bridges bridges = new Bridges(139, "BRIDGES_USER_NAME", "BRIDGES_API_KEY");
		DataSource ds = bridges.getDataSource();
        String[] authors = {"Mark Twain", "Shakespeare, William", "Dickens, Charles", "Homer"}; 

	bridges.setTitle("Project Gutenberg: Book Distance");
	bridges.setDescription("Implement a word frequency list for a book and use it to compare similarity to other books.");


        for (String x : authors){
            List<GutenbergMeta> meta = ds.getGutenbergBookMetaData(x, "author");
            book_meta.addAll(meta);
        }

        System.out.println(book_meta.size());

        for (GutenbergMeta x : book_meta){
            try{
                String book = ds.getGutenbergBookText(x.getId());

                book_text.put(x.getId(), book);
            } catch (Exception e) {
                System.out.println("ERROR: Failed to get book with id = " + x.getId());
            }    
        }

        
        for (int i : book_text.keySet()){
            freq_books.put(i, freq_list_gen(i, book_text.get(i)));
        }

        List<Integer> indexes = new ArrayList<Integer>(freq_books.keySet());

        for (int y = 0 ; y < indexes.size() ; y++){
            for (int z = y + 1 ; z < indexes.size(); z++){
                Double word_dist = calc_dist(indexes.get(y), indexes.get(z), freq_books);
                ArrayList<Double> temp = new ArrayList<Double>();
                temp.add(Double.valueOf(indexes.get(y)));
                temp.add(Double.valueOf(indexes.get(z)));
                temp.add(word_dist);
                dist_list.add(temp);
                if (word_dist < smallest){
                    smallest = word_dist;
                }
            }
        }

        

        GraphAdjListSimple<String> graph = new GraphAdjListSimple<String>();
        bridges.setDescription(".7");
        graph = gen_graph(.7, graph, dist_list, smallest, book_meta);
        bridges.setDataStructure(graph);
        bridges.visualize();

        bridges.setDescription(".8");
        graph = gen_graph(.8, graph, dist_list, smallest, book_meta);
        bridges.setDataStructure(graph);
        bridges.visualize();

        bridges.setDescription(".9");
        graph = gen_graph(.9, graph, dist_list, smallest, book_meta);
        bridges.setDataStructure(graph);
        bridges.visualize();

        bridges.setDescription("1");
        graph = gen_graph(1.0, graph, dist_list, smallest, book_meta);
        bridges.setDataStructure(graph);
        bridges.visualize();


    }


}
