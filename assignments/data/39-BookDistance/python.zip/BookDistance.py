from bridges import graph_adj_list
from bridges.bridges import *
from bridges.data_src_dependent import data_source
from bridges.data_src_dependent import *
from bridges.graph_adj_list import *
from bridges.bridges import *
import sys
import time

book_texts = {}
book_freq = {}
dist_list = []  # [[book1_id, book2_id, dist], ....]
smallest_dist = 100

# Generates a word frequency list for a given book
def freq_list_gen(split_book1, b1):
    #------------------------------------
    # Write the code that will generate a dictionary
    # containing each unique word in the books text
    # as the key and the number of occurences of that
    # word as the value. Store this dictionary in 
    # the global dictionary book_freq, with the key as
    # the books id and the value as the books frequency dictionary
    # of unique words.
    #------------------------------------
    
    return

# Calculates the linear distance between two word frequency lists
def calc_dist(b1, b2):
    
    #generate unique word bank between the two books
    word_bank = []
    word_bank = list(set(book_freq[b1]).union(set(book_freq[b2])))
    word_dist = 0
    #------------------------------------
    # Write the code that will calculate the distance 
    # between each word between the two books.
    # You should return a single int that is the
    # cummulative distance between each word. 
    #------------------------------------



    return word_dist

#Generates graph for each point and connection
def gen_graph(threshhold=.8):
    #------------------------------------
    # Write the code that will take the the 
    # list of book connections and distance values
    # and generate a graph adjaceny list between book
    # nodes with the connections representing the 
    # distance between them
    #------------------------------------
    return

bridges = Bridges(239, "BRIDGES_USER_NAME", "BRIDGES_API_KEY")
bridges.set_title("Book Similarity")
bridges.set_description("Threshhold 1")
graph = GraphAdjList()


#Requests search results for a list of authors
book_list = []
book_meta_list = []
author_list = ["Mark Twain", "Shakespeare, William", "Dickens, Charles", "Homer"]
for auth in author_list:
    meta_list = get_gutenberg_book_metadata(auth, "author")
    for x in meta_list:
        book_list.append(x.id)
        book_meta_list.append(x)


over_time = time.time()

#Download book text based on the list of IDs
for x in book_list:
    try:
        book_texts[str(x)] = data_source.gutenberg_book_text(x)[str(x)]
    except:
        #removes id from list if it couldn't download text
        print(f"Error Downloading book {x}")
        book_list.remove(x)
        pass

#Generate word freq list per book
for book in book_texts:
    split_book = book_texts[str(book)].split()
    freq_list_gen(split_book, str(book))



#compares each book and creates a list of book connections and distance values
for book1 in range(len(book_list)):
    for book2 in range(book1 + 1, len(book_list)):
        b1_num = book_list[book1]
        b2_num = book_list[book2]
        word_dist = calc_dist(str(b1_num), str(b2_num))
        dist_list.append([str(b1_num), str(b2_num), word_dist])
        if word_dist < smallest_dist:
            smallest_dist = word_dist


# Create graphs based on different similarity threshholds
gen_graph(1)

print("RUNTIME TIME: ", time.time() - over_time)
bridges.set_data_structure(graph)
bridges.visualize()


graph = GraphAdjList()
bridges.set_description("Threshhold .9")
gen_graph(.9)
bridges.set_data_structure(graph)
bridges.visualize()

graph = GraphAdjList()
bridges.set_description("Threshhold .8")
gen_graph(.8)
bridges.set_data_structure(graph)
bridges.visualize()

graph = GraphAdjList()
bridges.set_description("Threshhold .75")
gen_graph(.75)
bridges.set_data_structure(graph)
bridges.visualize()

graph = GraphAdjList()
bridges.set_description("Threshhold .7")
gen_graph(.7)
bridges.set_data_structure(graph)
bridges.visualize()

graph = GraphAdjList()
bridges.set_description("Threshhold .6")
gen_graph(.6)
bridges.set_data_structure(graph)
bridges.visualize()
