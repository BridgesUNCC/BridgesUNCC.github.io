class Entity:
    def __init__(self, xLoc, yLoc):
        self.xLoc = xLoc
        self.yLoc = yLoc