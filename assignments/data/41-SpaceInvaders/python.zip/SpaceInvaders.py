import random
from bridges import *
from enum import Enum
from Entity import Entity


class SpaceInvaders(NonBlockingGame):
    playerX = 6
    playerY = 19
    playerProjectiles = []
    enemyProjectiles = []
    enemies = []

    # The delays are used to time various actions.
    # They're set to a fixed value every time a command goes through, and decrement by one each frame.
    # If they aren't at 0, the action will not occur until they are.
    playerMoveDelay = 0
    shootDelay = 0
    enemyMoveDelay = 0
    enemyShootDelay = 0
    enemyShotMovementDelay = 0

    # These are the delay between each move and each shot.
    # Measured in frames(game is 30 frames per second, ish).
    # Changing these is the easiest way to tweak the difficulty
    TIME_BETWEEN_SHOTS = 10
    TIME_BETWEEN_MOVES = 10
    TIME_BETWEEN_ENEMY_MOVES = 35
    TIME_BETWEEN_ENEMY_SHOTS = 30
    TIME_BETWEEN_ENEMY_SHOT_MOVEMENT = 5

    class Direction(Enum):
        DOWN = 1
        LEFT = 2
        RIGHT = 3

    enemyMoveDirection = Direction.RIGHT

    def __init__(self, assid, login, apikey, rows, cols):
        super(SpaceInvaders, self).__init__(assid, login, apikey, cols, rows)

    def initialize(self):
        # Generate the board background
        self.generate_board_background()
        # Place enemies
        self.place_enemies_on_board()

    def game_loop(self):
        # Move the player if appropriate
        self.move_player()
        # Have the player character fire if appropriate
        self.player_fire()
        # Move the enemies if appropriate
        self.move_enemies()
        # Have an enemy fire if appropriate
        self.enemy_fire()
        # Move projectiles forward if appropriate
        self.move_projectiles()
        # Check for projectiles colliding with other things and handle those situations appropriately
        self.check_projectile_collision()
        # Redraw the board to match the game state
        self.redraw_board()

    # Clears the board, then redraws it appropriately
    def redraw_board(self):
        # Clear the board
        for i in range(self.board_height):
            for j in range(self.board_width):
                self.draw_symbol(i, j, NamedSymbol.none, NamedColor.blueviolet)
        
        # Place the player sprite at the location indicated by playerX and playerY
        self.draw_symbol(self.playerY, self.playerX, NamedSymbol.A, NamedColor.blueviolet)
        
        # Place player projectiles at the appropriate positions
        for projectile in self.playerProjectiles:
            self.draw_symbol(projectile.yLoc, projectile.xLoc, NamedSymbol.lightning, NamedColor.yellow)
        
        # Place enemy projectiles at the appropriate positions
        for projectile in self.enemyProjectiles:
            self.draw_symbol(projectile.yLoc, projectile.xLoc, NamedSymbol.droplet, NamedColor.red)
        
        # Place enemies in the appropriate positions
        for enemy in self.enemies:
            self.draw_symbol(enemy.yLoc, enemy.xLoc, NamedSymbol.bug2, NamedColor.blueviolet)

    def generate_board_background(self):
        
        # TODO: Use the setBGColor() method and nested for loops to make the background of the board however you like.
        

    def place_enemies_on_board(self):
        # The starting vertical distance between the lowest enemies and the player
        player_enemy_starting_dist = 13
        # The starting horizontal distance between the rightmost enemies and the right wall
        enemy_right_wall_starting_dist = 6
        for i in range(self.board_height):
            for j in range(self.board_width):
                # Enemies can't spawn too far down
                if (i < self.board_height - player_enemy_starting_dist
                        # Or past a certain horizontal point
                        and j < self.board_width - enemy_right_wall_starting_dist):
                    # Within the safe area, spawn enemies in a checkerboard pattern
                    if (i + j) % 2 == 0:
                        self.enemies.append(Entity(j, i))

    def update_enemy_move_direction(self):
        for enemy in self.enemies:
            # If any enemy is at the right edge of the board
            if enemy.xLoc == self.board_width - 1:
                # If enemies were moving right
                if self.enemyMoveDirection == self.Direction.RIGHT:
                    # Update the move direction
                    self.enemyMoveDirection = self.Direction.DOWN
                else:
                    # Otherwise, they were moving down, so tell them to move left
                    self.enemyMoveDirection = self.Direction.LEFT
                # Stop iterating on enemies (to save operations and to simplify code somewhat)
                break
            # If any enemy is on the left edge of the board
            if enemy.xLoc == 0:
                if self.enemyMoveDirection == self.Direction.LEFT:
                    self.enemyMoveDirection = self.Direction.DOWN
                else:
                    self.enemyMoveDirection = self.Direction.RIGHT
                # Stop iterating on enemies (to save operations and to simplify code somewhat)
                break

    def move_player(self):
        # If the player has waited long enough between moves
        if self.playerMoveDelay == 0:
            # TODO: Move left if A is pressed or if left arrow is pressed
            
            # TODO: Move right if D is pressed or if right arrow is pressed
            
            # This line prevents the player from moving too quickly
            self.playerMoveDelay = self.TIME_BETWEEN_MOVES
        else:
            # Decrement playerMoveDelay
            if self.playerMoveDelay > 0: self.playerMoveDelay -= 1

    def player_fire(self):
        # Shoot if space is pressed and it has been long enough since the lasts shot
        if self.key_space() and self.shootDelay == 0:
            # TODO: Create a new Entity at the appropriate position and add it to the playerProjectiles array
            
            # Reset the shoot delay if the player fired
            self.shootDelay = self.TIME_BETWEEN_SHOTS
        else:
            if self.shootDelay > 0: self.shootDelay -= 1

    def move_enemies(self):
        # Move enemies if they should move
        if self.enemyMoveDelay == 0:
            # TODO: Every time this section of code is run, all enemies should move in the direction specified by the
            #   enemyMoveDirection variable. 
            
            # Update the next direction they should move in
            self.update_enemy_move_direction()
            # If they moved, reset their move delay
            self.enemyMoveDelay = self.TIME_BETWEEN_ENEMY_MOVES
        else:
            # Decrement move delay
            if self.enemyMoveDelay > 0: self.enemyMoveDelay -= 1
    
    def enemy_fire(self):
        # If the enemy shoot delay is zero, pick a random enemy and have them fire.
        if self.enemyShootDelay == 0 and self.enemies:
            
            # TODO: Select a random enemy from enemies and add a new Entity to enemyProjectiles with their coordinates.
            
            # Reset enemy shoot delay if they shot
            self.enemyShootDelay = self.TIME_BETWEEN_ENEMY_SHOTS
        else:
            # Decrement move delay
            if self.enemyShootDelay > 0: self.enemyShootDelay -= 1
    
    def move_projectiles(self):
        # Move all player projectiles up one space
        for projectile in self.playerProjectiles:
            if projectile.yLoc > 0:
                projectile.yLoc -= 1
            else:
                # If the projectile is at the top of the screen, delete it
                self.playerProjectiles.remove(projectile)
        
        # Move all enemy projectiles down one space if delay is zero
        if self.enemyShotMovementDelay == 0:
            for projectile in self.enemyProjectiles:
                if projectile.yLoc < self.board_height - 1:
                    projectile.yLoc += 1
                else:
                    # If the projectile is at the bottom of the screen, delete it
                    self.enemyProjectiles.remove(projectile)
            self.enemyShotMovementDelay = self.TIME_BETWEEN_ENEMY_SHOT_MOVEMENT
        else:
            # Decrement enemy shot movement delay
            if self.enemyShotMovementDelay > 0: self.enemyShotMovementDelay -= 1

    def check_projectile_collision(self):
        
        # TODO: If a player projectile and an enemy are in the same space, delete both
        
        # TODO: If an enemy projectile and the player are in the same space, end the game


def main():
    si = SpaceInvaders(41, "BRIDGES_USER_ID", "BRIDGES_API_KEY", 20, 15)
    si.set_title("Space Invaders")
    si.set_description("A game similar to Space Invaders, made with BRIDGES")
    si.start()


if __name__ == '__main__':
    main()
