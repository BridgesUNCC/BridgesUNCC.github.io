import bridges.base.NamedColor;
import bridges.base.NamedSymbol;
import bridges.games.*;

import java.util.ArrayList;

public class SpaceInvaders extends NonBlockingGame {

    public int playerX = 6;
    public int playerY = 19;
    public ArrayList<Entity> playerProjectiles = new ArrayList<>();
    public ArrayList<Entity> enemyProjectiles = new ArrayList<>();
    public ArrayList<Entity> enemies = new ArrayList<>();

    // The delays are used to time various actions.
    // They're set to a fixed value every time a command goes through, and decrement by one each frame.
    // If they aren't at 0, the action will not occur until they are.
    public int playerMoveDelay = 0;
    public int shootDelay = 0;
    public int enemyMoveDelay = 0;
    public int enemyShootDelay = 0;
    public int enemyShotMovementDelay = 0;

    // These are the delay between each move and each shot.
    // Measured in frames (game is 30 frames per second, ish).
    // Changing these is the easiest way to tweak the difficulty
    public final int TIME_BETWEEN_SHOTS = 10;
    public final int TIME_BETWEEN_MOVES = 10;
    public final int TIME_BETWEEN_ENEMY_MOVES = 35;
    public final int TIME_BETWEEN_ENEMY_SHOTS = 30;
    public final int TIME_BETWEEN_ENEMY_SHOT_MOVEMENT = 5;

    public enum Direction {
        DOWN,
        LEFT,
        RIGHT
    }

    public Direction enemyMoveDirection = Direction.RIGHT;

    public SpaceInvaders(int assid, String login, String apiKey, int cols, int rows) {
        super (assid, login, apiKey, cols, rows);
    }

    public void initialize() {
        // Generate the board background
        generateBoardBackground();

        // Place enemies
        placeEnemiesOnBoard();
    }

    public void gameLoop() {

        // Move the player if appropriate
        movePlayer();

        // Have the player character fire a projectile if appropriate
        playerFire();

        // Move the enemies if appropriate
        moveEnemies();

        // Have an enemy fire if appropriate
        enemyFire();

        // move projectiles forward if appropriate
        moveProjectiles();

        // Check for projectiles colliding with other things and handle those situations appropriately
        checkProjectileCollision();

        // Redraw the board to match the game state
        redrawBoard();
    }

    public static void main (String args[]) {
        SpaceInvaders si = new SpaceInvaders(41, "BRIDGES_USER_ID", "BRIDGES_API_KEY", 20, 15);
        si.setTitle("Space Invaders");
        si.setDescription("A game similar to Space Invaders, made with BRIDGES");
        si.start();
    }

    // Clears the board, then redraws it appropriately
    public void redrawBoard() {
        // Clear the board
        for (int i = 0; i < this.getBoardHeight(); i++){
            for (int j = 0; j < this.getBoardWidth(); j++){
                drawSymbol(i, j, NamedSymbol.none, NamedColor.blueviolet);
            }
        }
        // Place the player sprite at the location indicated by playerX and playerY
        drawSymbol(playerY, playerX, NamedSymbol.A, NamedColor.blueviolet);

        // Place player projectiles at the appropriate positions
        for (Entity projectile: playerProjectiles) {
            drawSymbol(projectile.yLoc, projectile.xLoc, NamedSymbol.lightning, NamedColor.yellow);
        }

        // Place enemy projectiles at the appropriate positions
        for (Entity projectile: enemyProjectiles) {
            drawSymbol(projectile.yLoc, projectile.xLoc, NamedSymbol.droplet, NamedColor.red);
        }

        // Place enemies in the appropriate positions
        for (Entity enemy: enemies) {
            drawSymbol(enemy.yLoc, enemy.xLoc, NamedSymbol.bug2, NamedColor.blueviolet);
        }
    }

    public void generateBoardBackground(){

        // TODO: Use the setBGColor() method and nested for loops to make the background of the board however you like.

    }

    public void placeEnemiesOnBoard(){
        // The starting vertical distance between the lowest enemies and the player
        final int PLAYER_ENEMY_STARTING_DIST = 13;
        // The starting horizontal distance between the rightmost enemies and the right wall
        final int ENEMY_RIGHT_WALL_STARTING_DIST = 6;
        for (int i = 0; i < this.getBoardHeight(); i++) {
            for (int j = 0; j < this.getBoardWidth(); j++) {
                // Enemies can't spawn too far down
                if (i < this.getBoardHeight() - PLAYER_ENEMY_STARTING_DIST
                        // Or past a certain horizontal point
                        && j < this.getBoardWidth() - ENEMY_RIGHT_WALL_STARTING_DIST) {
                    // Within the safe area, spawn enemies in a checkerboard pattern
                    if ((i + j) % 2 == 0) {
                        enemies.add(new Entity(j, i));
                    }
                }
            }
        }
    }

    public void updateEnemyMoveDirection(){
        for (Entity enemy: enemies) {
            // If any enemy is at the right edge of the board
            if (enemy.xLoc == this.getBoardWidth() - 1){
                // if enemies were moving right
                if (enemyMoveDirection == Direction.RIGHT) {
                    // Update the move direction
                    enemyMoveDirection = Direction.DOWN;

                } else {
                    // Otherwise, they were moving down, so tell them to move left
                    enemyMoveDirection = Direction.LEFT;
                }
                // Stop iterating on enemies (to save operations and to simplify code somewhat)
                break;
            }

            // If any enemy is on the left edge of the board
            if (enemy.xLoc == 0){
                // if enemies were moving left
                if (enemyMoveDirection == Direction.LEFT) {
                    // Update the move direction
                    enemyMoveDirection = Direction.DOWN;
                } else {
                    enemyMoveDirection = Direction.RIGHT;
                }
                // Stop iterating on enemies (to save operations and to simplify code somewhat)
                break;
            }
        }
    }

    public void movePlayer(){
        // If the player has waited long enough between moves
        if (playerMoveDelay == 0) {

            // TODO: Move left if A is pressed or if left arrow is pressed

            // TODO: Move right if D is pressed or if right arrow is pressed

            // This line prevents the player from moving too quickly
            playerMoveDelay = TIME_BETWEEN_MOVES;
        } else {
            // Decrement playerMoveDelay
            if (playerMoveDelay > 0) playerMoveDelay--;
        }
    }

    public void playerFire(){
        // Shoot if space is pressed and it's been long enough since the last shot
        if (keySpace() && shootDelay == 0){

            // TODO: Create a new PlayerProjectile at the appropriate position and add it to the playerProjectiles array

            // Reset the shoot delay if the player fired
            shootDelay = TIME_BETWEEN_SHOTS;
        } else {
            // Decrement shoot delay
            if (shootDelay > 0) shootDelay--;
        }
    }

    public void moveEnemies(){
        // Move enemies if they should move
        if (enemyMoveDelay == 0){

            /* TODO: Every time this section of code is run, all enemies should move in the direction specified by the
                      enemyMoveDirection variable. */


            // Update the next direction they should move in
            updateEnemyMoveDirection();
            // If they moved, reset their move delay
            enemyMoveDelay = TIME_BETWEEN_ENEMY_MOVES;
        } else {
            // Decrement move delay
            if (enemyMoveDelay > 0) enemyMoveDelay--;
        }
    }

    public void enemyFire(){
        // If the enemy shoot delay is zero and there is at least one enemy remaining
        if (enemyShootDelay == 0 && !enemies.isEmpty()) {

            // TODO: Select a random enemy from enemies and create a new enemyProjectile with their coordinates.

            // Reset enemy shoot delay if they shot
            enemyShootDelay = TIME_BETWEEN_ENEMY_SHOTS;
        } else {
            // Decrement move delay
            if (enemyShootDelay > 0) enemyShootDelay--;
        }
    }

    public void moveProjectiles(){
        // Move all player projectiles up one space
        for (int i = 0; i < playerProjectiles.size(); i++){
            if (playerProjectiles.get(i).yLoc > 0) {
                playerProjectiles.get(i).yLoc -= 1;
            } else {
                //If the projectile is at the top of the screen, delete it
                playerProjectiles.remove(i);
            }
        }

        // Move all enemy projectiles down one space if delay is zero
        if (enemyShotMovementDelay == 0) {
            for (int i = 0; i < enemyProjectiles.size(); i++) {
                if (enemyProjectiles.get(i).yLoc < this.getBoardHeight() - 1) {
                    enemyProjectiles.get(i).yLoc += 1;
                } else {
                    //If the projectile is at the bottom of the screen, delete it
                    enemyProjectiles.remove(i);
                }
            }
            enemyShotMovementDelay = TIME_BETWEEN_ENEMY_SHOT_MOVEMENT;
        } else {
            // Decrement enemy shot movement delay
            if (enemyShotMovementDelay > 0) enemyShotMovementDelay--;
        }
    }

    public void checkProjectileCollision(){

        // TODO: If a player projectile and an enemy are in the same space, delete both

        // TODO: If an enemy projectile and the player are in the same space, end the game
    }
}
