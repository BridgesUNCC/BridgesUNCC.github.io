public class Entity {
    public int xLoc;
    public int yLoc;
    public Entity(int xLoc, int yLoc){
        this.xLoc = xLoc;
        this.yLoc = yLoc;
    }
}
