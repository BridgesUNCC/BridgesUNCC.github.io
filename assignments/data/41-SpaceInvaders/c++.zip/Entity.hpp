struct Entity {
    int xLoc;
    int yLoc;
    Entity(int xLoc, int yLoc){
        this -> xLoc = xLoc;
        this -> yLoc = yLoc;
    }
};
