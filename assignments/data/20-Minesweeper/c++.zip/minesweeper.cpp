#include <NonBlockingGame.h>
#include <vector>
using namespace std;
using namespace bridges::game;
using namespace bridges;

class Minesweeper : public NonBlockingGame {
  public:
    Minesweeper(int assignmentID, std::string username, std::string apikey)
      : NonBlockingGame(assignmentID, username, apikey, 10, 10) {}

  protected:
    void initialize() {
      setTitle("Minesweeper");
    }

    void restart() {
      // TODO Restart the game state
    }

    void showAll() {
      // Show all cells
    }

    void handleInput() {
      // TODO handle user input
      // Allow the user to move a cursor on the board
      // Allow the user to select a cell to check for mines
      // Allow the user to flag a cell
      // Do not allow the user to click a flagged cell
      // Allow the user to restart the game
    }

    void showCell(int pos[2]) {
      // Show a cell at position
      // If the cell has no surrounding mines show all neighbors and recursively call on
      // neighbors that do not have any surrounding mines
    }

    void checkWin() {
      // Check if all cells have been shown that are not mines
    }

    void draw() {
      // Draw the game board
    }

    void gameLoop() {
      handleInput();
      draw();
      checkWin();
    }

};

int main() {
  Minesweeper nbg(120, "BRIDGES_USER_ID", "BRIDGES_API_KEY");

  nbg.start();

  return 0;
}
