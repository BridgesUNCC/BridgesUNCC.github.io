from bridges import *

import random
from datetime import datetime

class Minesweeper(NonBlockingGame):
    def __init__(self, assid, login, apikey):
        super(Minesweeper, self).__init__(assid, login, apikey, 10, 10)

    def initialize(self):
        self.set_title("Minesweeper")
        self.set_description("Controls -\nArrow Keys: Move\nSpace: Click\nQ: Restart\nS: Flag")

    def restart(self):
        # Reset the state of the game board

    def handle_input(self):
        # TODO handle user input
        # Allow the user to move a cursor on the board
        # Allow the user to select a cell to check for mines
        # Allow the user to flag a cell 
        # Do not allow the user to click a flagged cell
        # Allow the user to restart the game

    def show_cell(self, pos):
        # Show a cell at position
        # If the cell has no surrounding mines show all neighbors and recursively call on 
        # neighbors that do not have any surrounding mines

    def check_win(self):
        # Check if all cells have been shown that are not mines

    def draw(self):
        # Draw the game board

    def game_loop(self):
        self.handle_input()
        self.draw()
        self.check_win()

def main():
    game = Minesweeper(ASSIGNMENT_NUMBER, "BRIDGES_USER_ID", "BRIDGES_API_KEY")

    # Start the game
    game.start()

if __name__ == '__main__':
    main()