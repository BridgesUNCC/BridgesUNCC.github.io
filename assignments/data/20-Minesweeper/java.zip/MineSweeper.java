import bridges.games.NonBlockingGame;
import bridges.base.Grid;
import bridges.base.NamedColor;
import bridges.base.NamedSymbol;

public class MineSweeper extends NonBlockingGame {

  // set up default colors, symbols, positions, and sizes for the game grid
  static int numRows = 5;
  static int numCols = 5;
  NamedColor oldColor;
  NamedColor color = NamedColor.grey;
  NamedSymbol mine = NamedSymbol.bomb;
  NamedSymbol flag = NamedSymbol.flag;

  int numMines;

  boolean gameOver;

  int openCells = 0;

  public static void main(String args[]) {

    // Initialize our blocking game
    MineSweeper bg = new MineSweeper(20, "BRIDGES_USER_ID", "BRIDGES_API_KEY", numRows, numCols);
  }

  public MineSweeper(int assid, String login, String apiKey, int row,
                     int col) {
    super(assid, login, apiKey, row, col);

    start();
  }

  public void initialize() {
    setTitle("Minesweeper");
    setDescription("Keys:\nClick: Space\nRefresh: 'r'\nFlag: 'f'");
  }

  public void gameLoop() {
    // Handle each keypress
    handleKeypress();
  }

  // handle keypress events from the player
  public void handleKeypress() {
    // TODO handle user input
    // Allow the user to move a cursor on the board
    // Allow the user to select a cell to check for mines
    // Allow the user to flag a cell
    // Do not allow the user to click a flagged cell
    // Allow the user to restart the game
  }

  // Handle 'clicking' on a particular cell
  public void clickCell() {
    // Show a cell at position
    // If the cell has no surrounding mines show all neighbors and recursively call on
    // neighbors that do not have any surrounding mines
  }

  // add or remove a flag from the current cell selection
  public void flag() {

  }

  // Recursively visit a cell. If it has no adjacent mines, visit its neighbors.
  public void visitCell(int i, int j) {

  }

  // after losing, show all the mine positions
  public void highlightMines() {

  }

  // Move the current cell selection
  public void moveSelection() {

  }

  // reinitialize everything and start over
  public void restart() {

  }

  // see if all the mines have been flagged
  public void checkVictory() {
    // Check if all cells have been shown that are not mines
  }

  // you won! Show all the mines you found.
  public void victory() {

  }

  // Initialize positions, counts, and board states
  public void setupgg() {

  }

  // Initialize the state representation
  public void initializeState() {

  }

  // Initialize a new set of mines
  // 0 = empty, 1 = mine
  public void setupMines() {

  }
}
