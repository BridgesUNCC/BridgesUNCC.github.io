package STUDENT_PACKAGE;

import bridges.games.NonBlockingGame;
import bridges.base.Grid;
import bridges.base.NamedColor;
import bridges.base.NamedSymbol;

public class STUDENT_CLASS_NAME extends NonBlockingGame {

    // set up default colors, symbols, positions, and sizes for the game grid
    static int numRows = 5;
    static int numCols = 5;
    NamedColor oldColor;
    NamedColor color = NamedColor.grey;
    NamedSymbol mine = NamedSymbol.bomb;
    NamedSymbol flag = NamedSymbol.flag;

    int numMines;

    boolean gameOver;

    int openCells = 0;

    public static void main(String args[]) {

        // Initialize our blocking game
        STUDENT_CLASS_NAME bg = new STUDENT_CLASS_NAME(ASSIGNMENT_NUMBER, "Bridges_Username", "Profile_APIKey", numRows, numCols);
    }

    public STUDENT_CLASS_NAME(int assid, String login, String apiKey, int row, int col) {
        super(assid, login, apiKey, row, col);

        start();
    }

    public void initialize() {

    }

    public void gameLoop(){
        // Handle each keypress
        handleKeypress();
    }

    // handle keypress events from the player
    public void handleKeypress() {

    }

    // Handle 'clicking' on a particular cell
    public void clickCell() {

    }

    // add or remove a flag from the current cell selection
    public void flag() {

    }

    // Recursively visit a cell. If it has no adjacent mines, visit its neighbors.
    public void visitCell(int i, int j) {

    }

    // after losing, show all the mine positions
    public void highlightMines() {

    }

    // Move the current cell selection
    public void moveSelection() {

    }

    // reinitialize everything and start over
    public void restart() {

    }

    // see if all the mines have been flagged
    public void checkVictory() {

    }

    // you won! Show all the mines you found.
    public void victory() {

    }

    // Initialize positions, counts, and board states
    public void setupgg() {

    }

    // Initialize the state representation
    public void initializeState() {

    }

    // Initialize a new set of mines
    // 0 = empty, 1 = mine
    public void setupMines() {

    }
}