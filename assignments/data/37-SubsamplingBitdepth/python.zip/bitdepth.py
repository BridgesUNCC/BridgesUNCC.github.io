from bridges import AudioClip, Bridges

## Bitdepth class, handles conversion of audio
class Bitdepth:

    ## Converts audioclip into a lower bit, takes AudioClip object and the bitdepth needed for the outputted file
    def conversion(self, converting: AudioClip, bit_depth_num: int):
        changed_bit: AudioClip = AudioClip(sample_count=converting.get_sample_count(), num_channels=converting.get_num_channels(), sample_bits=bit_depth_num, sample_rate=converting.get_sample_rate())
        for channel in range(changed_bit.get_num_channels()):
            for sample in range(changed_bit.get_sample_count()):
                changed_bit.set_sample(channel, sample, (converting.get_sample(channel, sample) >> (32-bit_depth_num) ))
        
        return changed_bit

## Main method, controls declaration and use of variables
def main():
    ## TODO: Pass name and api key to bridges constructor
    bridges = Bridges(237, "Bridges-User", "Bridges-API-Key")
    ## TODO: Create bitdepth object
    

    file = "../audio.wav"
    ## TODO: Create a new Audioclip using file
    
    ##TODO Create objects for each bit depth using fileclip and the method provided, conversion()
    ## Hint: bitdepth object needed

    ##TODO: Pass each audioclip object to bridges.set_data_structure(), then call bridges.visualize()
    

if __name__ == '__main__':
    main()
