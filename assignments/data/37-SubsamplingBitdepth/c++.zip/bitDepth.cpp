#include "Bridges.h"
#include "AudioClip.h"
#include <iostream>
using namespace std;

using namespace bridges;

void convert(AudioClip& input_clip, AudioClip& output_clip, int bitdepth) {
	// TODO: Write a conversion function that takes as input an input 
	// audio clip and converts it into  another (output_clip) with lower
	// bit depth. YOu shoulde dmonstrate 24, 16 and 8 bit cases
}
int main(int argc, char **argv) {
	// Initialize Bridges
	Bridges bridges (137, "BRIDGES_USER_ID", "BRIDGES_API_KEY");

	// set title and description
    bridges.setTitle("Audio Wave - Bit Depth Variation");
    bridges.setDescription("Changing the bit depth of an audio clip");

	// TODO:Load an audio file into an audio clip
	string input_clip_file;

	// visualize and play the input audio to ensure its working

	// TODO
	// call the convert function for bit depths of 8, 16 and 24 bits and 
	// each time visualize and play the clips
	
}
