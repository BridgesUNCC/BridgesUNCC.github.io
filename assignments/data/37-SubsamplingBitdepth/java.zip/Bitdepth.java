
import java.io.IOException;

import bridges.base.AudioClip;
import bridges.connect.Bridges;
import bridges.validation.RateLimitException;



public class Bitdepth {
    // Default Constructor
    public Bitdepth() {

    }

    /**
     * Method for converting an audioclip from 32 bit to a lower bit depth
     * @param converting Audio clip object with the sound to convert
     * @param bitdepthnum The desired bit depth of the outputted clip
     * @return a new Audioclip object with the bitdepth changed
     */
    public AudioClip conversion(AudioClip converting, int bitdepthnum) {

        AudioClip changedBit = new AudioClip(converting.getSampleCount(), converting.getNumChannels(), bitdepthnum, converting.getSampleRate());

        for(int channel = 0; channel < changedBit.getNumChannels(); channel++) {

            for(int i = 0; i < changedBit.getSampleCount(); i++) {
                
                changedBit.setSample(channel, i, (converting.getSample(channel, i) >> (32-bitdepthnum)) );
            }
        }
        return changedBit;
    }

    

    /*
     * Main method, does all function calls needed for assignment
     */
    public static void main(String[] args) throws IOException, RateLimitException {
        //Creates bridges object
        // TODO pass your username and bridges api key to the constructor
        Bridges bridges = new Bridges(237, "BRIDGES_USER_NAME", "BRIDGES_API_KEY");
        // TODO Create a bitdepth object
        
        String file = "../audio.wav";
        //TODO Create a new AudioClip object using the file location
        
        //TODO Create AudioClip objects for each needed bitdepth by passing the previous Audioclip 
        // and a number for bitdepth to the method conversion.
        // Hint: the bitdepth object is needed
        
        //TODOO for each audioclip object, use bridges.setDataStructure(audioobject) and bridges.visualize() 
        
    }
}
