import random
from enum import Enum
from bridges import *


class Direction(Enum):
    NORTH = 1
    SOUTH = 2
    EAST = 3
    WEST = 4


class StudentClass(NonBlockingGame):
    gridColumns = 0
    gridRows = 0

    startX = 0
    startY = 0
    startLength = 0

    dir = Direction.NORTH
    lastDir = Direction.NORTH

    bg = NamedColor.forestgreen
    bc = NamedColor.green
    fg = NamedColor.silver
    hc = NamedColor.white
    mc = NamedColor.gray

    def handle_input(self):
        if self.key_left() and self.dir != Direction.EAST and self.lastDir != Direction.EAST:
            self.dir = Direction.WEST
        if self.key_up() and self.dir != Direction.SOUTH and self.lastDir != Direction.SOUTH:
            self.dir = Direction.NORTH
        if self.key_down() and self.dir != Direction.NORTH and self.lastDir != Direction.NORTH:
            self.dir = Direction.SOUTH
        if self.key_right() and self.dir != Direction.WEST and self.lastDir != Direction.WEST:
            self.dir = Direction.EAST

    def update_position(self):
        

    def place_mouse(self):
        

    def detect_mouse(self):
        

    def detect_death(self):
        

    def paint(self):
        col = 0
        row = 0
        while col < self.gridColumns:
            row = 0
            while row < self.gridRows:
                if col%2 == row%2:
                    self.set_bg_color(col, row, self.bg)
                else:
                    self.set_bg_color(col, row, self.bc)
        
    def initialize(self):
        col = 0
        row = 0
        while col < self.gridColumns:
            row = 0
            while row < self.gridRows:
                if col%2 and row%2:
                    self.set_bg_color(col, row, self.bg)
                else:
                    self.set_bg_color(col, row, self.bc)
                row+=1
            col+=1

    def game_loop(self):
        self.handle_input()
        self.lastDir = self.dir
        self.detect_mouse()
        self.update_position()
        self.paint()
        self.detect_death()

    def __init__(self, assid, login, apikey, cols, rows):
        super(StudentClass, self).__init__(assid, login, apikey, cols, rows)
        self.gridColumns = cols
        self.gridRows = rows


def main():
    my_game = StudentClass(80, "STUDENT_USERNAME", "STUDENT_API_KEY", 30, 30)
    my_game.start()


if __name__ == '__main__':
    main()
