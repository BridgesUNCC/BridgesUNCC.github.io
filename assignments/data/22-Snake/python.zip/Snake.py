import random
from enum import Enum
from bridges import *


class Direction(Enum):
    NORTH = 1
    SOUTH = 2
    EAST = 3
    WEST = 4


class StudentClass(NonBlockingGame):
    gridColumns = 0
    gridRows = 0

    startX = 0
    startY = 0
    startLength = 0

    dir = Direction.NORTH
    lastDir = Direction.NORTH

    bg = NamedColor.forestgreen
    bc = NamedColor.green
    fg = NamedColor.silver
    hc = NamedColor.white
    mc = NamedColor.gray

    def handle_input(self):
        if self.key_left() and self.dir != Direction.EAST and self.lastDir != Direction.EAST:
            self.dir = Direction.WEST
        if self.key_up() and self.dir != Direction.SOUTH and self.lastDir != Direction.SOUTH:
            self.dir = Direction.NORTH
        if self.key_down() and self.dir != Direction.NORTH and self.lastDir != Direction.NORTH:
            self.dir = Direction.SOUTH
        if self.key_right() and self.dir != Direction.WEST and self.lastDir != Direction.WEST:
            self.dir = Direction.EAST

    def initialize(self):
		# create the snake of some number of elements, 
		# perform all initializations, place the mouse
        pass


    def update_position(self):
		# Move the snake one position, based on its direction and update
		# the linked list

		# handle edge cases - check to make sure the snake
		# doesnt go off the edge of the board; can do a wrap around
		# in X or Y to handle it. Must handle all 4 directions the snake
		# might be traveling..
        pass

    def place_mouse(self):
		# randomly position the mouse, taking care to ensure that it doesnt
		# intersect with the snake position.
        pass

    def detect_mouse(self):
		# if mouse is found, snake consumes it and update the board and plant
		# a new mouse on the board.
        pass
        

	# check if snake ate itself! Yuk!
    def detect_death(self):
        pass
        

    def paint(self):
        # draw the board, the apple and the snake
        # make sure to choose colors so that snake and apple are clearly visible.

    # Game loop will run many times per second.
	# handle input, check if apple was detected, update position, redraw, 
    # detect if snake ate itself
    def game_loop(self):
        pass

    def __init__(self, assid, login, apikey, cols, rows):
        super(StudentClass, self).__init__(assid, login, apikey, cols, rows)
        self.gridColumns = cols
        self.gridRows = rows


def main():
    my_game = StudentClass(222, "BRIDGES_USER_ID", "BRIDGES_API_KEY", 30, 30)

    my_game.set_title("Snake")
    my_game.set_description("Snake: Eat the food, not yourself! Use the arrow keys to move.")
	
    my_game.start()


if __name__ == '__main__':
    main()
