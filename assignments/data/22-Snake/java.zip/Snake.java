package STUDENT_PACKAGE;

import bridges.base.NamedColor;
import bridges.base.NamedSymbol;
import bridges.games.NonBlockingGame;

class STUDENT_CLASS_NAME extends NonBlockingGame {

    java.util.Random random = new java.util.Random();
    static int gridColumns = 30;
    static int gridRows = 30;

    final long FRAMERATE = 1000000000 / 15;
    long frameTime;
    long nextFrameTime;

    NamedColor bg = NamedColor.forestgreen;
    NamedColor bc = NamedColor.green;
    NamedColor fg = NamedColor.silver;
    NamedColor hc = NamedColor.white;
    NamedColor ac = NamedColor.red;

    public STUDENT_CLASS_NAME(int assid, String login, String apiKey, int c, int r) {
        super(assid, login, apiKey, c, r);
    }

    public void handleInput() {

    }

    public void updatePosition() {

    }

    public void plantApple() {

    }

    public void detectApple() {

    }

    public void detectDeath() {

    }

    public void paint() {

    }

    // Set up the first state of the game grid
    public void initialize(){

    }

    // Game loop will run many times per second.
    public void gameLoop() {

    }

    public static void main(String args[]) {
        STUDENT_CLASS_NAME game = new STUDENT_CLASS_NAME(ASSIGNMENT_NUMBER, "Bridges_Username", "Profile_APIKey", gridColumns, gridRows);
        game.setTitle("snake");

        game.start();
    }
}

enum Direction {
    NORTH,
    SOUTH,
    EAST,
    WEST
}

class Block {
    public Block next;
    public int x;
    public int y;

    public Block() {
        this(-1, -1, null);
    }

    public Block(int x, int y) {
        this(x, y, null);
    }

    public Block(int x, int y, Block next) {
        this.x = x;
        this.y = y;
        this.next = next;
    }
}