import bridges.base.NamedColor;
import bridges.base.NamedSymbol;
import bridges.games.NonBlockingGame;

class Snake extends NonBlockingGame {

    java.util.Random random = new java.util.Random();
    static int gridColumns = 30;
    static int gridRows = 30;

    final long FRAMERATE = 1000000000 / 15;
    long frameTime;
    long nextFrameTime;

    NamedColor bg = NamedColor.forestgreen;
    NamedColor bc = NamedColor.green;
    NamedColor fg = NamedColor.silver;
    NamedColor hc = NamedColor.white;
    NamedColor ac = NamedColor.red;

	// constructor - set bridges credentials, grid size
    public Snake(int assid, String login, String apiKey, int c, int r) {
        super(assid, login, apiKey, c, r);
    }

	// user input related 
    public void handleInput() {

    }

	// update snake position
    public void updatePosition() {

    }

	// create a new apple (position)
    public void plantApple() {

    }

	// check if snake has found the apple
    public void detectApple() {

    }

	// check if snake ate itself! Yuk!
    public void detectDeath() {

    }

	// redraw
    public void paint() {

    }

    // Set up the first state of the game grid
    public void initialize(){

    }

    // Game loop will run many times per second.
	// handle input, check if apple was detected, update position, redraw, 
    // detect if snake ate itself
    public void gameLoop() {

    }

    public static void main(String args[]) {
        Snake game = new Snake(1, "BRIDGES_USER_ID", "BRIDGES_API_KEY", 
											gridColumns, gridRows);
        game.setTitle("Snake");

        game.start();
    }
}

enum Direction {
    NORTH,
    SOUTH,
    EAST,
    WEST
}

// helper class to hold snake and apple objects; not snake grows as it
// eats and hence a linked list of blocks
class Block {
    public Block next;
    public int x;
    public int y;

    public Block() {
        this(-1, -1, null);
    }

    public Block(int x, int y) {
        this(x, y, null);
    }

    public Block(int x, int y, Block next) {
        this.x = x;
        this.y = y;
        this.next = next;
    }
}
