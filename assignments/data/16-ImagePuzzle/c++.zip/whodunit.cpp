#include <iostream>
#include <fstream>
#include "image.h"
#include "Bridges.h"
#include "ColorGrid.h"

using namespace std;
using namespace bridges;

string numbers[6] = {
  "0.ppm",
  "3.ppm",
  "4.ppm",
  "5.ppm",
  "6.ppm",
  "7.ppm"
};

int main() {
  Image img("background.ppm");

  for (int i = 0; i < 6; i++) {
    Image num(numbers[i]);
    img.fitImage(num);
  }

  Bridges * bridges = new Bridges(116, "BRIDGES_USER_ID", "BRIDGES_API_KEY");
  bridges->setTitle("Pin Image");
  ColorGrid * cg = new ColorGrid(img.getHeight(), img.getWidth());
  bridges->setDataStructure(cg);

  // Draw to colorgrid
  for (int i = 0; i < img.getWidth() * img.getHeight(); i++) {
    int* pixel = img.getPixel(i % img.getWidth(), i / img.getWidth());
    cg->set(i / img.getWidth(), i % img.getWidth(), Color(pixel[0], pixel[1], pixel[2]));
  }
  bridges->visualize();

  return 0;
}
