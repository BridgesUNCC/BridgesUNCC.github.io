#ifndef IMAGE_H
#define IMAGE_H

#include <iostream>

using namespace std;

class Image {
    private:
        int width;
        int height;
        string header;
        int maxValue;
        int** colors;

    public:
        Image(string file);
        int getWidth();
        int getHeight();
        int* getPixel(int x, int y);
        void setPixel(int x, int y, int color[3]);
        void replaceColor(int color1[3], int color2[3]);
        void overlayImage(int x, int y, Image other);
        void fitImage(Image other);
};

#endif
