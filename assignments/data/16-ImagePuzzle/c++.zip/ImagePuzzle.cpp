#include <iostream>
#include <fstream>
#include "image.h"
#include "Bridges.h"
#include "ColorGrid.h"

using namespace std;
using namespace bridges;

string numbers[6] = {
  "0.ppm",
  "3.ppm",
  "4.ppm",
  "5.ppm",
  "6.ppm",
  "7.ppm"
};

int main() {
  Image img("background.ppm");

  for (int i = 0; i < 6; i++) {
    Image num(numbers[i]);
    img.fitImage(num);
  }

  Bridges * bridges = new Bridges(116, "BRIDGES_USER_ID", "BRIDGES_API_KEY");
  bridges->setTitle("Pin Image");
  bridges->setDescription("Solve the image puzzle by fitting the number images into the background image.");

  // TODO create an image using the background ppm image

  // TODO Loop through and create images for the number ppm images and fit them to the background

  // TODO Create a colorgrid and apply it as the datastructure to bridges

  // TODO Color the cologrid using the color values from the background image

  return 0;
}
