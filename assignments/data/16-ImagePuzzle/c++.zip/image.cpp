#include <iostream>
#include <fstream>
#include <array>
#include <vector>
#include "image.h"

using namespace std;

// Create a new Image object by reading a bmp file
Image::Image(string file) {
  // TODO: Read the ppm file at path into this image object
  // use header, width, height, maxvalue, and colors to store the data
}

// Replace all instances of a color with another color
//Colors are length 3 array that holds color values in the form {r, g, b} from 0-255
// @param color1 The color to replace
// @param color2 The new color to replace color1 with
void Image::replaceColor(int color1[3], int color2[3]) {
}

// Return true if the color is full white
bool isWhite(int color[3]) {
  return color[0] == 255 && color[1] == 255 && color[2] == 255;
}

// Overlay one image onto another using white as transparent
void Image::overlayImage(int x, int y, Image other) {
  // TODO: Overlay other image onto this image using white as transparent
}

// Fit one image into another so that no colors overlap
void Image::fitImage(Image other) {
  // TODO loop through this image and check for any points where
  // the other image will fit into this image using white as transparent
}

int Image::getWidth() {
  return width;
}

int Image::getHeight() {
  return height;
}

void Image::setPixel(int x, int y, int color[3]) {
  colors[x + y * width][0] = color[0];
  colors[x + y * width][1] = color[1];
  colors[x + y * width][2] = color[2];
}

int* Image::getPixel(int x, int y) {
  return colors[x + y * width];
}
