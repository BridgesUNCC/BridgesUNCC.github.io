from bridges import *;

class Image(object):
    header = ""
    width = 0
    height = 0
    maxValue = 0
    colors = []

    def __init__(self, path):
		# TODO: Read the ppm file at path into this image object
		# use header, width, height, maxvalue, and colors to store the data

    def fitImage(self, other):
        # TODO Fit the other image somewhere onto this image where there is no overalp
        # using white as transparent
        pass

    def overlayImage(self, x, y, other):
        # TODO Apply the other image's colors to this image using white as transparent
        pass

    @staticmethod
    def isWhite(color):
        return (color[0] == 255 and color[1] == 255 and color[2] == 255)

    def setPixel(self, x, y, color):
        self.colors[x + y * self.width] = color

    def getPixel(self, x, y):
        return self.colors[x + y * self.width]

numbers = [ "0.ppm", "3.ppm", "4.ppm", "5.ppm", "6.ppm", "7.ppm" ]

def main():
    bridges = Bridges(216, "BRIDGES_USER_ID", "BRIDGES_API_KEY")

    bridges.set_title("Image Puzzle")
    bridges.set_description("Solve the image puzzle by fitting the number images into the background image.")

    # TODO create an image using the background ppm image

    # TODO Loop through and create images for the number ppm images and fit them to the background

    # TODO Create a colorgrid and apply it as the datastructure to bridges

    # TODO Color the cologrid using the color values from the background image

    bridges.visualize()

if __name__ == '__main__':
    main()
