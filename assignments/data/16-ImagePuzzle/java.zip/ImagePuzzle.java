import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import bridges.validation.RateLimitException;
import bridges.connect.Bridges;
import bridges.base.Color;
import bridges.base.ColorGrid;

import java.io.BufferedReader;

class Image {
	private String header;
	private int width;
	private int height;
	private int maxValue;
	private ArrayList<ArrayList<Integer>> colors = new ArrayList<ArrayList<Integer>>();
	
	Image(String path) throws IOException {
		//TODO Read the ppm file at path into this image object
		// use header, width, height, maxvalue, and colors to store the data
	}
	
	int getWidth() {
		return width;
	}
	
	int getHeight() {
		return height;
	}
	
	ArrayList<Integer> getPixel(int x, int y) {
		return colors.get(x + y * width);
	}
	
	
	// Fit other image onto this image in a place where it does not overlap any colors
	// using white as transparent
	void fitImage(Image other) {
		// TODO loop through this image and check for any points where
		// the other image will fit into this image using white as transparent
	}

	// Apply other image's colors on top of this image using white as transparent
	private void overlayImage(int x, int y, Image other) {
		// Overlay other image onto this image using white as transparent
	}

	// Return true if the color has 255 for all values rgb
	private boolean isWhite(ArrayList<Integer> color) {
		return color.get(0) == 255 && color.get(1) == 255 && color.get(2) == 255;
	}
	
	private void setPixel(int x, int y, ArrayList<Integer> color) {
	    colors.set(x + y * width, color);
	}
}


public class ImagePuzzle {
	public static void main(String[] args) throws RateLimitException, IOException {
		// TODO: Create background image
		
		// Loop through number images and fit them onto background image
		
		// Initialize bridges and apply the background image's color onto a color grid then visualize
	}
}
