from bridges.bridges import *
from bridges.bst_element import *
from bridges.data_src_dependent.data_source import *
import sys

# recursive insert method to insert nodes into a binary search tree
def insertR(rt, newel):
    if (rt is None):
        return newel
    elif newel.key < rt.key:
        rt.left = insertR(rt.left, newel)
    else:
        rt.right = insertR(rt.right, newel)
    return rt


def main():
    # command line args provide credentials and server to test on
    args = sys.argv[1:]
    bridges = Bridges(36, "BRIDGES_USER_ID", "BRIDGES_API_KEY")

    # title, description
    bridges.set_title("A Binary Search Tree Example with Earthquake Data")
    bridges.set_description("This example illustrates retrieving USGS earthquake data records and inserted into a binary search tree. Attributes of the quake are displayed at each node.")

    # Retrieve a list of 25 earthquake records from USGS using the BRIDGES API

    MaxQuakes = 25
    quake_list = get_earthquake_usgs_data(MaxQuakes)

    root = None
    # create BST nodes and insert into a tree
    for i in range(len(quake_list)):
        bst_node = BSTElement(key=quake_list[i].magnitude, e=quake_list[i])

        # set label of the node
        bst_node.label = quake_list[i].title + quake_list[i].time

        # insert node into tree
        root = insertR(root, bst_node)

    # set some visual attributes
    root.color = "red"
    # TODO: Modify the insert function to color all the nodes, except the
    # root node to "blue"

    # TODO: Write a function to traverse the tree and highlight the 
    # largest quake (color it in a different color and set it to a larger
    # size (using the setSize(sz) size ranges 1-50


    # set visualizer type
    bridges.set_data_structure(root)
    # visualize the tree
    bridges.visualize()


if __name__ == "__main__":
    main()

