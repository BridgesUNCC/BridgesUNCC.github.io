
#include <string>
#include "Bridges.h"
#include "DataSource.h"
#include "data_src/EarthquakeUSGS.h"
#include "BSTElement.h"

using namespace std;
using namespace bridges;
using namespace bridges::dataset;

BSTElement<float, EarthquakeUSGS> *insert (BSTElement<float, 
	EarthquakeUSGS> *rt, BSTElement<float, EarthquakeUSGS> *new_el);

int max_quakes = 25;

int main(int argc, char **argv) {
	// create Bridges object
	// command line args provide credentials and server to test on
	Bridges bridges (105, "BRIDGES_USER_ID", "BRIDGES_API_KEY");

	// set title, description
	bridges.setTitle("A Binary Search Tree Example with Earthquake Data");
	bridges.setDescription("This example illustrates retrieving USGS earthquake data records and inserted into a binary search tree. Attributes of the quake are displayed at each node.");

	// get earthquake data
	DataSource *ds = new DataSource;
	vector<EarthquakeUSGS> eq_list = ds->getEarthquakeUSGSData(max_quakes);

	// create the binary tree root
	BSTElement<float, EarthquakeUSGS> *root = nullptr;

	// insert quake records into the tree
	// TODO: insert all the quakes into the tree by calling the insert() method

	// TODO: Modify the insert function to color all the nodes, except the
	//       root node.

	// TODO: Write a function to traverse the tree and highlight the 
	// largest quake (color it in a different color and set it to a larger
    // size (using the setSize(sz) size ranges 1-50

	// visualize the binary search tree -- uncomment these lines after 
	// you have implemented the functions

	// bridges.setDataStructure(root);
	// bridges.visualize();

	return 0;
}

// inserts a record into the tree
BSTElement<float, EarthquakeUSGS> *insert (
		BSTElement<float, EarthquakeUSGS> *rt,
		BSTElement<float, EarthquakeUSGS> *new_el) {
	if (rt == nullptr)
		return new_el;
	else if (new_el->getKey() < rt->getKey())
		rt->setLeft(insert(rt->getLeft(), new_el));
	else
		rt->setRight(insert(rt->getRight(), new_el));

	return rt;
}

