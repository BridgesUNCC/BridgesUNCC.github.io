from dictionary import Dictionary
from abc import ABC, abstractmethod
from bridges import *


class MyHeapElement(BinTreeElement):
    k = None
    count_left = 0
    count_right = 0

#Iterator object for Heaps
class MyHeapIter:
    #May need to adjust constructor
    def __init__(self, mh):
        self.mh = mh

    def __iter__(self):
        return self

    ##TODO
    def __next__(self):
        return None

    

class MyHeap(object):
    def __init__(self):
        self.root = None

    def __iter__(self):
        return MyHeapIter(self)

    ##TODO
    def insert(self, k, v):
        pass

    ##TODO
    def pop(self):
        pass



    #these functions are only there to enable the visualization
    def _update_labels(self):
        if self.root != None:
            self._update_labels_helper(self.root)

    def _update_labels_helper(self, lroot):
        lroot.label = str(lroot.k) + ", " + str(lroot.value)

        if lroot.left:
            self._update_labels_helper(lroot.left)

        if lroot.right:
            self._update_labels_helper(lroot.right)


    def visualize(self, bridges) -> None:
        self._update_labels()

        bridges.set_data_structure(self.root)
        bridges.visualize()
