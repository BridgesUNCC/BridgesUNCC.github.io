from abc import ABC, abstractmethod


class Dictionary(ABC):
    @abstractmethod
    def get(self, key):
        """
        returns the value of node at key
        :param key: key of node
        :return: value of node
        """
        pass

    @abstractmethod
    def set(self, key, value) -> None:
        """
        set node at key with value
        :param key: key of node
        :param value: new value of node
        :return: None
        """
        pass
