from dictionary import Dictionary
from abc import ABC, abstractmethod
from bridges.symbol_collection import *
from bridges.rectangle import *
from bridges.label import *
from bridges.polyline import *


class HashTableNode:
    def __init__(self, key, value):
        self.key = key
        self.value = value
        self.next = None

class HashTableIter:
    
    def __init__(self, ht):
        self.ht = ht

    def __iter__(self):
        return self

    ##TODO
    def __next__(self):
        return None
        
        
class HashTable(Dictionary, ABC):

    def __init__(self, capacity=30, load_factor=10):
        self._table = [None] * capacity
        self.capacity = capacity
        self.count = 0
        self.load_factor = load_factor

    def __iter__(self):
        return HashTableIter (self)

    ##TODO
    def get(self, key):
        return None


    ##TODO
    def set(self, key, value) -> None:
        pass
        

    #this function are only there to enable the visualization
    def visualize(self, bridges_inst):
        vis = SymbolCollection()

        for index, bucket in enumerate(self._table):
            x = 0
            y = 100 + (self.capacity - index) * 30
            bucket_rect = Rectangle(w=25, h=25, locx=x, locy=y)
            bucket_rect.fill_color = "white"
            vis.add_symbol(bucket_rect)
            bucket_label = Label()
            bucket_label.set_location(x, y)
            bucket_label.font_size = 12
            bucket_label.label = f'{index}'
            vis.add_symbol(bucket_label)
            x += 62.5
            while bucket is not None:
                bucket_rect = Rectangle(w=100, h= 25, locx=x, locy=y)
                bucket_rect.fill_color = "white"
                vis.add_symbol(bucket_rect)
                bucket_label = Label()
                bucket_label.set_location(x, y)
                bucket_label.font_size = 12
                bucket_label.label = f'{bucket.key}: {bucket.value}'
                vis.add_symbol(bucket_label)
                line = Polyline()
                line.add_point(x + 50, y)
                line.add_point(x + 150, y)
                line.add_point(x + 125, y - 12.5)
                line.add_point(x + 150, y)
                line.add_point(x + 125, y + 12.5)
                line.stroke_width = 1
                line.stroke_color = "red"
                vis.add_symbol(line)
                x += 200
                bucket = bucket.next

            bucket_rect = Rectangle(w=100, h=20, locx=x, locy=y)
            bucket_rect.fill_color = "white"
            vis.add_symbol(bucket_rect)
            bucket_label = Label()
            bucket_label.set_location(x, y)
            bucket_label.font_size = 12
            bucket_label.label = "∅"
            vis.add_symbol(bucket_label)

        bridges_inst.set_data_structure(vis)
        bridges_inst.visualize()
