from dictionary import Dictionary
from abc import ABC, abstractmethod


class StandardDictionary(Dictionary, ABC):

    def __init__(self):
        self.d = {}

    def __iter__(self):
        return self.d.items().__iter__()
        
    def get(self, key):
        """
        returns the value of node at key
        :param key: key of node
        :return: value or None
        """
        
        return self.d.get(key)
        
    def set(self, key, value) -> None:
        """
        set node at key with value
        :param key: key 
        :param value: value associated with key
        :return: None
        """
        self.d[key] = value
