from dictionary import Dictionary
from abc import ABC, abstractmethod
from bridges import *



#Iterator object for BSTs
class BSTIter:
    #May need to adjust constructor
    def __init__(self, bst):
        self.bst = bst

    def __iter__(self):
        return self

    #To implement
    def __next__(self):
        return None
        

class BSTDictionary(Dictionary, ABC):

    def __init__(self):
        self.root = None

    def __iter__(self):
        return BSTIter(self)


    ##TODO
    def get(self, key):
        pass
        

    ##TODO
    def set(self, key, value) -> None:
        pass

    
    def visualize(self, bridges) -> None:
        bridges.set_data_structure(bst_dictionary.root)
        bridges.visualize()
