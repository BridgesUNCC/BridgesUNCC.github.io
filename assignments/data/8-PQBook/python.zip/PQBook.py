from bridges import *

class MyHeapElement(BinTreeElement):
    k = None
    count_left = 0
    count_right = 0

class MyHeap(object):
    def __init__(self):
        self.root = None

    def _insert_helper(self, lroot, k, v):
        # TODO: Stopping condition: Deal with empty heap, aka lroot
	
        # TODO: Retain the smallest element in the localroot. so swap k,e with the root if necessary
        
        # TODO: push to the subtree with the fewer elements.
	
    def insert(self, k, v):
        self.root = self._insert_helper(self.root, k, v)

    def size(self):
        if self.root == None:
            return 0
        else:
            return 1 + self.root.count_left + self.root.count_right

    def update_labels(self):
        if self.root != None:
            self._update_labels_helper(self.root)

    def _update_labels_helper(self, lroot):
        lroot.label = str(lroot.k) + ", " + str(lroot.value)

        if lroot.left:
            self._update_labels_helper(lroot.left)

        if lroot.right:
            self._update_labels_helper(lroot.right)
        

def split_lyrics(lyrics):
    return lyrics.split(" ")

def main():
    # Initialize bridges with your credentials
    bridges = Bridges(ASSIGNMENT_NUMBER, "BRIDGES_USER_ID", "BRIDGES_API_KEY")

    # Set assignment details
    bridges.set_title("Priority Queue Book")
    bridges.set_description("MiniHeap represented as a Binary Tree.")

    # Get some shakespear poems
    shksp_list = get_shakespeare_data("poems", True)
    
    # Only retain first data
    pol = shksp_list[0]

    # Split the data string into a list
    words = split_lyrics(pol.text)

    # Count each instance of a word
    count = {}
    for w in words:
        if w in count.keys():
            count[w] += 1
        else:
            count[w] = 1

    my_heap = MyHeap()
    for k, v in count.items():
        my_heap.insert(v, k)

    my_heap.update_labels()

    bridges.set_data_structure(my_heap.root)
    bridges.visualize()


if __name__ == '__main__':
    main()