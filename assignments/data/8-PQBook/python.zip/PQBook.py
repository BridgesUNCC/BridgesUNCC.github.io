from bridges import *

from dictionary import Dictionary
from standard_dictionary import StandardDictionary
from hash_table import HashTable
from bst_dictionary import BSTDictionary
from my_heap import MyHeap

def split_lyrics(lyrics):
    return lyrics.split(" ")

def main():
    bridges = Bridges(208, "BRIDGES_USER_ID", "BRIDGES_API_KEY")

    # Set assignment details
    bridges.set_title("Priority Queue Book")
    bridges.set_description("MinHeap represented as a Binary Tree.")

    shksp_list = get_shakespeare_data("poems", True)
    pol = shksp_list[0]

    words = split_lyrics(pol.text)

    #my_dict = BSTDictionary()
    #my_dict = HashTable()
    my_dict = StandardDictionary()

    #TODO
    # compute the word count using one of dictionaries above
    for w in words:
        pass

    ##you can remove that comment to visualize your BSTdictionary or HashTable
    #my_dict.visualize(bridges)

    ##Getting the proper printout will require implementing the iterator logic for the dictionary
    for k, v in my_dict:
        print (str(k) + " " + str(v))


    ##remove that return when moving onto the heap part
    return


    k = 20

    #retain only top k elements
    # you can use heap to do  this by inserting the elements 
    # into the heap and then removing k elements

    my_heap = MyHeap()

    ##TODO
    for k, v in count.items():
        pass
        
    for k, v in my_heap:
        print (str(k) + " " + str(v))

            
    my_head.visualize(bridges)



if __name__ == '__main__':
    main()
