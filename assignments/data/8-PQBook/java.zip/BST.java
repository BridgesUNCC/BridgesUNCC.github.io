
import bridges.base.BSTElement;
import bridges.connect.Bridges;
import java.lang.Comparable;
import java.security.Key;

import java.util.Iterator;
import java.util.Map;
import java.util.AbstractMap;
import java.util.Stack;



public class BST<String extends Comparable<? super String>, Integer> implements Dictionary< String, Integer> {
    private BSTElement<String, Integer> root;

    ///TODO: Implement iterator logic for BST
    class BSTIterator implements Iterator<Map.Entry<String, Integer>>  {
	
	BSTIterator(BSTElement<String, Integer> r) {
	}

	public boolean hasNext() {
	    return false;
	}

	public Map.Entry<String, Integer> next() {
	    return  new AbstractMap.SimpleEntry<String, Integer> (null, null);
	}
    }
    
    public Iterator<Map.Entry<String, Integer>> iterator() {
	return new BSTIterator(root);
    }
    
    BST(){
    }

    //TODO
    @Override
    public Integer  get(String k) {
	return null;
    }

    //TODO
    @Override
    public void set(String k, Integer e) {

    }

    ///visualization function
    public void visualize (Bridges bridges) {
	if (root != null) {
	    bridges.setDataStructure(root);
	    try {
		bridges.visualize();
	    } catch (Exception e) {
		System.err.println ("Exception :" + e.getMessage());
	    }
	}
    }
}
