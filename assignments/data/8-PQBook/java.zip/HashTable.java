import bridges.base.Label;
import bridges.base.Polyline;
import bridges.base.Rectangle;
import bridges.base.SymbolCollection;
import bridges.connect.Bridges;
import bridges.validation.RateLimitException;
import java.util.Iterator;
import java.util.Map;
import java.util.AbstractMap;

import java.io.IOException;

public class HashTable implements Dictionary<String, Integer> {
    private Node[] table;
    private int capacity;
    private double loadFactor;
    private int count;

    //TODO: implement iterator logic
    class HashTableIterator implements Iterator<Map.Entry<String, Integer>> {
	HashTable ht;
	
	public boolean hasNext() {
	    return false;
	}
	
	public Map.Entry<String, Integer> next() {

	    return  new AbstractMap.SimpleEntry<String, Integer> (null, null);
	}

	public HashTableIterator(HashTable ht) {
	    this.ht = ht;
	}
	    
    }
    
    public Iterator<Map.Entry<String, Integer>> iterator() {
	return new HashTableIterator(this);
    }
    
    public HashTable() {
        this(30, 10.0);
    }

    public HashTable(int capacity) {
        this(capacity, 10);
    }

    public HashTable(int capacity, double loadFactor) {
        this.loadFactor = loadFactor;
        this.capacity = capacity;
        this.table = new Node[this.capacity];
        this.count = 0;
    }



    //TODO
    @Override
    public Integer get(String key) {

    }

    //TODO
    @Override
    public void set(String key, Integer value) {
    }



    //TODO
    private void resize(int capacity) {
    }

    //visualization function
    
    public void visualize(Bridges bridgesInstance) throws IOException, RateLimitException {
        SymbolCollection vis = new SymbolCollection();
        Rectangle rect;
        Label label;
        Polyline line;

	int maxx = 0;

	float label_width=100;
	float label_height=25;
	float spacing_width=50;

	
        for (int i = 0; i < this.table.length; ++i) {
            int x = 0;
            int y = (this.capacity - i) * 30;

            rect = new Rectangle(x, y, 25, 25);
            rect.setFillColor("white");
            vis.addSymbol(rect);

            label = new Label(String.valueOf(i));
            label.setLocation((float)(x+25/2.), (float)(y+25/2.));
            label.setFontSize(12);
            vis.addSymbol(label);

            x += 62.5;

            Node node = this.table[i];
            while (node != null) {
                rect = new Rectangle(x, y, label_width, label_height);
                rect.setFillColor("white");
                vis.addSymbol(rect);

                label = new Label(String.format("%s: %d", node.key, node.value));
                label.setLocation((float)(x+label_width/2.), (float)(y+label_height/2.));
                label.setFontSize(12);
                vis.addSymbol(label);

                line = new Polyline();
                line.addPoint((float)(x + label_width), (float)(y+label_height/2.));
                line.addPoint((float)(x + label_width+spacing_width), (float)(y+label_height/2.));
                line.addPoint((float)(x + label_width+3./4.*spacing_width), (float)(y) );
                line.addPoint((float)(x + label_width+spacing_width), (float)(y+label_height/2.));
                line.addPoint((float)(x + label_width+3./4.*spacing_width), (float)(y + label_height));
                line.setStrokeWidth(1);
                line.setStrokeColor("red");
                vis.addSymbol(line);

                x += label_width+spacing_width;
                node = node.next;
            }

	    if (x > maxx)
		maxx=x;
	    
            rect = new Rectangle(x, y, label_width, label_height);
            rect.setFillColor("white");
            vis.addSymbol(rect);

            label = new Label("null");
            label.setLocation((float)(x+label_width/2.), (float)(y+label_height/2.));
            label.setFontSize(12);
            vis.addSymbol(label);
        }

	vis.setViewport (-30.f, (float)(maxx+200), -30.f, (this.capacity+1)*30.f);
	
        bridgesInstance.setDataStructure(vis);
        bridgesInstance.visualize();
    }
}

class Node {
    public String key;
    public int value;
    public Node next;

    public Node(String key, int value) {
        this.key = key;
        this.value = value;
        this.next = null;
    }
}
