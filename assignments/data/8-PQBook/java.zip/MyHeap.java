import java.util.List;

/* Import Bridges and relevant data source */
import bridges.connect.Bridges;
import bridges.base.BinTreeElement;
import bridges.data_src_dependent.Shakespeare;

import java.util.List;
import java.util.HashMap;
import java.util.Map;
import java.util.AbstractMap;


class MyHeapElement<K extends Comparable, V> extends BinTreeElement<V> {
  public K k;
  public int sizeleft;
  public int sizeright;

}

class MyHeap<K extends Comparable, V> {
  public MyHeapElement<K, V> root;

  public boolean isEmpty() {
    return root == null;
  }

  /* TODO: Write insert here */
  private MyHeapElement<K, V> insert (MyHeapElement<K, V> lroot, K k, V v) {

    //TODO: Stopping condition: Deal with empty heap, aka lroot

    //TODO: Retain the smallest element in the localroot. so swap k,e with the root if necessary

    //TODO: push to the subtree with the fewer elements.

    return lroot;
  }

  public void insert(K k, V v) {
    root = insert(root, k, v);
  }

  private void pop(MyHeapElement<K, V> lroot) {
    //by convention, lroot has a descendant
    MyHeapElement<K, V> lc = (MyHeapElement<K, V>) lroot.getLeft();
    MyHeapElement<K, V> rc = (MyHeapElement<K, V>) lroot.getRight();

    //if one of the child is null
    if (lroot.sizeright == 0) {
      //pop left

      lroot.k = lc.k;
      lroot.setValue(lc.getValue());
      lroot.sizeleft --;
      if (lroot.sizeleft == 0)
        lroot.setLeft(null);
      else
        pop(lc);

      return;
    }

    if (lroot.sizeleft == 0) {
      //pop right

      lroot.k = rc.k;
      lroot.setValue(rc.getValue());
      lroot.sizeright --;
      if (lroot.sizeright == 0)
        lroot.setRight(null);
      else
        pop(rc);

      return;
    }

    //by construction both child are there.
    //so pop from the one storing the smallest element

    if (lc.k.compareTo(rc.k) < 0) {
      //pop left

      lroot.k = lc.k;
      lroot.setValue(lc.getValue());
      lroot.sizeleft --;
      if (lroot.sizeleft == 0)
        lroot.setLeft(null);
      else
        pop(lc);

    }
    else {
      //pop right
      lroot.k = rc.k;
      lroot.setValue(rc.getValue());
      lroot.sizeright --;
      if (lroot.sizeright == 0)
        lroot.setRight(null);
      else
        pop(rc);

    }
  }

  public Map.Entry<K, V> pop() {
    AbstractMap.SimpleEntry<K, V> en = new AbstractMap.SimpleEntry<K, V> (root.k, root.getValue());

    if (root.sizeright == 0 && root.sizeleft == 0)
      root = null;

    pop(root);

    return en;
  }

  public void updateLabels() {
    if (root != null)
      updateLabels(root);
  }

  public int size() {
    if (root == null)
      return 0;
    else
      return 1 + root.sizeleft + root.sizeright;
  }

  private void updateLabels(MyHeapElement<K, V> localRoot) {
    localRoot.setLabel(localRoot.k.toString() + ", " + localRoot.getValue().toString());

    if (localRoot.getLeft() != null)
      updateLabels((MyHeapElement<K, V>)(localRoot.getLeft()));

    if (localRoot.getRight() != null)
      updateLabels((MyHeapElement<K, V>)(localRoot.getRight()));
  }

}
