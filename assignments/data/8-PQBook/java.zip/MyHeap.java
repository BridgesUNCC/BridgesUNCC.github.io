import java.util.List;

// Import Bridges and relevant data source 
import bridges.connect.Bridges;
import bridges.base.BinTreeElement;
import bridges.data_src_dependent.Shakespeare;

import java.util.List;
import java.util.HashMap;
import java.util.Map;
import java.util.AbstractMap;
import java.util.Iterator;

import java.util.Stack;


class MyHeapElement<K extends Comparable, V> extends BinTreeElement<V> {
  public K k;
  public int sizeleft;
  public int sizeright;

}

class MyHeap<K extends Comparable, V> implements Iterable<Map.Entry<K,V>>{
  public MyHeapElement<K, V> root;


    //TODO: implement iteration logic for heaps
    class HeapIterator implements Iterator<Map.Entry<K, V>>  {
	
	HeapIterator(MyHeapElement<K, V> r) {
	}

	public boolean hasNext() {
	    return false;
	}

	public Map.Entry<K, V> next() {
	    
	    return new AbstractMap.SimpleEntry<K, V> (null, null);
	}
    }
    
    public Iterator<Map.Entry<K, V>> iterator() {
	return new HeapIterator(root);
    }
    
    //TODO
    public boolean isEmpty() {
	return true;
    }

    //TODO
    public void insert(K k, V v) {
	
    }

    //TODO
    public Map.Entry<K, V> pop() {
	AbstractMap.SimpleEntry<K, V> en = null;
	
	return en;
    }


    ///visualization features.
    public void visualize(Bridges bridges) {
	
	this.updateLabels();
	
	// Pass the data structure to Bridges
	bridges.setDataStructure(this.root);
	
	// Visualize the list
	try {
	    bridges.visualize();
	} catch (Exception e) {
	    System.err.println("exception: "+e.getMessage());
	}
    }

    
    protected void updateLabels() {
	if (root != null)
	    updateLabels(root);
    }


    private void updateLabels(MyHeapElement<K, V> localRoot) {
	localRoot.setLabel(localRoot.k.toString() + ", " + localRoot.getValue().toString());
	
	if (localRoot.getLeft() != null)
	    updateLabels((MyHeapElement<K, V>)(localRoot.getLeft()));
	
	if (localRoot.getRight() != null)
	    updateLabels((MyHeapElement<K, V>)(localRoot.getRight()));
    }
    
}
