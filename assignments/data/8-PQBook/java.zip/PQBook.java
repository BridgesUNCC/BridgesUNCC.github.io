// Import Bridges and relevant data source
import bridges.connect.Bridges;
import bridges.data_src_dependent.Shakespeare;
import bridges.base.*;

import java.util.List;

import java.util.Map;


    
public class PQBook {

  public static String[] splitLyrics(String lyrics) {       // splits raw lyrics string into a parsable array
    lyrics = lyrics.replaceAll("\\[.+\\]", "");         // removes the titles of song stage ex [Intro]
    lyrics = lyrics.trim();
    String[] lyricsSplit = lyrics.split("\\s+");

    for (int i = 0; i < lyricsSplit.length; i++) {          // clears special characters from individual terms
      lyricsSplit[i] = lyricsSplit[i].replaceAll("\\W+$", "");
      lyricsSplit[i] = lyricsSplit[i].replaceAll("^\\W+", "");
      lyricsSplit[i] = lyricsSplit[i].trim();
    }

    return lyricsSplit;
  }


  public static void main(String[] args) throws Exception {

    // Initialize a Bridges connection with your credentials
    Bridges bridges = new Bridges(8, "BRIDGES_USER_ID", "BRIDGES_API_KEY");
    
    // Set an assignment title
    bridges.setTitle("PQBook");
    bridges.setDescription("MinHeap represented as a Binary Tree.");

    List<Shakespeare> shksp_list = bridges.getDataSource().getShakespeareData("poems", true);

    //Retain only the first text
    Shakespeare po1 = shksp_list.get(0);

    //System.out.println(po1.getText());

    // Tokenize
    String[] wordlist = splitLyrics(po1.getText());

    for (int i=0; i<wordlist.length; ++i)
	System.out.println(wordlist[i]);




    StandardDictionary<String,Integer> my_dict = new StandardDictionary<String, Integer>();
    HashTable my_dicthash = new HashTable();
    //BST<String, Integer> my_dict = new BST<String, Integer>();
    

    //TODO
    for (String word : wordlist) {
    }

    //my_dict.visualize(bridges);

    
    for (Map.Entry<String,Integer> e : my_dict) {
	System.out.println(e.getKey() + " "+e.getValue());
    }


    
    //activate to work on heap part.
    if (false) {
	
	//building the heap
	MyHeap<Integer, String> mh = new MyHeap<Integer, String>();

	int k = 20;
	
	//TODO: Use a heap to extract the top k words.
	for (Map.Entry<String, Integer> e : my_dict) {
	}

	for (Map.Entry<Integer,String> e : mh) {
	    System.out.println(e.getKey() + " "+e.getValue());
	}
    	
	mh.visualize(bridges);
    }
  }
}
