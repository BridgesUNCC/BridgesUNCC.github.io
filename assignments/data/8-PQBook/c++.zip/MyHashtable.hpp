#ifndef _MY_HASHTABLE_H
#define _MY_HASHTABLE_H

#include <functional>
#include <iostream>
#include <vector>
#include <SymbolCollection.h>
#include <Label.h>
#include <Polyline.h>
#include <Rectangle.h>
#include <Bridges.h>

template<class K, class V>
struct Node {
  K key;
  V value;
  Node* next;
  
  Node(const K& key, const V& value)
    : key(key), value(value), next(nullptr)
  {}
  
  Node() = default;
};

template<class K, class V>
class MyHashtable : public Dictionary<K, V> {
protected:
  typedef typename Dictionary<K, V>::dict_iter dict_iter;

  //TODO: You'll certainly need some variables and a constructor and destructor.
  
  
  //TODO: Implement a hashtable iterator with these functions
  struct hashtable_iter : public dict_iter {
    
    virtual bool operator==(dict_iter& ite) {
    }
    virtual bool operator!=(dict_iter& ite) {
    }
    virtual dict_iter& operator++() {
    }
    virtual std::pair<K,V> operator*() {
    }
  };
  


public:
  /**
   * Returns the node at key
   * @param key key of node to get
   * @return node of type Node at key
   */
  virtual V get(const K& key) const {
    //TODO
  }
  /**
   * sets the value of node at key with value
   * @param key key of node to be set
   * @param value new value of node
   */
  virtual void set(const K& key, const V& value) {
    //TODO
  }

  void visualize(bridges::Bridges& bridges_inst) {
    //TODO: Implement a way to visualize the hash table using Bridges Symbol Collection.

  }
  
  virtual std::unique_ptr<dict_iter> realBegin() {
    //TODO
  }
  
  virtual std::unique_ptr<dict_iter> realEnd() {
    //TODO
  }
};

#endif
