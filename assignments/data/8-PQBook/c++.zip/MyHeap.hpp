#ifndef MYHEAP__
#define MYHEAP__


template<typename K, typename E>
class MyHeapElement : public BinTreeElement< E> {
public:
  K k;
  

  int countleft;
  int countright;

  MyHeapElement()
    : countleft(0), countright(0){
  }

  virtual const string getElementRepresentation() const override {
    string json = Element<E>::getElementRepresentation();
    stringstream conv;
    conv << k;
    return json.insert(
		       json.size() - 1,
		       COMMA + QUOTE + "key" + QUOTE + COLON + QUOTE + conv.str() +
		       QUOTE
		       );
  }

};


//this builds a min heap
template<typename K, typename E>
class MyHeap {
public:

  MyHeapElement<K, E>* root;

  static void updateLabels(MyHeapElement<K, E>* localroot) {
    localroot->setLabel(localroot->getValue()); //this assumes E can be implicitely casted to string.

    if (localroot->countright != 0)
      updateLabels((MyHeapElement<K, E>*)localroot->getRight());
    if (localroot->countleft != 0)
      updateLabels((MyHeapElement<K, E>*)localroot->getLeft());

  }

  
  static MyHeapElement<K, E>* pop(MyHeapElement<K, E>** localroot) {
    if ((*localroot)->countleft == 0 && (*localroot)->countright == 0) {
      delete *localroot;
      *localroot = nullptr;
      
      return *localroot;
    }

    MyHeapElement<K, E>* lc = (MyHeapElement<K, E>*) (*localroot)->getLeft();
    MyHeapElement<K, E>* rc = (MyHeapElement<K, E>*) (*localroot)->getRight();

    //defining local pops
    auto popright = [&]() -> void{
      (*localroot)->k = rc->k;
      (*localroot)->setValue(rc->getValue());
      (*localroot)->countright --;
      pop(&rc);
      (*localroot)->setRight(rc);
    };

    auto popleft = [&]()-> void{
      (*localroot)->k = lc->k;
      (*localroot)->setValue(lc->getValue());
      (*localroot)->countleft --;
      pop(&lc);
      (*localroot)->setLeft(lc);
    };

    //if one of the subtree is empty, need to pop from the other one
    if ((*localroot)->countleft == 0) {
      popright();
      return *localroot;
    }

    if ((*localroot)->countright == 0) {
      popleft();
      return *localroot;
    }

    //both subtrees contain something, pop from the one with the lowest key
    if (lc->k < rc->k) popleft();
    else popright();
    return *localroot;			 
  }
   
  
  /* TODO: Write insert here */
  static MyHeapElement<K,E>* insert(MyHeapElement<K, E>** localroot,
				    K k, E e) {
    
    //TODO: Stopping condition: Deal with empty heap, aka *localroot == nullptr
    
    
    //TODO: Retain the smallest element in the localroot. so swap k,e with the root if necessary

    
    //TODO: push to the subtree with the fewer elements.

    return (*localroot);
  }
  
  MyHeap()
    :root(nullptr){
  }
  

  void insert(const K& k, const E& e) {
    insert (&root, k, e);
  }

  int count() const {
    if (empty()) return 0;
    
    return 1+root->countleft + root->countright;
  }
  
  bool empty() const {
    return root == nullptr;
  }

  void updateLabels() {
    updateLabels(root);
  }
  
  std::pair<K,E> pop () {
    std::pair<K,E> p = {root->k, root->getValue()};

    //perform actual pop here
    pop(&root);
    
    return p;
  }
  
};

#endif
