from bridges import *


class ControlsTutorial(NonBlockingGame):
    def __init__(self, assid, login, apikey):
        super(ControlsTutorial, self).__init__(assid, login, apikey, 6, 6)

    def initialize(self):
        self.draw_symbol(0, 2, NamedSymbol.J, NamedColor.black)
        self.draw_symbol(0, 3, NamedSymbol.P, NamedColor.black)
        self.draw_symbol(1, 2, NamedSymbol.S, NamedColor.black)
        self.draw_symbol(1, 3, NamedSymbol.P, NamedColor.black)
        self.draw_symbol(2, 2, NamedSymbol.J, NamedColor.black)
        self.draw_symbol(2, 3, NamedSymbol.N, NamedColor.black)
        self.draw_symbol(2, 4, NamedSymbol.P, NamedColor.black)
        self.draw_symbol(3, 2, NamedSymbol.S, NamedColor.black)
        self.draw_symbol(3, 3, NamedSymbol.N, NamedColor.black)
        self.draw_symbol(3, 4, NamedSymbol.P, NamedColor.black)

        self.draw_symbol(4, 2, NamedSymbol.F, NamedColor.black)

    # Loop through each column (0 to 5) and row (0 to 5) to set the background color of the grid
    # Iterate over columns
    # Iterate over rows
    # Set the background color to white for each cell

    # Check if the 'up' key was just pressed, and draw a symbol based on that
    # Draw an 'X' at position (0, 0) if the 'up' key was just pressed
    # Clear the symbol if the 'up' key wasn't just pressed

    # Check if the 'up' key is still pressed, and draw a symbol based on that
    # Draw an 'X' at position (1, 0) if the 'up' key is still pressed
    # Clear the symbol if the 'up' key isn't still pressed

    # Check if the 'up' key was just released, and draw a symbol based on that
    # Draw an 'X' at position (2, 0) if the 'up' key was just released
    # Clear the symbol if the 'up' key wasn't just released

    # Check if the 'up' key is still not pressed, and draw a symbol based on that
    # Draw an 'X' at position (3, 0) if the 'up' key is still not pressed
    # Clear the symbol if the 'up' key is still pressed

    # Check if the fire button (likely another key) is pressed, and draw a symbol based on that
    # Draw an 'X' at position (4, 0) if the fire button is pressed

    # Clear the symbol if the fire button isn't pressed


def main():
    my_game = ControlsTutorial(267, "BRIDGES_USER_ID", "BRIDGES_API_KEY")
    my_game.set_title("My First Game!")
    my_game.set_description("Test out your controls here")
    my_game.start()


if __name__ == '__main__':
    main()

