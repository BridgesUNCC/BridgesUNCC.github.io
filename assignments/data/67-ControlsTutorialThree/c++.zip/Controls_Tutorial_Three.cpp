#include <NonBlockingGame.h>
#include <iostream>

using namespace bridges::game;

struct my_game : public NonBlockingGame {

  my_game(int assID, std::string username, std::string apikey)
    : NonBlockingGame (assID, username, apikey, 6, 6) {
    setTitle("My First Game!");
    setDescription("Test out your controls here");
  }

  virtual void initialize() override {
      drawSymbol(0, 2, NamedSymbol::J, NamedColor::black);
      drawSymbol(0, 3, NamedSymbol::P, NamedColor::black);
      drawSymbol(1, 2, NamedSymbol::S, NamedColor::black);
      drawSymbol(1, 3, NamedSymbol::P, NamedColor::black);
      drawSymbol(2, 2, NamedSymbol::J, NamedColor::black);
      drawSymbol(2, 3, NamedSymbol::N, NamedColor::black);
      drawSymbol(2, 4, NamedSymbol::P, NamedColor::black);
      drawSymbol(3, 2, NamedSymbol::S, NamedColor::black);
      drawSymbol(3, 3, NamedSymbol::N, NamedColor::black);
      drawSymbol(3, 4, NamedSymbol::P, NamedColor::black);

      drawSymbol(4, 2, NamedSymbol::F, NamedColor::black);
  }

// Method to update the game state based on user inputs
// Reset the background color of each cell in the grid to white at the start of each loop
virtual void gameLoop() override {
  
    }

 

    // Check if the "Up" key was just pressed
      // Display an "X" symbol at (0, 0) when "Up" key is just pressed
      // Clear the symbol at (0, 0) if "Up" key is not just pressed

    // Check if the "Up" key is still being held down
      // Display an "X" symbol at (1, 0) while "Up" key is held down
      // Clear the symbol at (1, 0) if "Up" key is no longer held down

    // Check if the "Up" key was just released
      // Display an "X" symbol at (2, 0) when "Up" key is just released
      // Clear the symbol at (2, 0) if "Up" key is not just released

    // Check if the "Up" key has been released and is no longer pressed
      // Display an "X" symbol at (3, 0) when "Up" key is not pressed
      // Clear the symbol at (3, 0) if "Up" key is pressed again

    // Check if the "Up" key action should trigger a special action
      // Display an "X" symbol at (4, 0) to represent a special action trigger
      // Clear the symbol at (4, 0) if the special action is not triggered

  
};

int main (int argc, char** argv) {
  my_game g(167, "BRIDGES_USER_ID", "BRIDGES_API_KEY");

  g.start();
}

