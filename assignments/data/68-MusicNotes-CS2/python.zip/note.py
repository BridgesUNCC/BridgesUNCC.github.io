from enum import Enum
from math import sin, pi, floor
from bridges import AudioClip


class Note:
    """This class handles everthing relating to the Notes themselves
    """    
    class NoteFreq(Enum):
        """this enum handles frequencies for notes
        """
        C = 16.35
        D = 18.35
        E = 20.60
        F = 21.83
        G = 24.50
        A = 27.50
        B = 30.87
        R = 0.0

        def getHZ(self, octave: int, accidental) -> float:
            """this gets the HZ value for the note for a selected octave

            Args:
                octave (int): which octave to get the HZ for
                accidental (Note.Accidental): if the note is Sharp or Flat (or natural)

            Returns:
                float: hz value for selected note 
            """
            if(accidental == Note.Accidental.NATURAL):
                return self.value * (2 ** octave)
            elif(accidental == Note.Accidental.FLAT):
                return (self.value - 1) * (2 ** octave)
            elif(accidental == Note.Accidental.SHARP):
                return (self.value + 1) * (2 ** octave)
            else:
                return 0
            
    class Accidental(Enum):
        """this Enum handles naturals, sharps and flats
        """
        NATURAL = 0
        SHARP = 1
        FLAT = 2
    
    note: NoteFreq
    length: float
    octave: int
    accidental: Accidental
    repeat: bool
    
    def __init__(self, length: float, note: NoteFreq, octave: int, accidental: Accidental, repeat: bool) -> None:
        """Constructor for a note class

        Args:
            length (float): the duration in seconds of a note
            note (NoteFreq): the key of the note
            octave (int): which octave the note should be in
            accidental (Accidental): is the note sharp or flat
            repeat (bool): True to flag the Note with repeat
        """
        self.length = float(length)
        self.note = note
        self.octave = int(octave)
        self.accidental = accidental
        self.repeat = repeat == "true"
    
    def getLength(self) -> float:
        """a Getter for the length property

        Returns:
            float: length of the note
        """
        return self.length
    
    def generateSineSample(self, amplitude: float, time: float) -> int:
        """find the value of the sin wave at a certain time

        Args:
            amplitude (float): amplitude of the sine wave
            time (float): time to sample at

        Returns:
            int: the value of the sine wave given the properties
        """
        frequency = self.note.getHZ(self.octave, self.accidental)
        val = sin((2 * pi) * frequency * time)
        return int(val * amplitude)
    
    def getHZ(self) -> float:
        """gets the HZ value for this note

        Returns:
            float: the HZ of the note
        """           
        return self.note.getHZ(self.octave, self.accidental)
    
    def addToClip(self, ac: AudioClip, start: float, volume: float):
        """this will add the note to the audioClip

        Args:
            ac (AudioClip): the audio clip to add to
            start (float): the time to start at
            volume (float): how loud to add it
        """
        amplitudeMultiplier = (((2 ** 32) / 2) - 1) * volume
        frequency = self.getHZ()
        period = ac.get_sample_rate() / frequency
        end = start + self.length
        firstSample = int(start * ac.get_sample_rate())
        lastSample = int(end * ac.get_sample_rate()) -1
        for i in range(firstSample, lastSample):
            time = float(i) / ac.get_sample_rate()
            sampleValue = self.generateSineSample(amplitudeMultiplier, time)
            ac.set_sample(0, i, sampleValue)
        #Last sample should be a 0 to prevent popping noises 
        lastSample = int(period * floor(lastSample/period))
        ac.set_sample(0, int(end * period), lastSample)