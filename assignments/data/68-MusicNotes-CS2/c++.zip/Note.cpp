#include "AudioClip.h"
#include <math.h>       /* pow */
#include <cstring>
#include <iostream>

using namespace std;
using namespace bridges;

/**
 * This class handles everything relating to the Notes themselves
*/
class Note {
    public:
        /**
         * this enum provedes the ability to store which accidental the note is
        */
        enum Accidental {
            NATURAL,
            SHARP,
            FLAT
        };

        /**
         * this finds the accidental thats in a string
         * param: str the string to check
         * return: the accidental the string is 
        */
        static Accidental valueOF(string str){
            for (auto & c: str) c = toupper(c);
            cout << str << endl;
            cout << "A: " << str << endl;
            if(str == "SHARP"){
                return Accidental::SHARP;
            } else if(str == "FLAT"){
                return Accidental::FLAT;
            } else {
                return Accidental::NATURAL;
            } 
        };
        /**
         * this class handles frequencys and relates them to notes
        */
        class NoteFreq{
            public:
                //these are 100 higher than in the other languages because c++ enum doesnt support float types
                enum Value {
                        C = 1835,
                        D = 1835,
                        E = 2060,
                        F = 2183,
                        G = 2450,
                        A = 2750,
                        B = 3087,
                        R = 0
                };
                /**
                 * get the enum out of a string
                */
                static Value valueOF(string str){
                    for (auto & c: str) c = toupper(c);
                    if(str == "A"){
                        return Value::A;
                    } else if(str == "B"){
                        return Value::B;
                    } else if(str == "C"){
                        return Value::C;
                    } else if(str == "D"){
                        return Value::D;
                    } else if(str == "E"){
                        return Value::E;
                    } else if(str == "F"){
                        return Value::F;
                    } else if(str == "G"){
                        return Value::G;
                    }  else {
                        return Value::R;
                    }
                }
                NoteFreq() = default;
                constexpr NoteFreq(Value freq) : value(freq) {}
                constexpr operator Value() const { return value; }

                //division by 100 in this method is to revert the fix to c++ enum not supporting float
                double getHz(int octave, Accidental accidental){
                    
                    switch (accidental)
                    {
                    case NATURAL:
                        return (value/100) * pow(2, octave);
                    case FLAT:
                        return ((value/100) -1) * pow(2, octave);
                    case SHARP:
                        return ((value/100) + 1) * pow(2, octave);
                    default:
                        return 0.0;
                    }
                }

            private:
                Value value;

        };
        Note(double length, NoteFreq note, int octave, Accidental accidental, bool repeat){
            Note::length = length;
            Note::note = note;
            Note::octave = octave;
            Note::accidental = accidental;
            Note::repeat = repeat;
        };
        bool getRepeat(){
            return repeat;
        };
        double getLength(){
            return length;
        }
        /**
         * this method adds the note to an audio clip using the HZ values
        */
        void addToClip(AudioClip& ac, double start, double volume){
            double amplitudeMultiplier = ((pow(2,32)/2.0)-1.0)*volume;
            double frequency = getHz();
            double period = ac.getSampleRate() / frequency;
            double end = start + length;
            int firstSample = (int)(start * ac.getSampleRate());
            int lastSample = (int)(end * ac.getSampleRate()) - 1;
            for (int i = firstSample; i < lastSample; i++){
                double time = (double)i / ac.getSampleRate();
                int sampleValue = generateSineSample(amplitudeMultiplier, time);
                ac.setSample(0,i,sampleValue);
            }
            //Last sample should always be 0 to prevent popping noises
            lastSample = (int) (period * floor(lastSample/period));
            ac.setSample(0, (int) (end*ac.getSampleRate()), lastSample);
        }



    private:
        /**
         * gets the hz value of the note
        */
        double getHz(){
            return note.getHz(octave, accidental);
        };
        /**
         * finds the output of a sine function for a given time
        */
        int generateSineSample(double amplitude, double time){
            double frequency = getHz();
            double val = sin((2*M_PI) * frequency * time);
            //cout << (int) (val*amplitude) << " | " << val << " | " << amplitude << " | " << frequency << endl;
            return (int) (val * amplitude);
        };
        NoteFreq note;
        double length;
        int octave;
        Accidental accidental;
        bool repeat;
};