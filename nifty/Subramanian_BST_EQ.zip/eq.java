
//
// SimpleDriver.java : Driver to illustrate importing USGS earthquake data
// 
import bridges.connect.Bridges;
import bridges.base.BSTElement;
import bridges.data_src_dependent.EarthquakeUSGS;
import bridges.data_src_dependent.Tweet;
import bridges.data_src_dependent.USGSaccount;
import java.util.List;

public class eq {
	public static final int maxElements = 50; //number of tweets

	public static void main(String[] args) throws Exception {
	
  					// Instantiate a Bridges object */
		Bridges<Double, EarthquakeUSGS> bridges = new Bridges<Double, 
			EarthquakeUSGS>(99, "997924677918", "bridges_public");
					// set visualization title
		bridges.setTitle("Recent Earthquakes(USGIS Data)");
					// Set up the earthquake user 
		USGSaccount name = new USGSaccount( "earthquake" ); 
					// Retrieve a list of (maxElements) earthquake records 
		List<EarthquakeUSGS> eqlist = Bridges.getAssociations(name, maxElements );
					// create a binary search tree object
		BST<Double, EarthquakeUSGS>  bst = new BST<Double, EarthquakeUSGS>();
					// insert the records into the binary search tree
		for ( int i = 0; i < eqlist.size(); i++ ){
			bst.insert(eqlist.get(i).getMagnitude(), eqlist.get(i));
		}
					// provide BRIDGES a handle to the tree root
		bridges.setDataStructure(bst.getTreeRoot());
					// visualize the tree and earthquake data
		bridges.visualize();
    }
}
