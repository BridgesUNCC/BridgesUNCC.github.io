package program2_1;

import bridges.base.BSTElement;
import bridges.data_src_dependent.EarthquakeUSGS;
import bridges.data_src_dependent.Tweet;

/** Binary Search Tree implementation for Dictionary ADT */
class earthquakeTree extends BridgesBST<Double, EarthquakeUSGS> {
	public void setNodeAttributes() {
		setNodeAttributes( root );
	}
	
	private void setNodeAttributes( BSTElement r ) {
		if( r == null )
			return;
		
		double magnitude = 0.0;
		String nodeColor = "";
		String shape = "";
		
		
		magnitude = ( (EarthquakeUSGS) r.getValue()).getMagnitude();
		
		if(magnitude > 5.0) {
			nodeColor = "red";
			shape = "circle";
		} else if( magnitude > 2.0 ) {
			nodeColor = "orange";
			shape = "square";
		} else {
			nodeColor = "yellow";
			shape = "triangle-up";
		}
		
		r.getVisualizer().setColor(nodeColor);
		r.getVisualizer().setShape(shape);
		
		setNodeAttributes( r.getLeft() );
		setNodeAttributes( r.getRight() );
	}
	
	public void setLabels() {
		setLabels( root );
	}
	
	private void setLabels( BSTElement r ) {
		if( r == null ) 
			return;
		
		String label = "";
		label += ( (EarthquakeUSGS) r.getValue() ).getLocation() + "\n";
		label += ( (EarthquakeUSGS) r.getValue() ).getDate() + "\n";
		label += ( (EarthquakeUSGS) r.getValue() ).getMagnitude() + "\n";
		
		
		r.setLabel( label );
		setLabels( r.getLeft() );
		setLabels( r.getRight() );
	}
	
	public void reset() {
		reset( root );
	}
	
	private void reset( BSTElement r ) {
		if( r == null )
			return;
		
		reset(r.getLeft());
		reset(r.getRight());
		r.getVisualizer().setColor("blue");
		r.getVisualizer().setShape("square");	
	}
	
	public void findLoc( String search ) {
		findLoc( root, search );
	}
	
	private void findLoc( BSTElement r, String s ) {
		if( r == null )
			return;
		
		findLoc( r.getLeft(), s );
		findLoc( r.getRight(), s );
		
		if( ( (EarthquakeUSGS) r.getValue() ).getLocation().contains(s) ) {
			r.getVisualizer().setOpacity(1.0);
			r.getVisualizer().setSize(30);
			r.getVisualizer().setColor("purple");
		} else {
			r.getVisualizer().setOpacity(0.1);
			r.getVisualizer().setColor("yellow");
		}
	}
	
	public void highlightRange( Double low, Double high ) {
		highlightRange( root, low, high );
	}
	
	private void highlightRange( BSTElement r, Double low, Double high ) {
		if( r == null )
			return;
		Double m = ((EarthquakeUSGS) r.getValue()).getMagnitude();
		if( m >= low && m <= high ) {
			r.getVisualizer().setColor("blue");
		}
		highlightRange( r.getLeft(), low, high );
		highlightRange( r.getRight(), low, high );
	}
}