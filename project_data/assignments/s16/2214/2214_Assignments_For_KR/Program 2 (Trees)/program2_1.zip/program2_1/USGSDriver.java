package program2_1;

/*
 * David Burlinson
 * 
 * Purpose: simple driver to show how to use the USGS source
 * 	USGS account - queries data from the USGS earthquake feedb
 *  
 */
import bridges.connect.Bridges;
import bridges.data_src_dependent.EarthquakeUSGS;
import bridges.data_src_dependent.Tweet;
import bridges.data_src_dependent.USGSaccount;

import java.util.List;
import java.util.Scanner;

public class USGSDriver {
	public static final int maxElements = 500; //number of tweets

	@SuppressWarnings("unchecked")
	public static void main(String[] args) throws Exception{
		String nodeColor = "";	// holds the color for each new earthquake node
		Integer nodeSize = 0; 	// holds the node size
		
    	/** Instantiate a Bridges object */
		Bridges<String, Tweet> bridges = new Bridges<String, Tweet>(....);
		
		/** Any actual user on Twitter; in this case we use the earthquake account */
		USGSaccount name = new USGSaccount( "earthquake" ); 
		
		/** Retrieve a list of (maxElements) Tweets */	
		System.out.println("\n-----Querying for " + maxElements + " Tweets-------\n");
		List<EarthquakeUSGS> eqList = Bridges.getAssociations( name, maxElements );
		
		/** A Tree to hold Tweet objects */
		earthquakeTree eqTree= new earthquakeTree();

		/** 
		 * Read each Tweet returned from Bridges
		 */
		System.out.println("-----Adding elements to the Bridges Tree-------\n");
		for ( int i = 0; i < eqList.size(); i++ ){
//		for ( int i = 0; i < 6; i++ ){
			eqTree.insert( eqList.get( i ).getMagnitude(), eqList.get( i ) );
		}

		//tmp
		eqTree.getRoot().getLinkVisualizer(eqTree.getRoot().getLeft()).setColor("red");
		eqTree.getRoot().getLinkVisualizer(eqTree.getRoot().getLeft()).setOpacity(0.1);
		eqTree.getRoot().getLinkVisualizer(eqTree.getRoot().getLeft()).setThickness(40);
		//tmp
		
		System.out.println( "-----Visualizing the tree-------\n" );
		bridges.setDataStructure( eqTree.getRoot() );
		bridges.getVisualizer().setVisualizeJSON( true );
		
		Scanner sc = new Scanner( System.in );
		String input = "";
		printMenu();
		System.out.print("enter a command: ");
		while((input = sc.next()).compareTo("exit") != 0) {
			System.out.println(input);
			
			switch(input) {
				case "1":
					System.out.print("Enter the location to search for: ");
					input = sc.next();
					eqTree.findLoc(input);
					bridges.visualize();
					break;
				case "2":
					double upper, lower;
					try {
						System.out.print("Enter the lower bound: ");
						lower = Double.valueOf(sc.next());
						System.out.print("Enter the upper bound: ");
						upper = Double.valueOf(sc.next());
						eqTree.highlightRange(lower, upper);
						bridges.visualize();
					} catch( NumberFormatException e) {
						System.err.println("ERROR " + e.getMessage());
					}
					break;
				case "3":
					eqTree.setLabels();
					bridges.visualize();
					break;
				case "4":
					eqTree.setNodeAttributes();
					bridges.visualize();
					break;
				case "5":
					eqTree.reset();
					bridges.visualize();
					break;
			}

			printMenu();
			System.out.print("enter a command: ");
		}
    }
	
	public static void printMenu() {
		System.out.println("\nOptions:");
		System.out.println("1: Search by location");
		System.out.println("2: Highlight range");
		System.out.println("3: Set Labels");
		System.out.println("4: Set Node Colors");
		System.out.println("5: Reset");
		System.out.println("exit");
	}
}
