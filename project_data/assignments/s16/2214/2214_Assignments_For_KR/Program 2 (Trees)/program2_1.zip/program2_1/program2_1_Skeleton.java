package program2_1;

import bridges.connect.Bridges;
import bridges.data_src_dependent.EarthquakeUSGS;
import bridges.data_src_dependent.USGSaccount;

import java.util.List;
import java.util.Scanner;

/*
 * David Burlinson
 * 
 * Program 2.1 Driver 
 * 	This program provides the skeleton for the driver
 * 	Comments will indicate the usage of existing code and suggest 
 * 	the structure for the students' unimplemented code
 *  
 */


public class program2_1_Skeleton {

	// number of earthquake Tweets to read. This can range from 2 to 500
	public static final int maxElements = 25;  

	public static void main( String[] args ) throws Exception{
		
    	/** Instantiate a Bridges object */
		Bridges<String, EarthquakeUSGS> bridges = new Bridges<String, EarthquakeUSGS>(0, "598257885849", "dburlins");

		/** 
		 * For this program, we are reading a sequence of Tweets from the USGS Earthquake Twitter feed.
		 * The USGSaccount object specifies the particular feed
		 * The Bridges.getAssociations method returns the Earthquake Tweets and stores them in a Java List
		 * 
		 * These lines do not need to be modified.
		 *  
		 * You can test this by writing a simple loop to print all the elements in the list
		 */
		USGSaccount name = new USGSaccount( "earthquake" ); 
		List<EarthquakeUSGS> eqList = Bridges.getAssociations( name, maxElements );
		
		for(int i = 0; i < eqList.size(); i++)
			System.out.println(eqList.get(i));
		
		/** Instantiate a Tree  
		 * 	The key should be the magnitude of the Earthquake
		 * 	The value should hold EarthquakeUSGS objects
		 * 	
		 * <Double, EarthquakeUSGS>
		 */

		
		
		/** 
		 * Read the Earthquake Tweets returned from Bridges, store them in the Tree
		 * 
		 * Once your Tree is fully built, use Briges.setDataStructure and pass in the tree root
		 *  to tell Bridges what to visualize
		 */
		
		
		
		/**
		 * Create a menu using a Scanner object (or whatever implementation you prefer)
		 * Present the menu in a loop until the program is terminated by the user
		 * Provide a list of options for the user to select corresponding to the new methods in your Tree
		 * 	(reset, min, max, setLabels, findLocation, highlightRange)
		 * 
		 * For each user-specified option, call the relevant operations on the Tree, then visualize your tree
		 */
		
	} /* end main */
}
